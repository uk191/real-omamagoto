@echo off
setlocal
set "C1_UPDATE_FILE=%~f0"
set "C1_PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" set "C1_PS=%SystemRoot%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
"%C1_PS%" -NoLogo -NoProfile -STA -Command "$raw = [IO.File]::ReadAllText($env:C1_UPDATE_FILE); $marker = '# C1_' + 'POWERSHELL_BEGIN'; $body = $raw.Substring($raw.IndexOf($marker) + $marker.Length); try { & ([ScriptBlock]::Create($body)) } catch { Write-Host $_ -ForegroundColor Red; exit 1 }"
set "C1_UPDATE_RESULT=%ERRORLEVEL%"
if not "%C1_UPDATE_RESULT%"=="0" (
 echo.
 echo Update failed. Keep the error above. The full C1 pack is also available.
 pause
)
exit /b %C1_UPDATE_RESULT%
# C1_POWERSHELL_BEGIN
$ErrorActionPreference = 'Stop'
$scriptRoot = Split-Path -Parent $env:C1_UPDATE_FILE
Add-Type -AssemblyName System.Windows.Forms
$picker = New-Object System.Windows.Forms.FolderBrowserDialog
$picker.Description = 'Select your working game folder containing PLAY.cmd, runtime and app.'
$candidate = Join-Path $env:LOCALAPPDATA 'RealOmamagoto\C01\game\C01_Play'
if (Test-Path $candidate) { $picker.SelectedPath = $candidate }
if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Cancelled. No game files were changed.'; exit 0 }
$target = $picker.SelectedPath
$manifest = Get-Content -LiteralPath (Join-Path $scriptRoot 'UPGRADE_MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($entry in $manifest.dependencies.PSObject.Properties) {
    $path = Join-Path $target $entry.Name
    if (-not (Test-Path -LiteralPath $path)) { throw "Required original file is missing: $($entry.Name). Please select the folder containing PLAY.cmd and runtime." }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw "Original file has a different version: $($entry.Name). Use the full C1 pack; no files were changed." }
}
foreach ($entry in $manifest.files.PSObject.Properties) {
    $path = Join-Path (Join-Path $scriptRoot 'payload') $entry.Name
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Value) { throw "Upgrade checksum mismatch: $($entry.Name)" }
}
# Preserve earlier C1 updates, without overwriting the working C01 or its saves.
$backup = Join-Path $target ('c1_backups\' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
foreach ($entry in $manifest.files.PSObject.Properties) {
    $dest = Join-Path $target $entry.Name
    if (Test-Path -LiteralPath $dest) {
        $saved = Join-Path $backup $entry.Name
        New-Item -ItemType Directory -Force -Path (Split-Path $saved) | Out-Null
        Copy-Item -LiteralPath $dest -Destination $saved -Force
    }
    New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
    Copy-Item -LiteralPath (Join-Path (Join-Path $scriptRoot 'payload') $entry.Name) -Destination $dest -Force
}
Write-Host 'C1 is installed. Original C01 and its saves are unchanged.'
Start-Process -FilePath (Join-Path $target 'PLAY_C1.cmd') -WorkingDirectory $target
