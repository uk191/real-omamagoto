"""Preserve original payload; create SHA256 manifest, CRC-tested atomic archives."""
from pathlib import Path
import zipfile,hashlib,json,os,shutil,ast
from common import ROOT,PROJECT,atomic_json,VERSION
from provenance import IMPLEMENTATION

def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def include(p):return p.is_file()and not any(x.startswith('.')for x in p.relative_to(PROJECT).parts)and '__pycache__'not in p.parts and not p.name.endswith('.lock')and'.writing'not in p.name and not p.name.endswith(('.pyc','-wal','-shm'))
def main():
 out=PROJECT.parent.parent/'A302_outputs';out.mkdir(exist_ok=True)
 summary=json.loads((ROOT/'validation/summary_v02.json').read_text());assert summary['completed24']==10340 and summary['implementation_sha256']==IMPLEMENTATION
 assert json.loads((ROOT/'validation/database_v02.json').read_text())['inherited_rows_unchanged']
 for p in PROJECT.rglob('*.py'):
  if include(p):ast.parse(p.read_text())
 for p in PROJECT.rglob('*.json'):
  if include(p):json.loads(p.read_text())
 manifest=PROJECT/'release_manifest_v02.json';files={str(p.relative_to(PROJECT)):sha(p)for p in sorted(PROJECT.rglob('*'))if include(p)and p!=manifest}
 atomic_json(manifest,{'version':VERSION,'implementation_sha256':IMPLEMENTATION,'formal_source_zip_sha256':'44292caad047b2260dbfc05fb9ce8cc6b4f7f4ac7c090cba3054e0a7084f04bd','files':files,'manifest_self_hash':'external ZIP digest covers this file','financially_playable':False,'newborn_full_joint_externally_validated':False})
 target=out/'A1_A3_日本家庭月次シミュレーション基盤_A3.0-0.2.zip';temp=target.with_name(target.name+'.writing')
 with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True)as z:
  for p in sorted(PROJECT.rglob('*')):
   if include(p):z.write(p,'JapanFamily/'+str(p.relative_to(PROJECT)))
 with zipfile.ZipFile(temp)as z:assert z.testzip()is None
 os.replace(temp,target);digest=sha(target);(out/'A3.0-0.2_SHA256.txt').write_text(digest+'  '+target.name+'\n')
 example=out/'A3.0-0.2_24か月履歴と意思決定比較.zip'
 with zipfile.ZipFile(example,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5)as z:
  for p in sorted((ROOT/'examples').glob('*.json')):z.write(p,p.name)
  for n in ['decision_comparisons_v02','example_summaries_v02','sensitivity_v02','low_liquidity_stress_v02']:z.write(ROOT/'validation'/(n+'.json'),'validation/'+n+'.json')
 with zipfile.ZipFile(example)as z:assert z.testzip()is None
 shutil.copy2(ROOT/'INTEGRATED_REPORT.md',out/'A1_A3_統合構築報告_A3.0-0.2.md')
 atomic_json(out/'A3.0-0.2_BUILD_RECORD.json',{'version':VERSION,'zip_sha256':digest,'zip_bytes':target.stat().st_size,'manifest_files':len(files),'zip_crc_pass':True,'saved_bytes_verification_pending':True})
 print(json.dumps({'zip':str(target),'sha256':digest,'bytes':target.stat().st_size,'files':len(files)}),flush=True)
if __name__=='__main__':main()
