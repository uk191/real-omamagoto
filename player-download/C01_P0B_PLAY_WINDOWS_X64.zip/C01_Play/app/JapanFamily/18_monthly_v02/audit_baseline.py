"""Read saved baseline records to EOF and replay its unmodified code in subprocess."""
from pathlib import Path
import zipfile,hashlib,json,gzip,subprocess,sys,collections
from common import ROOT,PROJECT,canonical,atomic_json

def main():
 inputs=PROJECT.parent.parent/'A302_inputs';zpath=inputs/'A1_A3_日本家庭月次シミュレーション基盤_A3.0-0.1.zip';checks=[]
 with zipfile.ZipFile(zpath)as z:
  assert z.testzip()is None
  for info in z.infolist():
   if info.is_dir():continue
   local=PROJECT.parent/info.filename
   if info.filename.endswith('data/region.sqlite'):continue
   actual=hashlib.file_digest(local.open('rb'),'sha256').hexdigest();expected=hashlib.sha256(z.read(info)).hexdigest();checks.append({'path':info.filename,'sha256':actual,'same':actual==expected})
 assert all(x['same']for x in checks)
 old=PROJECT/'17_monthly';pairs={};rows=0;stats=collections.Counter();example=None
 for pref in range(1,48):
  found={}
  with gzip.open(old/'validation/trials'/f'{pref:02d}.jsonl.gz','rt',encoding='utf-8')as f:
   for line in f:
    row=json.loads(line);rows+=1
    if row['elapsed']in [18,24]:found.setdefault(row['seed'],{})[row['elapsed']]=row['values']['gross_month']
  for seed,d in found.items():assert len(d)==2;stats['households']+=1;stats['income18_exactly24']+=int(d[18]==d[24])
 r=json.loads((old/'examples/comparison_no_parental_leave.json').read_text());code="""import sys,json;from engine import Engine;from common import digest;r=json.load(open(sys.argv[1]));f=r['final'];e=Engine();s=e.initialize(f['household']['prefecture_code'],seed=f['seed'],birth_date=f['birth_date'],initial_family=f['initial_family'],include_region=False);s['config'].update(r['scenario_changes']);out=e.run(s,actions_by_month=r['actions']);print(json.dumps({'same':digest(out)==digest(f),'actions':r['actions'],'mother_work':[x['parents'].get('mother',{}).get('actual_weekly_hours')for x in out['monthly_history']],'care_app':out['care']['application'],'care_status':out['care']['status']}))"""
 replay=json.loads(subprocess.check_output([sys.executable,'-c',code,str(old/'examples/comparison_no_parental_leave.json')],cwd=old,text=True));assert replay['same']
 national=json.loads((inputs/'A3_全国月次検証結果.json').read_text());links={}
 for name in ['summary','month_distributions','external_comparisons','decision_comparisons']:
  p=old/'validation'/(name+'.json')
  if p.exists()and name in national:links[name]=json.loads(p.read_text())==national[name]
 report=(inputs/'A1_A3_統合構築報告_A3.0-0.1.md').read_bytes();links['report_bytes']=report==(old/'INTEGRATED_REPORT.md').read_bytes()
 out={'formal_zip_sha256':hashlib.file_digest(zpath.open('rb'),'sha256').hexdigest(),'formal_zip_crc_pass':True,'source_payload_checks':checks,'source_nonDB_files_unchanged':all(x['same']for x in checks),'baseline_monthly_rows_read':rows,**stats,'no_parental_leave_exact_saved_replay':replay,'formal_report_links':links,'causes':{'income_fixation':'baseline job hazards only months2..11; common month12 return and constant nominal contracts; care retention has no new decisions','misnamed_branch':'no_parental_leave actually request_return at0, not a leave decline; baseline childcare equality at target-2 is negative, hence no application and unpaid care suppression','employment_proxy':'state!=nonemployed conflated contract retention and work/leave/zero income; historical2010 有職 itself includes育休, definition correction alone does not remove cohort differences'}}
 atomic_json(ROOT/'validation/baseline_audit.json',out);print(canonical({k:v for k,v in out.items()if k!='source_payload_checks'}),flush=True)
if __name__=='__main__':main()
