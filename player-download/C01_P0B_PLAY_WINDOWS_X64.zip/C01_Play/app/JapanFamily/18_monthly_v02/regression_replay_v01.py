"""Replay47 saved v01 paths without writing into its preserved directories."""
from pathlib import Path
import sys,json,gzip
HERE=Path(__file__).resolve().parent;OLD=HERE.parent/'17_monthly';sys.path.insert(0,str(OLD))
from engine import Engine
from common import canonical

def main():
 e=Engine();tests=[];total=0
 for pref in range(1,48):
  seed=f'A3-validation/{pref:02d}/0';sample=[]
  with gzip.open(OLD/'validation/trials'/f'{pref:02d}.jsonl.gz','rt',encoding='utf-8')as f:
   for line in f:
    r=json.loads(line);total+=1
    if r['seed']==seed:sample.append(r)
  st=e.initialize(f'{pref:02d}',seed=seed,include_region=False)
  for expected in sample:
   st=e.step(st,retain_journal=False);m=st['last_month'];mother=m['parents'].get('mother');vals={'gross_month':m['actual_earned_gross'],'cash':st['accounts']['cash'],'net_worth':m['ledger']['net_worth_close'],'past_due_payables':m['ledger']['unpaid_due'],'care_enrolled':int(m['care']['status']=='enrolled'),'mother_employed_proxy':int(mother is not None and mother['state']!='nonemployed')};assert all(expected['values'][k]==v for k,v in vals.items())
  assert len(sample)==24;tests.append({'prefecture':pref,'months_replayed':24,'same':True})
 result={'baseline_records_read':total,'replayed_households':47,'replayed_periods':47*24,'all_same':True,'tests':tests,'source_version':'A3.0-0.1','original_code_modified':False};(HERE/'validation/regression_replay_v01.json').write_text(canonical(result));print('old monthly replay',47*24)
if __name__=='__main__':main()
