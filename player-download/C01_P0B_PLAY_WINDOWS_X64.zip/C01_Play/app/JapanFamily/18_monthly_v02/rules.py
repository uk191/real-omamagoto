"""Verified functions given inputs, with explicit transport outside rule windows."""
import json,sys,bisect,math,calendar
from decimal import Decimal,ROUND_HALF_UP,ROUND_FLOOR
from datetime import date,timedelta
from functools import lru_cache
from common import ROOT,PROJECT,age_months,month_index
sys.path.insert(0,str(PROJECT/'15_initial_state'))
import policy as old_policy
from municipal import resident_tax_2026_kashiwa,salary_income_2025_resident,nhi_2026_kashiwa
K=json.loads((ROOT/'data/kernels.json').read_text());OLD=json.loads((PROJECT/'15_initial_state/data/state_kernels.json').read_text())
def rule_status(d,domain):
    ends={'leave':date(2027,7,31),'insurance':date(2027,2,28),'municipal':date(2027,3,31),'pension':date(2027,3,31)}
    start=date(2026,8,1) if domain=='leave' else date(2026,4,1)
    return 'verified_snapshot_given_eligibility' if start<=d<=ends.get(domain,date(2026,12,31)) else 'frozen_or_backcast_snapshot_scenario'
def overlap(a,z,start,end):return max(0,(min(z,end)-max(a,start)).days+1)
def leave_amount(daily,days,previous_days=0,support_days=0):
    # Insurance benefit units are30-day units, not arbitrary31-day monthly caps.
    wage=max(3203,min(16540,daily));before=min(days,max(0,180-previous_days));after=days-before
    return math.floor(wage*(.67*before+.50*after)),math.floor(wage*.13*support_days)
def short_amount(normal,paid):
    if normal<=0 or paid<=0 or paid>=normal:return 0
    rate=paid/normal
    x=(Decimal(paid)*100/Decimal(normal)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
    y=Decimal(10)if x<=90 else(Decimal(9000)/x-90).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
    raw=Decimal(paid)*max(Decimal(0),y)/100
    value=math.floor(min(raw,max(0,484121-paid)))
    return 0 if value<=2562 else value
@lru_cache(maxsize=10000)
def insurance(pref,normal,age,salary,exempt):
    grade=standard_monthly(normal)
    def half(rate):return math.floor(grade*rate/2+.499999999)
    health=0 if exempt else half(float(OLD['health_rates'][pref]));care=0 if exempt or not 40<=age<65 else half(.0162);support=0 if exempt else half(.0023);pension=0 if exempt or age>=70 else math.floor(min(650000,max(88000,grade))*.183/2)
    unemployment=math.floor(salary*.005)
    return {'health':health,'care':care,'child_support':support,'pension':pension,'employment_insurance':unemployment,'total':health+care+support+pension+unemployment}
def standard_monthly(normal):return OLD['standard_health_bands'][bisect.bisect_right(OLD['standard_health_thresholds'],normal)]
def annual_tax(gross,social,year,other=0):
    if year<=2027:return old_policy.annual_income_tax(int(gross),int(social),int(other),year=2026)['income_and_reconstruction_tax']
    # Published2028 lower-income deduction change; table rounding below2.2m remains approximate.
    income=max(0,int(gross)-max(690000,int(gross*.3+80000))) if gross<2200000 else old_policy.salary_income(int(gross),2026)
    income+=int(other);basic=990000 if income<=1320000 else next((v for top,v in [(23500000,620000),(24000000,480000),(24500000,320000),(25000000,160000)]if income<=top),0)
    taxable=max(0,income-social-basic)//1000*1000
    top,rate,offset=next(x for x in [(1950000,.05,0),(3300000,.1,97500),(6950000,.2,427500),(9000000,.23,636000),(18000000,.33,1536000),(40000000,.4,2796000),(float('inf'),.45,4796000)]if taxable<x[0])
    return max(0,math.floor((taxable*rate-offset)*1.021)//100*100)
def pension_amount(who,age,birth,d,approved=True):
    if not 20<=age<60:return 0
    birth_month=month_index(birth);current=month_index(d)
    postpartum=who=='mother' and birth_month-1<=current<=birth_month+2 and approved
    # Mother nine months following the four-month postpartum exemption can extend into birthday month.
    raising=(current<=birth_month+11 if who!='mother' else current<=birth_month+11) and current>=birth_month
    if postpartum or (d>=date(2026,10,1)and raising and approved):return 0
    return 17510 if d<date(2026,4,1)else 17920
def child_amount(persons,month,birth):
    eligible=[]
    for p in persons:
        dob=p.get('date_of_birth')
        if not dob or p.get('alive')is False or not p.get('supported',p.get('co_resident')):continue
        b=date.fromisoformat(dob);a=age_months(dob,month)
        if a is None or a<0 or a>=23*12:continue
        if p['person_id']in ['mother','father'] or p.get('role')in ['co_resident_grandparent']:continue
        eligible.append((b,p,a))
    eligible.sort(key=lambda x:x[0]);total=0
    for rank,(b,p,a) in enumerate(eligible,1):
        fiscal_end=date(b.year+19 if b.month>=4 else b.year+18,3,31)
        if month>fiscal_end or month<=b.replace(day=1):continue
        total+=30000 if rank>=3 else 15000 if a<36 else 10000
    return total
def municipal_tax(gross,social,dependents=0,business=False):
    income=int(gross)if business else salary_income_2025_resident(int(gross))
    return resident_tax_2026_kashiwa(max(0,income),int(social),dependent_person_count=dependents)
def fee(city,city_levy,rank,non_taxable=False,single=False):
    if non_taxable:amount=0
    else:
        amount=next(v for lo,v in reversed(K['kashiwa_fees'])if city_levy>=lo)
        if rank>=3:amount=0
        elif rank==2:amount=amount//20*10
        if single and city_levy<77101:amount=0 if rank>=2 else min(9000,amount//20*10)
    return {'amount':amount,'authority':'12217','actual_city':city,'scope':'Kashiwa2026_given_tax_inputs' if city=='12217' else 'unsupported_local_rule_using_explicit_Kashiwa_benchmark','income_basis':'September switch to current assessment year; otherwise prior assessment year'}
