import json,gzip
from common import ROOT,atomic_json,digest
from provenance import IMPLEMENTATION
from engine import Engine

def main():
 e=Engine();rows=[]
 for pref in range(1,48):
  code=f'{pref:02d}';meta=json.loads((ROOT/'validation/trials_v02'/(code+'.json')).read_text());assert meta['implementation_sha256']==IMPLEMENTATION
  initial=meta['initials'][0];st=e.initialize(code,seed=initial['seed'],birth_date=initial['birth_date'],include_region=False);assert st['initial_family_hash']==initial['initial_family_hash'];full=e.run(st,24,retain_journal=False);assert digest(full)==initial['final_state_hash'];rows.append({'prefecture':code,'initial_family_hash':st['initial_family_hash'],'final24_sha256':digest(full),'same':True})
 atomic_json(ROOT/'validation/replay_v02.json',{'implementation_sha256':IMPLEMENTATION,'same_seed_47_paths':rows,'households':47,'months':1128,'all_exact':True});print('v02 replay47 passed')
if __name__=='__main__':main()
