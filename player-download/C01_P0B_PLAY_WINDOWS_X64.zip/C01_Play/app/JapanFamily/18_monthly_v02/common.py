from pathlib import Path
from datetime import date
import hashlib,json,random,calendar,os
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent;VERSION='A3.0-0.2'
RNG_NAMESPACE='A3.0-0.1'
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canonical(x).encode()).hexdigest()
def random_key(seed,month,domain,person=''):
    return random.Random(int(hashlib.sha256(canonical([RNG_NAMESPACE,seed,month,domain,person]).encode()).hexdigest(),16))
def add_month(d,n):
    y,m=divmod(d.year*12+d.month-1+n,12);return date(y,m+1,min(d.day,calendar.monthrange(y,m+1)[1]))
def month_first(d):return d.replace(day=1)
def month_index(d):return d.year*12+d.month-1
def age_months(birth,asof):
    if birth is None:return None
    b=date.fromisoformat(birth);return (asof.year-b.year)*12+asof.month-b.month-int(asof.day<b.day)
def atomic_json(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.writing')
    with tmp.open('w')as f:f.write(canonical(value));f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
