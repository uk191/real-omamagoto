import hashlib
from common import ROOT,digest
FILES=['common.py', 'engine.py', 'rules.py', 'environment.py', 'time_budget.py', 'ledger.py', 'realism.py', 'cash_rules.py', 'data/kernels.json', 'data/conditional_budget.json', 'data/employment_conditionals.json']
IMPLEMENTATION=digest({name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest()for name in FILES})
