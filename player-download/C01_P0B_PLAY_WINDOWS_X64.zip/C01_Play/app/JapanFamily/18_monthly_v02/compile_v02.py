import json,sys,unicodedata,re
from pathlib import Path
import openpyxl,fitz
R=Path(__file__).resolve().parent;P=R.parent
sys.path.insert(0,str(P/'13_family'));from tables import interval
CATS=['210101','210103','210104','210105','210106','210107','210108','210109','210110','21010202']
def main():
 w=openpyxl.load_workbook(R/'raw/finance_1-30-1.xlsx',read_only=True,data_only=True);s=w.worksheets[0];g={};headers={};labels={}
 for rn,row in enumerate(s.values,1):
  if rn==6:headers={j:str(v).split('_',1)[0]for j,v in enumerate(row)if j>=10 and v};labels={headers[j]:str(row[j])for j in headers}
  if rn<8 or row[1]!='00000_全国'or row[3]!='0_全世帯':continue
  ic=str(row[5]).split('_')[0];code=str(row[8]).split('_')[0];measure=row[6]
  if not ic.isdigit()or int(ic)>43:continue
  field={'集計世帯数（概数）':'sample_count','世帯数分布':'weight'}.get(measure,code if code in CATS else None)
  if field is None:continue
  for j,fam in headers.items():
   v=row[j];x=g.setdefault(fam+'|'+ic,{'family':fam,'income':ic,'interval':interval(unicodedata.normalize('NFKC',str(row[5])),10000),'values':{},'cells':{}});x['values'][field]=v if isinstance(v,(int,float))else None;x['cells'][field]=[s.title,rn,j+1,str(v)]
 w.close();details={};w=openpyxl.load_workbook(P/'13_family/raw/finance_1-10.xlsx',read_only=True,data_only=True);s=w.worksheets[0]
 for rn,row in enumerate(s.values,1):
  if rn==6:headers={j:str(v).split('_',1)[0]for j,v in enumerate(row)if j>=8 and v}
  if rn<8 or row[1]!='00000_全国'or row[3]!='0_全世帯':continue
  code=str(row[6]).split('_')[0]
  if code not in ['210110015009','210110','210107010003','210107010006','210107']:continue
  for j,fam in headers.items():details.setdefault(fam,{})[code]=row[j]if isinstance(row[j],(int,float))else None
 w.close();(R/'data/conditional_budget.json').write_text(json.dumps({'groups':g,'labels':labels,'embedded':details,'observation':'2024Oct/Nov','publication_date':'2025-12-19'},ensure_ascii=False,separators=(',',':')))
 # Parse corrected industry-specific columns from the actual complete PDF.
 def rows(page,n):
  out={}
  for line in page.get_text(sort=True).splitlines():
   line=unicodedata.normalize('NFKC',line);m=re.search(r'\*?\s*100\.0',line)
   if not m:continue
   name=line[:m.start()].strip().replace(' ','');tokens=re.findall(r'\d+\.\d+|(?<!\S)-(?!\S)',line[m.start():])
   if name and not any(c.isdigit()for c in name)and len(tokens)==n:out[name]={'values':[float(t)if t!='-'else 0 for t in tokens],'small_sample':'*'in line,'source_line':line}
  return out
 with fitz.open(P/'17_monthly/raw/employment_2025.pdf')as doc:take=rows(doc[104],7);end=rows(doc[107],9)
 assert take['総数']['values'][1]==88.3 and take['鉱業、採石業、砂利採取業']['values'][3]==59.4
 (R/'data/employment_conditionals.json').write_text(json.dumps({'uptake':take,'ending':end,'source':'17_monthly/raw/employment_2025.pdf pp105,108','selection':'private establishments>=5;2023/24 births uptake;2024FY scheduled leave endings; not unconditional monthly hazards','old_mining_parse_error':'legacy female .594,male .048 misaligned; corrected100%,59.4% small-sample flagged'},ensure_ascii=False,indent=2))
 print('budget groups',len(g),'industry rows',len(take),len(end))
if __name__=='__main__':main()
