"""Deterministic weekly feasible schedule; parallel supervision is explicit."""
def allocate(parents,care_hours=0,relative_hours=0):
    # Child awake07-19; sleeping child supervised at home by a sleeping adult.
    awake=set(d*24+h for d in range(7)for h in range(7,23))
    need=set(d*24+h for d in range(7)for h in range(7,19))
    nursery=set(d*24+h for d in range(5)for h in range(8,min(19,8+int(care_hours/5))));need-=nursery
    relative=set(sorted(need)[:int(relative_hours)]);need-=relative
    planned={};actual={};commute={};care={p:0 for p in parents};suppressed={p:0 for p in parents}
    for p,x in parents.items():
        w=max(0,min(60,x['planned_weekly_hours']));days=5;daily=int(w/days);extra=round(w-days*daily)
        planned[p]=set(d*24+h for d in range(days)for h in range(9,min(22,9+daily+int(d<extra))))
        commute[p]=set(d*24+h for d in range(days)for h in [8,min(22,9+daily+int(d<extra))])if w and x['commute_minutes_oneway']>0 else set()
        actual[p]=set(planned[p])
    for slot in sorted(need):
        available=[p for p in parents if slot in awake and slot not in actual[p]and slot not in commute[p]]
        if not available:
            # Research fallback: unpaid interruption of the lower-hour parent.
            # This is a flagged assumption, not an employer's observed permission.
            p=min(parents,key=lambda p:(-parents[p].get('previous_care',0),parents[p].get('previous_work',len(planned[p])),len(planned[p]),p));actual[p].discard(slot);commute[p].discard(slot);suppressed[p]+=1;available=[p]
        p=min(available,key=lambda p:(care[p],p));care[p]+=1
    out={}
    for p,x in parents.items():
        commute_hours=len(commute[p])*min(60,x['commute_minutes_oneway'])/60
        occupied=len(actual[p])+commute_hours;house=min(14,max(0,112-occupied-care[p]));rest=168-56-occupied-care[p]-house
        out[p]={'sleep':56,'work':len(actual[p]),'commute':commute_hours,'active_care':care[p],'housework':house,'rest':rest,'total':168,'work_suppressed_for_care':len(planned[p])-len(actual[p]),'requested_work':len(planned[p]),'kind':'conservative hourly coverage grid, actual commute minutes; sleep8h and child_awake12h; unpaid interruption unverified'}
        assert rest>=0 and sum(out[p][k]for k in ['sleep','work','commute','active_care','housework','rest'])==168
    return {'parents':out,'child_awake_need':84,'nursery':len(nursery),'relative':len(relative),'parent_care':sum(care.values()),'uncovered':0,'night_supervision':'co-resident adult present; sleep-time co-supervision, no additional awake hours','siblings':'shared supervision; extra simultaneous-care load unidentified'}
