from pathlib import Path
import urllib.request,json,hashlib,datetime,concurrent.futures,os
R=Path(__file__).resolve().parent
JOBS={'finance_1-30-1.xlsx':'https://www.e-stat.go.jp/stat-search/file-download?statInfId=000040379263&fileKind=0','kashiwa_admission_2026.pdf':'https://www.city.kashiwa.lg.jp/documents/43426/r8goannai0430.pdf','kashiwa_return.html':'https://www.city.kashiwa.lg.jp/hoikuunei/faq11.html','ota_fees.html':'https://www.city.ota.tokyo.jp/seikatsu/kodomo/hoiku/hoikuryo/ketteihouhou.html','sumida_fees.html':'https://www.city.sumida.lg.jp/kosodate_kyouiku/kosodate_site/azukeru/hoikuen/zaien/hoikuenhoikuryoukete.html','mitaka_fees.html':'https://www.city.mitaka.lg.jp/c_service/090/090852.html','NTA2026.pdf':'https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/data/18.pdf','NTA2027.pdf':'https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2027/data/18.pdf','coverage2026.html':'https://www.nenkin.go.jp/oshirase/taisetu/jigyosho/2026/202610/100104.html','coverage2027.html':'https://www.nenkin.go.jp/service/kounen/tekiyo/jigyosho/tanjikan.html','leave_extension.html':'https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000160564_00040.html','leave_qa.html':'https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000158500.html','labour_definition.html':'https://www.stat.go.jp/data/roudou/qa-1.html','maternity.html':'https://www.kyoukaikenpo.or.jp/benefit/childbirth/001/','national_care.pdf':'https://www.cfa.go.jp/assets/contents/node/basic_page/field_ref_resources/e4b817c9-5282-4ccc-b0d5-ce15d7b5018c/b9bfd72b/20260507_policies_hoiku_231.pdf'}
def fetch(it):
 n,u=it;p=R/'raw'/n;r={'source_id':'A302_'+n.replace('.','_'),'url':u,'path':'raw/'+n,'retrieved':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  if not p.exists():
   with urllib.request.urlopen(u,timeout=45)as h:b=h.read()
   p.write_bytes(b)
  b=p.read_bytes();assert len(b)>200
  if n.endswith('.pdf'):
   assert b.startswith(b'%PDF');import fitz
   with fitz.open(p)as d:p.with_suffix('.txt').write_text('\n'.join(f'PAGE {i+1}\n'+x.get_text()for i,x in enumerate(d)))
  r.update(status='acquired',bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
 except Exception as e:r.update(status='unavailable',error=repr(e))
 return r
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=6)as p:r=list(p.map(fetch,JOBS.items()))
 (R/'data/sources_v02.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print([(x['source_id'],x['status'])for x in r])
