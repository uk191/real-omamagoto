"""Atomic additive SQLite migration; inherited table rows are immutable."""
import sqlite3,json,gzip,hashlib,shutil,os
from pathlib import Path
from common import ROOT,PROJECT,atomic_json,canonical,VERSION
from provenance import IMPLEMENTATION
DB=PROJECT/'data/region.sqlite'
def fingerprint(path,names=None):
 c=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);tables=names or[x[0]for x in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")];out={}
 for name in tables:
  h=hashlib.sha256();count=0
  try:rows=c.execute('SELECT * FROM "'+name+'" ORDER BY rowid')
  except sqlite3.OperationalError:rows=c.execute('SELECT * FROM "'+name+'" ORDER BY '+','.join(str(i+1)for i in range(len(c.execute('PRAGMA table_info("'+name+'")').fetchall()))))
  for row in rows:h.update((json.dumps(row,ensure_ascii=False,separators=(',',':'),default=lambda v:v.hex())+'\n').encode());count+=1
  out[name]={'rows':count,'sha256':h.hexdigest()}
 c.close();return out

def main():
 beforefile=ROOT/'validation/inherited_tables_before.json'
 if not beforefile.exists():atomic_json(beforefile,fingerprint(DB))
 before=json.loads(beforefile.read_text());assert len(before)==55
 temp=DB.with_suffix('.v02.writing');shutil.copy2(DB,temp);c=sqlite3.connect(temp);c.execute('PRAGMA foreign_keys=ON')
 c.executescript('''
 CREATE TABLE IF NOT EXISTS monthly_v02_model(version TEXT PRIMARY KEY,implementation_sha256 TEXT,financially_playable INTEGER CHECK(financially_playable=0),full_joint_validated INTEGER CHECK(full_joint_validated=0),description TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_source(source_id TEXT PRIMARY KEY,metadata_json TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_variable(variable TEXT PRIMARY KEY,metadata_json TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_backlog(id TEXT PRIMARY KEY,priority TEXT,metadata_json TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_run(run_id TEXT PRIMARY KEY,version TEXT REFERENCES monthly_v02_model(version),metadata_json TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_household(seed TEXT PRIMARY KEY,run_id TEXT REFERENCES monthly_v02_run(run_id),prefecture_code TEXT,metadata_json TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_state(seed TEXT REFERENCES monthly_v02_household(seed),elapsed INTEGER CHECK(elapsed BETWEEN 1 AND 240),month TEXT,state_json TEXT,PRIMARY KEY(seed,elapsed));
 CREATE TABLE IF NOT EXISTS monthly_v02_validation(name TEXT PRIMARY KEY,metadata_json TEXT);
 CREATE TABLE IF NOT EXISTS monthly_v02_example(name TEXT PRIMARY KEY,version TEXT REFERENCES monthly_v02_model(version),state_json TEXT);
 ''')
 # Rebuilding only this version's additive tables is idempotent; never DROP inherited tables.
 for t in ['state','household','run','example','model','source','variable','backlog','validation']:c.execute('DELETE FROM monthly_v02_'+t)
 c.execute('INSERT INTO monthly_v02_model VALUES(?,?,?,?,?)',(VERSION,IMPLEMENTATION,0,0,'24-month source-bounded research simulation; statistical path validity remains unresolved'))
 for filename,table,key in [('source_registry_v02','source','source_id'),('variable_registry_v02','variable','variable')]:
  for row in json.loads((ROOT/'data'/(filename+'.json')).read_text()):c.execute('INSERT INTO monthly_v02_'+table+' VALUES(?,?)',(row[key],canonical(row)))
 for row in json.loads((ROOT/'data/backlog_v02.json').read_text()):c.execute('INSERT INTO monthly_v02_backlog VALUES(?,?,?)',(row['id'],row['priority'],canonical(row)))
 summary=json.loads((ROOT/'validation/summary_v02.json').read_text());assert summary['implementation_sha256']==IMPLEMENTATION and summary['completed24']==10340
 c.execute('INSERT INTO monthly_v02_run VALUES(?,?,?)',('nationwide_v02',VERSION,canonical(summary)))
 for row in json.loads((ROOT/'validation/initials_v02.json').read_text()):c.execute('INSERT INTO monthly_v02_household VALUES(?,?,?,?)',(row['seed'],'nationwide_v02',row['prefecture'],canonical(row)))
 count=0
 for p in sorted((ROOT/'validation/trials_v02').glob('*.jsonl.gz')):
  with gzip.open(p,'rt',encoding='utf-8')as f:
   batch=[]
   for line in f:
    row=json.loads(line);batch.append((row['seed'],row['elapsed'],row['month'],line.strip()));count+=1
    if len(batch)>=1000:c.executemany('INSERT INTO monthly_v02_state VALUES(?,?,?,?)',batch);batch=[]
   if batch:c.executemany('INSERT INTO monthly_v02_state VALUES(?,?,?,?)',batch)
 for p in sorted((ROOT/'validation').glob('*.json')):c.execute('INSERT INTO monthly_v02_validation VALUES(?,?)',(p.stem,p.read_text()))
 for p in sorted((ROOT/'examples').glob('*.json')):c.execute('INSERT INTO monthly_v02_example VALUES(?,?,?)',(p.stem,VERSION,p.read_text()))
 c.commit();assert count==248160;integrity=c.execute('PRAGMA integrity_check').fetchall();fk=c.execute('PRAGMA foreign_key_check').fetchall();assert integrity==[('ok',)]and not fk;c.close()
 after=fingerprint(temp,list(before));assert after==before
 with temp.open('rb')as f:os.fsync(f.fileno())
 os.replace(temp,DB)
 atomic_json(ROOT/'validation/database_v02.json',{'original_DB_sha256':'9d0d1080196716015b285a9025346af491d4da11dd5ae76a01b43039479e6bb9','updated_DB_sha256':hashlib.file_digest(DB.open('rb'),'sha256').hexdigest(),'inherited_tables_checked':55,'inherited_rows_unchanged':True,'before':before,'after':after,'new_monthly_rows':count,'integrity_check':integrity,'foreign_key_check':fk,'new_tables':9,'migration':'copy+transaction+integrity+old-row-fingerprint+atomic replace'})
 print('DB installed',count,flush=True)
if __name__=='__main__':
 if '--fingerprint-only'in __import__('sys').argv:atomic_json(ROOT/'validation/inherited_tables_before.json',fingerprint(DB));print('55-table baseline fingerprint saved')
 else:main()
