"""A3 monthly research engine composed over unchanged A2.5.

Actions are requests. Outcomes, approvals, accruals, receipts and payments have
separate records. No future one-year employment label causes a past resignation.
"""
import sys,json,copy,math,calendar
from pathlib import Path
from datetime import date,timedelta
from common import ROOT,PROJECT,VERSION,canonical,digest,random_key,add_month,month_first,month_index,age_months
sys.path.insert(0,str(PROJECT/'16_recovery'))
from model import Model as A25,DEFAULT as A25_DEFAULT
import rules
from rules import K,OLD
from ledger import Ledger,worth
from time_budget import allocate
from environment import Environment
import realism,cash_rules
class DecisionError(ValueError):pass
class Engine:
    def __init__(self):self.generator=A25();self.environment=Environment()
    def initialize(self,prefecture_code='13',conditions=None,seed=0,birth_date='2026-10-01',scenario=None,include_region=True,initial_family=None):
        if not isinstance(seed,(str,int))or isinstance(seed,bool):raise DecisionError('Integer/string seed required')
        birth=date.fromisoformat(birth_date)
        if birth.year!=2026:raise DecisionError('Initial cohort must be born in2026')
        cfg={**K['unobserved_scenario_defaults'],**(scenario or{})}
        cfg.setdefault('employment_transition_mode','leave_end_conditional');cfg.setdefault('exit_hazard_scale',1.)
        allowed=set(K['unobserved_scenario_defaults'])|{'macro_scenario','initial_cash_override','extension_evidence','father_leave_days','environment_path','employment_transition_mode','exit_hazard_scale'}
        if set(cfg)-allowed:raise DecisionError('Unknown scenario keys')
        for key in ['relative_available_probability','job_search_probability','hours_request_acceptance','bonus_share']:
            if not isinstance(cfg[key],(int,float))or not math.isfinite(cfg[key])or not 0<=cfg[key]<=1:raise DecisionError(key)
        for key in ['benefit_approval_lag','benefit_payment_lag','payroll_lag','care_processing_months','return_month','return_spread_months']:
            if not isinstance(cfg[key],int)or isinstance(cfg[key],bool)or cfg[key]<0:raise DecisionError(key)
        for key in ['spending_factor','budget_cv','minimum_income_ratio_for_budget','commute_cost_per_workday','relative_hours','salary_growth_annual','borrowing_limit']:
            if not isinstance(cfg[key],(int,float))or isinstance(cfg[key],bool)or not math.isfinite(cfg[key])or cfg[key]<0:raise DecisionError(key)
        if cfg['unknown_future']not in ['freeze_last_verified','freeze_with_warning']:raise DecisionError('Unknown future policy mode')
        if cfg['return_month']>240:raise DecisionError('Return request outside horizon')
        if cfg['care_admission_probability']is not None:raise DecisionError('Unidentified admission probability removed; choose resource scenario')
        if cfg['care_access_scenario']not in ['constrained','available','unavailable']:raise DecisionError('Resource scenario')
        if cfg['return_plan_mode']not in ['duration_transport','declared_month']:raise DecisionError('Return plan mode')
        if cfg['bonus_share']!=0:raise DecisionError('Bonus payroll adapter/withholding unimplemented; no ordinary-salary tax on bonus')
        for key in ['expense_cv','protected_share_scale','leave_exit_scale','care_cutoff_april','care_cutoff_midyear']:
            if not isinstance(cfg[key],(int,float))or isinstance(cfg[key],bool)or not math.isfinite(cfg[key])or cfg[key]<0:raise DecisionError(key)
        for key in ['unknown_fee_quantile','commute_reimbursement_fraction']:
            if not isinstance(cfg[key],(int,float))or isinstance(cfg[key],bool)or not math.isfinite(cfg[key])or not 0<=cfg[key]<=1:raise DecisionError(key)
        for key in ['insurance_history_months','employer_size_proxy','filing_units']:
            if not isinstance(cfg[key],int)or isinstance(cfg[key],bool)or cfg[key]<0:raise DecisionError(key)
        if cfg['filing_units']not in [1,2]:raise DecisionError('Filing units1 or 2')
        if cfg['payroll_lag']not in [0,1]:raise DecisionError('Payroll arrears>1 month require separate adapter')
        if cfg['employment_transition_mode']not in ['leave_end_conditional','frozen']:raise DecisionError('Unknown employment transition mode')
        if not isinstance(cfg['exit_hazard_scale'],(int,float))or not math.isfinite(cfg['exit_hazard_scale'])or not 0<=cfg['exit_hazard_scale']<=3:raise DecisionError('Invalid exit-hazard sensitivity')
        if initial_family is None:
            anchor=birth_date if date(2026,8,1)<=birth<=date(2026,11,30)else'2026-10-01'
            family=self.generator.generate(prefecture_code,conditions,seed,birth_date=anchor,include_region=include_region)
            if anchor!=birth_date:
                b=self.generator.prepare_reference(prefecture_code,conditions,seed,include_region,A25_DEFAULT)
                actual=self.generator.old.generate(prefecture_code,conditions,seed,birth_date,{'roster_scenario':'backcast_under18_co_residence'},include_region,reference=b)
                for key in ['automatic_accounts','automatic_jobs_annual','maternal_phase_connection']:actual[key]=family[key]
                family=actual
        else:
            family=copy.deepcopy(initial_family)
            if family['model_version']not in ['A2.5-0.2r2','A2.5-0.1'] or family['birth_date']!=birth_date or not all(k in family for k in ['automatic_accounts','automatic_jobs_annual','maternal_phase_connection']):raise DecisionError('Initial family version/date mismatch')
        family_hash=digest(family);accounts={};unknown=[]
        for a in family['automatic_accounts']['accounts']or[]:
            balance=a['balance']
            if balance is None:unknown.append('unknown_opening_account/'+a['account_id']);balance=0
            accounts[('L:'if a['side']=='liability'else'')+a['account_id']]=int(balance)
        accounts.setdefault('cash',0)
        if 'initial_cash_override'in cfg:
            v=cfg['initial_cash_override']
            if not isinstance(v,int)or isinstance(v,bool)or v<0:raise DecisionError('Initial declared cash must be nonnegative integer')
            accounts['cash']=v;unknown.append('explicit_initial_cash_scenario')
        parents={}
        for who in ['mother','father']:
            person=next((p for p in family['persons']if p['person_id']==who),None)
            if not person or not person['co_resident']or person.get('alive')is False:continue
            e=family['employment'][who];ref=e.get('reference')or{};kind=ref.get('employment_type');annual=family['automatic_jobs_annual'].get(who)
            if annual is None:unknown.append('unquantified_normal_income/'+who);annual=0
            employee=kind in ['regular','nonregular','employee_other'];employed=bool(e.get('usual_employed_reference'))
            uptake=employee and employed and random_key(seed,0,'baseline_leave_request',who).random()<K['uptake_employee_2025'][who]
            nh=e.get('normal_hours');nh=nh.get('value')if isinstance(nh,dict)else nh;normal_hours=float(nh or(40 if employed else 0))
            spread=random_key(seed,0,'return_month',who).randint(0,cfg['return_spread_months'])
            parents[who]={'person_id':who,'employment_type':kind,'industry':ref.get('industry'),'normal_annual':int(annual),'normal_weekly_hours':min(60,normal_hours),'hours_ratio':1.,'return_month':cfg['return_month']+spread if who=='mother'else 1,'leave_requested':uptake,'father_leave_days':cfg.get('father_leave_days',28)if uptake and who=='father'else 0,'employee_eligible_estimate':employee and employed,'state':'maternity'if who=='mother'and employee and employed else'working'if employed else'nonemployed','leave_days_used':0,'support_days_used':0,'commute_minutes_oneway':30,'job_search':False,'gross_year':{},'social_year':{},'tax_provision_year':{},'initial_phase':'prepregnancy proxy; old future-derived quit flag not used'}
        if not parents:raise DecisionError('No co-resident adult; institutional-care model not implemented')
        parents=dict(sorted(parents.items()))
        for p in parents.values():p['benefit_eligible_estimate']=p['employee_eligible_estimate'];p['insurance_enrollment_kind']='estimated_from_reference_employment'
        for who,p in parents.items():
            spouse=parents.get('father'if who=='mother'else'mother')
            p['dependent_spouse_scenario']=bool(not p['employee_eligible_estimate']and spouse and spouse['employee_eligible_estimate']and family['household']['legal_birth_status']=='marital'and p['normal_annual']<1300000)
            p['closed_year_income']={};p['closed_year_social']={}
            p['pregnancy_employment_type_reference']=p['employment_type']
        total=sum(p['normal_annual']for p in parents.values());source_mean=sum(x['reference_mean']for x in OLD['baby_budget']if x['code']not in ['2101','210102','210108'])
        ratio=max(cfg['minimum_income_ratio_for_budget'],total/OLD['budget_income_anchor']);mu=source_mean*math.sqrt(max(1,family['household']['resident_person_count'])/3)*math.sqrt(ratio)
        cv=cfg['budget_cv'];sigma=math.sqrt(math.log1p(cv*cv));budget=round(random_key(seed,0,'persistent_consumption').lognormvariate(math.log(max(1,mu))-sigma*sigma/2,sigma))
        state={'model_version':VERSION,'seed':seed,'initial_family_hash':family_hash,'initial_family':family,'birth_date':birth_date,'month':month_first(birth).isoformat(),'elapsed_months':0,'persons':copy.deepcopy(family['persons']),'household':copy.deepcopy(family['household']),'housing':copy.deepcopy(family['housing']),'region_context':copy.deepcopy(family.get('region_context')),'parents':parents,'accounts':accounts,'loans':copy.deepcopy(family['automatic_accounts']['loans']),'claims':[],'receipts_due':[],'payments_due':[],'care':{'application':None,'status':'home','hours_weekly':0,'relative_requested':False,'relative_confirmed':False,'relative_available':random_key(seed,0,'relative_availability').random()<cfg['relative_available_probability']},'config':cfg,'base_consumption':budget,'spending_factor':cfg['spending_factor'],'journal':[],'decisions':[],'monthly_history':[],'annual_income_history':{},'scope_gaps':unknown+['employment_and_insurance_eligibility_estimated','income2022_not_revalued_as_observed2026','return_timing_and_care_allocation_scenarios','private_nursery_admission_not_identified','municipal_benchmark_not_all_local_rules','expense_distribution_not_newborn_observation','annual_tax_other_deductions_and_credits_missing','prior_year_income_proxy','unpaid_care_interruption_employer_permission_unknown'],'quality_flags':{'financially_playable':False,'newborn_full_joint_externally_validated':False,'calendar_engine_verified':False}}
        # Initial payroll receivable is a disclosed previous-month ordinary-wage premise.
        for who,p in parents.items():
            normal=round(p['normal_annual']/12*(1-cfg['bonus_share']))
            if normal and cfg['payroll_lag']:
                key='opening_payroll/'+who;state['accounts']['AR:'+key]=normal;state['receipts_due'].append({'key':key,'amount':normal,'due':cfg['payroll_lag']-1,'source':'opening prior-month payroll estimate'})
        items=family.get('automatic_periods',[{}])[0].get('expense_scenario',{}).get('items')or[]
        denom=sum(x['amount']for x in items)or source_mean
        food=sum(x['amount']for x in items if x['code']=='210101')/denom if items else 73353/source_mean
        energy=sum(x['amount']for x in items if x['code']=='210103')/denom if items else 18880/source_mean
        state['price_exposure']={'food':food,'energy':energy,'other':max(0,1-food-energy)}
        realism.initialize(state);cash_rules.initialize(state)
        return state
    def _job_offer_legacy(self,s,who,p,n,events,origin):
        person=next(x for x in s['persons']if x['person_id']==who);age=max(15,(age_months(person.get('date_of_birth'),date.fromisoformat(s['month']))or 360)//12)
        sex='2'if who=='mother'else'1';coarse=(person.get('attributes')or{}).get('education_coarse');r=random_key(s['seed'],n,'job_attributes',who)
        try:
            candidate=self.generator.base.parent(who,sex,age,True,[0,None],r,coarse=coarse);work=self.generator.base.work(s['household']['prefecture_code'],sex,candidate,r)
        except ValueError:
            events.append({'type':'job_offer_support_unidentified','person':who});return
        value=candidate['main_job_income']['value'];p['normal_annual']=int(value or 0)
        if value is None:s['scope_gaps'].append('job_offer_income_unquantified')
        nh=work.get('reference_hours')or{};hours=nh.get('value')if isinstance(nh,dict)else nh
        p.update(state='working',job_search=False,employment_type=work.get('employment_type'),industry=work.get('industry'),normal_weekly_hours=min(60,float(hours or 40)),employee_eligible_estimate=work.get('employment_type')in ['regular','nonregular','employee_other'],dependent_spouse_scenario=False,benefit_eligible_estimate=False,hire_month=n,insurance_enrollment_kind='new_job_enrollment_estimate; benefit qualifying12months unproven',job_offer_source=candidate['source'])
        events.append({'type':'job_offer_accepted','person':who,'origin':origin,'salary_source':candidate['source'],'evidence_kind':'2022 ESS conditional job attributes; timing transported/scenario'})
    def _decision(self,s,request,outcome,reason):s['decisions'].append({'month':s['month'],'request':copy.deepcopy(request),'outcome':outcome,'reason':reason})
    def _actions_legacy(self,s,actions):
        n=s['elapsed_months'];cfg=s['config'];care=s['care']
        if cfg['auto_actions']:
            if n==0:actions=[{'type':'apply_child_allowance','origin':'baseline_policy'}]+actions
            mother=s['parents'].get('mother')
            needs=lambda p:p['state']!='nonemployed' or p.get('job_search',False)
            need_care=mother and all(needs(p)for p in s['parents'].values())
            intended_return=mother['return_month']if mother and mother['leave_requested']else 2
            if need_care and n==max(0,intended_return-2)and care['application']is None:actions=[{'type':'apply_childcare','origin':'baseline_policy'}]+actions
        seen=set()
        for a in actions:
            if not isinstance(a,dict)or 'type'not in a:raise DecisionError('Action object required')
            if set(a)-{'type','person','value','origin','id'}:raise DecisionError('Actions cannot assign outcomes or override external evidence')
            typ=a['type'];who=a.get('person','mother');p=s['parents'].get(who);value=a.get('value');identifier=a.get('id')
            if identifier is not None:
                if identifier in seen or any(d['request'].get('id')==identifier for d in s['decisions']):raise DecisionError('Duplicate action id')
                seen.add(identifier)
            if typ=='apply_child_allowance':
                if any(c['kind']=='child_application'for c in s['claims']):self._decision(s,a,'unchanged','already applied');continue
                s['claims'].append({'kind':'child_application','applied_month':n,'approve_month':n+cfg['benefit_approval_lag'],'approved':False});self._decision(s,a,'submitted','eligibility and approval separated')
            elif typ=='apply_childcare':
                if not all(p['state']!='nonemployed'or p.get('job_search',False)for p in s['parents'].values()):
                    self._decision(s,a,'needs_eligibility_evidence','full-time nonworking parent without declared other statutory grounds; no automatic admission');continue
                care['application']={'submitted':n,'eligible_at':n+cfg['care_processing_months']};care['status']='pending';self._decision(s,a,'submitted','one persistent outcome per application; not repeated independent monthly draws or waitlist ratio')
            elif typ=='request_relative_support':care['relative_requested']=True;care['relative_confirmed']=care['relative_available'];self._decision(s,a,'available'if care['relative_confirmed']else'unavailable','latent support availability scenario')
            elif typ=='end_relative_support':care['relative_requested']=False;care['relative_confirmed']=False;self._decision(s,a,'accepted','request withdrawn')
            elif typ=='set_liquidity_policy':
                if value not in ['cash_only','use_term','use_securities']:raise DecisionError('Unknown liquidity policy')
                cfg['liquidate_term']=value!='cash_only';cfg['liquidate_securities']=value=='use_securities';self._decision(s,a,'accepted','asset conversion changes cash without creating income')
            elif typ=='extra_repayment':
                if not isinstance(value,int)or isinstance(value,bool)or value<0:raise DecisionError('Nonnegative integer repayment')
                s['extra_repayment_requested']=value;self._decision(s,a,'submitted','limited to cash after current obligations')
            elif typ=='set_spending':
                if not isinstance(value,(int,float))or isinstance(value,bool)or not math.isfinite(value)or not 0<=value<=5:raise DecisionError('Spending ratio0..5')
                s['spending_factor']=value;self._decision(s,a,'accepted','changes prospective consumption only')
            elif typ=='request_move':
                if s['housing']['tenure']=='owner':self._decision(s,a,'needs_decision','home sale/collateral and moving contract not implemented');continue
                s['move_request']={'target':value,'review':n+1};self._decision(s,a,'pending','future rental offer; location and rent not directly assigned')
            elif typ in ['request_return','request_hours','take_leave','extend_leave','quit','job_search']:
                if not p:raise DecisionError('Unknown resident parent')
                if typ=='quit':p['state']='nonemployed';p['employee_eligible_estimate']=False;p['leave_requested']=False;self._decision(s,a,'accepted','future wages stop; existing receivables retained')
                elif typ=='job_search':p['job_search']=True;self._decision(s,a,'submitted','offer draw is separate')
                elif typ=='request_return':
                    if not isinstance(value,int)or isinstance(value,bool)or value<n or value>240:raise DecisionError('Prospective return month required')
                    p['return_month']=value;self._decision(s,a,'scheduled','subject to mandatory maternity and care constraints')
                elif typ=='request_hours':
                    if not isinstance(value,(int,float))or isinstance(value,bool)or not 0<value<=1:raise DecisionError('Hours ratio(0,1]')
                    accepted=random_key(s['seed'],n,'hours_request',who).random()<cfg['hours_request_acceptance'];self._decision(s,a,'accepted'if accepted else'denied','employer feasibility scenario; statutory eligibility not fully identified')
                    if accepted:p['hours_ratio']=value
                elif typ=='take_leave':
                    if p['employee_eligible_estimate']and n<12:
                        p['leave_requested']=True;p['return_month']=12 if who=='mother'else n+1;p['father_leave_days']=28 if who=='father'else 0
                        if who=='father':p['father_leave_start']=max(date.fromisoformat(s['month']),date.fromisoformat(s['birth_date'])).isoformat()
                        self._decision(s,a,'accepted_conditional','eligibility is employment-insurance premise')
                    else:self._decision(s,a,'unidentified_or_ineligible','not automatically entitled')
                elif typ=='extend_leave':
                    if value not in [18,24]:raise DecisionError('Extension boundary18/24')
                    if cfg.get('extension_evidence',False)and p['leave_requested']and n<=18:p['return_month']=value;self._decision(s,a,'accepted_conditional','external verified extension-evidence scenario')
                    else:self._decision(s,a,'needs_evidence','childcare denial alone is not the complete administrative extension test')
            else:raise DecisionError('Unsupported action '+str(typ))
    def _decision(self,s,request,outcome,reason):
        aid=request.get('id')or digest([s['month'],len(s['decisions']),request])[:24]
        s['decisions'].append({'action_id':aid,'model_version':VERSION,'month':s['month'],'request':copy.deepcopy(request),'requested_action':request['type'],'outcome':outcome,'reason':reason,'feasibility':{'status':outcome,'reason':reason},'counterparty_approval':'scenario or supplied eligibility evidence'if outcome in ['accepted_conditional','pending','submitted','scheduled']else None,'adopted_action':copy.deepcopy(request)if outcome in ['accepted','accepted_conditional','scheduled']else None,'direct_change':{'status':outcome},'later_outcomes_recorded_separately':True})
    def _job_offer(self,s,who,p,n,events,origin):
        proposal=copy.deepcopy(p);local=[];self._job_offer_legacy(s,who,proposal,n,local,origin)
        if not any(x['type']=='job_offer_accepted'for x in local):events+=local;return
        p['job_offer']={k:proposal[k]for k in ['normal_annual','normal_weekly_hours','employment_type','industry']};p['job_offer']['id']=digest([s['month'],who,'job_offer'])[:20];events.append({'type':'job_offer_proposed','person':who,'offer':copy.deepcopy(p['job_offer']),'scope':'ESS conditional job attributes; hiring chance a scenario; acceptance separate'})
    def _actions(self,s,actions):
        n=s['elapsed_months'];cfg=s['config'];care=s['care'];d=date.fromisoformat(s['month']);birth=date.fromisoformat(s['birth_date'])
        accepted=s.get('accepted_move')
        if accepted and n>=accepted['effective']:s['housing']['monthly_rent']['value']=accepted['rent'];[(p.update(commute_minutes_oneway=accepted['commute']))for p in s['parents'].values()];s['action_outcomes'].append({'month':s['month'],'type':'move_effective','offer_id':accepted['id']});s.pop('accepted_move')
        auto=[]
        if cfg['auto_actions']:
            if n==0:auto.append({'type':'apply_child_allowance','origin':'baseline_policy'})
            for who,p in s['parents'].items():
                if p.get('job_offer'):auto.append({'type':'accept_job_offer','person':who,'value':p['job_offer']['id'],'origin':'baseline_policy_acceptance'})
            mother=s['parents'].get('mother');returns=[a for a in actions if a['type']in ['request_return','decline_parental_leave']];target=mother['return_month']if mother and mother['leave_requested']else 2
            if returns:target=min(a.get('value',2)if a['type']=='request_return'else 2 for a in returns)
            if n>=max(0,target-cfg['care_processing_months'])and care['application']is None and realism.eligibility(s)['eligible']:auto.append({'type':'apply_childcare','value':{'desired_start':max(n+cfg['care_processing_months'],target)},'origin':'baseline_policy'})
        actions=auto+actions;old_auto=cfg['auto_actions'];cfg['auto_actions']=False;seen=set()
        try:
            for a in actions:
                if set(a)-{'type','person','value','origin','id'}:raise DecisionError('Actions cannot assign outcomes')
                typ=a.get('type');who=a.get('person','mother');p=s['parents'].get(who);v=a.get('value');aid=a.get('id')
                if aid is not None:
                    if not isinstance(aid,str)or not aid or aid in seen or any(x['request'].get('id')==aid for x in s['decisions']):raise DecisionError('Unique nonempty action id required')
                    seen.add(aid)
                if typ=='apply_childcare':
                    cert=realism.eligibility(s)
                    if not cert['eligible']:self._decision(s,a,'needs_evidence','each guardian needs employment/return/job-search evidence; other statutory grounds not inferred');continue
                    if care['status']=='enrolled':self._decision(s,a,'unchanged','already enrolled');continue
                    v=v or{}
                    if not isinstance(v,dict)or set(v)-{'desired_start','preferred_facilities'}:raise DecisionError('Childcare application fields')
                    target=v.get('desired_start',n+cfg['care_processing_months'])
                    if not isinstance(target,int)or isinstance(target,bool)or not n<=target<=240:raise DecisionError('Prospective childcare start required')
                    ready=max(target,n+cfg['care_processing_months']);target_date=add_month(month_first(birth),target)
                    if s['household']['municipality_code']=='12217'and target_date.month==4 and d>date(target_date.year-1,12,8):ready=max(ready,target+1)
                    care['application']={'id':len(care.setdefault('applications',[]))+1,'submitted':n,'eligible_at':ready,'desired_start':target,'certification':cert,'preferred_facilities':v.get('preferred_facilities',[]),'last_review':None,'deadline_scope':'Kashiwa2026 Dec8 deadline transported to later April; future calendar unverified'};care['applications'].append(copy.deepcopy(care['application']));care['status']='pending';self._decision(s,a,'submitted','certification, requested start, resource selection and enrollment separate; no measured admission probability')
                elif typ=='decline_parental_leave':
                    if not p or not p['employee_contract']:self._decision(s,a,'rejected','no employee leave contract');continue
                    p['leave_requested']=False;p['father_leave_days']=0 if who=='father'else p['father_leave_days'];p['player_return_override']=True;p['return_month']=max(n,2 if who=='mother'else n);self._decision(s,a,'accepted','parental leave declined; mandatory postpartum leave and care feasibility remain')
                elif typ=='request_return':
                    if not p or not p['contract_active']:self._decision(s,a,'rejected','no continuing job; job search required');continue
                    if not isinstance(v,int)or isinstance(v,bool)or not n<=v<=240:raise DecisionError('Prospective return month')
                    p['return_month']=max(v,month_index(birth+timedelta(days=57))-month_index(birth)if who=='mother'and p['employee_contract']else n);p['player_return_override']=True;self._decision(s,a,'scheduled','return intention recorded; mandatory maternity, care and employer arrangement constrain actual work')
                elif typ in ['accept_job_offer','reject_job_offer']:
                    offer=(p or{}).get('job_offer')
                    if not offer or offer['id']!=v:self._decision(s,a,'rejected','no matching offer');continue
                    if typ=='accept_job_offer':p.update({k:offer[k]for k in ['normal_annual','normal_weekly_hours','employment_type','industry']});p.update(contract_active=True,employee_contract=offer['employment_type']in realism.EMP,job_search=False,leave_requested=False,state='working',benefit_eligible_estimate=False)
                    p.pop('job_offer');self._decision(s,a,'accepted_conditional','job offer accepted'if typ=='accept_job_offer'else'job offer declined')
                elif typ=='accept_move_offer':
                    offer=s.get('move_offer')
                    if not offer or offer['id']!=v:self._decision(s,a,'rejected','no matching rental offer');continue
                    s['accepted_move']={**offer,'effective':n+1};s.pop('move_offer');self._decision(s,a,'accepted_conditional','same-city contract effective next month; moving costs/deposits unimplemented')
                elif typ=='extend_leave':
                    if v not in [18,24]:raise DecisionError('Extension18/24')
                    boundary=12 if v==18 else 18
                    if not p or not p['leave_requested']or not boundary-2<=n<=boundary or care['status']=='enrolled'or(v==24 and p.get('extension_to',12)<18):self._decision(s,a,'rejected','stage/timing or enrolled care incompatible');continue
                    if cfg.get('extension_evidence')is True:p['extension_to']=v;p['return_month']=v;self._decision(s,a,'accepted_conditional','explicit assumed-complete external evidence SCENARIO; not actual administrative verification')
                    else:self._decision(s,a,'needs_evidence','2025 prompt-return certification/application copy/denial needed; denial alone insufficient')
                elif typ=='take_leave'and p and p['leave_requested']and n<p['return_month']:self._decision(s,a,'unchanged','existing leave start cannot be rewritten')
                elif typ=='take_leave':
                    if not p or not p['employee_contract']or n>=12:self._decision(s,a,'rejected','continuing employee contract within statutory first-year window required');continue
                    p['leave_requested']=True;p['leave_start_date']=max(d,birth+timedelta(days=57)if who=='mother'else birth).isoformat();p['leave_end_evaluated']=False;p['return_month']=12 if who=='mother'else n+1;p['father_leave_days']=28 if who=='father'else 0;self._decision(s,a,'accepted_conditional','employee leave request accepted under notice/contract scenario; insurance benefit qualification separate')
                elif typ=='request_hours'and(not p or not p['contract_active']):self._decision(s,a,'rejected','no continuing work contract')
                elif typ=='request_move'and v not in [None,s['household']['municipality_code']]:self._decision(s,a,'needs_data','cross-city housing/geography/contract not implemented')
                else:
                    if typ=='set_spending'and(not isinstance(v,(int,float))or isinstance(v,bool)or not math.isfinite(v)):raise DecisionError('Finite spending ratio')
                    self._actions_legacy(s,[a])
                    if typ=='quit'and p:p.update(contract_active=False,employee_contract=False,benefit_eligible_estimate=False)
                    if typ=='take_leave'and p and p['leave_requested']:p['leave_start_date']=max(d,birth+timedelta(days=57)if who=='mother'else birth).isoformat()
                    if typ=='set_spending':s['decisions'][-1]['reason']='only discretionary category shares change; protected shares and rent contracts retained'
        finally:cfg['auto_actions']=old_auto
    def step(self,state,actions=None,retain_journal=True):
        if state['model_version']!=VERSION:raise DecisionError('Version mismatch')
        if actions is not None and(not isinstance(actions,list)or any(not isinstance(a,dict)for a in actions)):raise DecisionError('Actions list of objects required')
        if state['elapsed_months']>=240:raise DecisionError('240-month structural horizon reached')
        s=copy.deepcopy(state);n=s['elapsed_months'];d=date.fromisoformat(s['month']);end=add_month(d,1)-timedelta(days=1);birth=date.fromisoformat(s['birth_date']);cfg=s['config'];parents=dict(sorted(s['parents'].items()));s['parents']=parents;L=Ledger(s['accounts'],s['month']);events=[]
        self._actions(s,copy.deepcopy(actions or[]));env=self.environment.at(d,month_first(birth),cfg,parents,s['household'])
        for c in s['claims']:
            if not c.get('approved')and c.get('approve_month')is not None and n>=c['approve_month']:
                c['approved']=True;c['approved_month']=n;events.append({'type':'claim_approved','kind':c['kind'],'source_month':c.get('earned_month')})
                if c['kind']!='child_application':
                    if not c.get('accrued'):L.earn(c['key'],c['amount'],{'kind':c['kind'],'earned_month':c['earned_month'],'eligibility':'estimated_given_inputs'})
                    s['receipts_due'].append({'key':c['key'],'amount':c['amount'],'due':n+cfg['benefit_payment_lag'],'source':c['kind']})
        care=s['care'];realism.care_advance(s,d,end,events)
        for who,p in parents.items():
            if p['job_search']and not p.get('job_offer')and random_key(s['seed'],n,'job_offer',who).random()<cfg['job_search_probability']:self._job_offer(s,who,p,n,events,'player_job_search_scenario')
        realism.employment(s,d,end,events)
        time=allocate(parents,care['hours_weekly']if care['status']=='enrolled'else 0,cfg['relative_hours']if care['relative_confirmed']else 0)
        def schedule_expense(key,amount,lag=0,metadata=None):
            amount=max(0,int(amount));L.expense_due(key,amount,metadata);s['payments_due'].append({'key':'L:AP:'+key,'amount':amount,'due':n+lag})
        def benefit(kind,who,amount):
            if amount<=0:return
            key=f'{kind}/{who}/{n}';s['claims'].append({'kind':kind,'key':key,'person':who,'amount':int(amount),'earned_month':n,'applied_month':n,'approve_month':n+1+cfg['benefit_approval_lag'],'approved':False,'timing':'monthly filing approximation; not actual two-unit application cycle'})
        # Pay earlier receivables before calculating cash-period short-time support.
        paid_salary={who:0 for who in parents}
        for r in s['receipts_due']:cash_rules.settle(s,L,r,d,events,paid_salary)
        # NHI is a household levy, not a separate full household bill for each adult.
        nhi_members=[];nhi_who=[];assessment=(d.year if d.month>=4 else d.year-1)-1
        for who,p in parents.items():
            if not p['employee_eligible_estimate']and not p.get('dependent_spouse_scenario',False):
                person=next(x for x in s['persons']if x['person_id']==who);age=max(0,(age_months(person['date_of_birth'],d)or 360)//12)
                g=p.get('closed_year_income',{}).get(str(assessment),p['normal_annual']);income=g if p['employment_type']=='self_employed'else max(0,rules.salary_income_2025_resident(g))
                nhi_members.append({'assessed_income2025':income,'age':min(74,age),'preschool':False});nhi_who.append(who)
        if nhi_members and not any(p['employee_eligible_estimate']for p in parents.values()):
            for child in s['persons']:
                a=age_months(child.get('date_of_birth'),d)
                if child.get('co_resident')and child['person_id']not in parents and a is not None and a>=0:nhi_members.append({'assessed_income2025':0,'age':min(74,a//12),'preschool':a<72})
        nhi_each={}
        if nhi_members:
            nh=rules.nhi_2026_kashiwa(nhi_members,relief_income=sum(x['assessed_income2025']for x in nhi_members),all_income_reported=True,no_special_relief_applies=True);total_nhi=round(float(nh['annual_equivalent_before_final_rounding'])/12)
            for index,who in enumerate(nhi_who):nhi_each[who]=total_nhi//len(nhi_who)+int(index<total_nhi%len(nhi_who))
        for who,p in parents.items():
            normal=p['normal_annual']/12*(1-cfg['bonus_share'])*env['wage_factors'][who];t=time['parents'][who];factor=t['work']/p['normal_weekly_hours']if p['normal_weekly_hours']else 0
            gross=round(normal*factor)
            if d.month in [6,12]:gross+=round(p['normal_annual']*cfg['bonus_share']/2*min(1,factor))
            key=f'payroll/{who}/{n}';L.earn(key,gross,{'type':'business'if p['employment_type']=='self_employed'else'salary','usual_reference_year':2022});s['receipts_due'].append({'key':key,'amount':gross,'due':n+(0 if p['employment_type']=='self_employed'else cfg['payroll_lag']),'source':'salary_or_net_business_profit','person':who,'income_type':'net_business_profit'if p['employment_type']=='self_employed'else'salary','earned_month':s['month'],'deduction_keys':[]})
            person=next(x for x in s['persons']if x['person_id']==who);age=max(0,(age_months(person['date_of_birth'],d)or 360)//12)
            if p['employee_eligible_estimate']:
                # End-of-month leave criterion; short male leave >=14day rule is separately labelled.
                start=date.fromisoformat(p['leave_start_date']);finish=add_month(month_first(birth),p['return_month'])-timedelta(days=1)if who=='mother'else start+timedelta(days=p['father_leave_days']-1)
                exempt=(p['maternity_days']>0 and end<=birth+timedelta(days=56))or(p['parental_days']>0 and min(finish,add_month(birth,p.get('extension_to',12))-timedelta(days=1))>=end)or(month_index(start)==month_index(finish+timedelta(days=1))and p['parental_days']>=14)
                si=rules.insurance(s['household']['prefecture_code'],round(normal),age,gross,exempt);social=si['total'];schedule_expense(f'social/{who}/{n}',social,cfg['payroll_lag'],{'status':rules.rule_status(d,'insurance'),'eligibility':'hours/assumed employer size and insurance history, not verified enrollment'});s['receipts_due'][-1]['deduction_keys']=['L:AP:'+f'social/{who}/{n}']
            else:
                unemployment=math.floor(gross*.005)if p['employment_insured_estimate']else 0
                if unemployment:schedule_expense(f'EI/{who}/{n}',unemployment,cfg['payroll_lag']);s['receipts_due'][-1]['deduction_keys']=['L:AP:'+f'EI/{who}/{n}']
                dependent=p.get('dependent_spouse_scenario',False);pen=0 if dependent else rules.pension_amount(who,age,birth,d);schedule_expense(f'pension/{who}/{n}',pen,1,{'status':rules.rule_status(d,'pension'),'dependent_spouse_assumption':dependent})
                health=nhi_each.get(who,0);schedule_expense(f'NHI/{who}/{n}',health,1,{'scope':'Kashiwa household annual-equivalent shared once; actual family membership and relief unverified','dependent_spouse_assumption':dependent});social=pen+health
            year=str(d.year);p['gross_year'][year]=p['gross_year'].get(year,0)+gross;p['social_year'][year]=p['social_year'].get(year,0)+social
            assess_year=d.year if d.month>=6 else d.year-1;previous=str(assess_year-1);prior_gross=p['closed_year_income'].get(previous,p['normal_annual']);prior_soc=p['closed_year_social'].get(previous,round(prior_gross*.14));rt=rules.municipal_tax(prior_gross,prior_soc,business=p['employment_type']=='self_employed')
            schedule_expense(f'resident_tax/{who}/{n}',round(rt['annual_liability']/12),0,{'scope':'Kashiwa benchmark monthly bill/reserve scenario; actual notice,January1 address and installments unverified','income_year':assess_year-1})
            p['actual_gross_this_month']=gross;p['actual_weekly_hours']=t['work']
        for r in s['receipts_due']:cash_rules.settle(s,L,r,d,events,paid_salary)
        for who,p in parents.items():
            if p['actual_weekly_hours']>0 and p['benefit_eligible_estimate']and p['hours_ratio']<1 and n<24:benefit('shorttime',who,rules.short_amount(round(p['normal_annual']/12),paid_salary[who]))
        cash_rules.benefits(s,L,d,end,events);realism.measure(s,time,events)
        if d.month==12:
            for who,p in parents.items():
                p['closed_year_income'][str(d.year)]=p['paid_gross_year'].get(str(d.year),0);p['closed_year_social'][str(d.year)]=p['social_year'].get(str(d.year),0)+(p['prior_social_proxy']if d.year==birth.year else 0)
                if p['employment_type']=='self_employed':
                    tax=rules.annual_tax(0,p['closed_year_social'][str(d.year)],d.year,other=p['closed_year_income'][str(d.year)]);schedule_expense(f'business_income_tax/{who}/{d.year}',tax,3,{'scope':'restricted next-March filing estimate; ESS income already net of business expenses'})
                else:events.append({'type':'year_end_tax_needs_complete_deductions','person':who,'paid_gross_year':p['closed_year_income'][str(d.year)],'withholding':p['withholding_year'].get(str(d.year),0),'automatic_refund':False,'scope':'no invented refund from annualized wage provisions; complete year-end adjustment is P0 backlog'})
        child_app=next((c for c in s['claims']if c['kind']=='child_application'),None)
        if child_app:
            if child_app['approved']:
                booked=s.setdefault('child_entitlements_booked',[])
                for entitlement in range(child_app['applied_month'],n+1):
                    if entitlement in booked:continue
                    source_month=add_month(month_first(birth),entitlement);amount=rules.child_amount(s['persons'],source_month,birth);key=f'child_allowance/{entitlement}'
                    # Newborn late application starts the month after application; existing children are a separate ongoing-enrollment premise.
                    if entitlement==child_app['applied_month'] and entitlement>0:amount=max(0,amount-(30000 if s['household']['index_birth_rank_interval'][0]>=3 else 15000))
                    L.earn(key,amount,{'entitlement_month':source_month.isoformat()[:7],'recognized_after_approval':n});delay=0 if entitlement<n and d.month%2==0 else 1 if add_month(d,1).month%2==0 else 2
                    s['receipts_due'].append({'key':key,'amount':amount,'due':n+delay,'source':'child_allowance'});booked.append(entitlement)
            else:s['scope_gaps'].append('child_allowance_approval_pending_entitlement_not_booked')
        for r in s['receipts_due']:cash_rules.settle(s,L,r,d,events,paid_salary)
        # Baseline expense level persists; only category prices and decisions change it.
        price=sum(weight*env['price_factors'][key]for key,weight in s['price_exposure'].items())
        budget_detail=realism.budget_month(s,env);consumption=budget_detail['total'];schedule_expense(f'consumption/{n}',consumption)
        rent=s['housing']['monthly_rent']['value']
        if rent is None:rent=0;s['scope_gaps'].append('unknown_rent_unquantified')
        schedule_expense(f'rent/{n}',rent)
        commuting=round(sum(t['commute']/(parents[who]['commute_minutes_oneway']/30)if parents[who]['commute_minutes_oneway']else 0 for who,t in time['parents'].items())*52/12*cfg['commute_cost_per_workday']);schedule_expense(f'commute/{n}',commuting,metadata={'scope':'work travel; embedded rail/bus pass mean removed from conditional category'})
        reimbursement=round(commuting*cfg['commute_reimbursement_fraction'])
        if reimbursement:key=f'commute_reimbursement/{n}';L.earn(key,reimbursement,{'scope':'declared employer reimbursement scenario; actual employer and legal caps unverified'});s['receipts_due'].append({'key':key,'amount':reimbursement,'due':n+cfg['payroll_lag'],'source':'commute_reimbursement_scenario'})
        carefee=None
        if care['status']=='enrolled':
            basis=d.year-1 if d.month>=9 else d.year-2;citylevy=0;tax_total=0
            for p in parents.values():
                gross=p['closed_year_income'].get(str(basis),p['normal_annual']);soc=p['closed_year_social'].get(str(basis),round(gross*.14));assessed=rules.municipal_tax(gross,soc,business=p['employment_type']=='self_employed');citylevy+=assessed['city_income_levy'];tax_total+=assessed['annual_liability']
            carefee=realism.care_fee(s,d,citylevy,tax_total==0);schedule_expense(f'childcare/{n}',carefee['cash_charge'],metadata=carefee)
        if n==0:
            invoice=s['initial_family'].get('birth_invoice_estimate',{}).get('amount')
            if invoice is None:invoice=round(self.generator.fees[s['household']['prefecture_code']]['mean_basic_fee'])+12000
            schedule_expense('birth_invoice',invoice);L.earn('birth_grant',500000,{'kind':'direct_payment_approved_scenario; not cash pocket money'})
            # Direct payment offsets hospital payable, including a receivable if surplus.
            offset=min(500000,invoice);L.post('direct_payment',{'AR:birth_grant':-offset,'L:AP:birth_invoice':-offset},offset)
            if invoice<500000:s['receipts_due'].append({'key':'birth_grant','amount':500000-invoice,'due':n+cfg['benefit_payment_lag']+1,'source':'birth_grant_surplus_application_scenario'})
        for loan in s['loans']:
            key='L:'+loan['account_id'];balance=s['accounts'].get(key,0)
            if balance<=0:continue
            months=max(1,loan['remaining_months']);rate=loan['annual_rate']/12;payment=math.ceil(balance/months)if not rate else math.ceil(balance*rate/(1-(1+rate)**(-months)));interest=math.floor(balance*rate);schedule_expense(f'interest/{loan["account_id"]}/{n}',interest)
            loan['principal_due']=min(balance,max(0,payment-interest))
        due=sum(min(r['amount'],s['accounts'].get(r['key'],0))for r in s['payments_due']if n>=r['due'])+sum(l.get('principal_due',0)for l in s['loans'])
        gap=max(0,due-s['accounts']['cash'])
        if gap and cfg['liquidate_term']:gap-=L.transfer('term','cash',gap)
        if gap and cfg['liquidate_securities']:gap-=L.transfer('securities','cash',gap)
        if gap and cfg['borrowing_limit']>s['accounts'].get('L:emergency_credit',0):
            draw=min(gap,cfg['borrowing_limit']-s['accounts'].get('L:emergency_credit',0));L.post('authorized_borrow',{'cash':draw,'L:emergency_credit':draw},draw,{'kind':'explicit_credit_scenario; lender decision not modeled'})
        for r in s['payments_due']:
            if n>=r['due']:L.pay(r['key'],r['amount'])
        for loan in s['loans']:
            paid=L.pay('L:'+loan['account_id'],loan.get('principal_due',0));loan['remaining_months']=max(1,loan['remaining_months']-1)
            if paid<loan.get('principal_due',0):events.append({'type':'loan_arrears','account':loan['account_id'],'unpaid':loan['principal_due']-paid,'scope':'no automatic bankruptcy; delinquency fees not identified'})
        extra=s.pop('extra_repayment_requested',0)
        if extra:
            key='L:mortgage'if s['accounts'].get('L:mortgage',0)>0 else'L:other_debt';paid=L.pay(key,extra);events.append({'type':'extra_repayment','requested':extra,'paid':paid})
        # Move request obtains an offer probabilistically; it never directly assigns a selected result.
        move=s.get('move_request')
        if move and n>=move['review']:
            if random_key(s['seed'],n,'rental_offer').random()<.5:
                # Within-city rental contract scenario; geographic migration remains a decision gate.
                if move['target']not in [None,s['household']['municipality_code']]:events.append({'type':'move_needs_geography_data','requested_city':move['target']})
                else:
                    s['move_offer']={'rent':round(max(0,rent)*.9),'commute':20,'id':digest([s['month'],'move_offer'])[:20]};events.append({'type':'within_city_rental_offer','offer':copy.deepcopy(s['move_offer']),'requires_decision':True,'scope':'hypothetical contract; acceptance separate, moving costs unidentified'})
            else:events.append({'type':'rental_offer_unavailable'})
            s.pop('move_request')
        audit=L.check();audit['payables_total']=audit['unpaid_obligations'];audit['unpaid_due']=sum(min(r['amount'],s['accounts'].get(r['key'],0))for r in s['payments_due']if n>=r['due']);audit['future_payables']=audit['payables_total']-audit['unpaid_due'];audit['unpaid_principal_due']=sum(x['unpaid']for x in events if x['type']=='loan_arrears')
        snapshot={'month':s['month'],'elapsed_months':n+1,'environment':env,'parents':copy.deepcopy(parents),'care':copy.deepcopy(care),'care_fee':carefee,'time':time,'accounts':copy.deepcopy(s['accounts']),'ledger':audit,'events':events,'consumption':consumption,'budget_detail':budget_detail,'payroll_bank_receipts':[e for e in events if e['type']=='payroll_paid'],'commuting':commuting,'commute_reimbursement':reimbursement,'model_version':VERSION,'rent':rent,'income_reference':sum(p['normal_annual']for p in parents.values()),'actual_earned_gross':sum(p['actual_gross_this_month']for p in parents.values()),'policy_status':{k:rules.rule_status(d,k)for k in ['leave','insurance','municipal','pension']},'paused_decisions':[e for e in events if e.get('requires_decision')or e['type']in ['move_needs_geography_data']]}
        shortage=audit['unpaid_due']+audit['unpaid_principal_due'];s['pending_decisions']=snapshot['paused_decisions']+([{'type':'cash_shortage','amount':shortage}]if shortage else[])
        if retain_journal:s['journal']+=L.entries;s['monthly_history'].append(snapshot)
        else:s['monthly_history']=[snapshot]
        s['elapsed_months']=n+1;s['month']=add_month(d,1).isoformat();asof=date.fromisoformat(s['month'])
        for p in s['persons']:
            a=age_months(p.get('date_of_birth'),asof);p['age_months']=a;p['age_years']=None if a is None else a//12
        s['scope_gaps']=sorted(set(s['scope_gaps']));s['last_month']=snapshot;return s
    def run(self,state,months=24,actions_by_month=None,retain_journal=True,stop_on_decision=False):
        if not isinstance(months,int)or isinstance(months,bool)or not 0<=months<=240-state['elapsed_months']:raise DecisionError('Invalid month count')
        s=copy.deepcopy(state)
        for _ in range(months):
            s=self.step(s,(actions_by_month or{}).get(str(s['elapsed_months']),[]),retain_journal)
            if stop_on_decision and s.get('pending_decisions'):break
        return s
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--pref',default='13');p.add_argument('--seed',default='demo');p.add_argument('--months',type=int,default=24);a=p.parse_args();e=Engine();print(canonical(e.run(e.initialize(a.pref,seed=a.seed),a.months)))
