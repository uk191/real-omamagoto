"""Actual 47-stratum full paths, resumable only against full core/data fingerprint."""
import gzip,json,math,time,os,sys,collections,statistics
from concurrent.futures import ProcessPoolExecutor
from common import ROOT,VERSION,canonical,atomic_json,digest
from provenance import IMPLEMENTATION
from engine import Engine
AGES=[6,12,18,24]
def describe(v):
 v=sorted(x for x in v if isinstance(x,(float,int))and math.isfinite(x));n=len(v)
 return {'n':n,'mean':statistics.mean(v)if n else None,'variance':statistics.pvariance(v)if n else None,'quantiles':{str(q):v[int((n-1)*q)]if n else None for q in [.01,.1,.25,.5,.75,.9,.99]}}
def _worker_unlocked(arg):
 pref,count=arg;code=f'{pref:02d}';folder=ROOT/'validation/trials_v02';folder.mkdir(parents=True,exist_ok=True);meta=folder/(code+'.json');path=folder/(code+'.jsonl.gz')
 if meta.exists()and path.exists():
  old=json.loads(meta.read_text())
  if old['implementation_sha256']==IMPLEMENTATION and old['requested']==count:return old
 e=Engine();t=time.time();summary=collections.Counter();errors=[];ages={str(a):collections.defaultdict(list)for a in AGES};uptake=[];conditionals=collections.defaultdict(list);paths=collections.Counter();initials=[]
 with gzip.open(str(path)+f'.writing.{os.getpid()}','wt',encoding='utf-8',compresslevel=1)as f:
  for i in range(count):
   seed=f'A3-validation/{code}/{i}';birth=f'2026-{1+(i+pref-1)%12:02d}-01'
   try:
    s=e.initialize(code,seed=seed,birth_date=birth,include_region=False);family=s['initial_family'];h=family['household'];normal=sum(p['normal_annual']for p in s['parents'].values());income='under3m'if normal<3000000 else'3to8m'if normal<8000000 else'over8m';bywho={x['person_id']:x for x in s['persons']};initial={'seed':seed,'birth_date':birth,'prefecture':code,'normal_jobs':normal,'reference_household_income':h['reference_usual_household_income']['value'],'initial_family_hash':s['initial_family_hash'],'rank':h['index_birth_rank_interval'][0],'resident_count':h['resident_person_count'],'marital':h['legal_birth_status'],'grandparent':h.get('reference_co_resident_grandparent'),'tenure':s['housing']['tenure'],'budget_family':s['budget']['family'],'budget_income_class':s['budget']['income_class'],'budget_sample_count':s['budget']['source_sample_count_rounded'],'initial_cash':s['accounts']['cash'],'mother_age':bywho.get('mother',{}).get('age_years'),'father_age':bywho.get('father',{}).get('age_years')};initials.append(initial)
    for who,p in s['parents'].items():
     if p['employee_contract']:uptake.append({'parent':who,'p':p['takeup_probability'],'draw':int(p['leave_requested']),'industry':p['takeup_industry']})
    prior={};gross18=None;streak=0;maxstreak=0;cum_short=0;changes=collections.Counter()
    for n in range(1,25):
     s=e.step(s,retain_journal=False);m=s['last_month'];a=m['ledger'];summary['household_months']+=1
     assert a['cash_identity_residual']==a['net_worth_identity_residual']==0 and min(s['accounts'].values())>=0
     assert abs(sum(m['time'][k]for k in ['nursery','relative','parent_care'])-84)<1e-8
     assert all(abs(sum(t[k]for k in ['sleep','work','commute','active_care','housework','rest'])-168)<1e-8 for t in m['time']['parents'].values())
     assert not s['quality_flags']['financially_playable']and not s['quality_flags']['newborn_full_joint_externally_validated']
     vals={'gross_month':m['actual_earned_gross'],'consumption':m['consumption'],'rent':m['rent'],'cash':s['accounts']['cash'],'term':s['accounts'].get('term',0),'securities':s['accounts'].get('securities',0),'net_worth':a['net_worth_close'],'past_due':a['unpaid_due'],'receivables':a['receivables'],'recognized_income':a['recognized_income'],'recognized_expense':a['recognized_expense'],'care_enrolled':int(m['care']['status']=='enrolled'),'care_applied':int(m['care']['application']is not None),'care_fee_actual_unknown':int(m['care_fee']is not None and m['care_fee']['amount']is None),'care_fee_cash_scenario':(m['care_fee']or{}).get('cash_charge',0),'care_work_conflict':int(any(x['type']=='care_work_conflict'for x in m['events'])),'loan_balances':sum(v for k,v in s['accounts'].items()if k in ['L:mortgage','L:other_debt']),'payroll_net_bank':sum(x['net_bank']for x in m['payroll_bank_receipts'])}
     status={}
     for who in ['mother','father']:
      p=m['parents'].get(who);em=(p or{}).get('employment_measurement',{});status[who]=em.get('status','absent')
      for key,out in [('actually_worked','actually_worked'),('contract_continues','contract_continues'),('on_maternity_leave','maternity'),('on_parental_leave','parental_leave'),('lfs_employed_proxy','lfs_proxy'),('unpaid_interruption','unpaid_interruption')]:vals[who+'_'+out]=None if not p or em.get(key)is None else int(em[key])
      vals[who+'_work_hours']=(p or{}).get('actual_weekly_hours');vals[who+'_gross']=(p or{}).get('actual_gross_this_month')
      if who in prior and status[who]!=prior[who]:changes[who+'_status_changes']+=1;paths[who+'/'+prior[who]+'->'+status[who]]+=1
     prior=status
     for x in m['events']:paths['event/'+x['type']]+=1
     short=a['unpaid_due']+a['unpaid_principal_due']>0;streak=streak+1 if short else 0;cum_short+=int(short);maxstreak=max(maxstreak,streak)
     row={'seed':seed,'prefecture':code,'birth_month':int(birth[5:7]),'month':m['month'],'elapsed':n,'age_months':n-1,'values':vals,'employment_status':status,'care_status':m['care']['status'],'event_types':[x['type']for x in m['events']],'cash_residual':a['cash_identity_residual'],'worth_residual':a['net_worth_identity_residual']};f.write(canonical(row)+'\n')
     if n in AGES:
      for k,v in vals.items():ages[str(n)][k].append(v)
      for axis,level in [('prefecture',code),('income',income),('birth_rank','first'if initial['rank']==1 else'later'),('household','single'if len(s['parents'])==1 else'two_parent'),('tenure',initial['tenure']),('birth_month',str(int(birth[5:7]))),('care_state',m['care']['status'])]+[(who+'_age','unknown'if initial[who+'_age']is None else str(initial[who+'_age']//5*5))for who in ['mother','father']]+[(who+'_jobtype',(s['parents'].get(who)or{}).get('employment_type','absent'))for who in ['mother','father']]:conditionals[str(n)+'|'+axis+'|'+str(level)].append([vals['gross_month'],vals['cash'],vals['past_due'],vals['mother_actually_worked'],vals['mother_lfs_proxy'],vals['care_enrolled']])
     if n==18:gross18=vals['gross_month']
     if n==12:summary['completed12']+=1
    summary['completed24']+=1;summary['gross18_equals24']+=int(gross18==vals['gross_month']);summary['status_changes']+=sum(changes.values());initial.update(max_shortage_streak=maxstreak,months_in_shortage=cum_short,final_state_hash=digest(s),status_changes=dict(changes))
   except Exception as ex:errors.append({'seed':seed,'error':repr(ex)});print(code,i,repr(ex),flush=True)
 os.replace(str(path)+f'.writing.{os.getpid()}',path)
 out={'version':VERSION,'implementation_sha256':IMPLEMENTATION,'prefecture':code,'requested':count,'summary':dict(summary),'errors':errors,'ages':ages,'conditionals':conditionals,'uptake':uptake,'path_counts':dict(paths),'initials':initials,'seconds':time.time()-t};out=json.loads(canonical(out));atomic_json(meta,out);print('PREF',code,out['summary'],len(errors),'sec',round(out['seconds']),flush=True);return out

def worker(arg):
 import fcntl
 folder=ROOT/'validation/trials_v02';folder.mkdir(parents=True,exist_ok=True)
 with (folder/(f'{arg[0]:02d}.lock')).open('a')as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  return _worker_unlocked(arg)

def main(count=220):
 start=time.time()
 with ProcessPoolExecutor(max_workers=2,max_tasks_per_child=1)as pool:results=list(pool.map(worker,[(p,count)for p in range(1,48)]))
 counters=collections.Counter();paths=collections.Counter();ages={str(a):collections.defaultdict(list)for a in AGES};groups=collections.defaultdict(list);initial=[];errors=[];cal=collections.defaultdict(list)
 for r in results:
  counters.update(r['summary']);paths.update(r['path_counts']);initial+=r['initials'];errors+=r['errors']
  for age,d in r['ages'].items():
   for k,v in d.items():ages[age][k]+=v
  for k,v in r['conditionals'].items():groups[k]+=v
  for x in r['uptake']:cal[x['parent']].append(x)
 calibration=[]
 for who,rows in cal.items():
  expected=sum(x['p']for x in rows);v=sum(x['p']*(1-x['p'])for x in rows);actual=sum(x['draw']for x in rows);calibration.append({'parent':who,'n_employee_contract_proxy':len(rows),'expected_count_conditional_industry':expected,'draw_count':actual,'z':(actual-expected)/math.sqrt(v)if v else None,'classification':'same-source internal random-draw calibration; industry/sample cohort transport not validated'})
 cond={key:{'n_simulated':len(rows),'precision':'insufficient simulated cell n<30'if len(rows)<30 else'monte-carlo cell; empirical sample precision separate','variables':{k:describe([r[j]for r in rows])for j,k in enumerate(['gross','cash','past_due','mother_actual_work','mother_lfs_like','care_enrolled'])}}for key,rows in groups.items()}
 summary={'version':VERSION,'implementation_sha256':IMPLEMENTATION,**dict(counters),'requested_households':47*count,'prefectures':47,'per_prefecture':count,'failures':len(errors),'internal_identity_violations':len(errors),'sampling':'equal prefecture strata, rotating12 birth months; NOT national birth weighted and NOT observed2026 monthly seasonality','source_calibration_pass':all(x['z']is None or abs(x['z'])<7 for x in calibration),'elapsed_seconds':time.time()-start,'financially_playable':False,'newborn_full_joint_externally_validated':False,'statistical_path_realism_validated':False}
 for name,data in [('summary_v02',summary),('month_distributions_v02',{a:{k:{**describe(v),'unknown_count':sum(x is None for x in v)}for k,v in vs.items()}for a,vs in ages.items()}),('conditionals_v02',cond),('source_calibration_v02',calibration),('path_counts_v02',dict(paths)),('initials_v02',initial),('failures_v02',errors)]:atomic_json(ROOT/'validation'/(name+'.json'),data)
 print(canonical(summary),flush=True);assert not errors and counters['completed24']==47*count and summary['source_calibration_pass']
if __name__=='__main__':main(int(sys.argv[1])if len(sys.argv)>1 else 220)
