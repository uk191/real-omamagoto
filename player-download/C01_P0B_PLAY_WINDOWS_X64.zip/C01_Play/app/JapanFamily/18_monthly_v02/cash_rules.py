"""Bank-net salary and calendar benefit units, conditional eligibility explicit."""
from datetime import date,timedelta
from decimal import Decimal,ROUND_CEILING,ROUND_HALF_UP
import math,calendar
from common import add_month,month_index
import rules

def withholding(a,year,n=0):
 a=max(0,int(a))
 if year<=2026:return rules.old_policy.monthly_withholding(a,n)
 deduction=57500 if a<=169444 else math.ceil(a*.3+6667)if a<=299999 else math.ceil(a*.2+36667)if a<=549999 else math.ceil(a*.1+91667)if a<=708330 else 162500
 basic=next((v for top,v in [(2120833,51667),(2162499,40000),(2204166,26667),(2245833,13334)]if a<=top),0);b=max(0,a-deduction-basic-31667*n);rate,off=next((r,o)for top,r,o in [(162500,'.05105',0),(275000,'.10210',8296),(579166,'.20420',36374),(750000,'.23483',54113),(1500000,'.33693',130688),(3333333,'.40840',237893),(float('inf'),'.45945',408061)]if b<=top)
 return max(0,int(((Decimal(b)*Decimal(rate)-off)/10).quantize(Decimal(1),rounding=ROUND_HALF_UP))*10)

def historical(p,who,earn,birth):
 z=add_month(earn,1)-timedelta(days=1);g=p['normal_annual']/12
 if not p['contract_active']:return 0
 if who=='mother'and p['employee_contract']:
  pre=birth-timedelta(days=41);days=max(0,(min(z,pre-timedelta(days=1))-earn).days+1);g*=min(1,days/calendar.monthrange(earn.year,earn.month)[1])
 return round(g)
def initialize(s):
 birth=date.fromisoformat(s['birth_date']);d=date.fromisoformat(s['month']);cfg=s['config']
 for who,p in s['parents'].items():
  yr=str(birth.year);prior=sum(historical(p,who,add_month(date(birth.year,m,1),-cfg['payroll_lag']),birth)for m in range(1,birth.month));p['paid_gross_year'][yr]=prior;p['prior_social_proxy']=round(prior*.14)
  for r in s['receipts_due']:
   if r.get('person')==who and r.get('income_type')=='salary'and r['amount']and p['employee_eligible_estimate']:
    person=next(x for x in s['persons']if x['person_id']==who);age=person.get('age_years')or 30;amount=rules.insurance(s['household']['prefecture_code'],round(p['normal_annual']/12),age,r['amount'],who=='mother'and birth-timedelta(days=41)<=d-timedelta(days=1))['total'];key='opening_social/'+who;s['accounts']['L:AP:'+key]=amount;r['deduction_keys']=['L:AP:'+key];s['payments_due'].append({'key':'L:AP:'+key,'amount':amount,'due':r['due']})
  if who=='mother'and p['employee_eligible_estimate']and p['normal_annual']>0:
   daily=rules.old_policy.maternity_allowance(rules.standard_monthly(round(p['normal_annual']/12)),1,0,True)['amount'];key='prenatal_maternity_opening';amount=daily*41;s['accounts']['AR:'+key]=amount;s['claims'].append({'kind':'maternity','key':key,'person':who,'amount':amount,'earned_month':-1,'applied_month':None,'approve_month':None,'approved':False,'accrued':True,'period':{'start':(birth-timedelta(days=41)).isoformat(),'end':(birth-timedelta(days=1)).isoformat(),'days':41,'scope':'opening estimate assuming prenatal leave and insurer qualification, not observed past receivable'}})
def settle(s,L,r,d,events,paid_salary):
 if r.get('paid')or s['elapsed_months']<r['due']:return
 amount=r['amount'];who=r.get('person');key=r['key']
 if who in s['parents']and r.get('income_type')=='salary'and amount:
  remaining=amount;ded={}
  for k in r.get('deduction_keys',[]):v=min(remaining,s['accounts'].get(k,0));ded[k]=v;remaining-=v
  social=amount-remaining;tax=min(remaining,withholding(remaining,d.year));tk='withheld/'+who+'/'+str(s['elapsed_months'])+'/'+key
  if tax:L.expense_due(tk,tax,{'scope':'official ordinary monthly electronic withholding甲0 source deductions;2028 freezes2027; final tax filing/credits incomplete'});ded['L:AP:'+tk]=tax
  net=amount-social-tax;delta={'AR:'+key:-amount,'cash':net};delta.update({k:-v for k,v in ded.items()if v});L.post('payroll_net_receipt',delta,net,{'person':who,'gross':amount,'social':social,'withholding':tax,'net_bank':net,'earned_month':r.get('earned_month'),'paid_month':s['month']})
  p=s['parents'][who];yr=str(d.year);p['paid_gross_year'][yr]=p['paid_gross_year'].get(yr,0)+amount;p['withholding_year'][yr]=p['withholding_year'].get(yr,0)+tax;paid_salary[who]+=amount;events.append({'type':'payroll_paid','person':who,'gross':amount,'social':social,'withholding':tax,'net_bank':net})
 else:
  L.collect(key,amount,{'source':r['source']});events.append({'type':'cash_received','key':key,'amount':amount})
  if who in s['parents']and r.get('income_type')=='net_business_profit':p=s['parents'][who];yr=str(d.year);p['paid_gross_year'][yr]=p['paid_gross_year'].get(yr,0)+amount
 r['paid']=True

def claim(s,L,kind,who,key,amount,period):
 if amount<=0:return
 n=s['elapsed_months'];L.earn(key,amount,{'kind':kind,'period':period,'eligibility':'assumed qualifying history and zero wages on covered days; not administratively verified'});s['claims'].append({'kind':kind,'key':key,'person':who,'amount':amount,'earned_month':n,'applied_month':None,'approve_month':None,'approved':False,'accrued':True,'period':period})
def benefits(s,L,d,end,events):
 n=s['elapsed_months'];birth=date.fromisoformat(s['birth_date']);cfg=s['config']
 for who,p in s['parents'].items():
  normal=p['normal_annual']/12
  if who=='mother'and p['maternity_days']and p['employee_eligible_estimate']and normal>0:
   amount=rules.old_policy.maternity_allowance(rules.standard_monthly(round(normal)),p['maternity_days'],0,True)['amount'];claim(s,L,'maternity',who,f'maternity/{who}/{n}',amount,{'start':max(d,birth).isoformat(),'end':min(end,birth+timedelta(days=56)).isoformat(),'days':p['maternity_days']})
  if who=='mother'and end>=birth+timedelta(days=56):
   for c in s['claims']:
    if c['kind']=='maternity'and c['applied_month']is None:c.update(applied_month=n,approve_month=n+1+cfg['benefit_approval_lag'])
  ld=p['parental_days'];start=date.fromisoformat(p['leave_start_date']);max_end=add_month(birth,p.get('extension_to',12))-timedelta(days=2)
  if ld:
   a=max(d,start);z=min(a+timedelta(days=ld-1),max_end)
   if z>=a:p['realized_leave_segments'].append({'start':a.isoformat(),'end':z.isoformat()})
  segments=p['realized_leave_segments']
  if not p['benefit_eligible_estimate']or normal<=0 or not segments:continue
  realized=max(date.fromisoformat(x['end'])for x in segments);stopped=ld==0 or realized<end;short=who=='father'and p['father_leave_days']<=28
  units=[]
  if short:
   if end>=start+timedelta(days=p['father_leave_days']-1):units=[('birth',start,realized,min(28,(realized-start).days+1))]
  else:
   for j in range(max(0,month_index(end)-month_index(start))+1):
    a=add_month(start,j);z=add_month(start,j+1)-timedelta(days=1)
    if a>realized:break
    if end<z and not stopped:continue
    covered=sum(rules.overlap(date.fromisoformat(x['start']),date.fromisoformat(x['end']),a,min(z,realized))for x in segments)
    if covered:units.append((str(j),a,min(z,realized),30 if covered==(z-a).days+1 and not(stopped and realized<=z)else min(30,covered)))
  for ident,a,z,days in units:
   token=p['leave_start_date']+'/'+ident
   if token in p['benefit_units_booked']:continue
   amount,_=rules.leave_amount(normal/30,days,p['leave_days_used']);p['leave_days_used']+=days;p['benefit_units_booked'].append(token);claim(s,L,'parental_leave',who,'unit/'+who+'/'+token,amount,{'start':a.isoformat(),'end':z.isoformat(),'benefit_days':days,'calendar_days':(z-a).days+1,'wages_on_leave_days':0,'scope':'calendar entitlement unit;2026 cap frozen outside verified interval; actual insured wage history unknown'})
  pending=[c for c in s['claims']if c.get('person')==who and c['kind']=='parental_leave'and c['applied_month']is None]
  if len(pending)>=cfg['filing_units']or stopped or short:
   for c in pending:c.update(applied_month=n,approve_month=n+1+cfg['benefit_approval_lag']);events.append({'type':'claim_submitted','kind':'parental_leave','key':c['key']})
  window=birth+timedelta(days=112 if who=='mother'else 56);own=sum(rules.overlap(date.fromisoformat(x['start']),date.fromisoformat(x['end']),birth,window)for x in segments);q=s['parents'].get('father'if who=='mother'else'mother');qdays=sum(rules.overlap(date.fromisoformat(x['start']),date.fromisoformat(x['end']),birth,birth+timedelta(days=56))for x in(q or{}).get('realized_leave_segments',[]));base_days=sum(c.get('period',{}).get('benefit_days',0)for c in s['claims']if c.get('person')==who and c['kind']=='parental_leave')
  exception=not q or not q['employee_contract']or who=='father'
  if own>=14 and base_days>=14 and(exception or qdays>=14):
   days=max(0,min(28,own)-p['support_days_used'])
   if days:
    amount=math.floor(max(3203,min(16540,normal/30))*.13*days);claim(s,L,'birth_support',who,f'birth_support/{who}/{n}',amount,{'own_days':own,'paid_days':days,'spouse_exception':exception,'source':'leave_qa Q35-Q40','expected_birth_date':'actual date assumed equal expected'});s['claims'][-1].update(applied_month=n,approve_month=n+1+cfg['benefit_approval_lag']);p['support_days_used']+=days
