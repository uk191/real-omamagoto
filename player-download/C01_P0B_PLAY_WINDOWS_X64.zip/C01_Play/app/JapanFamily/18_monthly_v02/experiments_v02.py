"""Paired initial families and keyed randomness; choices and scenario access differ."""
import json,copy,collections,time
from common import ROOT,atomic_json,digest
from engine import Engine
from validate_v02 import describe

def summarize(s):
 m=s['last_month'];return {'cash':s['accounts']['cash'],'net_worth':m['ledger']['net_worth_close'],'past_due':m['ledger']['unpaid_due'],'gross24':m['actual_earned_gross'],'consumption24':m['consumption'],'care_status':s['care']['status'],'care_fee_actual':(m['care_fee']or{}).get('amount'),'care_fee_scenario':(m['care_fee']or{}).get('cash_charge'),'cumulative_gross':sum(x['actual_earned_gross']for x in s['monthly_history']),'cumulative_recognized_income':sum(x['ledger']['recognized_income']for x in s['monthly_history']),'cumulative_expense':sum(x['ledger']['recognized_expense']for x in s['monthly_history']),'months_in_shortage':sum(x['ledger']['unpaid_due']>0 for x in s['monthly_history']),'care_conflict_months':sum(any(y['type']=='care_work_conflict'for y in x['events'])for x in s['monthly_history']),'mother_work_path':[x['parents'].get('mother',{}).get('actual_weekly_hours')for x in s['monthly_history']],'mother_status_path':[x['parents'].get('mother',{}).get('employment_measurement',{}).get('status')for x in s['monthly_history']],'father_work_path':[x['parents'].get('father',{}).get('actual_weekly_hours')for x in s['monthly_history']],'state_hash':digest(s)}
def main():
 e=Engine();(ROOT/'examples').mkdir(exist_ok=True);reports=[]
 fixtures=[('urban_first','13',{'birth_rank':1,'mother_employed':True,'father_employed':True}),('single_parent','27',{'partner_present':False,'legal_status':'nonmarital'}),('low_income','40',{'household_income_yen':2000000}),('later_birth','01',{'birth_rank':2}),('rental','12',{'tenure':'private_rental'}),('nonemployed','47',{'mother_employed':False,'father_employed':False})]
 states={}
 for j,(name,pref,c)in enumerate(fixtures):
  s=e.initialize(pref,conditions=c,seed='v02-example/'+name,birth_date=f'2026-{1+j*2:02d}-01',include_region=True)
  if name=='urban_first':
   candidate=0
   while not(s['parents']['mother']['employee_contract']and s['parents']['mother']['leave_requested']):
    candidate+=1;s=e.initialize(pref,conditions=c,seed='v02-example/'+name+'/'+str(candidate),birth_date=f'2026-{1+j*2:02d}-01',include_region=True)
  out=e.run(s,24);atomic_json(ROOT/'examples'/(name+'.json'),out);reports.append({'name':name,'conditions':c,'initial_family_hash':s['initial_family_hash'],**summarize(out)});states[name]=s
 # Use the same existing employee family in every branch; override only disclosed scenarios.
 s=states['urban_first'];branches={
 'baseline':({},{}),
 'decline_parental_leave':({}, {'0':[{'type':'decline_parental_leave','person':'mother'}]}),
 'request_early_return':({}, {'0':[{'type':'request_return','value':3}]}),
 'request_late_return':({}, {'0':[{'type':'request_return','value':12}]}),
 'care_available':({'care_access_scenario':'available'},{}),
 'care_unavailable':({'care_access_scenario':'unavailable'},{}),
 'spend_discretionary_0_8':({}, {'0':[{'type':'set_spending','value':.8}]}),
 'spend_discretionary_1_2':({}, {'0':[{'type':'set_spending','value':1.2}]}),
 'relative_available_requested':({'relative_available_probability':1}, {'0':[{'type':'request_relative_support'}]}),
 'relative_unavailable_requested':({'relative_available_probability':0}, {'0':[{'type':'request_relative_support'}]}),
 'request_shorttime':({}, {'12':[{'type':'request_hours','value':.6}]}),
 }
 compared={}
 for name,(cfg,actions)in branches.items():
  initial=e.initialize('13',seed=s['seed'],birth_date=s['birth_date'],initial_family=s['initial_family'],scenario={'return_plan_mode':'declared_month','return_month':12,'return_spread_months':0,'care_access_scenario':'available',**cfg},include_region=True);out=e.run(initial,24,actions);atomic_json(ROOT/'examples'/('comparison_'+name+'.json'),{'initial_family_hash':initial['initial_family_hash'],'scenario_changes':{'controlled_base':{'return_plan_mode':'declared_month','return_month':12,'care_access_scenario':'available'},**cfg},'actions':actions,'summary':summarize(out),'final':out});compared[name]=summarize(out)
 for name,row in compared.items():
  row['delta_vs_baseline']={k:row[k]-compared['baseline'][k]for k in ['cash','net_worth','cumulative_gross','cumulative_expense','months_in_shortage']};row['interpretation']='paired simulation mechanism, not estimated causal effect or population probability'
 atomic_json(ROOT/'validation/decision_comparisons_v02.json',compared);atomic_json(ROOT/'validation/example_summaries_v02.json',reports)
 if '--examples-only'in __import__('sys').argv:return
 # Sensitivity on common 47x2 initial families; scenario inputs are unmeasured, not fitted parameters.
 base=[]
 for pref in range(1,48):
  for i in range(2):base.append(e.initialize(f'{pref:02d}',seed=f'v02-sensitivity/{pref}/{i}',include_region=False))
 scenarios={'baseline':{},'care_available':{'care_access_scenario':'available'},'care_unavailable':{'care_access_scenario':'unavailable'},'unknown_fee_zero':{'unknown_fee_quantile':0},'unknown_fee_reference_high':{'unknown_fee_quantile':1},'no_conditional_leave_exit':{'leave_exit_scale':0},'leave_exit1_5':{'leave_exit_scale':1.5},'expense_CV0':{'expense_cv':0},'expense_CV0_6':{'expense_cv':.6},'approval_payment_fast':{'benefit_approval_lag':0,'benefit_payment_lag':0},'approval_payment_slow':{'benefit_approval_lag':3,'benefit_payment_lag':3},'commute_not_reimbursed':{'commute_reimbursement_fraction':0},'no_qualifying_insurance_history':{'insurance_history_months':0},'small_employer':{'employer_size_proxy':5}}
 sensitivity={};low=[]
 for label,cfg in scenarios.items():
  rows=[];t=time.time()
  for initial in base:
   st=e.initialize(initial['household']['prefecture_code'],seed=initial['seed'],birth_date=initial['birth_date'],initial_family=initial['initial_family'],scenario=cfg,include_region=False);out=e.run(st,24);rows.append(summarize(out))
  sensitivity[label]={'scenario':cfg,'households':len(rows),'household_months':len(rows)*24,'summaries':{k:describe([x[k]for x in rows])for k in ['cash','net_worth','past_due','cumulative_gross','cumulative_expense','months_in_shortage','care_conflict_months']},'care_enrolled_fraction':sum(x['care_status']=='enrolled'for x in rows)/len(rows),'seconds':time.time()-t};print('sensitivity',label,flush=True)
 for i in range(47):
  pref=f'{i+1:02d}';st=e.initialize(pref,conditions={'household_income_yen':2000000},seed='v02-poor/'+pref,scenario={'initial_cash_override':0,'liquidate_term':False,'liquidate_securities':False},include_region=False);out=e.run(st,24);low.append({'prefecture':pref,**summarize(out),'warning':'liquidity stress scenario; declared income is not observed joint asset/expense poverty sample; no incidence inference'})
 atomic_json(ROOT/'validation/sensitivity_v02.json',{'paired_households_per_scenario':94,'scenarios':sensitivity,'identified_probabilities':False});atomic_json(ROOT/'validation/low_liquidity_stress_v02.json',low)
if __name__=='__main__':main()
