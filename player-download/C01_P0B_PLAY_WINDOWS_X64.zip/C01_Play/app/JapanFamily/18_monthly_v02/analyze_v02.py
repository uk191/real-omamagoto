"""No external-fit certificate is inferred from numerical accounting success."""
import json,gzip,collections,math,statistics
from common import ROOT,PROJECT,atomic_json
from engine import Engine
from provenance import IMPLEMENTATION
from validate_v02 import describe

def weighted(pairs):
 pairs=sorted((x,w)for x,w in pairs if isinstance(x,(int,float)));W=sum(w for x,w in pairs)
 if not W:return {'n':0,'mean':None}
 mean=sum(x*w for x,w in pairs)/W;qs={}
 for q in [.01,.1,.25,.5,.75,.9,.99]:
  t=0
  for x,w in pairs:
   t+=w
   if t>=q*W:qs[str(q)]=x;break
 return {'n':len(pairs),'sum_weight':W,'effective_n':W*W/sum(w*w for x,w in pairs),'mean':mean,'variance':sum(w*(x-mean)**2 for x,w in pairs)/W,'quantiles':qs}
def main():
 e=Engine();totals={p:sum(x['weight']for x in rows if x['sex']=='all')for p,rows in e.generator.base.g['birth_pref'].items()};den=sum(totals.values());weights={k:v/den for k,v in totals.items()};initials=json.loads((ROOT/'validation/initials_v02.json').read_text());counts=collections.Counter(x['prefecture']for x in initials);w={x['seed']:weights[x['prefecture']]/counts[x['prefecture']]for x in initials};mom=collections.defaultdict(lambda:collections.defaultdict(list));states=collections.defaultdict(collections.Counter);care=collections.defaultdict(collections.Counter);rows=0;checks=[]
 for p in sorted((ROOT/'validation/trials_v02').glob('*.jsonl.gz')):
  meta=json.loads(p.with_suffix('').with_suffix('.json').read_text());assert meta['implementation_sha256']==IMPLEMENTATION
  seen=collections.Counter()
  with gzip.open(p,'rt',encoding='utf-8')as f:
   for line in f:
    r=json.loads(line);rows+=1;seen[r['seed']]+=1;assert r['cash_residual']==r['worth_residual']==0
    if r['elapsed']in [6,12,18,24]:
     age=str(r['elapsed'])
     for key,v in r['values'].items():mom[age][key].append((v,w[r['seed']]))
     for who,status in r['employment_status'].items():states[age+'/'+who][status]+=w[r['seed']]
     care[age][r['care_status']]+=w[r['seed']]
  assert len(seen)==220 and set(seen.values())=={24};checks.append({'prefecture':p.stem.split('.')[0],'households':len(seen),'rows':sum(seen.values()),'implementation':IMPLEMENTATION})
 assert rows==248160
 distributions={age:{key:{**weighted(v),'unknown_weight':sum(w for x,w in v if x is None)}for key,v in values.items()}for age,values in mom.items()}
 comparisons=[]
 for age,ref in [(6,.354),(18,.42)]:
  vs=mom[str(age)]['mother_lfs_proxy'];presentW=sum(ww for x,ww in vs);lower=sum((x or 0)*ww for x,ww in vs)/presentW;upper=(sum((x or 0)*ww for x,ww in vs)+sum(ww for x,ww in vs if x is None))/presentW
  comparisons.append({'id':'cohort2010/mother/'+str(age),'source':'../17_monthly/raw/cohort_2010_work.pdf p1/Table2','observed_year':'2010 birth cohort,6/18-month surveys','published':'2012','population':'same child and co-resident mother at both waves,33311','geography':'nationwide','numerator':'有職 includes childcare leave;6month35.4% includes23.3%leave','denominator':'co-resident mother participants both waves','model_variable':'mother_lfs_proxy (monthly endpoint, not reference survey week)','generated_lower':lower,'generated_upper_unknown_attachment':upper,'source_value':ref,'classification':'独立統計との歴史的比較・現代妥当性未確認','external_fit_pass':None,'uncertainty':'2010 vs2026,question definitions and month reference; do not infer monthly hazards or target-fit'})
  comparisons.append({'id':'cohort2010/care/'+str(age),'source':'../17_monthly/raw/cohort_2010_care.pdf','observed_year':'2010 birth cohort','published':'2012','population':'cohort respondents age'+str(age),'numerator':'保育サービス利用者（施設種類の対応は完全でない）','denominator':'対象出生児','geography':'nationwide','model_variable':'authorized-care scenario enrollment','source_value':.045 if age==6 else .312,'generated':distributions[str(age)]['care_enrolled']['mean'],'classification':'独立統計との歴史的比較・定義一部不一致','external_fit_pass':None,'uncertainty':'施設範囲、コホート、入園資源シナリオを識別できない'})
 cohort=[x for x in initials if x['rank']==1 and x['marital']=='marital'and x['resident_count']==3 and not x['grandparent']];reference=json.loads((PROJECT/'17_monthly/validation/income_gap_analysis.json').read_text());ref=reference['source2024_main_job_wage_plus_business_ex_property'];income={'all_families_2022_normal_jobs':weighted([(x['normal_jobs'],w[x['seed']])for x in initials]),'first_marital_roster3_no_grandparent_2022_normal_jobs':weighted([(x['normal_jobs'],w[x['seed']])for x in cohort]),'same_cohort_2022_household_reference':weighted([(x['reference_household_income'],w[x['seed']])for x in cohort]),'source_2024_main_job_wage_business':ref,'source_population':'2024 couple plus one child age0–2; not only newborn and not first-marital selected','multiplier_correction_applied':False,'old_decomposition':reference,'classification':'定義未整合・未適合。比較可能な部分の記述であり所得誤差の因果分解ではない','unidentified':['2022 income referent year vs2024 survey','regular/bonus/full-year vsactual partial-year and leave','all children0–2 vsnewborn event weighting','first marriage unobserved','joint ESS job selection, maternal-phase graft and geographic weighting','household non-parent income and sampling underincome bins']}
 income['ratio_different_definitions']=income['first_marital_roster3_no_grandparent_2022_normal_jobs']['mean']/ref
 domains=[('calendar_and_ledger','プログラム動作・内部整合性','会計恒等式・時間グリッド・seed・年齢。現実統計一致とは別'),('ordinary_salary_withholding','独立制度原文に条件付きで支持された','甲0・普通給与・適用年の関数。加入/扶養/年末調整を含む全家計税額は未完成'),('leave_uptake','同一出典での内部校正','産業別乱数抽選の校正。出生コホートへの輸送妥当性は未確認'),('leave_duration_return_exit','研究やデータから識別できない','復職者期間→希望、終了者退職率→出生家庭。観測月次パネルでない'),('modern_employment_prevalence','統計との比較は可能だが未適合/定義未整合','2010比較に現代誤差の合否を付けない。未払育児中断の雇用継続未確認'),('childcare_selection','ゲーム用の明示的な仮定','部分指数＋持続的資源条件。実測入園確率なし'),('local_fee_known_cities','独立制度原文に条件付きで支持された','柏/大田/墨田/三鷹の通常保育料と推定税・支援児人数を条件とする'),('local_fee_elsewhere','研究やデータから識別できない','実額null、現金請求は参照幅のシナリオ'),('spending_conditional_mean','同一出典の原表接続','2024所得×家族平均。新生児経路の分散/相関適合は未確認'),('assets_and_shortage_incidence','研究やデータから識別できない','前版資産接合・新条件付き支出分散・料金幅に依存'),('normal_income_external','比較可能な部分はあるが定義未整合・未適合','年次・対象・実収入と通常参照を分離。18.4%を倍率で消さない'),('future_after_age2','未完成・利用不可','240月容器/APIのみ。年齢別制度・生活・就学等は追加推定必須')]
 atomic_json(ROOT/'validation/birth_weighted_distributions_v02.json',distributions);atomic_json(ROOT/'validation/employment_states_v02.json',dict(states));atomic_json(ROOT/'validation/care_states_v02.json',dict(care));atomic_json(ROOT/'validation/external_comparisons_v02.json',comparisons);atomic_json(ROOT/'validation/income_analysis_v02.json',income);atomic_json(ROOT/'validation/validity_domains_v02.json',[{'domain':d,'classification':c,'evidence_scope':s}for d,c,s in domains]);atomic_json(ROOT/'validation/trial_readthrough_v02.json',{'rows_read':rows,'checks':checks,'all_records_match_full_core_fingerprint':True,'age_note':'elapsed6 is end of six calendar periods age0..5; state next-month starts age6 for first-day births. Survey reference week not identical.'});print('analyzed',rows)
if __name__=='__main__':main()
