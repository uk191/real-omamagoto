"""Boundary fixtures and actual independent HTTP/reproducibility checks."""
import json,sys,copy,subprocess,urllib.request,urllib.error
from datetime import date
from common import ROOT,canonical,digest,age_months
from engine import Engine,DecisionError
from ledger import Ledger,worth
import rules
def main():
    e=Engine();tests=[]
    def check(name,fn):
        try:assert fn();tests.append({'name':name,'passed':True})
        except Exception as ex:tests.append({'name':name,'passed':False,'error':repr(ex)})
    initial=e.initialize('13',seed='A3-fixture',include_region=False);original=digest(initial);full=e.run(initial,24)
    check('input_immutable',lambda:digest(initial)==original)
    check('24_months',lambda:full['elapsed_months']==24 and full['month']=='2028-10-01')
    check('newborn_24_months',lambda:next(p for p in full['persons']if p['person_id']=='index_child')['age_months']==24)
    check('person_ages',lambda:all(p['age_months']==age_months(p['date_of_birth'],date.fromisoformat(full['month']))for p in full['persons']))
    check('all_cash_and_worth_identities',lambda:all(x['ledger']['cash_identity_residual']==x['ledger']['net_worth_identity_residual']==0 for x in full['monthly_history']))
    check('time_coverage',lambda:all(abs(sum(x['time'][k]for k in ['nursery','relative','parent_care'])-84)<1e-9 for x in full['monthly_history']))
    check('no_negative_balance',lambda:min(full['accounts'].values())>=0)
    check('certificate_false',lambda:not full['quality_flags']['financially_playable']and not full['quality_flags']['newborn_full_joint_externally_validated'])
    replay=e.run(json.loads(canonical(e.run(initial,12))),12)
    check('serialized12_plus12_equals24',lambda:digest(full)==digest(replay))
    check('repeat_same_seed_actions',lambda:digest(full)==digest(e.run(initial,24)))
    for month in range(1,13):
        s=e.initialize('12',seed=f'birth{month}',birth_date=f'2026-{month:02d}-15',include_region=False);r=e.run(s,24,retain_journal=False)
        check(f'birth_month_{month:02d}',lambda r=r:r['elapsed_months']==24 and next(p for p in r['persons']if p['person_id']=='index_child')['age_months']==23)
    poor=e.initialize('13',seed='poor',scenario={'initial_cash_override':0,'liquidate_term':False,'liquidate_securities':False,'borrowing_limit':0},include_region=False)
    poor=e.run(poor,24)
    check('shortfall_becomes_payable',lambda:sum(v for k,v in poor['accounts'].items()if k.startswith('L:AP:'))>=0 and all(x['ledger']['cash_identity_residual']==0 for x in poor['monthly_history']))
    check('no_unrequested_credit',lambda:not poor['accounts'].get('L:emergency_credit',0))
    check('child_allowance_birth_month_zero',lambda:rules.child_amount([{'person_id':'index_child','date_of_birth':'2026-10-01','role':'newborn','supported':True}],date(2026,10,1),date(2026,10,1))==0)
    check('child_allowance_next_month15000',lambda:rules.child_amount([{'person_id':'index_child','date_of_birth':'2026-10-01','role':'newborn','supported':True}],date(2026,11,1),date(2026,10,1))==15000)
    check('leave180_boundary',lambda:rules.leave_amount(10000,30,170)[0]==167000)
    check('shorttime90pct',lambda:rules.short_amount(300000,270000)==27000)
    check('shorttime95pct_rounding',lambda:rules.short_amount(300000,285000)==13509)
    check('shorttime_cap',lambda:rules.short_amount(600000,500000)==0)
    check('pension_birth_before_Oct_reform',lambda:rules.pension_amount('father',30,date(2026,8,1),date(2026,9,1))==17920 and rules.pension_amount('father',30,date(2026,8,1),date(2026,10,1))==0)
    check('kashiwa_second_half',lambda:rules.fee('12217',160000,2)['amount']==21400)
    check('kashiwa_third_zero',lambda:rules.fee('12217',500000,3)['amount']==0)
    check('unsupported_city_labelled',lambda:'unsupported' in rules.fee('13101',160000,1)['scope'])
    for name,kwargs in [('nan_scenario',{'scenario':{'spending_factor':float('nan')}}),('negative_scenario',{'scenario':{'benefit_payment_lag':-1}}),('invalid_year',{'birth_date':'2025-10-01'})]:
        def rejected(kwargs=kwargs):
            try:e.initialize('13',include_region=False,**kwargs)
            except ValueError:return True
            return False
        check(name,rejected)
    def outcome_rejected():
        try:e.step(initial,[{'type':'apply_childcare','result':'accepted'}])
        except DecisionError:return True
        return False
    check('actions_cannot_assign_results',outcome_rejected)
    # Stable environment keys and latent relatives are unaffected by an unrelated expense choice.
    changed=e.run(initial,24,{'0':[{'type':'set_spending','value':.8}]})
    check('common_environment_under_action_branch',lambda:all(a['environment']==b['environment']for a,b in zip(full['monthly_history'],changed['monthly_history'])))
    proc=subprocess.Popen([sys.executable,str(ROOT/'api.py'),'--port','0'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        port=json.loads(proc.stdout.readline())['port'];url=f'http://127.0.0.1:{port}'
        check('HTTP_health',lambda:json.load(urllib.request.urlopen(url+'/health'))['model_version']=='A3.0-0.2')
        def post(path,obj):
            req=urllib.request.Request(url+path,data=canonical(obj).encode(),headers={'Content-Type':'application/json'})
            try:
                with urllib.request.urlopen(req)as response:return response.status,json.load(response)
            except urllib.error.HTTPError as err:return err.code,json.load(err)
        code,remote=post('/initialize',{'prefecture_code':'13','seed':'A3-fixture','include_region':False})
        check('independent_process_initialization',lambda:code==200 and digest(remote)==digest(initial))
        code,remote=post('/simulate',{'state':remote,'months':24})
        check('independent_process24_reproduction',lambda:code==200 and digest(remote)==digest(full))
        check('HTTP_invalid_action',lambda:post('/step',{'state':initial,'actions':[{'type':'invent'}]})[0]==400)
        check('HTTP_invalid_months',lambda:post('/simulate',{'state':initial,'months':241})[0]==400)
    finally:proc.terminate();proc.wait(timeout=10)
    out={'tests':tests,'passed':sum(x['passed']for x in tests),'total':len(tests)};(ROOT/'validation').mkdir(exist_ok=True);(ROOT/'validation/tests.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(canonical(out),flush=True)
    assert out['passed']==out['total']
if __name__=='__main__':main()
