"""Integer-yen accrual ledger. Unpaid obligations remain liabilities."""
from copy import deepcopy
from common import digest
def worth(a):return sum(v for k,v in a.items()if not k.startswith('L:'))-sum(v for k,v in a.items()if k.startswith('L:'))
class Ledger:
    def __init__(self,accounts,month):
        self.a=accounts;self.opening=deepcopy(accounts);self.month=month;self.entries=[];self.income=0;self.expense=0
    def post(self,kind,deltas,amount=None,meta=None):
        if any(not isinstance(x,int)or isinstance(x,bool)for x in deltas.values()):raise ValueError('Integer yen required')
        delta=sum(v if not k.startswith('L:')else-v for k,v in deltas.items())
        if kind not in ['income','expense','expense_reversal'] and delta:raise AssertionError(('unbalanced transfer',kind,deltas))
        if kind=='income':assert delta>=0;self.income+=delta
        if kind=='expense':assert delta<=0;self.expense-=delta
        if kind=='expense_reversal':assert delta>=0;self.expense-=delta
        for k,v in deltas.items():self.a[k]=self.a.get(k,0)+v
        if any(v<0 for v in self.a.values()):raise AssertionError(('negative account',self.a))
        row={'event_id':digest([self.month,len(self.entries),kind,deltas])[:20],'kind':kind,'deltas':deltas,'amount':amount,'metadata':meta or{}};self.entries.append(row)
    def earn(self,key,n,meta=None):
        if n:self.post('income',{'AR:'+key:n},n,meta)
    def expense_due(self,key,n,meta=None):
        if n:self.post('expense',{'L:AP:'+key:n},n,meta)
    def collect(self,key,n,meta=None):
        if n:self.post('receipt',{'AR:'+key:-n,'cash':n},n,meta)
    def pay(self,key,n,meta=None):
        available=min(self.a.get('cash',0),n,self.a.get(key,0))
        if available:self.post('payment',{key:-available,'cash':-available},available,meta)
        return available
    def transfer(self,source,target,n):
        n=min(self.a.get(source,0),n)
        if n:self.post('asset_transfer',{source:-n,target:n},n)
        return n
    def check(self):
        residual=worth(self.a)-worth(self.opening)-self.income+self.expense
        cash=self.a.get('cash',0)-self.opening.get('cash',0)-sum(e['deltas'].get('cash',0)for e in self.entries)
        assert residual==cash==0 and min(self.a.values(),default=0)>=0
        return {'net_worth_open':worth(self.opening),'net_worth_close':worth(self.a),'recognized_income':self.income,'recognized_expense':self.expense,'net_worth_identity_residual':residual,'cash_identity_residual':cash,'unpaid_obligations':sum(v for k,v in self.a.items()if k.startswith('L:AP:')),'receivables':sum(v for k,v in self.a.items()if k.startswith('AR:'))}
