"""Source boundaries and behavioral semantics; fixture contracts are explicitly declared."""
import copy,json,math
from datetime import date,timedelta
from common import ROOT,canonical,atomic_json,digest,add_month
from engine import Engine,DecisionError
import realism,cash_rules,rules

def main():
 e=Engine();tests=[]
 def check(name,fn):
  try:assert fn();tests.append({'name':name,'passed':True})
  except Exception as ex:tests.append({'name':name,'passed':False,'error':repr(ex)})
 def reject(fn):
  try:fn()
  except (ValueError,TypeError):return True
  return False
 def fixture(birth='2026-10-01',cfg=None):
  s=e.initialize('13',conditions={'mother_employed':True,'father_employed':True},seed='v02-law-fixture',birth_date=birth,scenario={'auto_actions':False,'return_plan_mode':'declared_month','employment_transition_mode':'frozen','care_access_scenario':'available',**(cfg or{})},include_region=False)
  for who,p in s['parents'].items():
   p.update(contract_active=True,employee_contract=True,employment_type='regular',employee_eligible_estimate=True,employment_insured_estimate=True,benefit_eligible_estimate=True,normal_annual=3600000,normal_weekly_hours=40,return_month=12,leave_requested=who=='mother',father_leave_days=0,state='maternity'if who=='mother'else'working')
  return s
 s=fixture();r=e.run(s,24,{'0':[{'type':'apply_childcare','value':{'desired_start':12}}]});mom=r['parents']['mother'];claims=[x for x in r['claims']if x['kind']=='parental_leave'and x['person']=='mother']
 check('mandatory_postpartum_57_including_birth',lambda:sum(m['parents']['mother']['maternity_days']for m in r['monthly_history'])==57)
 check('maternal_parental_start_birth_plus57',lambda:claims[0]['period']['start']=='2026-11-27')
 check('full_calendar_unit30_not31',lambda:any(c['period']['calendar_days']==31 and c['period']['benefit_days']==30 for c in claims))
 check('benefit_end_birthday_minus2',lambda:max(c['period']['end']for c in claims)=='2027-09-29')
 check('legal_leave_one_day_longer_than_benefit',lambda:r['monthly_history'][11]['parents']['mother']['parental_days']==30)
 check('distinct_benefit_unit_keys',lambda:len(claims)==len({c['key']for c in claims}))
 check('application_approval_receipt_distinct',lambda:all(c['applied_month']<c['approved_month']for c in claims))
 check('recognized_once_approval_no_duplicate_income',lambda:sum(x['amount']for x in r['journal']if x['kind']=='income'and any(k.startswith('AR:unit/mother/')for k in x['deltas']))==sum(x['amount']for x in claims))
 feb=e.run(fixture('2026-12-05'),6);febc=[c for c in feb['claims']if c['kind']=='parental_leave'and c['person']=='mother'];check('February_full28calendar_days_paid30',lambda:any(c['period']['calendar_days']==28 and c['period']['benefit_days']==30 for c in febc))
 no=e.run(s,4,{'0':[{'type':'decline_parental_leave'}]});check('decline_parental_preserves_maternity',lambda:sum(m['parents']['mother']['maternity_days']for m in no['monthly_history'])==57)
 check('decline_parental_does_not_earn_leave_benefit',lambda:not any(c['kind']=='parental_leave'and c['person']=='mother'for c in no['claims']))
 ret=e.step(s,[{'type':'request_return','value':0}]);check('return_request_does_not_decline_leave',lambda:ret['parents']['mother']['leave_requested'])
 check('return_request_cannot_cancel_mandatory_maternity',lambda:ret['parents']['mother']['maternity_days']==31 and ret['parents']['mother']['planned_weekly_hours']==0)
 auto=fixture(cfg={'auto_actions':True});auto=e.run(auto,4,{'0':[{'type':'request_return','value':0}]});check('overdue_early_return_still_applies_care',lambda:auto['care']['application']is not None)
 check('request_outcome_uniform_record',lambda:all(set(['action_id','requested_action','feasibility','counterparty_approval','adopted_action','direct_change','later_outcomes_recorded_separately'])<=set(x)for x in auto['decisions']))
 check('cannot_inject_admission_result',lambda:reject(lambda:e.step(s,[{'type':'apply_childcare','result':'granted'}])))
 check('unidentified_probability_rejected',lambda:reject(lambda:e.initialize('13',scenario={'care_admission_probability':.65})))
 check('unsupported_bonus_rejected',lambda:reject(lambda:e.initialize('13',scenario={'bonus_share':.2})))
 check('long_payroll_arrears_rejected',lambda:reject(lambda:e.initialize('13',scenario={'payroll_lag':2})))
 check('nonfinite_action_rejected',lambda:reject(lambda:e.step(s,[{'type':'set_spending','value':float('nan')}])))
 check('duplicate_id_rejected',lambda:reject(lambda:e.step(s,[{'type':'set_spending','value':1,'id':'x'},{'type':'set_spending','value':.9,'id':'x'}])))
 q=copy.deepcopy(s);q['parents']['mother'].update(contract_active=False,employee_contract=False,state='nonemployed');q=e.step(q,[{'type':'request_return','value':3}]);check('nonemployed_return_rejected',lambda:q['decisions'][-1]['outcome']=='rejected')
 p=copy.deepcopy(s['parents']['mother']);p.update(employment_type='nonregular',normal_weekly_hours=20,normal_annual=900000)
 check('health88000before_reform',lambda:not realism.insured(p,date(2026,9,1),s['config']))
 check('health88000abolished_Oct2026',lambda:realism.insured(p,date(2026,10,1),s['config']))
 cfg={**s['config'],'employer_size_proxy':36};check('health36size_beforeOct2027',lambda:not realism.insured(p,date(2027,9,1),cfg));check('health36size_fromOct2027',lambda:realism.insured(p,date(2027,10,1),cfg))
 check('2027withholding_updated',lambda:cash_rules.withholding(160000,2027)<cash_rules.withholding(160000,2026))
 check('zero_wage_zero_withholding',lambda:cash_rules.withholding(0,2027)==0)
 check('payroll_bank_gross_minus_deductions',lambda:all(x['gross']-x['social']-x['withholding']==x['net_bank']for m in r['monthly_history']for x in m['payroll_bank_receipts']))
 check('no_automatic_fabricated_yearend_refund',lambda:not any('annual_refund'in str(x)for x in r['receipts_due']))
 unknown=copy.deepcopy(s);unknown['household']['municipality_code']='13101';fee=realism.care_fee(unknown,date(2026,10,1),500000,False);check('unknown_municipal_actual_fee_null',lambda:fee['amount']is None and fee['cash_charge']==35650)
 check('non_taxable_under3_fee0',lambda:realism.care_fee(unknown,date(2026,10,1),0,True)['amount']==0)
 for code in ['13111','13107','13204']:
  unknown['household']['municipality_code']=code;check('verified_free_city_'+code,lambda:realism.care_fee(unknown,date(2026,10,1),500000,False)['amount']==0)
 p=copy.deepcopy(s);p['parents']['mother']['normal_weekly_hours']=15;check('care_qualification_low_hours_not_automatically_granted',lambda:not realism.eligibility(p)['eligible'])
 deny=e.run(fixture(cfg={'care_access_scenario':'unavailable'}),24,{'0':[{'type':'apply_childcare'}]});selections=[x for m in deny['monthly_history']for x in m['events']if x['type']=='care_selection'];check('care_selection_not_iid_monthly',lambda:1<=len(selections)<=3 and all(x['statistical_admission_probability']is None for x in selections))
 offered=e.step(fixture(cfg={'job_search_probability':1}),[{'type':'job_search'}]);check('job_offer_does_not_auto_change_contract_same_month',lambda:'job_offer'in offered['parents']['mother']and any(x['type']=='job_offer_proposed'for x in offered['last_month']['events']))
 accepted=e.step(offered,[{'type':'accept_job_offer','value':offered['parents']['mother']['job_offer']['id']}]);check('offer_acceptance_separate',lambda:'job_offer'not in accepted['parents']['mother'])
 check('spending_zero_preserves_protected_expenses',lambda:realism.budget_month({**s,'spending_factor':0},{'price_factors':{'food':1,'energy':1,'other':1}})['total']>0)
 check('spending_changes_not_all_costs_same_ratio',lambda:realism.budget_month({**s,'spending_factor':.5},{'price_factors':{'food':1,'energy':1,'other':1}})['total']>.5*realism.budget_month(s,{'price_factors':{'food':1,'energy':1,'other':1}})['total'])
 check('unit_180_boundary_known_value',lambda:rules.leave_amount(10000,30,170)[0]==167000)
 check('low_cash_no_unrequested_credit',lambda:not e.run(fixture(cfg={'initial_cash_override':0,'liquidate_term':False,'liquidate_securities':False}),24)['accounts'].get('L:emergency_credit',0))
 check('scope_flags_preserved',lambda:not r['quality_flags']['financially_playable']and not r['quality_flags']['newborn_full_joint_externally_validated'])
 for birth_month in range(1,13):
  initial=e.initialize('13',seed='own-family/'+str(birth_month),birth_date=f'2026-{birth_month:02d}-01',include_region=False);roundtrip=e.initialize('13',seed=initial['seed'],birth_date=initial['birth_date'],initial_family=initial['initial_family'],include_region=False);check('own_initial_family_roundtrip_'+str(birth_month),lambda initial=initial,roundtrip=roundtrip:digest(initial)==digest(roundtrip))
 out={'fixture':'explicit employee contract3600000/40h; tests do not validate population probability or administrative approval','tests':tests,'passed':sum(x['passed']for x in tests),'total':len(tests)};atomic_json(ROOT/'validation/tests_v02.json',out);print(canonical(out),flush=True);assert out['passed']==out['total']
if __name__=='__main__':main()
