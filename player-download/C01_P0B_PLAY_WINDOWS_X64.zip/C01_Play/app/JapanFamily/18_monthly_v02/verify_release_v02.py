"""Verify exact release ZIP in a fresh directory, including original/new HTTP APIs."""
import zipfile,hashlib,json,sys,tempfile,subprocess,urllib.request,sqlite3,argparse
from pathlib import Path

def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('zip');ap.add_argument('--expected-sha256',required=True);ap.add_argument('--destination');ap.add_argument('--output',required=True);args=ap.parse_args();archive=Path(args.zip).resolve();assert sha(archive)==args.expected_sha256
 dest=Path(args.destination).resolve()if args.destination else Path(tempfile.mkdtemp(prefix='A302_fresh_'));dest.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None
  for info in z.infolist():
   rel=Path(info.filename);assert not rel.is_absolute()and'..'not in rel.parts
  z.extractall(dest)
 project=dest/'JapanFamily';module=project/'18_monthly_v02';manifest=json.loads((project/'release_manifest_v02.json').read_text());checked=[]
 for rel,expected in manifest['files'].items():
  p=project/rel;assert p.is_file()and sha(p)==expected,rel;checked.append(rel)
 db=project/'data/region.sqlite';c=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True);integrity=c.execute('PRAGMA integrity_check').fetchall();fk=c.execute('PRAGMA foreign_key_check').fetchall();assert integrity==[('ok',)]and not fk
 assert c.execute('select count(*) from monthly_v02_household').fetchone()[0]==10340;assert c.execute('select count(*) from monthly_v02_state').fetchone()[0]==248160;c.close()
 # Recheck every inherited row against pre-migration saved hashes using restored code.
 code="import json;from install_v02 import fingerprint;from common import ROOT,PROJECT;before=json.load(open(ROOT/'validation/inherited_tables_before.json'));assert fingerprint(PROJECT/'data/region.sqlite',list(before))==before;print(len(before))"
 inherited=int(subprocess.check_output([sys.executable,'-c',code],cwd=module,text=True).strip());assert inherited==55
 expected=json.loads((module/'data/release_expectations_v02.json').read_text());checks=[]
 for dirname,version in [('17_monthly','A3.0-0.1'),('18_monthly_v02','A3.0-0.2')]:
  root=project/dirname;proc=subprocess.Popen([sys.executable,str(root/'api.py'),'--port','0'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  try:
   port=json.loads(proc.stdout.readline())['port'];url=f'http://127.0.0.1:{port}'
   assert json.load(urllib.request.urlopen(url+'/health'))['model_version']==version
   def post(path,body):
    req=urllib.request.Request(url+path,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
    return json.load(urllib.request.urlopen(req))
   def digest(x):return hashlib.sha256(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
   st=post('/initialize',{'prefecture_code':'13','seed':'A302-release-check','include_region':False});assert digest(st)==expected[version]['initial_sha256']
   full=post('/simulate',{'state':st,'months':24});half=post('/simulate',{'state':st,'months':12});split=post('/simulate',{'state':half,'months':12});assert digest(full)==digest(split)==expected[version]['final24_sha256']
   checks.append({'module':dirname,'version':version,'health':True,'initialize_exact':True,'24months_exact':True,'serialized12_plus12_exact':True,'sha256':digest(full)})
  finally:proc.terminate();proc.wait(timeout=15)
 # A2.5 direct-generation API, kept separately from the monthly adapter.
 a25=json.loads(subprocess.check_output([sys.executable,str(project/'16_recovery/model.py'),'--pref','13','--seed','A302-release-check','--no-region'],text=True));assert a25['model_version']=='A2.5-0.2r2'
 out={'zip_sha256':sha(archive),'zip_crc_pass':True,'fresh_destination':str(dest),'manifest_files_checked':len(checked),'all_payload_sha256_match':True,'DB_integrity_check':integrity,'DB_foreign_key_check':fk,'inherited_tables_unchanged':inherited,'new_households':10340,'new_monthly_rows':248160,'old_new_monthly_HTTP_APIs':checks,'A25_generate_API_version':a25['model_version'],'saved_bytes_verification':True,'financially_playable':False,'newborn_full_joint_externally_validated':False}
 Path(args.output).write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
