"""Local stateless state/action API; never publish or mutate source DB."""
from http.server import BaseHTTPRequestHandler,HTTPServer
import json,argparse
from common import VERSION,canonical
from engine import Engine,DecisionError
class Handler(BaseHTTPRequestHandler):
    engine=None
    def log_message(self,*args):pass
    def reply(self,code,data):
        b=canonical(data).encode();self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):self.reply(200,{'model_version':VERSION,'horizon_months':240,'demonstration_months':24,'financially_playable':False,'newborn_full_joint_externally_validated':False})if self.path=='/health'else self.reply(404,{'error':'not_found'})
    def do_POST(self):
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=16000000:raise DecisionError('Request body1..16MB')
            p=json.loads(self.rfile.read(length))
            if not isinstance(p,dict):raise DecisionError('JSON object required')
            if self.path=='/initialize':out=self.engine.initialize(**p)
            elif self.path=='/step':out=self.engine.step(**p)
            elif self.path=='/simulate':out=self.engine.run(**p)
            elif self.path=='/compare':
                state=p['state'];branches=p['branches'];months=p.get('months',24)
                if not isinstance(branches,dict)or not 1<=len(branches)<=10:raise DecisionError('1..10 branches')
                out={name:self.engine.run(state,months,actions)for name,actions in branches.items()}
            else:return self.reply(404,{'error':'not_found'})
            self.reply(200,out)
        except (ValueError,TypeError,KeyError)as e:self.reply(400,{'error':type(e).__name__,'message':str(e)})
def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8769);a=p.parse_args();Handler.engine=Engine();server=HTTPServer(('127.0.0.1',a.port),Handler);print(canonical({'port':server.server_port}),flush=True);server.serve_forever()
if __name__=='__main__':main()
