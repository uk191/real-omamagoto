"""Targeted financial, eligibility, claim-calendar and scenario tests."""
import json,copy
from datetime import date
from common import ROOT,canonical,atomic_json
from engine import Engine
from ledger import Ledger
import rules
def main():
    e=Engine();tests=[]
    def check(name,fn):
        try:assert fn();tests.append({'name':name,'passed':True})
        except Exception as ex:tests.append({'name':name,'passed':False,'error':repr(ex)})
    a={'cash':1000,'L:mortgage':500};l=Ledger(a,'2026-10');l.earn('wage',200);l.collect('wage',200);l.expense_due('interest',10);l.pay('L:AP:interest',10);l.pay('L:mortgage',100);c=l.check()
    check('principal_is_not_expense',lambda:c['recognized_income']==200 and c['recognized_expense']==10 and a['cash']==1090 and a['L:mortgage']==400 and c['net_worth_identity_residual']==0)
    a={'cash':0};l=Ledger(a,'2026-10');l.expense_due('rent',1000);l.pay('L:AP:rent',1000);c=l.check()
    check('cash_shortage_preserved',lambda:a['cash']==0 and a['L:AP:rent']==1000 and c['net_worth_close']==-1000)
    a={'cash':0,'term':1000};l=Ledger(a,'2026-10');l.transfer('term','cash',400);c=l.check()
    check('deposit_conversion_not_income',lambda:c['recognized_income']==c['recognized_expense']==0 and c['net_worth_open']==c['net_worth_close'])
    s=e.initialize('13',conditions={'birth_rank':1},seed='claim-calendar',scenario={'auto_actions':False},include_region=False)
    timely=e.run(s,6,{'0':[{'type':'apply_child_allowance'}]});late=e.run(s,6,{'3':[{'type':'apply_child_allowance'}]})
    child_income=lambda st:sum(x['amount']or 0 for x in st['journal']if x['kind']=='income'and any(k.startswith('AR:child_allowance/')for k in x['deltas']))
    check('timely_newborn_entitlement5months',lambda:child_income(timely)==75000)
    check('late_application_not_backfilled',lambda:child_income(late)==30000)
    firstpaid=[m['month']for m in timely['monthly_history']if any(x['type']=='cash_received'and x['key'].startswith('child_allowance/')for x in m['events'])]
    check('child_allowance_even_months',lambda:all(int(m[5:7])%2==0 for m in firstpaid))
    check('future_payables_not_delinquency',lambda:all(m['ledger']['payables_total']==m['ledger']['unpaid_due']+m['ledger']['future_payables']for m in timely['monthly_history']))
    own=e.initialize('13',conditions={'mother_employed':False,'father_employed':True,'legal_status':'marital'},seed='dependent',include_region=False)
    if own['parents']['father']['employee_eligible_estimate']:
        one=e.step(own);check('dependent_spouse_not_double_NHI_pension',lambda:own['parents']['mother']['dependent_spouse_scenario'] and not any(x['amount']for x in one['journal']if x['kind']=='expense'and any(k.startswith(('L:AP:NHI/mother/','L:AP:pension/mother/'))for k in x['deltas'])))
    check('2028_published_tax_change',lambda:rules.annual_tax(1800000,0,2028)>rules.annual_tax(1800000,0,2027))
    path={'2026-10':{'publication_date':'2028-01-01','kind':'observation','values':{'price_levels':{'food':9}}}}
    withfuture=e.initialize('13',seed='macro',scenario={'environment_path':path},include_region=False);out=e.step(withfuture)
    check('unpublished_future_not_applied',lambda:out['last_month']['environment']['price_factors']['food']==1 and out['last_month']['environment']['future_unpublished_records_withheld']==['2026-10'])
    early=e.initialize('13',seed='macro',scenario={'environment_path':{'2026-10':{'publication_date':'2026-10-01','kind':'scenario','values':{'price_levels':{'food':1.1}}}}},include_region=False);out=e.step(early)
    check('published_external_environment_applied',lambda:out['last_month']['environment']['price_factors']['food']==1.1)
    check('IPSS_population_connected',lambda:out['last_month']['environment']['population_reference']['year']=='2026')
    inactive=e.initialize('13',conditions={'mother_employed':False,'father_employed':False},seed='no_care_need',scenario={'employment_transition_mode':'frozen'},include_region=False);inactive=e.run(inactive,24)
    check('no_automatic_childcare_without_employment_reason',lambda:inactive['care']['application']is None and inactive['care']['status']=='home')
    denied=e.initialize('13',conditions={'mother_employed':True,'father_employed':True},seed='care_once',scenario={'auto_actions':False,'care_access_scenario':'unavailable','employment_transition_mode':'frozen'},include_region=False);denied=e.run(denied,24,{'0':[{'type':'apply_childcare'}]})
    check('denied_application_not_redrawn_monthly',lambda:sum(x['type']=='care_selection'for m in denied['monthly_history']for x in m['events'])<=3 and denied['care']['status']=='not_admitted')
    for index in range(30):
        funded=e.initialize('13',seed=f'future_payable/{index}',scenario={'initial_cash_override':1000000000},include_region=False)
        father=funded['parents'].get('father')
        if father and father['employee_eligible_estimate']and not father['leave_requested']:break
    funded=e.step(funded)
    check('future_payable_is_not_cash_shortage_gate',lambda:funded['last_month']['ledger']['future_payables']>0 and not any(x['type']=='cash_shortage'for x in funded['pending_decisions']))
    result={'tests':tests,'passed':sum(x['passed']for x in tests),'total':len(tests)};atomic_json(ROOT/'validation/tests_extra.json',result);print(canonical(result),flush=True);assert result['passed']==result['total']
if __name__=='__main__':main()
