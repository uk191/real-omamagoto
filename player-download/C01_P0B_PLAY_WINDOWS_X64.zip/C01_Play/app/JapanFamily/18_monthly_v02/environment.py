"""As-of scenario paths: actual reference, published outlook, user scenario."""
import json,sqlite3,csv,math
from functools import lru_cache
from common import ROOT,PROJECT,month_index
from datetime import date
K=json.loads((ROOT/'data/kernels.json').read_text())
class Environment:
    def __init__(self):
        with (PROJECT/'data/future_prefecture_reference_2026_2046.csv').open(encoding='utf-8-sig')as f:self.population={(x['code'][:2],int(x['year'])):x for x in csv.DictReader(f)}
    def at(self,month,initial,config,parents,household):
        elapsed=month_index(month)-month_index(initial);factors={}
        for code in ['food','energy','other']:
            coefficient={'food':1.,'energy':1.4,'other':.8}[code];f=1.
            for m in range(elapsed):
                y,mm=divmod(month_index(initial)+m,12);fy=y if mm+1>=4 else y-1
                rate=K['macro']['CPI_ex_fresh_forecast_FY'].get(str(fy),.02)
                if config.get('macro_scenario')=='constant_prices':rate=0
                if config.get('macro_scenario')=='high_inflation':rate+=.02
                f*=(1+rate*coefficient)**(1/12)
            factors[code]=f
        wage={}
        for who,p in parents.items():
            # Existing contracts remain nominally fixed unless a scenario explicitly changes them.
            exposure=.5 if p['employment_type']=='nonregular'else 1.
            industry=p.get('industry')or'unknown';bonus=1.2 if '情報' in industry else 1.
            wage[who]=(1+config['salary_growth_annual']*exposure*bonus)**(elapsed/12)
        year=min(2046,max(2026,month.year));key=(household['prefecture_code'],year)
        applied=[];withheld=[]
        for target,record in sorted(config.get('environment_path',{}).items()):
            if target>month.isoformat()[:7]:continue
            if record.get('publication_date','9999-01-01')>month.isoformat():withheld.append(target);continue
            values=record.get('values',{})
            for category,f in values.get('price_levels',{}).items():
                if category not in factors or not isinstance(f,(int,float))or not math.isfinite(f)or f<0:raise ValueError('Invalid external price level')
                factors[category]=f
            for who,p in parents.items():
                f=values.get('wage_levels_by_industry',{}).get(p.get('industry'),1)*values.get('wage_levels_by_prefecture',{}).get(household['prefecture_code'],1)
                if not isinstance(f,(int,float))or not math.isfinite(f)or f<0:raise ValueError('Invalid external wage level')
                if f!=1:wage[who]=f
            applied.append({'target_month':target,'publication_date':record['publication_date'],'kind':record.get('kind','scenario')})
        return {'month':month.isoformat()[:7],'price_factors':factors,'wage_factors':wage,'annual_rent_change':0,'interest':'inherited loans fixed-rate; variable-rate contracts not identified','employment_market':'no spontaneous layoffs in baseline; job_search uses explicit scenario','population_reference':self.population.get(key),'population_scope':'A1 IPSS23 prefecture annual projection, five-year linear interpolation; no invented municipal monthly population','kind':'2026Aug price anchor; BOJ FY outlook interpolated and category exposures estimated; wages contract/scenario','future_policy':config['unknown_future'],'external_records_applied':applied,'future_unpublished_records_withheld':withheld}
