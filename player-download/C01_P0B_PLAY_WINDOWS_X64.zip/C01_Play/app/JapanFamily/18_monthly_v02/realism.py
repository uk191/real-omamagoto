"""Source-bounded transitions, cost decomposition and definition mapping.
Probabilities and scenario inputs have different provenance and scope.
"""
import json,re,unicodedata,math,copy,calendar
from datetime import date,timedelta
from common import ROOT,random_key,add_month,month_first,month_index,age_months
import rules
B=json.loads((ROOT/'data/conditional_budget.json').read_text());E=json.loads((ROOT/'data/employment_conditionals.json').read_text())
EMP={'regular','nonregular','employee_other'}
FEMALE=[.6,.6,.5,1.4,3.6,4.6,10.6,28.7,31.4,12.4,3.5,1.8];MALE=[6.8,14.1,28.,30.3,10.1,5.2,1.1,2.4,1.8,.1,.1,.1];BINS=[(1,5),(5,14),(14,30),(30,90),(90,180),(180,240),(240,300),(300,360),(360,540),(540,720),(720,1080),(1080,1440)]
PROTECT={'210101':.7,'210103':.9,'210104':.3,'210105':.25,'210106':.9,'210107':.6,'210108':.8,'210109':.15,'210110':.4,'21010202':1.}
def row(p,kind):
 text=unicodedata.normalize('NFKC',p.get('industry')or'');text=re.sub('^[A-Z]','',text);text=re.sub(r'\(第[123]次産業\)$','',text).replace(',','、').replace(' ','');r=E[kind].get(text)
 return (text,r)if r and not r['small_sample']else('総数',E[kind]['総数'])
def insured(p,d,cfg):
 if not p.get('contract_active')or p['employment_type']not in EMP:return False
 if p['employment_type']!='nonregular'or p['normal_weekly_hours']>=30:return True
 return p['normal_weekly_hours']>=20 and cfg['employer_size_proxy']>=(36 if d>=date(2027,10,1)else 51)and(d>=date(2026,10,1)or p['normal_annual']/12>=88000)
def initialize(s):
 d=date.fromisoformat(s['month']);birth=date.fromisoformat(s['birth_date']);cfg=s['config']
 for who,p in s['parents'].items():
  p['contract_active']=p['state']!='nonemployed';p['employee_contract']=p['contract_active']and p['employment_type']in EMP;p['employment_insured_estimate']=p['employee_contract']and p['normal_weekly_hours']>=20;p['employee_eligible_estimate']=insured(p,d,cfg);p['benefit_eligible_estimate']=p['employment_insured_estimate']and cfg['insurance_history_months']>=12
  ind,r=row(p,'uptake');prob=r['values'][1 if who=='mother'else 3]/100;p['leave_requested']=p['employee_contract']and random_key(s['seed'],0,'baseline_leave_request',who).random()<prob;p['takeup_probability']=prob;p['takeup_industry']=ind
  p['leave_start_date']=(birth+timedelta(days=57)if who=='mother'else birth).isoformat();p['leave_end_evaluated']=False;p['realized_leave_segments']=[];p['benefit_units_booked']=[];p['paid_gross_year']={};p['withholding_year']={}
  if p['leave_requested']and cfg['return_plan_mode']=='duration_transport':
   weights=FEMALE if who=='mother'else MALE;rng=random_key(s['seed'],0,'duration_intention_v02',who);u=rng.random()*100;bucket=None;days=304 if who=='mother'else 28
   for j,(w,limits)in enumerate(zip(weights,BINS)):
    u-=w
    if u<0:days=rng.randrange(*limits);bucket=j;break
   target=date.fromisoformat(p['leave_start_date'])+timedelta(days=days);p['return_month']=max(2 if who=='mother'else 0,month_index(target)-month_index(birth)+int(target.day>1));p['father_leave_days']=days if who=='father'else 0;p['duration_intention_days']=days;p['duration_bucket']=bucket
  else:p['duration_intention_days']=None;p['duration_bucket']=None
  if not p['leave_requested']and who=='father':p['father_leave_days']=0
  p['state']='maternity'if who=='mother'and p['employee_contract']else'working'if p['contract_active']else'nonemployed'
 # Replace the old generic income-scaled spending draw with observed income×family means.
 children=[p for p in s['persons']if p['person_id']not in s['parents']and p.get('co_resident')and p.get('role')!='co_resident_grandparent'];fam='14'if s['household'].get('reference_co_resident_grandparent')else'1171'if len(s['parents'])==1 else'11211'if len(children)==1 else'11411'if len(children)==2 else'1161';income=s['household']['reference_usual_household_income']['value'];income=income if income is not None else sum(p['normal_annual']for p in s['parents'].values());g=next((g for g in B['groups'].values()if g['family']==fam and g['income']!='00'and(g['interval'][0]is None or income>=g['interval'][0])and(g['interval'][1]is None or income<g['interval'][1])),B['groups'][fam+'|00']);ic=g['income'];cats={};fallback=[];detail=B['embedded'].get(fam,B['embedded']['1']);other=detail.get('210110')or 1;travel=detail.get('210107')or 1;pre=sum(1 for p in children if(age_months(p.get('date_of_birth'),birth)or 0)<72);care_share=min(1,(detail.get('210110015009')or 0)/other)/max(1,pre);commute_share=min(1,sum(detail.get(k)or 0 for k in ['210107010003','210107010006'])/travel);cv=cfg['expense_cv'];sigma=math.sqrt(math.log1p(cv*cv));scale=random_key(s['seed'],0,'budget_persistent_v02').lognormvariate(-sigma*sigma/2,sigma)
 for code,protected in PROTECT.items():
  for key in [fam+'|'+ic,'1|'+ic,'0|'+ic,fam+'|00','1|00']:
   chosen=B['groups'].get(key,{});mean=chosen.get('values',{}).get(code)
   if isinstance(mean,(int,float)):break
  else:continue
  removed=mean*(care_share if code=='210110'else commute_share if code=='210107'else 0);cats[code]={'base':round((mean-removed)*1.0420209567198178*scale),'mean2024':mean,'removed_embedded_mean':removed,'protected_share':min(1,protected*cfg['protected_share_scale']),'source_group':key,'cell':chosen['cells'][code]}
  if key!=fam+'|'+ic:fallback.append(code)
 s['budget']={'family':fam,'income_class':ic,'source_sample_count_rounded':g['values'].get('sample_count'),'categories':cats,'fallback_categories':fallback,'income_basis':'2022 household nominal reference mapped to2024 classes; annual conversion unidentified','scope':'observed conditional means; persistent CV, care/pass cost split and 2026 price transport are estimates, not newborn longitudinal joint','index_child_care_share_removed':care_share};s['base_consumption']=sum(c['base']for c in cats.values());s['action_outcomes']=[]
 # Ordinary maternal prior-month wage during declared prenatal leave is not invented.
 for r in s['receipts_due']:
  if r['key'].startswith('opening_payroll/mother')and s['parents']['mother']['employee_contract']:
   a=add_month(d,-1);z=d-timedelta(days=1);prenatal=birth-timedelta(days=41);days=max(0,(min(z,prenatal-timedelta(days=1))-a).days+1);r['amount']=round(r['amount']*min(1,days/calendar.monthrange(a.year,a.month)[1]));s['accounts']['AR:'+r['key']]=r['amount']
  if r['key'].startswith('opening_payroll/'):
   who=r['key'].split('/')[1];r['person']=who;r['income_type']='net_business_profit'if s['parents'][who]['employment_type']=='self_employed'else'salary';r['deduction_keys']=[]
   if r['income_type']=='net_business_profit':r['amount']=0;s['accounts']['AR:'+r['key']]=0
 s['scope_gaps']+=['conditional_returners_duration_transported_to_intentions','no_unidentified_monthly_employment_hazard','health_EI_history_and_employer_size_estimated','unknown_local_fee_has_null_actual_value','year_end_tax_all_credits_and_actual_filing_unimplemented','paid_salary_year_differs_from_earned_year','budget_sparse_cells_and_unobserved_household_variance','prenatal_receivable_estimated_not_observed','bonus_contract_and_bonus_withholding_unimplemented']
def budget_month(s,env):
 items=[]
 for code,c in sorted(s['budget']['categories'].items()):
  kind='food'if code=='210101'else'energy'if code=='210103'else'other';amount=round(c['base']*env['price_factors'][kind]*(c['protected_share']+(1-c['protected_share'])*s['spending_factor']));items.append({'code':code,'amount':amount,'cell':c['cell'],'policy_rigidity_unobserved':True})
 return {'total':sum(x['amount']for x in items),'items':items}
def eligibility(s):
 out={}
 for who,p in s['parents'].items():
  h=p['normal_weekly_hours']*p['hours_ratio'];out[who]={'eligible':bool((p['contract_active']and h>=16 and h*52/12>=64)or p.get('job_search')),'reason':'employment/return/job-search subset','weekly_hours':h,'monthly_hours':h*52/12}
 return {'eligible':all(x['eligible']for x in out.values()),'parents':out,'scope':'actual Kashiwa subset; elsewhere explicit qualification scenario, not local confirmation'}
def score(s):
 total=0
 for p in s['parents'].values():
  h=p['normal_weekly_hours']*p['hours_ratio']*52/12;total+=6 if p.get('job_search')and not p['contract_active']else next((v for lo,v in [(160,30),(140,28),(120,26),(100,24),(80,22),(70,20),(64,18)]if h>=lo),0)
 if len(s['parents'])==1:total+=40
 if any(p['leave_requested']and s['elapsed_months']<p['return_month']for p in s['parents'].values()):total+=5
 if s['config']['sibling_enrolled']:total+=5
 return total

def care_advance(s,d,end,events):
 c=s['care'];a=c.get('application');n=s['elapsed_months'];cfg=s['config'];birth=date.fromisoformat(s['birth_date'])
 if a and c['status']in ['pending','not_admitted']and n>=a['eligible_at']and d>=birth+timedelta(days=57)and(a.get('last_review')is None or d.month==4):
  sc=score(s);cut=cfg['care_cutoff_april']if d.month==4 else cfg['care_cutoff_midyear'];affinity=random_key(s['seed'],0,'persistent_care_fit_v02',s['household']['municipality_code']).uniform(-10,10);resource=cfg['care_access_scenario']=='available'or(cfg['care_access_scenario']=='constrained'and sc+affinity>=cut);granted=eligibility(s)['eligible']and resource;c['status']='enrolled'if granted else'not_admitted';c['hours_weekly']=50 if granted else 0;a['last_review']=n
  if granted:c['return_due']=n+1;c['search_due']=n+3
  events.append({'type':'care_selection','result':'granted'if granted else'not_admitted','calendar_channel':'april'if d.month==4 else'midyear','score':sc,'supply_cutoff_scenario':cut,'persistent_fit_scenario':affinity,'statistical_admission_probability':None,'scope':'partial Kashiwa-like priority plus explicit resource scenario; no waitlist-derived probability'})
 if c['status']=='enrolled':
  missed=any(p['leave_requested']and n<p['return_month']for p in s['parents'].values())and n>c.get('return_due',n);search=any(p.get('job_search')and not p['contract_active']for p in s['parents'].values())and n>=c.get('search_due',n+1)
  if not eligibility(s)['eligible']or missed or search:c['status']='needs_eligibility_review';c['hours_weekly']=0;events.append({'type':'care_eligibility_review','requires_decision':True,'scope':'Kashiwa deadline subset or unverified other-local scenario'})
def employment(s,d,end,events):
 n=s['elapsed_months'];birth=date.fromisoformat(s['birth_date']);cfg=s['config']
 for who,p in s['parents'].items():
  p['employee_eligible_estimate']=insured(p,d,cfg);p['employment_insured_estimate']=p['contract_active']and p['employment_type']in EMP and p['normal_weekly_hours']>=20;p['maternity_days']=0;p['parental_days']=0;p['paternity_days_in_month']=0
  if not p['contract_active']:p['state']='nonemployed';p['planned_weekly_hours']=0;continue
  start=date.fromisoformat(p['leave_start_date']);finish=add_month(month_first(birth),p['return_month'])-timedelta(days=1)if who=='mother'else start+timedelta(days=p['father_leave_days']-1)
  if p['leave_requested']and d>finish and not p['leave_end_evaluated']:
   p['leave_end_evaluated']=True;ind,r=row(p,'ending');prob=min(1,(1-r['values'][1 if who=='mother'else 4]/100)*cfg['leave_exit_scale'])
   if cfg['employment_transition_mode']=='leave_end_conditional'and not p.get('player_return_override')and random_key(s['seed'],n,'leave_end_v02',who).random()<prob:
    p.update(contract_active=False,employee_contract=False,state='nonemployed',employee_eligible_estimate=False,benefit_eligible_estimate=False,leave_requested=False,planned_weekly_hours=0);events.append({'type':'employment_exit_at_leave_end','person':who,'probability':prob,'source_industry':ind,'scope':'conditional2024FY leave ending transported; not monthly hazard'});continue
  if who=='mother'and p['employee_contract']:p['maternity_days']=rules.overlap(birth,birth+timedelta(days=56),d,end)
  legal_end=add_month(birth,p.get('extension_to',12))-timedelta(days=1);p['parental_days']=rules.overlap(start,min(finish,legal_end),d,end)if p['leave_requested']else 0;p['paternity_days_in_month']=p['parental_days']if who=='father'else 0
  pre=rules.overlap(birth-timedelta(days=41),birth-timedelta(days=1),d,end)if who=='mother'and p['employee_contract']else 0;absent=p['maternity_days']+p['parental_days']+pre;p['state']='maternity'if p['maternity_days']else'parental_leave'if p['parental_days']and who=='mother'else'paternity_leave'if p['parental_days']else'working'
  if p['leave_requested']and d>legal_end and d<=finish:p['state']='unpaid_care_interruption';p['planned_weekly_hours']=0;events.append({'type':'leave_plan_exceeds_evidenced_entitlement','person':who,'requires_decision':True})
  else:p['planned_weekly_hours']=p['normal_weekly_hours']*p['hours_ratio']*max(0,1-absent/calendar.monthrange(d.year,d.month)[1])
 for who,p in s['parents'].items():
  q=s['parents'].get('father'if who=='mother'else'mother');p['dependent_spouse_scenario']=bool(not p['employee_eligible_estimate']and q and q['employee_eligible_estimate']and s['household']['legal_birth_status']=='marital'and(p['normal_annual']if p['contract_active']else 0)<1300000)
def measure(s,time,events):
 for who,p in s['parents'].items():
  t=time['parents'][who];worked=t['work']>0;leave=p['maternity_days']+p['parental_days']>0;conflict=t['work_suppressed_for_care']>0
  if conflict and not leave:p['state']='working_care_constrained'if worked else'unpaid_care_interruption'
  if conflict:events.append({'type':'care_work_conflict','person':who,'requested_hours':t['requested_work'],'actual_hours':t['work'],'unpaid_hours':t['work_suppressed_for_care'],'employer_permission':'unverified contract-retention scenario','requires_decision':True})
  status='job_seeking'if not p['contract_active']and p.get('job_search')else'outside_labour_force'if not p['contract_active']else'maternity_leave'if p['maternity_days']and not worked else'parental_leave'if leave and not worked else'working'if worked else'job_attached_zero_work_unpaid';lfs=True if worked or(leave and(p['employee_eligible_estimate']or p['benefit_eligible_estimate']))else False if not p['contract_active']else None
  p['employment_measurement']={'status':status,'contract_continues':p['contract_active'],'actually_worked':worked,'on_maternity_leave':p['maternity_days']>0,'on_parental_leave':p['parental_days']>0,'short_time_contract':p['hours_ratio']<1,'unpaid_interruption':conflict or status=='job_attached_zero_work_unpaid','lfs_employed_proxy':lfs,'income_positive':p['actual_gross_this_month']>0,'employment_type':p['employment_type'],'definition_scope':'monthly LFS-like proxy; unpaid job attachment unknown, not last-week survey'};p['previous_work']=t['work'];p['previous_care']=t['active_care']
def care_fee(s,d,levy,non_taxable):
 city=s['household']['municipality_code'];rank=max(1,sum(1 for p in s['persons']if p['person_id']not in s['parents']and p.get('supported',p.get('co_resident'))and p.get('date_of_birth')and 0<=(age_months(p['date_of_birth'],d)or 0)<22*12 and p.get('role')!='co_resident_grandparent'))
 if city=='12217':v=rules.fee(city,levy,rank,non_taxable,len(s['parents'])==1)['amount'];return {'amount':v,'cash_charge':v,'scope':'Kashiwa standard fee conditional on estimated tax/support; annual freeze outsideFY2026','source':'raw/kashiwa_admission_2026.pdf pp33-34','rank_used':rank}
 if city in ['13111','13107','13204']or non_taxable:return {'amount':0,'cash_charge':0,'scope':'verified ordinary authorized-care exemption given qualifications; extras separate','source':'raw/ota_fees.html, sumida_fees.html, mitaka_fees.html or national_care.pdf'}
 return {'amount':None,'cash_charge':round(71300*s['config']['unknown_fee_quantile']),'scope':'UNSUPPORTED local fee; numerical reference bracket is not a local observation or national legal bound','scenario_reference_bracket':[0,71300],'actual_local_fee_identified':False}
