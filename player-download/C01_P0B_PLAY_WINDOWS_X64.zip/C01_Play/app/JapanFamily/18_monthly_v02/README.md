# A3.0-0.2 月次研究エンジン

正式なA3.0-0.1を `17_monthly` に保持し、新版はこのディレクトリへ追加した。研究版であり `financially_playable=false`、`newborn_full_joint_externally_validated=false`。240か月は状態容器の構造上限であり、2歳以降の実証済み期間ではない。

Python3.11以上。依存は親ディレクトリのrequirements群に加えてopenpyxl、PyMuPDF。インストール済みデータから生成するときは追加取得やDB書換え不要。

```bash
cd JapanFamily/18_monthly_v02
python3 engine.py --pref 13 --seed demo --months 24 > family24.json
python3 api.py --port 8769
```

`POST /initialize` は `prefecture_code,conditions,seed,birth_date,scenario,include_region,initial_family` を受け取る。条件はA2.5 APIへ引き継ぐ。2026年の12出生月に対応するが、A2.5制度窓外では出生月の世帯構成と10月アンカーの自動家計を接合した明示推定。入力家庭の原版表記A2.5-0.1をr2観測値へ偽装しない。

`POST /step` は `{state,actions}`、`POST /simulate` は `{state,months,actions_by_month,retain_journal,stop_on_decision}`。`POST /compare` は `{state,months,branches}`。actions_by_monthのキーは経過月整数の文字列。`run`既定は未解決意思決定を記録して進行する研究モード。ゲーム用途では `stop_on_decision=true` を指定し、許可されていない無給中断等で停止させる。

```python
from engine import Engine
engine = Engine()
s = engine.initialize('12', seed='example', birth_date='2026-04-01')
r = engine.run(s,24,{'0':[{'type':'request_return','person':'mother','value':6}],
                      '5':[{'type':'request_relative_support'}]})
```

`decline_parental_leave` は育休辞退。`request_return` は継続する就業先への復職希望。両者を同一視しない。産後休業や保育・雇用先の条件は残る。求職はオファーを発生させるだけで採用は `accept_job_offer`、転居オファーも `accept_move_offer` が別に必要。基準自動方針は採用オファーを翌月受諾する。全プレイヤー操作を監査する場合は `auto_actions=false`。

保育資源は `care_access_scenario=constrained/available/unavailable`。入園確率を測定したものではない。未知自治体の `care_fee.amount=null`、`cash_charge` は参照幅のシナリオ。`unknown_fee_quantile=0..1` を感度分析する。全国の法律上の料金上限を意味しない。

就業継続・実働・休業・無給育児中断・短時間契約・求職を `parents.*.employment_measurement` で分離。`lfs_employed_proxy=None` は無給雇用継続等で統計上の休業者判定が不明。統計の調査週を月次値と同義にしない。

`cash_rules.py` が普通給与純入金・源泉・育休給付単位を扱う。給与は年額12分割の参照契約、賞与アダプタ未完成のため `bonus_share!=0` はエラー。最終年税額、全控除、年末調整、各地の国保・住民税通知と徴収暦、育休終了時標準報酬改定は未完成。柏以外の国保・住民税は柏の比較基準シナリオ。家計現金不足を実人口の発生率として使用しない。

```bash
python3 tests.py
python3 tests_extra.py
python3 tests_v02.py
python3 validate_v02.py 220
python3 experiments_v02.py
python3 analyze_v02.py
python3 catalogue_v02.py
```

全国試行は47×220=10340家庭×24か月。県均等抽選・12出生月の回転であり、全国分布は `birth_weighted_distributions_v02.json` の2025出生重み付き推計を使用。2026年実測の出生月構成ではない。`elapsed=6` の月次スナップショットは生後5か月の月末・翌月開始時に6か月（1日出生）。時点の意味を比較台帳に記載。

`acquire_v02.py` は一次資料取得、`compile_v02.py` は所得×家族費目平均と産業別育休統計をコンパイル。新たな公表版を無条件に上書きせず出典ハッシュの変更とモデル版を管理すること。給付資格・支給遅延・世帯支出分散などの仮定はdata/backlog_v02.jsonに残す。

`install_v02.py` は統計取得ではなく追加テーブルへの検証データ移植。既存55テーブルを行ハッシュで検査してから原子的に置き換える。既に配布DBへ導入済み。通常の生成に実行不要。

成果物の再検証は `verify_release_v02.py ZIP --expected-sha256 HASH --output VERIFY.json`。必ず新しい展開先を指定する。出力したZIPではなく、保存後に再取得した同一ZIPへ実行すること。

Bモデル、子どもの心理・能力、UIは実装していない。外部モデルへの接続は `monthly_history` の家庭資産負債、各親の時間/所得/状態、care、environment、decisions、events、model_versionを利用する。心理効果を固定係数として内包しない。
