# 再現・再検証・差分の適用

## 軽量パックだけで動く範囲

Python3.12、requirements-research.txtの実測版を使用。主要ランタイム依存はnumpy/scipy、検証にはjsonschema、資料再構築にopenpyxl/PyMuPDF、図にmatplotlib。

```bash
python JapanFamily/21_child_b11/scripts/demo_standalone.py
python JapanFamily/21_child_b11/scripts/playback_example.py --family 1 --month 12
```

旧5.31GBデータを再取得せずにB単体の実行と、実生成された10家庭の親の記録の閲覧ができる。新しい47都道府県の家庭生成は旧統計DBを必要とする。

## 旧正式版に追加

B1.0のコードとデータをその正式手順で展開した既存ディレクトリを使う。別の巨大DBコピーは不要。

```bash
python JapanFamily/21_child_b11/scripts/apply_update.py --baseline /path/to/B10 --check-only
python JapanFamily/21_child_b11/scripts/apply_update.py --baseline /path/to/B10
```

この処理は71個のコード・DBピンを照合し、21_child_b11だけを新設する。既に同名のディレクトリがある場合は上書きしない。旧Bの状態を新Bへ直接ロードしない。出生設定・同じA初期家庭を使って再実行し、モデル版を分離する。

## 研究と全家庭の再実行

リポジトリ直下で実行する。ネットワーク取得は公開資料のみ。利用できない資料は取得失敗ログを残す。実行時の依存追加は不要だったため、環境設定ドラフトは変更していない。

```bash
python JapanFamily/21_child_b11/scripts/acquire_research.py
python JapanFamily/21_child_b11/scripts/acquire_fulltexts.py
python JapanFamily/21_child_b11/scripts/acquire_official.py
python JapanFamily/21_child_b11/scripts/acquire_who.py
python JapanFamily/21_child_b11/scripts/normalize_who.py
python JapanFamily/21_child_b11/scripts/acquire_scale_norms.py
python JapanFamily/21_child_b11/scripts/calibrate.py
python JapanFamily/21_child_b11/scripts/build_catalogues.py
PYTHONPATH=JapanFamily/21_child_b11 python -m unittest discover -s JapanFamily/21_child_b11/tests -v
python JapanFamily/21_child_b11/scripts/run_population.py --workers 3
python JapanFamily/21_child_b11/scripts/analyze_population.py
python JapanFamily/21_child_b11/scripts/verify_functional.py
python JapanFamily/21_child_b11/scripts/experiments.py
python JapanFamily/21_child_b11/scripts/sensitivity.py
python JapanFamily/21_child_b11/scripts/verify_preservation.py
python JapanFamily/21_child_b11/scripts/write_report.py
python JapanFamily/21_child_b11/scripts/package_release.py
python JapanFamily/21_child_b11/scripts/verify_saved.py
```

古い候補・異なるパラメータのシャードへ結果を混ぜない。変更時は新しい出力先を指定する。既存47シャードのうち正しく完了したものは再利用し、不完全な自分の出力シャードだけ再生成する。失敗家庭を別seedに置換しない。

## 生データキャッシュ

旧A/B原資料とDBは元の正式アーカイブが保持する。新しい公開本文・公式HTML/PDFはdata/rawに保存済み。軽量パックは原著・尺度の本文を転載せず、公開集計値・メタデータ・取得URL・SHA256を含む。研究の再構築には取得スクリプトで同じ資料を取得し、保存されたハッシュを照合する。ホスト側の更新で本文ハッシュが変わった場合は同一資料と無条件に見なさない。

## 大規模保存と独立検査

データパックは新しい47シャードだけ。旧5.31GBは含めない。双方に同じbundle_idとファイルごとのSHA256を保存する。保存後検査は保存されたZIPを読み、CRCとハッシュを確認し、別作業場所へSQLiteを順次展開する。同時に全DBを複製せず、1シャードずつ整合性・外部キー・全月次ハッシュを検査し、47家庭の出生再生成と12+12再開を確認する。独立検査結果はZIP生成後の外付けJSONに保存する。
