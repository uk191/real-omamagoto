# 実日齢・家庭接続・保存API

## 日付の契約

A3のネイティブ会計は暦月単位で、出生月の1日に初期化される。Bは実際の出生日時点から始まり、出生前の曝露は生成しない。`A_accounting_through`は完了したA会計の境界、Bの`as_of_date`は実際の進行日付。両者の年月数を同じ変数に押し込めない。

同じ家庭IDと人物IDにより、Aの出生記録・性別・養育者とBを接続する。月のA計算から得た生活プロフィールを、その月の交差区間に一定と仮定してBへ渡す。これは日々の養育が実測されたという意味ではない。週の反応は週末側の日付のプロフィールを用い、日内・週内変化は識別していない。

月途中の24か月誕生日では、24個の暦月会計が完了し、誕生日を含む次の暦月の予測が私的な`forecast`に残る。Bは誕生日で停止する。予測内の誕生日後の会計・出来事を完了済みの生活や親の観測として返さない。A会計の日割り精算、出生前期間の家計の分離は未対応。この制限のまま「A/Bの会計と経験が完全に同じ日付で確定した」と宣言しない。

月末出生の月齢は、該当日がない月を月末に丸めた月次応当日で定義する。真の日数age_daysを必ず併記する。1月31日、2月28日、12月途中などをテストする。早産の医学的修正月齢を単純な係数で追加しない。

## 呼び出し例

リポジトリ直下から：

```python
import sys
sys.path.insert(0, 'JapanFamily/21_child_b11')
from child_b11.integrated import Simulation
s = Simulation.initialize('13', seed=123, birth_date='2026-10-17')
s.run(12, research_continue=True)
s.save('/tmp/B11-family.json')
r = Simulation.load('/tmp/B11-family.json')
r.run(12, research_continue=True)
parent = r.player_view('mother')
```

`research_continue=True`は未解決のA意思決定を明示して研究を続行するフラグ。解決済み・プレイ可能になったという意味ではない。Aの現在の月プロフィールを準備済みなら、同じ月へ遡って意思決定を加えない。A行動は次の会計境界で要求できる。途中日へは`advance_to_date`で進める。本版は途中月のA行動の自動キューや日割り採用を実装していない。3詳細体験は月初出生を選び、A行動の採用時点を曖昧にしない。

`step(a_actions=..., child_actions=..., research_continue=True)`は次の出生応当日まで進行。候補状態上で両モデルを処理し、入力拒否では元の状態を変更しない。`child_actions`のcaregiver_idは当該家庭のglobal IDのみ。

B単体は`Child.generate(...)`、`advance_one_month`、`advance_to(24)`、`advance_to_date`、`player_view`、`save/load`で動く。`research_snapshot`と`probe`は研究者専用で、ゲームの親に返さない。外部身体測定は`record_measurement`で観察者・通知先・出典を指定する。

## 増分DB

b11_caseは家庭の元A状態、元B状態、ID、設定、地域重みを保持。b11_monthは24個の月次内部状態・観察差分・出来事・曝露とSHA256。b11_a_periodはネイティブAの完了会計、人物、意思決定、取引。b11_checkpointは12/24か月の継続に必要な状態と未完了月の私的予測を保持。SQLiteの外部キーはrun_idを参照する。

巨大な旧DBのテーブルをコピーしない。旧モデルはdata/baseline_pins.jsonとlegacy_artifact_pins.jsonのハッシュで参照する。47個のSQLiteを集合DBとして扱う。都道府県別シャードは同一のモデル・パラメータハッシュに固定し、中断したシャードだけ再開する。失敗家庭を別の家庭へ抽選し直さない。

復元は`child_b11.storage.restore(db, run_id, 12/24)`。初期状態、チェックポイント、月次の観察・出来事差分、A暦月行から研究状態を再構築する。47都道府県で出生からの再生成、保存12+12、保存24を完全比較する。

B_delta.observed_behaviorsは最後に処理した日付区間の真の行動サンプル。月途中の分割では月全体の全週を含むとは限らない。月次parent_observationsと出来事の観察差分は全分割区間を含む。統計ではこれを一日当たりの頻度に読み替えない。すべての週の真の行動が必要な研究は同一seedで再実行する。

SHA256は破損検出と版固定のためで、改変者への認証署名ではない。Pythonの研究用状態へアクセスできる利用者から内面を隠す本番セキュリティは別工程。
