"""Install only21_child_b11, after checking existing baseline pins; no overwrite."""
import argparse,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--baseline',type=Path,required=True);ap.add_argument('--check-only',action='store_true');args=ap.parse_args();base=args.baseline.resolve();pins=json.loads((ROOT/'data/baseline_pins.json').read_text())
for row in pins:
 p=base/row['path']
 if not p.exists()or sha(p)!=row['sha256']:raise SystemExit('Baseline missing/mismatched: '+str(p))
if args.check_only:print('BASELINE_PINS_OK',len(pins));raise SystemExit(0)
dest=base/'JapanFamily/21_child_b11'
if dest.exists():raise SystemExit('Destination already exists; preserve it and choose an assembled B1.0 baseline without21_child_b11')
shutil.copytree(ROOT,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
print('ADDED',dest,'; A/B1.0 files unchanged')
