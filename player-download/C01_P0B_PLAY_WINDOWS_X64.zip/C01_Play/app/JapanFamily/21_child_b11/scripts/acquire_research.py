"""NCBI primary metadata queries and accessible original full texts, saved by hash."""
import concurrent.futures,datetime as dt,hashlib,json,time,urllib.parse,urllib.request,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'data/raw';RAW.mkdir(exist_ok=True,parents=True)
QUERIES={
 'japan_sleep':'(Japan[Title/Abstract] OR Japanese[Title/Abstract]) AND (infant[Title/Abstract] OR toddler[Title/Abstract]) AND (sleep duration[Title/Abstract] OR sleep development[Title/Abstract])',
 'japan_temperament':'(Japan[Title/Abstract] OR Japanese[Title/Abstract]) AND (infant temperament[Title/Abstract] OR Infant Behavior Questionnaire[Title/Abstract])',
 'japan_development':'(Japan Environment and Children[Title/Abstract] OR Japanese[Title/Abstract]) AND (ASQ-3[Title/Abstract] OR developmental trajectories[Title/Abstract])',
 'growth_longitudinal':'(Japan[Title/Abstract] OR WHO[Title/Abstract]) AND (infant growth velocity[Title/Abstract] OR longitudinal growth standards[Title/Abstract])',
 'motor_WHO':'WHO Motor Development Study windows achievement motor milestones',
 'calming_transport':'infant calming maternal carrying transport response',
 'sleep_cohort':'normal sleep development infants two birth cohorts Paavonen',
 'temperament_stability':'infant temperament stability meta-analysis longitudinal',
 'japan_language':'(Japanese[Title/Abstract]) AND (infant[Title/Abstract] OR toddler[Title/Abstract]) AND (vocabulary development[Title/Abstract] OR language comprehension[Title/Abstract])',
 'feeding_JECS':'Japan infants breastfeeding complementary feeding longitudinal cohort',
 'parent_RCT':'parenting interventions first three years development systematic review meta analysis randomized',
 'individual_differences':'infancy attention exploration individual differences longitudinal predict intelligence meta analysis'
}


def fetch(url,name):
 path=RAW/name
 if path.exists():return path.read_bytes()
 for attempt in range(5):
  try:
   req=urllib.request.Request(url,headers={'User-Agent':'B11-research/1.0 (public research data audit)'})
   with urllib.request.urlopen(req,timeout=40)as r:data=r.read()
   path.write_bytes(data);return data
  except Exception:
   if attempt==4:raise
   time.sleep(1.2*(attempt+1))


def main():
 queries=[];all_ids=set(['39234187','22897933','31782528','34836365','35455866'])
 for key,query in QUERIES.items():
  url='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?'+urllib.parse.urlencode({'db':'pubmed','term':query,'retmode':'json','retmax':15})
  try:
   d=fetch(url,'search_'+key+'.json');result=json.loads(d)['esearchresult'];ids=result['idlist'];all_ids.update(ids);queries.append({'id':key,'query':query,'url':url,'total':result['count'],'retrieved_pmids':ids,'status':'metadata_search_not_systematic_review'})
   print(key,result['count'],ids[:4],flush=True)
  except Exception as e:queries.append({'id':key,'query':query,'error':repr(e)})
  time.sleep(.36)
 (ROOT/'data/research_queries.json').write_text(json.dumps(queries,ensure_ascii=False,indent=2)+'\n')
 ids=sorted(all_ids);articles=[]
 for batch in range(0,len(ids),40):
  url='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?'+urllib.parse.urlencode({'db':'pubmed','id':','.join(ids[batch:batch+40]),'retmode':'xml'})
  data=fetch(url,f'pubmed_batch_{batch//40}.xml');xml=ET.fromstring(data)
  for a in xml.findall('PubmedArticle'):
   pmid=a.findtext('./MedlineCitation/PMID');title=''.join(a.find('./MedlineCitation/Article/ArticleTitle').itertext());abstract='\n'.join(''.join(x.itertext())for x in a.findall('./MedlineCitation/Article/Abstract/AbstractText'))
   article_ids={n.attrib['IdType']:n.text for n in a.findall('./PubmedData/ArticleIdList/ArticleId')}
   articles.append({'pmid':pmid,'title':title,'primary_article_ids':article_ids,'date':ET.tostring(a.find('./MedlineCitation/Article/Journal/JournalIssue/PubDate'),encoding='unicode'),
     'abstract':abstract,'access':'primary_pubmed_metadata_and_abstract; fulltext_requires_separate_verification','raw_file':f'data/raw/pubmed_batch_{batch//40}.xml','raw_sha256':hashlib.sha256(data).hexdigest()})
  time.sleep(.4)
 (ROOT/'data/research_metadata.json').write_text(json.dumps({'retrieved_UTC':dt.datetime.now(dt.timezone.utc).isoformat(),'articles':articles,'review_scope':'targeted searches, not exhaustive systematic review; title/abstract availability is not full-text or numerical-table verification'},ensure_ascii=False,indent=2)+'\n')
 print('TOTAL_PRIMARY_METADATA',len(articles),flush=True)

if __name__=='__main__':main()
