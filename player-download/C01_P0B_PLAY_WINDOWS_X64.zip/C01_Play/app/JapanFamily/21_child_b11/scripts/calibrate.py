"""Rebuild numerical parameters from pinned, cited published aggregates, not scale items."""
import hashlib,json,math,sys,xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from scipy.optimize import least_squares
from scipy.special import ndtr,ndtri
ROOT=Path(__file__).resolve().parents[1];OLD=ROOT.parent/'19_child_b10'
def main():
 ref=json.loads((OLD/'data/japan_reference.json').read_text());fits={}
 nodes,weights=np.polynomial.legendre.leggauss(16)
 for name,f in ref['milestone_fits'].items():
  raw=f['raw'];mid=np.array([r['age_midpoint_months'] for r in raw]);y=np.array([r['pass_proportion'] for r in raw]);ages=mid[:,None]+nodes[None,:]*.5
  def pred(theta):return ndtr((np.log(ages)-theta[0])/math.exp(theta[1]))@weights/2
  fit=least_squares(lambda t:pred(t)-y,[f['log_mu'],math.log(f['log_sd'])],bounds=([math.log(.5),math.log(.03)],[math.log(36),math.log(2)]))
  mu,ls=map(float,fit.x);fits[name]={'log_mu':mu,'log_sd':math.exp(ls),'median_months':math.exp(mu),'raw':raw,'source_id':f['source_id'],'bin_integration':'uniform age within published one-month bin; unidentified age composition','rmse':float(np.sqrt(np.mean((pred(fit.x)-y)**2))),'old_midpoint_rmse':f['rmse_probability'],'sampling_uncertainty':'denominators/design SE unavailable; unweighted LS, not binomial precision','interpretation':'cross-sectional parent-report proxy, not objective neurological onset'}
 articles=[]
 for p in sorted((ROOT/'data/raw').glob('PMC*.xml')):
  r=ET.parse(p).getroot();pmc=p.stem;lic=r.find('.//front//permissions')
  tables=[]
  for t in r.findall('.//table-wrap'):
   tables.append({'id':t.get('id'),'caption':' '.join(t.findtext('caption','').split()) or ' '.join(''.join(t.find('caption').itertext()).split()) if t.find('caption') is not None else '', 'rows':[[' '.join(''.join(c.itertext()).split()) for c in row if c.tag in ['td','th']] for row in t.findall('.//tr')]})
  articles.append({'pmc':pmc,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'license':ET.tostring(lic,encoding='unicode') if lic is not None else None,'tables':tables})
 (ROOT/'data/extracted_article_tables.json').write_text(json.dumps(articles,ensure_ascii=False,indent=2))
 sleep_table=next(t for a in articles if a['pmc']=='PMC13388294' for t in a['tables'] if t['id']=='tab2')
 rows=sleep_table['rows'];sleep=[]
 for age,col,lo,hi in [(6,1,12,15),(12,3,11,14),(18,5,11,14)]:
  counts=[int(rows[k][col].replace(',','')) for k in [2,3,4]];n=sum(counts);q1=ndtri(counts[0]/n);q2=ndtri((counts[0]+counts[1])/n);sd=(hi-lo)/(q2-q1);mean=lo-sd*q1
  sleep.append({'age_months':age,'mean_hours':float(mean),'sd_hours':float(sd),'cutpoints':[lo,hi],'counts_observed':counts,'observed_n':n,'all_n':104062,'missing_count':int(rows[5][col].replace(',','')),'source':'PMID42487822 / PMC13388294 Table2','definition':'caregiver previous-day report; complete-case categories; non-national JECS2011–14 births','shape':'normal latent duration fitted to two aggregate cutpoints; 0..24h truncation; not empirical mean/SD'})
 params={'version':'B-1.1-research.1','milestone_fits':fits,'frailty_shape':4.,'frailty_covariance':'shared gamma1 + domain gamma1 + skill gamma2, all rate4; uncalibrated covariance','trait_monthly_retention':.97,'trait_retention_sensitivity':[.85,.97,.995],'growth_lengthscale_months':30.,'growth_lengthscale_sensitivity':[12.,30.,60.],'growth_process':'stationary Matern3/2 z and velocity; weekly grid; nondecreasing length/head projection; unidentified longitudinal law','sleep_anchors':sleep,'sleep_outside_6_to_18_months':'hold nearest anchor for software only; NOT calibrated at0..5 or19..24months','sleep_monthly_retention':.85,'behavior_weight':1.,'hypothetical_effects_default':False,'hypothetical_sleep_disruption_hours':1.,'hypothetical_comfort_logit':.5,'relationship_contact_effect':False,'future_skill_targets_at_birth':False,'assumed_observation_sensitivity':.85,'assumed_observation_false_positive':.1}
 (ROOT/'data/parameters.json').write_text(json.dumps(params,ensure_ascii=False,indent=2))
 print(json.dumps({'milestones':{k:{a:v[a] for a in ['median_months','rmse','old_midpoint_rmse']} for k,v in fits.items()},'sleep':sleep},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
