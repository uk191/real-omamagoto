import json,sys,os
from pathlib import Path
import numpy as np
os.environ.setdefault('MPLCONFIGDIR','/tmp/B11_matplotlib_cache')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/B11_xdg_cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'results/cohort_10340';OUT=ROOT/'results/figures';OUT.mkdir(exist_ok=True)
m=json.loads((DATA/'milestone_calibration.json').read_text());gap=json.loads((DATA/'observable_skill_calibration_gap.json').read_text());physical=json.loads((DATA/'physical_calibration.json').read_text());who=json.loads((ROOT/'data/WHO_motor_reference.json').read_text());families=json.loads((ROOT/'results/examples/parent_growth_records_10.json').read_text())
fig,axes=plt.subplots(2,2,figsize=(12,8.5),layout='constrained')
for ax,key,signal in [(axes[0,0],'walking_independently','takes_independent_steps'),(axes[0,1],'first_contextual_word','uses_contextual_word')]:
 p=m[key]['points'];x=[sum(r['age_bin'])/2 for r in p];ax.plot(x,[r['generated_midinterval']for r in p],label='Generated capacity proxy');ax.scatter(x,[r['source_rate']for r in p],s=16,label='Japan2023 parent report (calibration)');ax.plot(x,[r['model_any_caregiver_first_positive_rate']for r in gap[signal]['points']],label='First observed by caregiver',ls='--');ax.set(title=key,xlabel='Age (months)',ylabel='Proportion');ax.set_ylim(0,1.02);ax.legend(fontsize=8)
ax=axes[1,0]
for metric in ['weight_kg','length_cm','head_circumference_cm']:
 rows=[r for r in physical if r['sex']=='female'and r['metric']==metric];ax.plot([r['month']for r in rows],[r['z_sd']for r in rows],label=metric)
ax.axhline(1,color='black',ls=':',lw=1);ax.set(title='Body rank spread; assumed longitudinal process',xlabel='Age (months)',ylabel='z-score SD (female)');ax.legend(fontsize=8)
ax=axes[1,1];values=np.array([[r['counts']['explores_available_space']['present']/r['counts']['explores_available_space']['sampled']if r['counts']['explores_available_space']['sampled']else np.nan for r in fam['months']]for fam in families]);im=ax.imshow(values,aspect='auto',vmin=0,vmax=1,origin='upper',extent=[.5,24.5,10.5,.5],cmap='viridis');ax.set(title='Parent records: exploration in sampled opportunities',xlabel='Age (months)',ylabel='Family ID (example1–10)');fig.colorbar(im,ax=ax,label='Reported / sampled; unvalidated observation model')
fig.suptitle('B-1.1 research: 10,340 households, 47 prefectures\nMarginal calibration, observable gaps and persistent differences; no full external-validity claim',fontsize=12)
fig.savefig(OUT/'calibration_and_parent_records.png',dpi=170);fig.savefig(OUT/'calibration_and_parent_records.pdf');plt.close(fig)
fig,ax=plt.subplots(figsize=(10,5),layout='constrained');mapping={'sitting_unsupported':'Sitting without support','standing_with_support':'Standing with assistance','crawling':'Hands-and-knees crawling','walking_independently':'Walking alone'}
for i,(key,label)in enumerate(mapping.items()):
 r=next(r for r in who['rows']if r['name']==label);p=r['points'];ax.plot([x['months']for x in p],[i-.12]*len(p),'o-',ms=3,color='tab:blue');q=m[key]['generated_onset_quantiles_months'];ax.plot([q['0.01'],q['0.5'],q['0.99']],[i+.12]*3,'o-',color='tab:orange')
ax.set_yticks(range(4),list(mapping));ax.set(xlabel='Age (months)',title='Independent WHO international observed percentiles vs Japan-calibrated proxy\nBlue: WHO1–99%; orange: generated1/50/99%; populations/definitions differ');ax.grid(axis='x',alpha=.2);fig.savefig(OUT/'WHO_independent_comparison.png',dpi=170);fig.savefig(OUT/'WHO_independent_comparison.pdf');print('FIGURES_SAVED')
