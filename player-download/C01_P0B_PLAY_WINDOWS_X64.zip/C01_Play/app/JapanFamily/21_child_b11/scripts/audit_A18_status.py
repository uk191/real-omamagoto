"""Native A's exact unresolved employment classification, not a B age claim."""
import collections,json,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11.storage import decode
counts=collections.Counter();n=0
for p in sorted((ROOT/'results/cohort_10340/shards').glob('*.sqlite')):
 c=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True);weights=dict(c.execute('SELECT run_id,geographic_weight FROM b11_case'))
 for rid,b in c.execute('SELECT run_id,payload FROM b11_a_period WHERE period=18'):
  r=decode(b);mother=r['A_month']['parents'].get('mother')
  if mother:counts[mother['employment_measurement']['status']]+=weights[rid];n+=1
 c.close()
out={'native_A_calendar_period':18,'mother_cases':n,'geographic_weighted_status':dict(counts),'unresolved_exact_status_share':counts['job_attached_zero_work_unpaid'],'source_field':'A_month.parents.mother.employment_measurement.status','B_age_not_equated_to_A_period':True,'external_validity_achieved':False,'causal_child_effects_applied':False}
(ROOT/'results/cohort_10340/A18_status_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False))
