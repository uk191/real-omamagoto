import hashlib,json,time,urllib.parse,urllib.request,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];RAW=ROOT/'data/raw'
SELECT=['36103560','34505173','41130623','41917429','36789883','39234187','22897933','33970913','34975680','40190042','42487822','30396332','31782528','34836365']

def main():
 metadata=json.loads((ROOT/'data/research_metadata.json').read_text())['articles'];out=[]
 for pmid in SELECT:
  row=next(a for a in metadata if a['pmid']==pmid);pmc=row['primary_article_ids'].get('pmc');record={'pmid':pmid,'pmc':pmc,'title':row['title'],'attempts':[]}
  if pmc:
   urls=['https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?'+urllib.parse.urlencode({'db':'pmc','id':pmc.removeprefix('PMC')}),'https://www.ebi.ac.uk/europepmc/webservices/rest/'+pmc+'/fullTextXML']
   for url in urls:
    try:
     with urllib.request.urlopen(url,timeout=35)as r:data=r.read();status=r.status
     xml=ET.fromstring(data)
     if xml.find('.//body')is None:raise ValueError('No article body, not verified full text')
     path=RAW/(pmc+'.xml');path.write_bytes(data)
     record.update({'url':url,'file':str(path.relative_to(ROOT)),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'access':'full_article_XML_with_body','tables':[{'id':t.get('id'),'label':t.findtext('label'),'caption':' '.join(t.find('caption').itertext())if t.find('caption')is not None else''}for t in xml.findall('.//table-wrap')]})
     (RAW/(pmc+'.txt')).write_text('\n'.join(' '.join(x.itertext())for x in xml.findall('.//body/sec')))
     break
    except Exception as e:record['attempts'].append({'url':url,'error':repr(e)})
    time.sleep(.5)
  out.append(record);(ROOT/'data/fulltext_acquisition.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(pmid,pmc,record.get('access','not_acquired'),record.get('bytes'),flush=True);time.sleep(.4)

if __name__=='__main__':main()
