"""Offline birth–24mo B demo; needs only lightweight pack, never old5GB data."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11 import Child
c=Child.generate(seed=20261016,birth_date='2026-10-17')
for month in range(24):c.advance_one_month({'caregivers':{'mother':{'observation_opportunity':.6}}})
view=c.player_view('mother');print(json.dumps({'child_id':view['child_id'],'as_of_date':view['as_of_date'],'observation_records':len(view['observations']),'last_observations':view['observations'][-3:],'note':'B standalone reference scenario; fresh A family generation requires pinned legacy baseline'},ensure_ascii=False,indent=2))
