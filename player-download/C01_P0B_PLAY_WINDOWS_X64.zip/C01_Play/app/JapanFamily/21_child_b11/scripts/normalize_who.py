import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];p=ROOT/'data/raw/mm_percentiles_table.pdf';text=p.with_suffix('.txt').read_text();names=['Sitting without support','Standing with assistance','Hands-and-knees crawling','Walking with assistance','Standing alone','Walking alone'];rows=[]
for i,name in enumerate(names):
 start=text.index(name);stop=text.index(names[i+1],start)if i+1<len(names)else len(text);block=text[start:stop];pts=[]
 pat=r'(\d+)(?:st|nd|rd|th)\s+(\d+)\s*\(\s*(\d+),\s*(\d+)\s*\)\s+([\d.]+)\s*\(\s*([\d.]+),\s*([\d.]+)\s*\)'
 for m in re.finditer(pat,block):
  q,days,dl,dh,mo,ml,mh=m.groups();pts.append({'percentile':int(q),'days':int(days),'days95CI':[int(dl),int(dh)],'months':float(mo),'months95CI':[float(ml),float(mh)]})
 assert len(pts)==11,(name,len(pts));rows.append({'name':name,'points':pts})
(ROOT/'data/WHO_motor_reference.json').write_text(json.dumps({'source_file':str(p.relative_to(ROOT)),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_url':next(x['url']for x in json.loads((ROOT/'data/WHO_acquisition.json').read_text())if x['file'].endswith('mm_percentiles_table.pdf')),'source':'WHO Child Growth Standards; PMID16817682; authors WHO Multicentre Growth Reference Study Group','role':'independent held-out international reference, never calibration','month_unit':'WHO30.4375 days; published table rounded','rows':rows},ensure_ascii=False,indent=2));print(len(rows),sum(len(r['points'])for r in rows))
