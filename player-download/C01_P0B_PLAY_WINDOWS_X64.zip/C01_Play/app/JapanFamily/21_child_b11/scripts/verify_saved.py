"""Verify saved ZIP bytes via separate extraction and all47 incremental SQLite files.

One fresh shard at a time avoids another multi-GB duplicate. All functional
imports come from extracted code. The baseline is only linked read-only input.
"""
import argparse,gzip,hashlib,json,os,sqlite3,subprocess,sys,time,zipfile
from pathlib import Path
SOURCE=Path(__file__).resolve().parents[1];REPO=SOURCE.parent.parent

def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--artifacts',type=Path,default=REPO/'artifacts');ap.add_argument('--baseline',type=Path,default=REPO);ap.add_argument('--destination',type=Path,default=REPO.parent/'scratch/B11_saved_release_verify');args=ap.parse_args();meta=json.loads((args.artifacts/'B1.1_ARCHIVES.json').read_text());dest=args.destination
 if dest.exists():raise SystemExit('Fresh destination required; preserve existing inspection')
 dest.mkdir(parents=True);started=time.time();archives=[]
 for a in meta['archives']:
  p=args.artifacts/a['filename'];assert sha(p)==a['sha256']
  with zipfile.ZipFile(p)as z:assert z.testzip()is None
  archives.append({'filename':p.name,'sha256':a['sha256'],'bytes':p.stat().st_size,'CRC':True})
 with zipfile.ZipFile(args.artifacts/'B1.1_CODE_AND_REPORTS.zip')as z:
  cm=json.loads(z.read('B11_CODE_MANIFEST.json'));assert cm['bundle_id']==meta['bundle_id']
  for name,info in cm['files'].items():
   parts=Path(name).parts;assert not Path(name).is_absolute()and '..'not in parts
   p=Path(z.extract(name,dest));assert sha(p)==info['sha256']
 project=dest/'JapanFamily';root=project/'21_child_b11'
 # All nonbundled original A material stays at the baseline; no old DB copy.
 for p in (args.baseline/'JapanFamily').iterdir():
  target=project/p.name
  if not target.exists():target.symlink_to(p.resolve(),target_is_directory=p.is_dir())
 env=dict(os.environ);env['PYTHONPATH']=str(root)
 demo=subprocess.run([sys.executable,str(root/'scripts/demo_standalone.py')],cwd=dest,env=env,capture_output=True,text=True);assert demo.returncode==0,demo.stderr
 sys.path.insert(0,str(root))
 from child_b11.integrated import Simulation,a18_engine_class
 from child_b11.engine import digest
 from child_b11.storage import decode,restore
 assert Path(sys.modules['child_b11.engine'].__file__).resolve().is_relative_to(dest)
 eng=a18_engine_class()();checks=[];total_cases=total_months=total_a=0
 with zipfile.ZipFile(args.artifacts/'B1.1_INCREMENTAL_DATA.zip')as z:
  dm=json.loads(z.read('B11_DATA_MANIFEST.json'));assert dm['bundle_id']==cm['bundle_id'];assert hashlib.sha256(json.dumps(dm['files'],sort_keys=True).encode()).hexdigest()==cm['paired_tree_sha256'];assert hashlib.sha256(json.dumps(cm['files'],sort_keys=True).encode()).hexdigest()==dm['paired_tree_sha256']
  for name,info in dm['files'].items():
   assert '..'not in Path(name).parts and not Path(name).is_absolute();path=Path(z.extract(name,dest));assert sha(path)==info['sha256'];db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not db.execute('PRAGMA foreign_key_check').fetchall();assert db.execute('SELECT count(*) FROM b11_failure').fetchone()[0]==0
   cases=db.execute('SELECT count(*) FROM b11_case').fetchone()[0];months=0
   assert not db.execute('SELECT run_id FROM b11_month GROUP BY run_id HAVING count(*)<>24').fetchall()
   for rid,month,blob,h in db.execute('SELECT run_id,month,payload,sha256 FROM b11_month ORDER BY run_id,month'):
    r=decode(blob);assert digest(r)==h and r['month']==month;assert r['B_delta']['as_of_date']==r['end'];assert not r['scenario_effects'];months+=1
   case=db.execute('SELECT run_id,prefecture,configuration,identity,initial_a FROM b11_case ORDER BY run_id LIMIT 1').fetchone();rid,pref,config,identity,ia=case;config=decode(config);identity=decode(identity)
   final=restore(db,rid,24,engine=eng);middle=restore(db,rid,12,engine=eng);middle.run(12,research_continue=True);fresh=Simulation.initialize(pref,seed=config['seed'],birth_date=identity['birth_date'],engine=eng);fresh.run(24,research_continue=True);assert final.payload()==middle.payload()==fresh.payload(),pref
   native=decode(ia)
   for blob, in db.execute('SELECT payload FROM b11_a_period WHERE run_id=? ORDER BY period',(rid,)):
    p=decode(blob);nxt=eng.step(native,p['requested_actions'],retain_journal=True);assert nxt['last_month']==p['A_month'] and nxt['persons']==p['A_persons_asof'] and nxt['journal']==p['A_transactions'];nxt['journal']=[];nxt['monthly_history']=[nxt['last_month']];native=nxt
   assert native==final.a;acount=db.execute('SELECT count(*) FROM b11_a_period').fetchone()[0];total_cases+=cases;total_months+=months;total_a+=acount
   if pref=='01':
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(root/'tests'),'-v'],cwd=dest,env=env,capture_output=True,text=True);(root/'results/independent_saved_tests.log').write_text(tests.stdout+tests.stderr);assert tests.returncode==0,tests.stderr
   checks.append({'prefecture':pref,'cases':cases,'B_months':months,'A_completed_periods':acount,'SQLite_integrity':'ok','foreign_keys':True,'all_monthly_record_SHA256':True,'fresh24_equals_saved24_equals_saved12plus12':True,'native_A24_replay':True,'sample_run_id':rid,'payload_sha256':digest(final.payload())});db.close();path.unlink();print('SAVED_DB_VERIFIED',pref,cases,months,flush=True)
 records=json.loads((root/'results/examples/parent_growth_records_10.json').read_text());references=0
 for fam in records:
  with gzip.open(root/'results/examples'/f'family_{fam["run_id"]}.json.gz','rt',encoding='utf-8')as f:payload=json.load(f)
  for m in fam['months']:
   for ref in m['source_refs']:
    i=int(ref['json_pointer'].rsplit('/',1)[1]);obj=payload['records'][m['month']-1]['parent_observations'][i];assert digest(obj)==ref['sha256'];references+=1
 assert len(checks)==47 and total_cases==10340 and total_months==total_a==248160
 result={'bundle_id':meta['bundle_id'],'saved_zip_SHA256_and_CRC':archives,'fresh_extraction_directory':str(dest),'data_extracted_and_verified_one_shard_at_a_time':True,'old_DB_copies_created':0,'extracted_code_imported':True,'standalone_demo':True,'new18_tests_from_saved_pack':True,'cases':total_cases,'B_months':total_months,'A_completed_calendar_periods':total_a,'all47_SQLite_integrity_foreign_keys_and_record_hashes':True,'birth24_and_saved12plus12_replays':checks,'parent_history_families':len(records),'parent_text_trace_references_checked':references,'legacy_preservation':json.loads((root/'results/legacy_preservation.json').read_text()),'functional_release_verified':True,'national_joint_external_validity':False,'psychological_behavior_external_validity':False,'clinical_or_causal_validity':False,'A_financial_playability':False,'two_to_six_year_model_validated':False,'seconds':time.time()-started}
 p=args.artifacts/'B1.1_RELEASE_VERIFICATION.json';p.write_text(json.dumps(result,ensure_ascii=False,indent=2));(SOURCE/'results/release_verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));sums=args.artifacts/'B1.1_SHA256SUMS.txt';sums.write_text(sums.read_text()+sha(p)+'  '+p.name+'\n');print('SAVED_RELEASE_VERIFIED',total_cases,total_months,round(result['seconds'],1),flush=True)
if __name__=='__main__':main()
