"""Independent rerun/DB restore/native-A replay from saved cohort shards."""
import argparse,copy,json,sqlite3,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11.integrated import Simulation,a18_engine_class
from child_b11.engine import digest
from child_b11.storage import decode,restore

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--data',type=Path,default=ROOT/'results/cohort_10340');ap.add_argument('--output',type=Path,default=ROOT/'results/replays_47.json');args=ap.parse_args();eng=a18_engine_class()();results=[];start=time.time()
 for path in sorted((args.data/'shards').glob('pref_*.sqlite')):
  db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);case=db.execute('SELECT run_id,prefecture,seed,identity,configuration,initial_a,initial_b FROM b11_case ORDER BY run_id LIMIT 1').fetchone();rid,pref,seed,identity,config,ia,ib=case;config=decode(config);identity=decode(identity)
  final=restore(db,rid,24,engine=eng);middle=restore(db,rid,12,engine=eng);middle.run(12,research_continue=True)
  fresh=Simulation.initialize(pref,seed=config['seed'],birth_date=identity['birth_date'],engine=eng);fresh.run(24,research_continue=True)
  assert final.payload()==middle.payload()==fresh.payload(),(pref,rid,'fresh/resume mismatch')
  # Verify every completed household accounting period independently of B code.
  a=decode(ia)
  for blob, in db.execute('SELECT payload FROM b11_a_period WHERE run_id=? ORDER BY period',(rid,)):
   p=decode(blob);nxt=eng.step(a,p['requested_actions'],retain_journal=True);assert nxt['last_month']==p['A_month'];assert nxt['persons']==p['A_persons_asof'];assert nxt['journal']==p['A_transactions'];nxt['journal']=[];nxt['monthly_history']=[nxt['last_month']];a=nxt
  assert a==final.a
  v=final.player_view();assert 'latent_state' not in json.dumps(v);assert all(x['date']<=v['as_of_date']for x in v['child']['observations'])
  results.append({'prefecture':pref,'run_id':rid,'birth_date':identity['birth_date'],'fresh24_equals_stored24_equals_saved12plus12':True,'native_A24_calendar_periods_exact':True,'B_exact24month_birthday':v['as_of_date'],'completed_A_accounting_through':v['A_accounting_through'],'uncommitted_A_forecast_until':final.forecast['month']if final.forecast else None,'final_payload_sha256':digest(final.payload())});db.close();print('REPLAY',pref,flush=True)
 args.output.write_text(json.dumps({'count':len(results),'seconds':time.time()-start,'replays':results},ensure_ascii=False,indent=2));print('ALL_REPLAY',len(results),flush=True)
if __name__=='__main__':main()
