"""Research-only assumed-parameter sweeps, not confidence intervals or causal estimates."""
import json,math,sys
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11.engine import Child,digest,normal
N=200
rows=[]
for name,values in [('growth_lengthscale_months',[12.,30.,60.]),('trait_monthly_retention',[.85,.97,.995]),('frailty_shape',[2.,4.,8.])]:
 for value in values:
  data=[]
  for seed in range(2101,2101+N):
   c=Child.generate(seed=seed);s=c._state;s['transition_parameters']['parameters'][name]=value
   s['generation_record']['research_override']={'parameter':name,'value':value,'evidence':'unidentified sensitivity scenario, not fitted confidence interval'}
   if name=='growth_lengthscale_months':
    for k in s['growth_process']['vectors']:s['growth_process']['vectors'][k][1]=normal(seed,'growth_velocity',k)/value
    c._forecast_growth()
   if name=='frailty_shape':
    rng=np.random.default_rng(int(digest([seed,'frailty-v1'])[:16],16));shared=float(rng.gamma(value/4,1/value));domains={d:float(rng.gamma(value/4,1/value))for d in ['motor','language']}
    for k in s['transition_parameters']['frailty']:s['transition_parameters']['frailty'][k]=shared+domains['language'if k=='first_contextual_word'else'motor']+float(rng.gamma(value/2,1/value))
   birth=dict(s['initial_dispositions']);c.advance_to(6);z6=s['physical_health']['growth_z']['length'];c.advance_to(24);dev=s['developmental_state']['milestones'];walk=dev.get('walking_independently');word=dev.get('first_contextual_word')
   data.append({'seed':seed,'birth_reactivity':birth['reactivity'],'reactivity24':s['latent_state']['reactivity'],'length_z6':z6,'length_z24':s['physical_health']['growth_z']['length'],'walk_months':sum(walk['age_days_interval'])/2/30.4375 if walk else None,'word_months':sum(word['age_days_interval'])/2/30.4375 if word else None,'growth_constraints':s['physical_health']['monotonic_constraint_count']})
  rows.append({'parameter':name,'value':value,'n':N,'trait_birth24_r':float(np.corrcoef([r['birth_reactivity']for r in data],[r['reactivity24']for r in data])[0,1]),'growth_length6to24_r':float(np.corrcoef([r['length_z6']for r in data],[r['length_z24']for r in data])[0,1]),'walking_quantiles_complete_cases':np.quantile([r['walk_months']for r in data if r['walk_months']is not None],[.05,.5,.95]).tolist(),'walking_censored24':sum(r['walk_months']is None for r in data),'mean_growth_weekly_constraints':float(np.mean([r['growth_constraints']for r in data])),'individual_results':data})
  print(name,value,flush=True)
(ROOT/'results/sensitivity.json').write_text(json.dumps({'interpretation':'Unidentified numerical assumptions varied with same initial seeds; no real-world treatment or fitted confidence interval','runs':rows},ensure_ascii=False,indent=2))
