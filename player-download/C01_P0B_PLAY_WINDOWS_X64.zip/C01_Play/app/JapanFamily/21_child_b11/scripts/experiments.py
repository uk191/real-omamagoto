"""All narratives are deterministic projections of recorded observations/actions."""
import copy,gzip,json,sys,tempfile
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11.integrated import Simulation,a18_engine_class
from child_b11.engine import Child,digest,MILESTONES
LABELS={'crying':'泣いていた','settles_after_comfort':'慰めの場面で落ち着いた','orients_to_unfamiliar_object':'見慣れない物へ注意を向けた','looks_toward_voice':'声の方を見た','difficulty_settling':'寝つく場面で落ち着きにくかった','takes_independent_steps':'ひとりで足を運んだ','uses_contextual_word':'場面に合う言葉を使った','sustains_object_attention':'物へ注意を向け続けた','withdraws_from_intense_stimulus':'強い刺激から身を引いた','explores_available_space':'周囲を探索した'}
def save(sim,path):
 with gzip.open(path,'wt',encoding='utf-8')as f:json.dump(sim.payload(),f,ensure_ascii=False,separators=(',',':'))
def bio(s):return {k:s.child._state[k]for k in ['physical_health','latent_state','developmental_state','emotion_regulation','sleep']}
def milestone_ages(s):return {k:sum(v['age_days_interval'])/2/30.4375 for k,v in s.child._state['developmental_state']['milestones'].items()}
def parent_month(sim,r,cg):
 reports=[(i,x)for i,x in enumerate(r['parent_observations'])if x['observer_id']==cg];counts={k:{'sampled':sum(k in x['behaviors']for i,x in reports),'present':sum(x['behaviors'].get(k,False)for i,x in reports)}for k in LABELS};parts=[f'{LABELS[k]}場面は{v["sampled"]}件中{v["present"]}件'for k,v in counts.items()if v['sampled']]
 return {'month':r['month'],'date':r['end'],'observation_records':len(reports),'counts':counts,'text':'。'.join(parts)+'。' if parts else 'この期間に届いた観察記録はありません。','source_refs':[{'file':f'family_{sim.identity["run_id"]}.json.gz','json_pointer':f'/records/{r["month"]-1}/parent_observations/{i}','sha256':digest(x)}for i,x in reports]}
def main():
 out=ROOT/'results/examples';out.mkdir(exist_ok=True,parents=True);eng=a18_engine_class()();summary={}
 common=dict(prefecture_code='13',seed='B11-same-family',birth_date='2026-10-17',engine=eng)
 A=[];afinal=None
 for seed in range(1201,1233):
  s=Simulation.initialize(**common,child_seed=seed);s.run(24,research_continue=True)
  if afinal is None:afinal=digest(s.a)
  assert digest(s.a)==afinal
  rates={k:float(np.mean([b['signals'][k]for r in s.records for b in r['B_delta']['observed_behaviors']]))for k in LABELS}
  A.append({'child_seed':seed,'initial_traits':s.initial_b['initial_dispositions'],'final_traits':s.child._state['latent_state'],'milestone_months':milestone_ages(s),'behavior_rates':rates,'A_final_sha256':afinal,'B_final_sha256':digest(bio(s))})
 (out/'experiment_A_32_children.json').write_text(json.dumps(A,ensure_ascii=False,indent=2));summary['A']={'children':len(A),'same_A_household_and_policy':True,'A_final_sha256':afinal,'distinct_B_final_states':len({r['B_final_sha256']for r in A}),'walking_range':[min(r['milestone_months'].get('walking_independently',24)for r in A),max(r['milestone_months'].get('walking_independently',24)for r in A)],'not_validated_joint_behavior_distribution':True}
 B={}
 for name,env,on in [('reference',{},False),('changed_environment_off',{'sleep_disruption':1,'responsive_episode':1,'language_opportunities':1,'context':'different_context'},False),('sleep_hypothesis_on',{'sleep_disruption':1},True)]:
  s=Simulation.initialize(**common,child_seed=1301)
  for month in range(24):s.step(research_continue=True,environment=env,scenario_effects=on)
  B[name]=s;save(s,out/f'experiment_B_{name}.json.gz')
 base=B['reference'];off=B['changed_environment_off'];on=B['sleep_hypothesis_on'];assert bio(base)==bio(off);assert base.child._state['experience_memory']!=off.child._state['experience_memory']
 summary['B']={'initial_child_equal':all(v.initial_b==base.initial_b for v in B.values()),'effects_off_biology_exactly_equal':bio(base)==bio(off),'context_ledger_different':True,'optin_sleep_hours_difference':on.child._state['sleep']['reported_day_duration_hours']-base.child._state['sleep']['reported_day_duration_hours'],'development_equal_even_scenario':on.child._state['developmental_state']==base.child._state['developmental_state'],'mechanism':'only explicit scenario -1h sleep report and +.05 fatigue/unit; no identified causal claim','causal_prediction':False}
 # C: independent rerun and a saved12+12 run, actual same history/conditions.
 c=Simulation.initialize(**common,child_seed=1301);c.run(12,research_continue=True)
 with tempfile.TemporaryDirectory()as tmp:
  p=Path(tmp)/'resume.json';c.save(p);resumed=Simulation.load(p,engine=eng)
 c.run(12,research_continue=True);resumed.run(12,research_continue=True);assert c.payload()==resumed.payload()==base.payload();summary['C']={'rerun_and_saved12plus12_exact':True,'sha256':digest(base.payload())}
 d=Simulation.initialize(**common,child_seed=1302);d.run(24,research_continue=True);save(d,out/'experiment_D_no_player_action.json.gz');summary['D']={'explicit_player_actions':0,'native_A_baseline_policy_not_disabled':True,'birth_length':d.initial_b['physical_health']['length_cm'],'age24_length':d.child._state['physical_health']['length_cm'],'milestones':milestone_ages(d),'ordinary_exposure_days':sum(e['days']for e in d.exposures),'all24months':d.elapsed_months==24}
 # Controlled probes: identical random cue keys, traits varied across real generated
 # children; within child sleep loss/familiarity/unwell are explicit hypotheses.
 probes=[]
 for seed in range(1401,1601):
  ch=Child.generate(seed=seed);ch.advance_to(12)
  for label,kwargs in [('reference',{}),('sleep_loss',{'sleep_loss':2}),('familiar',{'familiar':True}),('unwell_scenario',{'unwell':1}),('zero_trait_weight',{'weight':0})]:
   for rep in range(8):probes.append({'seed':seed,'condition':label,'replicate':rep,'traits':ch._state['latent_state'],'probe':ch.probe(key=['standard_cue',rep],**kwargs)})
 with gzip.open(out/'controlled_probes.json.gz','wt',encoding='utf-8')as f:json.dump(probes,f,ensure_ascii=False,separators=(',',':'))
 summary['controlled_behavior_probes']={'children':200,'situations_per_condition':1600,'same_random_cues':True,'trait_and_state_response_not_externally_calibrated':True,'results':{label:{k:float(np.mean([p['probe']['signals'][k]for p in probes if p['condition']==label]))for k in LABELS}for label in ['reference','sleep_loss','familiar','unwell_scenario','zero_trait_weight']}}
 # Ten genuinely distinct households. Three have traceable native A actions and
 # recorded child observation choices at months3/9/15, not invented stories.
 parent_records=[];details=[]
 for i,pref in enumerate(['01','04','13','14','23','27','34','40','46','47']):
  s=Simulation.initialize(pref,seed=f'B11-experience-{i}',child_seed=1701+i*17,birth_date='2026-10-01' if i<3 else f'2026-10-{3+i:02d}',engine=eng)
  plain=s.clone();plain.run(24,research_continue=True)
  for month in range(24):
   choices={}
   if i<3 and month in [3,9,15]:
    cg=s.identity['person_links'][s.identity['caregiver_local_ids'][0]];choices={'a_actions':[{'type':'set_spending','value':.9 if month!=9 else 1.05,'id':f'family{i}-choice{month}'}],'child_actions':[{'kind':{3:'observe',9:'offer_comfort',15:'shared_play'}[month],'caregiver_id':cg}]}
   s.step(research_continue=True,**choices)
  filename=out/f'family_{s.identity["run_id"]}.json.gz';save(s,filename);cg=s.identity['person_links'][s.identity['caregiver_local_ids'][0]];months=[parent_month(s,r,cg)for r in s.records]
  rec={'household_id':s.identity['household_id'],'run_id':s.identity['run_id'],'prefecture':pref,'observer':cg,'birth_date':s.identity['birth_date'],'months':months,'no_unsourced_free_text':True};parent_records.append(rec)
  lines=[f'# 観察記録 {i+1}',f'家庭ID: `{rec["household_id"]}`。観察者ID: `{cg}`。出生: {rec["birth_date"]}。','各文は保存された観察だけから機械的に作成しています。観察がない場面の能力や内面は推測していません。']
  for r in months:lines.append(f'\n## {r["month"]}か月（{r["date"]}）\n\n{r["text"]}')
  (out/f'parent_growth_{i+1:02d}.md').write_text('\n'.join(lines))
  if i<3:
   assert bio(s)==bio(plain)
   entries=[]
   for m in [3,9,15]:
    r=s.records[m];prior=s.records[m-1];next_r=s.records[m+1];p=[s.a_periods[j]for j in r['A_period_indices']]
    prior_view=parent_month(s,prior,cg);after_view=parent_month(s,r,cg);next_view=parent_month(s,next_r,cg)
    action_events=[e for e in r['events']if e['kind']=='parent_action'];entry={'decision_age_months':m,'parent_before':prior_view,'parent_choices_available':['observe','offer_comfort','shared_play','keep_routine','native A spending/care/work requests subject to A feasibility'],'actual_child_actions':r['child_actions'],'actual_A_actions':[a for period in p for a in period['requested_actions']],'actual_A_decisions':[a for period in p for a in period['A_decisions']],'postchoice_observations':after_view,'next_month_observations':next_view,'source_action_events':action_events,'internal_explanation':{'biological_effects_enabled':False,'child_biology_equal_to_no_explicit_action_counterfactual':True,'carryover':'A spending setting affects subsequent household consumption; action/observations remain in family ledger; no inferred attachment, IQ or developmental gain','environment_causality':'unidentified and disabled','behavior_differences':'extra elicited observation opportunity only; subsequent weekly cues unchanged'},'source_record_sha256':digest(r)};entries.append(entry)
   details.append({'household_id':s.identity['household_id'],'run_id':s.identity['run_id'],'entries':entries})
 (out/'parent_growth_records_10.json').write_text(json.dumps(parent_records,ensure_ascii=False,indent=2));(out/'decision_experiences_3.json').write_text(json.dumps(details,ensure_ascii=False,indent=2));(out/'comparison_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 lines=['# 3家庭の意思決定と観察','保存された状態と履歴の定型変換です。親の記録と研究用の説明を分けています。']
 for i,fam in enumerate(details):
  lines.append(f'\n## 家庭{i+1} `{fam["household_id"]}`')
  for e in fam['entries']:
   lines.extend([f'\n### {e["decision_age_months"]}か月の選択',f'直前の記録：{e["parent_before"]["text"]}',f'選択：{json.dumps(e["actual_child_actions"],ensure_ascii=False)}。家計の選択：{json.dumps(e["actual_A_actions"],ensure_ascii=False)}。',f'選択後に届いた記録：{e["postchoice_observations"]["text"]}',f'翌月の記録：{e["next_month_observations"]["text"]}','研究用説明：家計の支出設定と記録は持ち越されます。子どもへの未識別の生物学的効果は停止中です。同じ初期子どもで選択しなかった比較と、以後の身体・気質・発達・短期状態は一致しました。今回の観察変化を養育の実証的効果とは解釈できません。',f'参照レコードSHA256: `{e["source_record_sha256"]}`'])
 (out/'decision_experiences_3.md').write_text('\n\n'.join(lines));print(json.dumps(summary,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
