"""Restartable genuine47-prefecture A/B generation, no duplicated legacy DB."""
import argparse,concurrent.futures,datetime as dt,json,math,sqlite3,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11.integrated import Simulation,a18_engine_class
from child_b11.engine import VERSION,PARAMETER_HASH,digest
from child_b11.storage import connect,encode
ENGINE=None
def worker_init():
 global ENGINE
 ENGINE=a18_engine_class()()
def process_pref(task):
 pref,count,weight,out=task;path=Path(out)/f'pref_{pref}.sqlite';summary=path.with_suffix('.json')
 if path.exists() and summary.exists():
  v=json.loads(summary.read_text())
  if v['requested']==count and v['parameter_sha256']==PARAMETER_HASH:return v
  raise ValueError('existing shard belongs to different parameters')
 if path.exists():path.unlink()
 db=connect(path);start=time.time();failed=[];complete=0;periods=0;mid=0;person_count=0
 for i in range(count):
  seed=41100000+int(pref)*10000+i;birth=f'2026-{(i+int(pref)-1)%12+1:02d}-{1+(i*7+int(pref))%28:02d}'
  try:
   sim=Simulation.initialize(pref,seed=seed,birth_date=birth,engine=ENGINE);rid=sim.identity['run_id'];people=sim.initial_a['persons'];person_count+=len(people)
   with db:
    db.execute('INSERT INTO b11_case VALUES(?,?,?,?,?,?,?,?)',(rid,pref,str(seed),weight/count,encode(sim.identity),encode(sim.config),encode(sim.initial_a),encode(sim.initial_b)))
    old={'length_cm':sim.child._state['physical_health']['length_cm'],'head_circumference_cm':sim.child._state['physical_health']['head_circumference_cm']};ap=0
    for month in range(1,25):
     sim.step(research_continue=True);s=sim.child._state;ph=s['physical_health'];sim.assert_consistent()
     assert all(math.isfinite(ph[k]) and ph[k]>0 for k in ['weight_kg','length_cm','head_circumference_cm'])
     for k in old:assert ph[k]>=old[k];old[k]=ph[k]
     assert all(0<=v<=1 and math.isfinite(v) for v in s['emotion_regulation'].values())
     assert all(r['date']>=birth and r['date']<=s['as_of_date'] for r in s['parent_observations'])
     assert all(not obs['behaviors'].get(sig) or skill in s['developmental_state']['milestones'] for obs in sim.records[-1]['parent_observations'] for sig,skill in [('takes_independent_steps','walking_independently'),('uses_contextual_word','first_contextual_word')])
     assert not s['physical_health']['diagnoses'] and all(r['attachment_classification'] is None for r in s['caregiver_relationships'].values())
     for j in range(ap,len(sim.a_periods)):
      p=sim.a_periods[j];r=p['A_month'];assert r['ledger']['cash_identity_residual']==r['ledger']['net_worth_identity_residual']==0
      assert all(abs(t['total']-168)<1e-8 for t in r['time']['parents'].values());assert abs(sum(r['time'][k] for k in ['nursery','relative','parent_care','uncovered'])-84)<1e-8
      db.execute('INSERT INTO b11_a_period VALUES(?,?,?)',(rid,j+1,encode(p)))
     ap=len(sim.a_periods);rec=sim.records[-1];db.execute('INSERT INTO b11_month VALUES(?,?,?,?,?)',(rid,month,rec['end'],encode(rec),digest(rec)))
     if month in [12,24]:
      # Reconstruct history/records from monthly rows, not copied in each checkpoint.
      c={k:v for k,v in sim.payload().items() if k not in ['records','a_periods','exposures','initial_a','initial_b']};c['child']={k:v for k,v in c['child'].items() if k not in ['parent_observations','experience_ledger']};c['reconstruction']='initial_b + ordered b11_month ledgers + b11_a_period + checkpoint continuation'
      db.execute('INSERT INTO b11_checkpoint VALUES(?,?,?)',(rid,month,encode(c)))
    assert (dt.date.fromisoformat(s['as_of_date'])-dt.date.fromisoformat(birth)).days==sum(x['days']for x in sim.exposures)
    assert [e['date']for e in s['experience_ledger']]==sorted(e['date']for e in s['experience_ledger'])
   complete+=1;periods+=len(sim.a_periods);mid+=int(not birth.endswith('-01'))
  except Exception as exc:
   detail={'seed':seed,'birth_date':birth,'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()};failed.append(detail)
   with db:db.execute('INSERT INTO b11_failure VALUES(?,?,?)',(pref,str(seed),json.dumps(detail)))
  if (i+1)%25==0:print(json.dumps({'pref':pref,'attempted':i+1,'completed':complete,'seconds':round(time.time()-start,1)}),flush=True)
 assert not db.execute('PRAGMA foreign_key_check').fetchall();assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
 out={'prefecture':pref,'requested':count,'completed':complete,'B_months':complete*24,'completed_A_calendar_periods':periods,'midmonth_births':mid,'persons':person_count,'failed':failed,'version':VERSION,'parameter_sha256':PARAMETER_HASH,'seconds':time.time()-start}
 with db:db.execute('INSERT INTO b11_run VALUES(?,?)',('cohort',json.dumps(out)))
 db.close();summary.write_text(json.dumps(out,ensure_ascii=False,indent=2));return out
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--per-prefecture',type=int,default=220);ap.add_argument('--workers',type=int,default=3);ap.add_argument('--prefectures',default=','.join(f'{i:02d}'for i in range(1,48)));ap.add_argument('--output',type=Path,default=ROOT/'results/cohort_10340');args=ap.parse_args();args.output.mkdir(exist_ok=True,parents=True);shards=args.output/'shards';shards.mkdir(exist_ok=True)
 engine=a18_engine_class()();counts={p:sum(r['weight']for r in rows if r['sex']=='all')for p,rows in engine.generator.base.g['birth_pref'].items()};total=sum(counts.values());weights={k:v/total for k,v in counts.items()};start=time.time();results=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=worker_init) as pool:
  futures=[pool.submit(process_pref,(p,args.per_prefecture,weights[p],str(shards)))for p in args.prefectures.split(',')]
  for f in concurrent.futures.as_completed(futures):r=f.result();results.append(r);print('PREF_DONE',json.dumps(r),flush=True)
 report={'version':VERSION,'parameter_sha256':PARAMETER_HASH,'requested':len(results)*args.per_prefecture,'completed':sum(r['completed']for r in results),'B_months':sum(r['B_months']for r in results),'A_calendar_periods':sum(r['completed_A_calendar_periods']for r in results),'midmonth_births':sum(r['midmonth_births']for r in results),'prefectures':sorted(results,key=lambda r:r['prefecture']),'weights':weights,'seconds':time.time()-start,'source':'native A18 -> A2.5 -> A2 -> A1 family generator; no resampling','scope':'2026 birth days1..28, singleton term37..41 physiology reference; A daily exposures held monthly scenarios','unidentified_environment_effects':False,'external_validity':False}
 (args.output/'generation_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('DONE',report['completed'],report['B_months'],round(report['seconds'],1),flush=True)
 if report['completed']!=report['requested']:raise SystemExit('Incomplete; retained all failures, no resampling')
if __name__=='__main__':main()
