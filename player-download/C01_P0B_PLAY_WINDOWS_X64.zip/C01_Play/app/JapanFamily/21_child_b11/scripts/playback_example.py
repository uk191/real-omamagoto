"""Read recorded parent observations without inventing a new event or cause."""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--family',type=int,default=1);ap.add_argument('--month',type=int,default=12);a=ap.parse_args()
if not 1<=a.family<=10 or not 1<=a.month<=24:raise SystemExit('family1..10,month1..24')
families=json.loads((ROOT/'results/examples/parent_growth_records_10.json').read_text());row=families[a.family-1];m=row['months'][a.month-1]
print(json.dumps({'household_id':row['household_id'],'observer':row['observer'],'month':m['month'],'date':m['date'],'record':m['text'],'source_refs':m['source_refs'],'mode':'recorded actual simulation playback; not fresh household generation'},ensure_ascii=False,indent=2))
