"""Acquire Japanese screening validation, retain aggregate norms only (no items)."""
import hashlib,json,urllib.request,xml.etree.ElementTree as E
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];url='https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pmc&id=6899956';out={'pmid':'31419360','pmc':'PMC6899956','url':url}
try:
 data=urllib.request.urlopen(url,timeout=40).read();r=E.fromstring(data);assert r.find('.//body')is not None;p=ROOT/'data/raw/PMC6899956.xml';p.write_bytes(data);p.with_suffix('.txt').write_text('\n'.join(' '.join(x.itertext())for x in r.findall('.//body/sec')))
 out.update(file=str(p.relative_to(ROOT)),sha256=hashlib.sha256(data).hexdigest(),status='full_text_acquired',tables=[])
 for t in r.findall('.//table-wrap'):
  caption=' '.join(t.find('caption').itertext())if t.find('caption')is not None else''
  # Table metadata only until manually checked: do not copy protected items.
  out['tables'].append({'id':t.get('id'),'caption':caption})
except Exception as e:out.update(status='not_acquired',error=str(e))
if out.get('status')=='full_text_acquired':
 t=r.find('.//table-wrap[@id="ped13990-tbl-0001"]');rows=[[' '.join(''.join(c.itertext()).split())for c in row if c.tag in ['td','th']]for row in t.findall('.//tr')]
 (ROOT/'data/JASQ_aggregate_norms.json').write_text(json.dumps({'source':'PMID31419360 Table1 DOI10.1111/ped.13990','scope':'Japanese ASQ-3 caregiver screening scores, not latent capability','no_items_or_scoring_keys_reproduced':True,'use':'measurement evidence only; not clinical diagnosis or generated ability','aggregate_rows':rows,'raw_sha256':out['sha256']},ensure_ascii=False,indent=2))
(ROOT/'data/JASQ_validation_acquisition.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False))
