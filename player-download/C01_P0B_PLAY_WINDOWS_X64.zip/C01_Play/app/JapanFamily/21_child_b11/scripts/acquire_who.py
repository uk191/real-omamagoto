import concurrent.futures,hashlib,html,json,re,urllib.request
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parents[1];s=(ROOT/'data/raw/official_WHO_motor.html').read_text();urls=[html.unescape(u)for u in re.findall('href="([^"]+)"',s)if '/motor-development-milestones/'in u and '.pdf'in u]
def fetch(url):
 name=url.split('/')[-1].split('?')[0];p=ROOT/'data/raw'/name;r={'url':url,'file':str(p.relative_to(ROOT))}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ResearchModel-B11/1.1'}),timeout=40)as f:data=f.read()
  p.write_bytes(data);doc=fitz.open(p);text='\n'.join(page.get_text()for page in doc);p.with_suffix('.txt').write_text(text);r.update(status='fetched',sha256=hashlib.sha256(data).hexdigest(),pages=len(doc))
 except Exception as e:r.update(status='failed',error=str(e))
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:rows=list(pool.map(fetch,urls))
(ROOT/'data/WHO_acquisition.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False))
