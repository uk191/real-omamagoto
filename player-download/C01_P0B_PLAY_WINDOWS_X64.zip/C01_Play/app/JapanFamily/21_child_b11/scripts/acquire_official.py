import concurrent.futures,datetime as dt,hashlib,json,re,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
URLS={'CFA_growth_2023':'https://www.cfa.go.jp/policies/boshihoken/r5-nyuuyoujityousa/','CFA_growth_index':'https://www.cfa.go.jp/policies/boshihoken/hatsuiku/','MHLW_21c_2001':'https://www.mhlw.go.jp/toukei/list/27-9.html','MHLW_21c_2010':'https://www.mhlw.go.jp/toukei/list/27-22.html','IPSS_fertility':'https://www.ipss.go.jp/site-ad/index_Japanese/shussho-index.html','IPSS_fertility17_2025':'https://www.ipss.go.jp/ps-doukou/j/doukou17/doukou17_gaiyo.html','MEXT_21c_2001_latest':'https://www.mext.go.jp/b_menu/toukei/chousa08/21seiki/1380892.htm','WHO_motor':'https://www.who.int/toolkits/child-growth-standards/standards/motor-development-milestones'}
def fetch(item):
 name,url=item;r={'id':name,'url':url,'retrieved_UTC':dt.datetime.now(dt.timezone.utc).isoformat()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ResearchModel-B11/1.1'}),timeout=40) as response:data=response.read();r['final_url']=response.url;r['http_status']=response.status
  path=ROOT/'data/raw'/f'official_{name}.html';path.write_bytes(data);r.update(file=str(path.relative_to(ROOT)),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),status='fetched')
 except Exception as e:r.update(status='failed',error=str(e))
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(fetch,URLS.items()))
(ROOT/'data/official_acquisition.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False))
