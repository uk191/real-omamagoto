"""Lightweight executable/sample pack + new-only incremental data, shared hashes."""
import hashlib,json,platform,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parent.parent;OUT=REPO/'artifacts'
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 OUT.mkdir(exist_ok=True);cohort=json.loads((ROOT/'results/cohort_10340/generation_summary.json').read_text());assert cohort['completed']==cohort['requested']==10340;assert len(cohort['prefectures'])==47
 assert json.loads((ROOT/'results/replays_47.json').read_text())['count']==47
 assert json.loads((ROOT/'results/legacy_preservation.json').read_text())['B10_archives_SHA256_unchanged']
 code=[]
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file()or '__pycache__'in p.parts or p.suffix in ['.pyc','.sqlite','.sqlite-journal','.npz']:continue
  rel=p.relative_to(ROOT)
  if rel.parts[:2]==('data','raw')or 'candidate_before_float_fix'in rel.parts:continue
  if p.name in ['release_verification.json','independent_saved_tests.log']:continue
  if p.stat().st_size>20_000_000:continue
  code.append(p)
 for component in ['19_child_b10/child_b10','20_integrated_b10/integrated_b10']:
  code.extend(p for p in (ROOT.parent/component).glob('*.py'))
 for name in ['parameters.json','japan_reference.json','internal_state.schema.json','player_response.schema.json']:
  code.append(ROOT.parent/'19_child_b10/data'/name)
 data=sorted((ROOT/'results/cohort_10340/shards').glob('*.sqlite'));assert len(data)==47
 def listing(paths):return {str(p.relative_to(REPO)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(set(paths))}
 cm=listing(code);dm=listing(data);basis={'parameter_sha256':cohort['parameter_sha256'],'code_files':cm,'data_files':dm};bundle='B11-'+hashlib.sha256(json.dumps(basis,sort_keys=True).encode()).hexdigest()[:32]
 common={'bundle_id':bundle,'version':cohort['version'],'parameter_sha256':cohort['parameter_sha256'],'legacy_pins':json.loads((ROOT/'data/legacy_artifact_pins.json').read_text()),'runtime':{'python':platform.python_version(),'machine':platform.machine(),'platform':platform.platform()},'scientific_scope':'partial research calibration only; no validated national joint, clinical, psychological, causal or2–6y model','data_strategy':'new47shards only; no copied old1.7/1.1/5.2GB databases or5.31GB archive','raw_research_cache':'local workspace data/raw preserved; links/hashes/aggregate facts shipped, copyrighted scale items/full articles excluded'}
 artifacts=[]
 for name,kind,files in [('B1.1_CODE_AND_REPORTS.zip','CODE',cm),('B1.1_INCREMENTAL_DATA.zip','DATA',dm)]:
  p=OUT/name;manifest={**common,'kind':kind,'files':files,'paired_tree_sha256':hashlib.sha256(json.dumps(dm if kind=='CODE'else cm,sort_keys=True).encode()).hexdigest()}
  with zipfile.ZipFile(p,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True)as z:
   for file in files:z.write(REPO/file,file)
   z.writestr('B11_'+kind+'_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
  artifacts.append({'filename':name,'bytes':p.stat().st_size,'sha256':sha(p),'payload_files':len(files)})
  print('SAVED',name,p.stat().st_size,flush=True)
 meta={**common,'archives':artifacts,'saved_bytes_independent_verification':'B1.1_RELEASE_VERIFICATION.json is generated separately after packaging'};(OUT/'B1.1_ARCHIVES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(OUT/'B1.1_SHA256SUMS.txt').write_text('\n'.join(x['sha256']+'  '+x['filename']for x in artifacts)+'\n');print(bundle,flush=True)
if __name__=='__main__':main()
