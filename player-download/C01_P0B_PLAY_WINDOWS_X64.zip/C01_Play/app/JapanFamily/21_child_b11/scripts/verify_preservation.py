"""Read-only compare against B1.0 published archive and inherited SHA manifests."""
import hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parent.parent;PROJECT=ROOT.parent

def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 archive=REPO/'artifacts/B1.0_INTEGRATED_CODE_AND_REPORTS.zip'
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None;m=json.loads(z.read('INTEGRATION_CODE_MANIFEST.json'));count=0
  for name,info in m['files'].items():
   # ASSEMBLE.py is a distribution-root helper, not installed in source tree.
   p=REPO/name
   if not p.exists():
    assert name in ['ASSEMBLE.py','READ_INTEGRATED_RELEASE.md'],name;continue
   assert sha(p)==info['sha256'],name;count+=1
 old=json.loads((ROOT/'data/baseline_pins.json').read_text())
 for entry in old:assert sha(REPO/entry['path'])==entry['sha256'],entry['path']
 a=json.loads((PROJECT/'release_manifest_v02.json').read_text())
 for name,h in a['files'].items():assert sha(PROJECT/name)==h,name
 pins=json.loads((ROOT/'data/legacy_artifact_pins.json').read_text())
 for entry in pins['archives']:assert sha(REPO/'artifacts'/entry['filename'])==entry['sha256'],entry['filename']
 result={'all_existing_B10_code_pack_payloads_unchanged':count,'A_release_files_unchanged':len(a['files']),'explicit_code_and_database_pins_unchanged':len(old),'B10_archives_SHA256_unchanged':True,'old_data_copied_into_B11':False,'new_namespace':'JapanFamily/21_child_b11','legacy_B_tests':31,'legacy_integrated_tests':25,'clinical_or_causal_validation':False}
 (ROOT/'results/legacy_preservation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
