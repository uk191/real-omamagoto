"""Source-separated descriptive calibration/holdout and within-person audits.

Success flags here never assert national joint, clinical or causal validation.
"""
import argparse,collections,datetime as dt,json,math,sqlite3,sys,time
from pathlib import Path
import numpy as np
from scipy.special import ndtr
from scipy.stats import spearmanr
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from child_b11.engine import PARAMS,MILESTONES,OLD,digest
from child_b11.storage import decode
from child_b10.japan_reference import day_quantiles

def quant(x,probs=[.03,.1,.25,.5,.75,.9,.97]):return [float(v)for v in np.quantile(x,probs)] if len(x)else []
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT/'results/cohort_10340');args=ap.parse_args();start=time.time();monthly=collections.defaultdict(list);births=[];finals=[];weights=[];prefs=collections.Counter();stats=collections.Counter();onsets={k:[]for k in MILESTONES};parent_skill_early=0;A18=[];employment18=collections.Counter();first_known={k:[]for k in ['takes_independent_steps','uses_contextual_word']}
 for path in sorted((args.input/'shards').glob('pref_*.sqlite')):
  db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
  for rid,pref,wt,ib in db.execute('SELECT run_id,prefecture,geographic_weight,initial_b FROM b11_case ORDER BY run_id'):
   b=decode(ib);births.append(b);weights.append(wt);prefs[pref]+=1;rows=list(db.execute('SELECT month,payload,sha256 FROM b11_month WHERE run_id=? ORDER BY month',(rid,)));assert len(rows)==24;last=None;first_positive={}
   for month,blob,h in rows:
    r=decode(blob);assert digest(r)==h;d=r['B_delta'];assert d['elapsed_months']==month;assert sum(e['days']for e in r['A_exposures'])==(dt.date.fromisoformat(r['end'])-dt.date.fromisoformat(r['start'])).days
    if last:
     assert all(d['physical_health'][k]>=last['physical_health'][k]for k in ['length_cm','head_circumference_cm'])
    for behavior in d['observed_behaviors']:
     age=(dt.date.fromisoformat(behavior['date'])-dt.date.fromisoformat(b['child_identity']['birth_date'])).days/30.4375
     for sig,skill in [('takes_independent_steps','walking_independently'),('uses_contextual_word','first_contextual_word')]:
      if age<2 and behavior['signals'][sig]:parent_skill_early+=1
    for report in r['parent_observations']:
     stats['parent_reports']+=1
     report_age=(dt.date.fromisoformat(report['date'])-dt.date.fromisoformat(b['child_identity']['birth_date'])).days
     for sig in first_known:
      if report['behaviors'].get(sig):first_positive[sig]=min(first_positive.get(sig,100000),report_age)
     if (dt.date.fromisoformat(report['date'])-dt.date.fromisoformat(b['child_identity']['birth_date'])).days<60:
      for sig in ['takes_independent_steps','uses_contextual_word']:
       if report['behaviors'].get(sig):stats['under60day_skill_reports']+=1
    compact={'rid':rid,'weight':wt,'sex':b['child_identity']['sex_for_growth_reference'],'age_days':d['age_days'],'physical':d['physical_health'],'traits':d['latent_state'],'sleep':d['sleep'],'emotion':d['emotion_regulation']}
    monthly[month].append(compact);last=d;stats['B_months']+=1
   finals.append(last)
   for sig in first_known:first_known[sig].append(first_positive.get(sig,float('inf'))/30.4375)
   for name in MILESTONES:
    v=last['developmental_state']['milestones'].get(name);onsets[name].append(v['age_days_interval'] if v else None)
  for blob, in db.execute('SELECT payload FROM b11_a_period'):
   r=decode(blob);row=r['A_month'];stats['A_periods']+=1;assert row['ledger']['cash_identity_residual']==row['ledger']['net_worth_identity_residual']==0
   if row.get('elapsed_months')==18 or row.get('child_age_months')==18:
    pass
   # Source period count in stored table is native elapsed accounting n.
  for rid,blob in db.execute('SELECT run_id,payload FROM b11_checkpoint WHERE month=24'):
   ck=decode(blob);stats['final_partial_forecasts']+=int(ck['forecast'] is not None)
  # Household-native month18 is separately interrogated, not equated to B age18.
  case_weights={rid:wt for rid,wt in db.execute('SELECT run_id,geographic_weight FROM b11_case')}
  for rid,blob in db.execute('SELECT run_id,payload FROM b11_a_period WHERE period=18'):
   r=decode(blob);row=r['A_month'];mother=row.get('parents',{}).get('mother')
   # A row employment structure is implementation-specific; inspect explicit person state below.
   if mother:
    attached=mother.get('contract_active',False);zero=mother.get('actual_weekly_hours',0)==0;unpaid=mother.get('actual_gross_this_month',0)==0
    employment18['mother_present_weight']+=case_weights[rid]
    if attached and zero and unpaid:employment18['contract_active_zero_hours_zero_pay_weight']+=case_weights[rid]
  db.close();print('ANALYZED',path.name,stats['B_months'],flush=True)
 n=len(births);w=np.array(weights);w=w/w.sum();assert n and len(finals)==n
 summary={'families':n,'prefectures':dict(sorted(prefs.items())),'counts':dict(stats),'all_row_SHA256_checked':True,'newborn_skill_signals':parent_skill_early,'newborn_false_skill_reports':stats['under60day_skill_reports'],'unit':'geographic weights only; not national all-birth joint validation','seconds':time.time()-start,'A18_calendar_employment_weighted':dict(employment18)}
 # Seven milestones: uniform-bin integrals of empirical interval onset bounds.
 calibration={};holdout={};old2010=json.loads((ROOT.parent/'20_integrated_b10/results/coupled_10340/heldout2010_comparisons.json').read_text())
 for name,intervals in onsets.items():
  bounds=np.array([v if v else [float('inf'),float('inf')]for v in intervals],float)/30.4375
  mids=np.mean(bounds,axis=1);finite=mids[np.isfinite(mids)];ordered=np.sort(mids);dist={str(p):float(ordered[min(n-1,max(0,math.ceil(p*n)-1))]) if math.isfinite(ordered[min(n-1,max(0,math.ceil(p*n)-1))])else None for p in [.01,.05,.25,.5,.75,.95,.99]}
  points=[]
  for src in PARAMS['milestone_fits'][name]['raw']:
   x=src['age_midpoint_months'];lo=x-.5;hi=x+.5;rates=[float(np.dot(w,np.clip((hi-bounds[:,j])/(hi-lo),0,1)))for j in [0,1]]
   midrate=sum(rates)/2;points.append({'age_bin':[lo,hi],'source_rate':src['pass_proportion'],'generated_weekly_interval_CDF_bounds':[rates[1],rates[0]],'generated_midinterval':midrate,'difference':midrate-src['pass_proportion'],'source_cell':src['cell']})
  calibration[name]={'generated_onset_quantiles_months':dist,'right_censored24':int(n-len(finite)),'points':points,'RMSE':float(np.sqrt(np.mean([p['difference']**2 for p in points]))),'max_abs_difference':max(abs(p['difference'])for p in points),'status':'same_source_report_proxy_calibration; gamma joint law unvalidated; weekly interval uncertainty shown'}
  pts=[]
  for src in old2010['comparisons'][name]['points']:
   x=src['age_midpoint_months'];lo=x-.5;hi=x+.5;v=float(np.dot(w,np.clip((hi-mids)/(hi-lo),0,1)));pts.append({'age_bin':[lo,hi],'observed2010':src['observed2010'],'generated':v,'difference':v-src['observed2010'],'source_cell':src['cell']})
  holdout[name]={'points':pts,'RMSE':float(np.sqrt(np.mean([p['difference']**2 for p in pts]))),'interpretation':'independent historical sample, different cohort and survey; no full2026 external-validity claim'}
 (args.input/'milestone_calibration.json').write_text(json.dumps(calibration,ensure_ascii=False,indent=2,allow_nan=False));(args.input/'heldout2010_milestones.json').write_text(json.dumps({'source':old2010['source'],'comparisons':holdout},ensure_ascii=False,indent=2))
 observed={}
 for sig,name in [('takes_independent_steps','walking_independently'),('uses_contextual_word','first_contextual_word')]:
  x=np.asarray(first_known[sig]);pts=[]
  for src in PARAMS['milestone_fits'][name]['raw']:
   mid=src['age_midpoint_months'];rate=float(np.dot(w,np.clip((mid+.5-x),0,1)));pts.append({'age_bin':[mid-.5,mid+.5],'source_parent_report_rate':src['pass_proportion'],'model_any_caregiver_first_positive_rate':rate,'difference':rate-src['pass_proportion']})
  observed[sig]={'not_observed_by24':int(sum(~np.isfinite(x))),'points':pts,'RMSE':float(np.sqrt(np.mean([p['difference']**2 for p in pts]))),'measurement_warning':'Latent proxy calibrated to parent report and then sampled with assumed observation error; observable first-report curves are separate and may lag. Neither layer identifies true biological onset.'}
 (args.input/'observable_skill_calibration_gap.json').write_text(json.dumps(observed,ensure_ascii=False,indent=2))
 # Marginal physical body distributions by actual age, sex, percentiles and rank changes.
 physical=[]
 for month,rows in sorted(monthly.items()):
  for sex in ['male','female']:
   subgroup=[r for r in rows if r['sex']==sex]
   for name,key,table in [('weight','weight_kg','weianthro'),('length','length_cm','lenanthro'),('head','head_circumference_cm','hcanthro')]:
    vals=[r['physical'][key]for r in subgroup];zs=[r['physical']['growth_z'][name]for r in subgroup];age=float(np.median([r['age_days']for r in subgroup]));ref=day_quantiles(table,sex,int(round(age)))
    physical.append({'month':month,'sex':sex,'metric':key,'n':len(subgroup),'actual_age_days_median':age,'generated_quantiles':quant(vals),'Japanese2023_reference_quantiles':ref,'quantile_differences':[a-b for a,b in zip(quant(vals),ref)],'z_mean':float(np.mean(zs)),'z_sd':float(np.std(zs)),'z_quantiles':quant(zs),'interpretation':'same-source margins, term-hospital birth initialization and assumed joint dynamics can shift later cross-sectional distributions'})
 (args.input/'physical_calibration.json').write_text(json.dumps(physical,ensure_ascii=False,indent=2))
 # 2010 physical: compare exact stored-age points within source bins, not fabricated age composition.
 hphys=json.loads((ROOT.parent/'20_integrated_b10/data/heldout2010_physical.json').read_text());hc=[]
 for src in hphys['rows']:
  lo,hi=src['age_month_interval'];key={'head_cm':'head_circumference_cm'}.get(src['metric'],src['metric']);samples=[r['physical'][key]for month,rows in monthly.items()for r in rows if r['sex']==src['sex'] and lo*30.4375<=r['age_days']<hi*30.4375]
  if not samples:continue
  q=quant(samples);hc.append({'source':src,'generated_n':len(samples),'generated_quantiles':q,'differences':[a-b for a,b in zip(q,src['values'])],'age_mixture':'generated monthly checkpoints in original bin; source age mixture unknown'})
 (args.input/'heldout2010_physical.json').write_text(json.dumps({'source_independent_of_calibration':True,'comparisons':hc,'status':'historical descriptive check only'},ensure_ascii=False,indent=2))
 sleep=[]
 for anchor in PARAMS['sleep_anchors']:
  age=anchor['age_months'];x=np.array([r['sleep']['reported_day_duration_hours']for r in monthly[age]]);lo,hi=anchor['cutpoints'];rates=[float(np.mean(x<lo)),float(np.mean((x>=lo)&(x<=hi))),float(np.mean(x>hi))];target=np.array(anchor['counts_observed'])/anchor['observed_n']
  sleep.append({'age_months':age,'generated_mean':float(x.mean()),'generated_SD':float(x.std()),'generated_quantiles':quant(x),'generated_category_rates':rates,'source_complete_case_rates':target.tolist(),'differences':(rates-target).tolist(),'source':anchor,'MonteCarlo_SE_only':np.sqrt(np.array(rates)*(1-np.array(rates))/n).tolist(),'measurement':'last birth-relative weekly sample before birthday; not actual sleep diary', 'status':'same_source_aggregate_category_calibration; no independent sleep duration validation'})
 (args.input/'sleep_calibration.json').write_text(json.dumps(sleep,ensure_ascii=False,indent=2))
 persistence={}
 for key in OLD['trait_loadings']:
  vals=[np.array([r['traits'][key]for r in monthly[m]])for m in [6,12,24]]
  persistence[key]={'birth_to24_r':float(np.corrcoef([b['initial_dispositions'][key]for b in births],vals[-1])[0,1]),'6to12_r':float(np.corrcoef(vals[0],vals[1])[0,1]),'6to24_r':float(np.corrcoef(vals[0],vals[2])[0,1]),'age24_mean':float(vals[-1].mean()),'age24_SD':float(vals[-1].std()),'not_a_validation_against_IBQ_ECBQ':'latent computational traits differ from age-specific parent scale scores'}
 devcorr=[]
 for i,a in enumerate(MILESTONES):
  for b in MILESTONES[i+1:]:
   pairs=[(sum(x)/2,sum(y)/2)for x,y in zip(onsets[a],onsets[b])if x and y];xx,yy=zip(*pairs);devcorr.append({'a':a,'b':b,'n_pair_complete':len(pairs),'spearman':float(spearmanr(xx,yy).statistic),'selection':'right-censored excluded; not empirical covariance calibration'})
 gp={}
 for name in ['weight','length','head']:
  x=[r['physical']['growth_z'][name]for r in monthly[6]];y=[r['physical']['growth_z'][name]for r in monthly[24]];gp[name]={'6to24_r':float(np.corrcoef(x,y)[0,1]),'not_calibrated_longitudinal':True}
 (args.input/'individual_differences.json').write_text(json.dumps({'trait_persistence':persistence,'growth_rank_persistence':gp,'milestone_domain_correlations':devcorr,'weekly_growth_constraints_per_child':{'mean':float(np.mean([f['physical_health']['monotonic_constraint_count']for f in finals])),'fraction_with_any':float(np.mean([f['physical_health']['monotonic_constraint_count']>0 for f in finals]))},'scientific_limit':'Persistent, stochastic individual differences demonstrated internally; Japanese joint longitudinal latent dynamics NOT validated'},ensure_ascii=False,indent=2))
 who_ref=json.loads((ROOT/'data/WHO_motor_reference.json').read_text());mapping={'Sitting without support':'sitting_unsupported','Standing with assistance':'standing_with_support','Hands-and-knees crawling':'crawling','Walking alone':'walking_independently'};who={mapping[r['name']]:{'p01':next(p['months']for p in r['points']if p['percentile']==1),'p99':next(p['months']for p in r['points']if p['percentile']==99)} for r in who_ref['rows']if r['name']in mapping}
 # Source WHO official percentile table normalized separately; only endpoints
 # verified in primary abstract are used until exact table values are supplied.
 whoc=[]
 for name,v in who.items():
  whoc.append({'milestone':name,'WHO_1st_99th_window_months':[v['p01'],v['p99']],'generated_1st_99th':[calibration[name]['generated_onset_quantiles_months']['0.01'],calibration[name]['generated_onset_quantiles_months']['0.99']],'definition_caution':'WHO directly assessed healthy international816; Japanese parent report different definitions/selection; crawling may include different locomotion; not a universal diagnostic window'})
 (args.input/'WHO_independent_motor_comparison.json').write_text(json.dumps({'source':'PMID16817682; WHO official windows table','not_used_in_calibration':True,'WHO_non_handsknees_crawlers_percent':4.3,'not_implemented_as_Japanese_non_crawler_prevalence':True,'comparisons':whoc},ensure_ascii=False,indent=2))
 domains=[('身体発育','部分校正','日本2023周辺分位点;2010独立歴史資料比較','縦断順位・体格相関・出生標本選択・月齢内補間'),('粗大運動','部分校正','日本2023親回答7項目中6;2010とWHO別標本','能力と報告の差、領域間相関、非はいはい経路'),('微細運動','未校正','日本J-ASQ集計平均SD取得、潜在能力への測定接続未実装','旧pincer時期停止;尺度項目を転載せずNULL領域;個体内分布は未識別'),('受容言語','未校正','日本版尺度研究は確認、数値移植未実装','旧固定閾値停止;測定ライセンスと原表必要'),('表出言語','部分校正','日本2023初語親回答率','語彙量・二語文・言語理解との同時分布未校正'),('睡眠','6/12/18か月の回答区分のみ部分校正','JECS公開表2;独立睡眠標本未検証','0–5/19–24か月・縦断・客観睡眠・リズム未校正'),('授乳・食事','未実装','日本JECSと系統レビュー本文調査','摂取量、栄養、月次移行分布未取得;養育の優劣をつけない'),('気質・情動・注意・探索・自己調整','未校正','日本6→24か月尺度相関・n26縦断研究確認','数値潜在状態と行動係数・出生時測定は未識別'),('親子関係','未校正・数値効果停止','RCT介入パッケージ効果と接触時間を区別','養育者別ID/経験のみ;愛着安全性は未推定'),('健康と医学的条件','対象制限継続','正期産37–41週単胎参照','早産・多胎・疾患・死亡・感染確率未実装'),('行動観測','内部検証のみ','不可能技能誤報修正と条件付き反応実験','感度特異度・場面頻度・観察者誤差は実証未校正'),('家庭からの因果効果','未識別・標準停止','102RCTの介入パッケージ等を検討','A雇用・保育・家計も未確認;単位時間の固定効果なし')]
 (args.input/'domain_validity.json').write_text(json.dumps({'all_children_externally_validated':False,'causal_effects_identified':False,'two_to_six_year_decision':'research design and data acquisition may proceed in parallel; scientifically validated production extension NO-GO until domain-specific gaps closed','domains':[dict(zip(['domain','status','available_support','remaining_gap'],x))for x in domains]},ensure_ascii=False,indent=2))
 summary['seconds']=time.time()-start;(args.input/'analysis_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
