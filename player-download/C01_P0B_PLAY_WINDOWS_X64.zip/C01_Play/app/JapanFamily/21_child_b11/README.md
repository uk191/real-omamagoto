# B-1.1 統合研究版

47都道府県の既存A家庭生成APIを使用した10,340家庭・24か月の研究結果。旧A〜B1.0を変更せず、21_child_b11を追加した。

- [構築・校正・体験検証報告](B1.1_BUILD_REPORT.md)
- [10家庭の親観察記録と比較実験](results/examples/parent_growth_records_10.json)
- [3家庭の選択・反応・翌月の記録](results/examples/decision_experiences_3.md)
- [校正結果の比較図](results/figures/calibration_and_parent_records.png)
- [領域別の妥当性判定](results/cohort_10340/domain_validity.json)
- [数式・識別範囲](docs/model_design.md)
- [月途中出生・家庭接続API](docs/calendar_and_api.md)
- [研究資料の採用判断](docs/research_review.md)
- [再構築・差分適用・保存後検査](docs/rebuild.md)

軽量パックだけで：

```bash
python JapanFamily/21_child_b11/scripts/demo_standalone.py
python JapanFamily/21_child_b11/scripts/playback_example.py --family 1 --month 12
```

新しいA家庭の生成には、ハッシュ固定した既存正式B1.0の統計DBが必要。追加データパックは新しい47個のSQLiteだけを含み、旧5.31GBを再配布しない。

実行・内部整合性・同一出典校正・独立資料への外部適合・因果効果を区別している。微細運動、受容言語、食事、気質・行動・親子関係の数値は未校正/未実装部分が残る。2〜6歳への検証済み製品モデルとしての拡大はNO-GO、資料取得と研究設計は継続可能。
