"""A calendar accounting + B exact birth-relative age, with explicit forecasts.

A cannot provide empirical daily exposure. A representative calendar-month
profile is held constant over intersecting B dates, solely as a scenario.
Uncommitted full-month forecasts are separate from completed A accounting.
"""
import copy,datetime as dt,json,sys
from pathlib import Path
from .engine import Child,VERSION,PARAMETER_HASH,anniversary,digest
PROJECT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(PROJECT/'20_integrated_b10'))
from integrated_b10.legacy import a18_engine_class
class Simulation:
 def __init__(self,engine):self.engine=engine
 @classmethod
 def initialize(cls,prefecture_code='13',*,seed=0,birth_date='2026-10-01',conditions=None,initial_family=None,child_seed=None,engine=None,observation_opportunity=.6,birth_profile=None):
  if not isinstance(seed,(int,str)) or isinstance(seed,bool):raise ValueError('seed integer or string')
  if type(observation_opportunity) not in [int,float] or not 0<=observation_opportunity<=1:raise ValueError('opportunity0..1')
  profile=copy.deepcopy(birth_profile or {})
  if set(profile)-{'gestation_days','birth_weight_kg','birth_length_cm','evidence_kind','known_by'}:raise ValueError('unknown birth profile')
  if profile and profile.get('evidence_kind') not in ['observed_external','explicit_scenario']:raise ValueError('birth input provenance required')
  if profile.get('gestation_days') is not None and (type(profile['gestation_days']) is not int or not 259<=profile['gestation_days']<=293):raise NotImplementedError('term37..41 weeks only; no premature-body coefficient')
  obj=cls(engine or a18_engine_class()());obj.a=obj.engine.initialize(prefecture_code,conditions,seed,birth_date,None,True,initial_family)
  h=obj.a['household'];hid=h['household_id'];index=h['index_person_id'];people={p['person_id']:p for p in obj.a['persons']}
  if h['multiplicity']!=1:raise NotImplementedError('multiple births not calibrated; A roster is never replaced')
  sex=people[index]['sex']
  if sex not in ['male','female']:raise NotImplementedError('growth sex reference missing')
  cgs=sorted(obj.a['parents']);links={k:hid+'/'+k for k in people}
  obj.identity={'run_id':'b11_'+digest([VERSION,seed,birth_date,prefecture_code,child_seed,digest(obj.a['initial_family'])])[:24],'household_id':hid,'index_local_person_id':index,'index_global_person_id':links[index],'caregiver_local_ids':cgs,'person_links':links,'birth_date':birth_date,'delivery_event_id':h['delivery_event_id']}
  bseed=int(digest([VERSION,seed,'B_stream'])[:15],16) if child_seed is None else child_seed
  obj.child=Child.generate(seed=bseed,birth_date=birth_date,child_id=links[index],caregiver_ids=[links[k] for k in cgs],sex=sex,**{k:profile[k] for k in ['gestation_days','birth_weight_kg','birth_length_cm'] if k in profile})
  known=profile.get('known_by',cgs)
  if not isinstance(known,list) or set(known)-set(cgs):raise ValueError('birth measurement recipients must be registered caregivers')
  if profile.get('evidence_kind')=='observed_external':
   for k in ['birth_weight_kg','birth_length_cm']:
    if k in profile:obj.child.record_measurement(observer_id=hid+'/birth_record',metric=k.removeprefix('birth_'),value=profile[k],source='observed_external',known_by=[links[p] for p in known])
  obj.config={'seed':seed,'child_seed':bseed,'observation_opportunity':observation_opportunity,'A_unresolved_paths_retained':True,'monthly_profile_to_days':'piecewise constant representative calendar-month scenario; not observed daily care','hypothetical_effects':False,'birth_profile':profile}
  obj.forecast=None;obj.forecast_transactions=[];obj.forecast_actions=[];obj.a_periods=[];obj.records=[];obj.exposures=[];obj.chain='0'*64;obj.initial_a=copy.deepcopy(obj.a);obj.initial_b=obj.child.research_snapshot();obj.assert_consistent();return obj
 @property
 def elapsed_months(self):return self.child._state['elapsed_months']
 def _prepare(self,actions,research_continue):
  if self.a.get('pending_decisions') and not actions and not research_continue:raise RuntimeError('A decision pending; provide action or explicit research continuation')
  actions=copy.deepcopy(actions or []);inverse={v:k for k,v in self.identity['person_links'].items()}
  if not isinstance(actions,list) or any(not isinstance(x,dict) for x in actions):raise ValueError('A action list required')
  for x in actions:
   person=x.get('person');person=inverse.get(person,person)
   if person is not None:
    if person not in self.identity['caregiver_local_ids']:raise ValueError('A actor must be this family caregiver')
    x['person']=person
  nxt=self.engine.step(self.a,actions,retain_journal=True);self.forecast_transactions=nxt['journal'];nxt['journal']=[];nxt['monthly_history']=[nxt['last_month']];self.forecast=nxt;self.forecast_actions=actions
 def _environment(self,overrides=None):
  row=self.forecast['last_month'];links=self.identity['person_links']
  env={'caregivers':{links[k]:{'contact_episodes_per_day':None,'observation_opportunity':self.config['observation_opportunity']} for k in self.identity['caregiver_local_ids']},'context':'nursery_exposure' if row['care']['status']=='enrolled' and row['time']['nursery']>0 else 'home_or_other','provenance':'native A representative monthly scenario, not identified child developmental causes','a3_context':{'household_id':self.identity['household_id'],'source_month':row['month'],'source_model':'A3.0-0.2','A_quality_flags':self.forecast['quality_flags']}}
  if overrides:
   if set(overrides)-{'sleep_disruption','responsive_episode','language_opportunities','context','caregivers'}:raise ValueError('unknown environmental override')
   env.update(copy.deepcopy(overrides))
  return env
 def advance_to_date(self,date,*,a_actions=None,research_continue=False,environment=None,scenario_effects=False):
  if type(research_continue) is not bool or type(scenario_effects) is not bool:raise ValueError('boolean flags required')
  end=dt.date.fromisoformat(date);birth=dt.date.fromisoformat(self.identity['birth_date']);now=dt.date.fromisoformat(self.child._state['as_of_date'])
  if not now<=end<=anniversary(birth,24):raise ValueError('0..24 months monotone dates only')
  if self.forecast is not None and a_actions:raise ValueError('A monthly profile already prepared; decision can apply at next accounting boundary')
  while now<end:
   if self.forecast is None:self._prepare(a_actions,research_continue);a_actions=None
   boundary=dt.date.fromisoformat(self.forecast['month']);stop=min(end,boundary);env=self._environment(environment)
   self.child.advance_to_date(stop.isoformat(),env,enable_hypothetical_effects=scenario_effects)
   exposure={'start_inclusive':now.isoformat(),'end_exclusive':stop.isoformat(),'days':(stop-now).days,'A_source_month':self.forecast['last_month']['month'],'household_id':self.identity['household_id'],'environment':env,'A_profile_status':'representative_month_scenario'};self.exposures.append(exposure);now=stop
   if now==boundary:
    period={'start':self.a['month'],'end_exclusive':self.forecast['month'],'A_month':copy.deepcopy(self.forecast['last_month']),'A_persons_asof':copy.deepcopy(self.forecast['persons']),'A_transactions':copy.deepcopy(self.forecast_transactions),'requested_actions':copy.deepcopy(self.forecast_actions),'A_decisions':copy.deepcopy(self.forecast['decisions'][len(self.a['decisions']):]),'accounting_status':'completed_calendar_period','research_continued':research_continue,'prebirth_days':max(0,(birth-dt.date.fromisoformat(self.a['month'])).days) if not self.a_periods else 0}
    self.a_periods.append(period);self.a=self.forecast;self.forecast=None;self.forecast_transactions=[];self.forecast_actions=[]
  self.config['hypothetical_effects']=scenario_effects;self.assert_consistent();return self
 def step(self,a_actions=None,*,child_actions=None,research_continue=False,environment=None,scenario_effects=False):
  if self.elapsed_months>=24:raise ValueError('24-month horizon')
  start=self.child._state['as_of_date'];before=len(self.child._state['experience_ledger']);reports=len(self.child._state['parent_observations']);pstart=len(self.a_periods);estart=len(self.exposures)
  # Work on a private candidate: rejected input cannot partially advance A or B.
  obj=self.clone()
  for action in child_actions or []:
   if set(action)-{'kind','caregiver_id'}:raise ValueError('unknown child action fields')
   obj.child.act(action['kind'],caregiver_id=action['caregiver_id'],scenario_effects=scenario_effects)
  target=anniversary(dt.date.fromisoformat(obj.identity['birth_date']),obj.elapsed_months+1).isoformat()
  obj.advance_to_date(target,a_actions=a_actions,research_continue=research_continue,environment=environment,scenario_effects=scenario_effects)
  s=obj.child._state;delta={k:copy.deepcopy(v) for k,v in s.items() if k not in ['experience_ledger','parent_observations','generation_record','initial_dispositions','evidence_provenance','uncertainty_flags','transition_parameters','random_streams','birth_conditions','child_identity']}
  rec={'month':s['elapsed_months'],'start':start,'end':target,'A_period_indices':list(range(pstart,len(obj.a_periods))),'A_exposures':copy.deepcopy(obj.exposures[estart:]),'A_accounting_checkpoint':obj.a['month'],'A_forecast_end':obj.forecast['month'] if obj.forecast else None,'B_delta':delta,'events':copy.deepcopy(s['experience_ledger'][before:]),'parent_observations':copy.deepcopy(s['parent_observations'][reports:]),'child_actions':copy.deepcopy(child_actions or []),'scenario_effects':scenario_effects}
  obj.chain=digest([obj.chain,rec]);obj.records.append(rec);self.__dict__.update(obj.__dict__);return self
 def run(self,months=24,*,research_continue=False,actions_by_month=None):
  if type(months) is not int or not 0<=months<=24-self.elapsed_months:raise ValueError('invalid number of months')
  for _ in range(months):self.step(research_continue=research_continue,**(actions_by_month or {}).get(self.elapsed_months,{}))
  return self
 def player_view(self,observer='mother'):
  if observer not in self.identity['caregiver_local_ids']:
   inverse={v:k for k,v in self.identity['person_links'].items()};observer=inverse.get(observer,observer)
  if observer not in self.identity['caregiver_local_ids']:raise PermissionError('observer not a caregiver')
  # Forecast events and child truth are never exposed to the player.
  return {'household_id':self.identity['household_id'],'as_of_date':self.child._state['as_of_date'],'A_accounting_through':self.a['month'],'child':self.child.player_view(self.identity['person_links'][observer]),'A_completed_periods':[{k:p[k] for k in ['start','end_exclusive','requested_actions','A_decisions']} for p in self.a_periods]}
 def assert_consistent(self):
  s=self.child._state;birth=dt.date.fromisoformat(self.identity['birth_date']);now=dt.date.fromisoformat(s['as_of_date']);a_date=dt.date.fromisoformat(self.a['month']);hid=self.identity['household_id']
  assert s['model_version']==VERSION and s['parameter_sha256']==PARAMETER_HASH
  assert s['age_days']==(now-birth).days and a_date<=now
  assert self.a['household']['household_id']==hid and s['child_identity']['child_id']==self.identity['index_global_person_id']
  assert s['child_identity']['birth_date']==self.a['birth_date']==self.identity['birth_date']
  assert not self.a['quality_flags']['financially_playable'] and not self.a['quality_flags']['newborn_full_joint_externally_validated']
  if self.forecast:assert now<dt.date.fromisoformat(self.forecast['month'])
  if self.exposures:
   assert self.exposures[0]['start_inclusive']==birth.isoformat() and self.exposures[-1]['end_exclusive']==now.isoformat()
   assert all(a['end_exclusive']==b['start_inclusive'] for a,b in zip(self.exposures,self.exposures[1:]))
  assert sum(e['days'] for e in self.exposures)==s['age_days']
  assert set(s['caregiver_relationships'])=={self.identity['person_links'][k] for k in self.identity['caregiver_local_ids']}
  return True
 def clone(self):
  obj=copy.copy(self)
  # Immutable completed records and native A checkpoints are shared; the A
  # engine already deep-copies its input. Only mutable continuation is copied.
  obj.child=copy.deepcopy(self.child);obj.config=copy.deepcopy(self.config)
  obj.a_periods=list(self.a_periods);obj.records=list(self.records);obj.exposures=list(self.exposures)
  return obj
 def payload(self):return {k:(v.research_snapshot() if k=='child' else copy.deepcopy(v)) for k,v in self.__dict__.items() if k!='engine'}
 def save(self,path):
  payload=self.payload();env={'model_version':VERSION,'parameter_sha256':PARAMETER_HASH,'payload':payload,'sha256':digest(payload)};p=Path(path);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(env,ensure_ascii=False,sort_keys=True,allow_nan=False));tmp.replace(p)
 @classmethod
 def load(cls,path,*,engine=None):
  env=json.loads(Path(path).read_text());payload=env['payload']
  if env['model_version']!=VERSION or env['parameter_sha256']!=PARAMETER_HASH or digest(payload)!=env['sha256']:raise ValueError('checkpoint integrity/version mismatch')
  obj=cls(engine or a18_engine_class()())
  for k,v in payload.items():
   if k=='child':c=Child();c._state=v;setattr(obj,k,c)
   else:setattr(obj,k,v)
  obj.assert_consistent();return obj
