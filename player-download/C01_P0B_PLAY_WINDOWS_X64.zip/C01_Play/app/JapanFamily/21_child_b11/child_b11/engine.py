"""B-1.1 research kernel. Published marginals; explicitly assumed joint dynamics.

No parenting-hour, income, nursery, attachment, diagnosis or IQ coefficient.
Fixed birth-relative weekly ticks make date partition and save/resume invariant.
"""
import copy,datetime as dt,json,math,sys
from functools import lru_cache
from pathlib import Path
import numpy as np
from scipy.special import ndtr
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent
sys.path.insert(0,str(PROJECT/'19_child_b10'))
from child_b10.engine import Child as BaseChild, PARAMS as OLD, anniversary, logistic,unit,validate_environment,finite
from child_b10.randomness import normal,uniform,digest
from child_b10.japan_reference import from_z,to_z
from child_b10.player_api import parent_observations
PARAMS=json.loads((ROOT/'data/parameters.json').read_text());VERSION=PARAMS['version'];PARAMETER_HASH=digest(PARAMS)
METRICS={'weight':('weianthro','weight_kg'),'length':('lenanthro','length_cm'),'head':('hcanthro','head_circumference_cm')}
MILESTONES=list(PARAMS['milestone_fits']);SKILL_SIGNALS={'takes_independent_steps':'walking_independently','uses_contextual_word':'first_contextual_word'}
@lru_cache(maxsize=8)
def growth_transition(lengthscale):
 w=1/lengthscale;t=7/30.4375;e=math.exp(-w*t);a=e*np.array([[1+w*t,t],[-w*w*t,1-w*t]]);s=np.diag([1,w*w]);q=s-a@s@a.T
 return a,np.linalg.cholesky((q+q.T)/2)
def sleep_parameters(age):
 rows=PARAMS['sleep_anchors'];x=min(18,max(6,age));lo=rows[0];hi=rows[-1]
 for a,b in zip(rows,rows[1:]):
  if a['age_months']<=x<=b['age_months']:lo,hi=a,b;break
 f=(x-lo['age_months'])/(hi['age_months']-lo['age_months'])
 return (lo['mean_hours']*(1-f)+hi['mean_hours']*f,lo['sd_hours']*(1-f)+hi['sd_hours']*f)
def cumulative_hazard(name,days,shape):
 if days<=0:return 0.
 f=PARAMS['milestone_fits'][name];z=(math.log(days/30.4375)-f['log_mu'])/f['log_sd'];surv=max(1e-14,float(ndtr(-z)))
 return shape*math.expm1(-math.log(surv)/shape)
class Child(BaseChild):
 @classmethod
 def generate(cls,**kwargs):
  obj=super().generate(**kwargs);s=obj._state;seed=s['random_streams']['seed']
  s.update(model_version=VERSION,parameter_sha256=PARAMETER_HASH,schema_version=2)
  # Legacy initialization is retained only for birth references and unmeasured
  # computational priors. Its future onset targets and ability clocks are discarded.
  s['transition_parameters']={'future_onset_targets':'not_generated_or_used_in_B11','frailty':{},'parameters':{'trait_monthly_retention':PARAMS['trait_monthly_retention'],'growth_lengthscale_months':PARAMS['growth_lengthscale_months'],'frailty_shape':PARAMS['frailty_shape'],'behavior_weight':1.}}
  rng=np.random.default_rng(int(digest([seed,'frailty-v1'])[:16],16));shared=float(rng.gamma(1,1/4));domains={d:float(rng.gamma(1,1/4)) for d in ['motor','language']}
  for name in MILESTONES:s['transition_parameters']['frailty'][name]=shared+domains['language' if name=='first_contextual_word' else 'motor']+float(rng.gamma(2,1/4))
  s['developmental_state'].update(progress={k:None for k in OLD['development_domains']},milestones={},status='seven_report_proxy_capacities; other domain scores unmeasured',inactive_uncalibrated_milestones=[k for k in OLD['milestones'] if k not in MILESTONES])
  s['caregiver_relationships']={k:{'contact_episodes':0.,'last_contact_date':None,'familiarity':None,'attachment_classification':None,'attachment_status':'not_inferred'} for k in s['caregiver_relationships']}
  s['experience_memory']={'contexts':{},'autobiographical_recall':None,'mechanism':'exposure_bookkeeping_only; no attachment or autobiographical inference'}
  s['sleep']={'reported_day_duration_hours':None,'measurement_status':'no_calibrated_birth_sleep_distribution','calibration_scope':'JECS6,12,18mo complete-case caregiver categories only'}
  s['tick']=0;s['sleep_rank']=normal(seed,'sleep_rank_initial');s['hypothesis_offset_hours']=0.
  s['growth_process']={'week':0,'vectors':{k:[v,normal(seed,'growth_velocity',k)/PARAMS['growth_lengthscale_months']] for k,v in s['physical_health']['growth_z'].items()},'body':{k:s['physical_health'][v[1]] for k,v in METRICS.items()},'constraint_count':0}
  obj._forecast_growth();s['experience_ledger']=[];s['parent_observations']=[];s['observed_behaviors']=[]
  s['evidence_provenance'].update(seven_milestones='Japanese2023 bin-integrated report-proxy marginal fit; gamma frailty joint law unidentified',growth_dynamics='Matern3/2 smooth rank process; length/head projection unidentified',sleep='PMID42487822 Table2 category calibration; no sleep-to-development causal effect',behaviors='conditional stochastic hypothesis, no validated observation sensitivity',birth_traits='unmeasured computational priors, not administered Japanese IBQ scores')
  s['uncertainty_flags']=['term37to41_singleton_reference_only','Japanese2023_to2026_transport_unverified','growth_joint_and_longitudinal_law_unidentified','milestone_report_to_capacity_measurement_model','temperament_covariance_and_retention_unidentified','behavior_and_observation_coefficients_unidentified','no_clinical_diagnostic_inference','sleep_outside6to18months_uncalibrated','five_old_scenario_milestones_disabled','A3_environment_not_a_validated_causal_input']
  s['generation_record'].update(version=VERSION,parameters=PARAMETER_HASH)
  s['generation_record']['distributions'].update(milestones='sequential birth-relative weekly hazards; Gamma4 frailty; no birth onset targets',growth=PARAMS['growth_process'],speed='legacy speed scores discarded, not IQ')
  s['history_chain']='0'*64;obj._event('birth',dt.date.fromisoformat(s['as_of_date']),[],{'generation_record':s['generation_record']},[],'mixed_reference_and_assumption');return obj
 def _forecast_growth(self):
  s=self._state;g=s['growth_process'];seed=s['random_streams']['seed'];week=g['week']+1;lengthscale=s['transition_parameters']['parameters']['growth_lengthscale_months'];a,l=growth_transition(lengthscale)
  base=[normal(seed,'smooth_growth',week,'length',j) for j in range(2)];vectors={};body={}
  for name,(table,key) in METRICS.items():
   loading={'length':1.,'weight':.55,'head':.4}[name]
   n=np.array([loading*base[j]+math.sqrt(1-loading*loading)*normal(seed,'smooth_growth',week,name,j) for j in range(2)])
   v=a@np.asarray(g['vectors'][name])+l@n;vectors[name]=[float(x) for x in v]
   val=from_z(table,s['child_identity']['sex_for_growth_reference'],week*7,float(v[0]))
   body[name]=max(g['body'][name],val) if name!='weight' else val
  g['next_vectors']=vectors;g['next_body']=body
 def _body_at(self,days):
  s=self._state;g=s['growth_process'];f=(days-g['week']*7)/7
  for name,(table,key) in METRICS.items():
   value=g['body'][name]+f*(g['next_body'][name]-g['body'][name]);s['physical_health'][key]=value;s['physical_health']['growth_z'][name]=to_z(table,s['child_identity']['sex_for_growth_reference'],days,value)
  s['physical_health']['monotonic_constraint_count']=g['constraint_count'];s['physical_health']['measured_or_latent']='latent_reference_trajectory; no automatic parent measurement'
 def _probe(self,*,key,age,context='home_or_other',comfort=False,sleep_loss=0.,familiar=False,unwell=0.,weight=None):
  s=self._state;t=s['latent_state'];e=s['emotion_regulation'];b=s['transition_parameters']['parameters']['behavior_weight'] if weight is None else weight
  fatigue=unit(e['fatigue']+.15*sleep_loss+.2*unwell);distress=unit(e['distress']+.2*unwell)
  logits={'crying':-1+2*distress+.5*e['hunger']+b*.2*t['distress_persistence'],
   'settles_after_comfort':-.2+1.3*e['settling']-distress+b*.25*t['soothability'],
   'orients_to_unfamiliar_object':.2+b*(.4*t['approach']-.35*t['inhibition']+.2*t['exploration'])-fatigue+(.25 if familiar else 0),
   'looks_toward_voice':.1+b*(.3*t['social_orientation']+.2*t['attention_orientation'])-.2*fatigue,
   'difficulty_settling':-.6+fatigue-b*.4*t['sleep_regularity'],
   'sustains_object_attention':-.8+min(age,24)/24+b*.4*t['attention_persistence']-fatigue,
   'withdraws_from_intense_stimulus':-.4+b*(.45*t['sensory_sensitivity']+.3*t['inhibition'])+distress,
   'explores_available_space':-.7+min(age,24)/24+b*(.35*t['activity']+.35*t['exploration'])-fatigue}
  if comfort:logits['settles_after_comfort']+=PARAMS['hypothetical_comfort_logit']
  probs={k:logistic(v) for k,v in logits.items()};dev=s['developmental_state']['milestones']
  for signal,milestone in SKILL_SIGNALS.items():probs[signal]=.65 if milestone in dev else 0.
  seed=s['random_streams']['seed'];signals={k:uniform(seed,'B11_behavior',key,k)<p for k,p in probs.items()}
  return {'date':s['as_of_date'],'context':context,'sampling':'one synthetic elicited situation; not daily prevalence','signals':signals,'probabilities':probs,'assumption':'unvalidated conditional behavioral model; no deterministic trait classification'}
 def probe(self,**kwargs):
  """Trusted research probe; probabilities must never enter a player projection."""
  return self._probe(age=self._state['age_days']/30.4375,**kwargs)
 def _reports(self,behavior,env,key):
  s=self._state;seed=s['random_streams']['seed'];reports=[]
  for cg in sorted(s['caregiver_relationships']):
   opportunity=env.get('caregivers',{}).get(cg,{}).get('observation_opportunity',0);obs={};interpret=[]
   for signal,actual in behavior['signals'].items():
    if uniform(seed,'B11_opportunity',key,cg,signal)>=opportunity:continue
    if signal in SKILL_SIGNALS:
     # A non-existent action is not misreported as an acquired newborn skill.
     # Adult interpretation of babbling/assisted steps remains a separate unknown.
     obs[signal]=bool(actual and uniform(seed,'B11_error',key,cg,signal)<.85)
    else:obs[signal]=uniform(seed,'B11_error',key,cg,signal)<(.85 if actual else .1)
   if obs:reports.append({'observer_id':cg,'date':behavior['date'],'source':'synthetic_caregiver_report','behaviors':obs,'interpretation':'観察した場面の記録。気質・能力・愛着の診断はできません。','uncertain':True})
  s['parent_observations'].extend(reports);return reports
 def _tick(self,env,effects):
  s=self._state;week=s['tick']+1;days=week*7;seed=s['random_streams']['seed'];birth=dt.date.fromisoformat(s['child_identity']['birth_date']);date=birth+dt.timedelta(days=days);s['as_of_date']=date.isoformat();s['age_days']=days
  rho=s['transition_parameters']['parameters']['trait_monthly_retention']**(7/30.4375);factors=[normal(seed,'B11_trait_factor',week,j) for j in range(3)]
  for name,loads in OLD['trait_loadings'].items():
   innovation=sum(a*b for a,b in zip(loads,factors))+math.sqrt(1-sum(v*v for v in loads))*normal(seed,'B11_trait_residual',week,name)
   s['latent_state'][name]=rho*s['latent_state'][name]+math.sqrt(1-rho*rho)*innovation
  new=[];shape=s['transition_parameters']['parameters']['frailty_shape']
  for name in MILESTONES:
   if name in s['developmental_state']['milestones']:continue
   delta=cumulative_hazard(name,days,shape)-cumulative_hazard(name,days-7,shape);p=-math.expm1(-s['transition_parameters']['frailty'][name]*delta)
   if uniform(seed,'B11_milestone_week',week,name)<p:
    rec={'onset_interval':[(date-dt.timedelta(days=7)).isoformat(),date.isoformat()],'age_days_interval':[days-7,days],'evidence':'same_source_report_calibration; capacity measurement assumption'}
    s['developmental_state']['milestones'][name]=rec;new.append(name)
  # Logical prerequisite closure records an inferred capacity, never a separate observed attainment.
  for child,parent in [('walking_independently','standing_with_support'),('sitting_unsupported','head_control')]:
   if child in s['developmental_state']['milestones'] and parent not in s['developmental_state']['milestones']:
    rec=copy.deepcopy(s['developmental_state']['milestones'][child]);rec.update(inferred_from=child,evidence='logical prerequisite closure; may shift marginal report fit');s['developmental_state']['milestones'][parent]=rec;new.append(parent)
  sr=PARAMS['sleep_monthly_retention']**(7/30.4375);s['sleep_rank']=sr*s['sleep_rank']+math.sqrt(1-sr*sr)*normal(seed,'B11_sleep',week)
  mean,sd=sleep_parameters(days/30.4375);offset=PARAMS['hypothetical_sleep_disruption_hours']*env.get('sleep_disruption',0) if effects else 0.
  duration=max(.5,min(23.5,mean+sd*s['sleep_rank']-offset));s['hypothesis_offset_hours']=offset
  s['sleep']['reported_day_duration_hours']=duration;s['sleep']['measurement_status']='same-source two-cutpoint fitted report-duration proxy' if 6<=days/30.4375<=18 else 'outside calibrated age; held anchor scenario'
  t=s['latent_state'];e=s['emotion_regulation'];age=days/30.4375
  targets={'distress':logistic(-1+.4*t['reactivity']-.2*t['soothability']),'fatigue':.3+.05*offset,'hunger':logistic(-.6+.2*t['feeding_reactivity']),'arousal':logistic(-.3+.3*t['activity']),'settling':logistic(.1+.35*t['soothability']+.01*age),'sleep_pressure':.35}
  for k,v in targets.items():e[k]=unit(v+.55**7*(e[k]-v)+.08*normal(seed,'B11_short_state',week,k))
  if effects:e['distress']=unit(e['distress']-.08*env.get('responsive_episode',0))
  g=s['growth_process'];g['week']=week;g['vectors']=g['next_vectors'];g['body']=g['next_body']
  for name,(table,key) in METRICS.items():
   if name!='weight' and abs(g['body'][name]-from_z(table,s['child_identity']['sex_for_growth_reference'],days,g['vectors'][name][0]))>1e-10:g['constraint_count']+=1
  self._forecast_growth();self._body_at(days)
  behavior=self._probe(key=['week',week],age=age,context=env.get('context','home_or_other'));behavior['date']=date.isoformat();s['observed_behaviors'].append(behavior);reports=self._reports(behavior,env,['week',week])
  for name in new:self._event('latent_report_proxy_transition',date,[],{'milestone':name,'onset_interval':s['developmental_state']['milestones'][name]['onset_interval']},[],'same_source_calibrated; measurement_model_dependent')
  s['tick']=week
 def advance_to_date(self,date,environment=None,*,enable_hypothetical_effects=False):
  s=self._state;birth=dt.date.fromisoformat(s['child_identity']['birth_date']);start=dt.date.fromisoformat(s['as_of_date']);end=dt.date.fromisoformat(date)
  if type(enable_hypothetical_effects) is not bool:raise ValueError('explicit boolean required')
  if not start<=end<=anniversary(birth,24):raise ValueError('date must be monotone and <=24-month birthday')
  env=validate_environment(environment or {},s['caregiver_relationships']);days=(end-birth).days;before=len(s['parent_observations']);s['observed_behaviors']=[]
  while (s['tick']+1)*7<=days:self._tick(env,enable_hypothetical_effects)
  span=(end-start).days;context=env.get('context','home_or_other');mem=s['experience_memory']['contexts'].setdefault(context,{'exposure_days':0,'last_date':None});mem['exposure_days']+=span;mem['last_date']=end.isoformat()
  for cg,rel in s['caregiver_relationships'].items():
   episodes=env.get('caregivers',{}).get(cg,{}).get('contact_episodes_per_day')
   if episodes is not None:rel['contact_episodes']+=episodes*span;rel['last_contact_date']=end.isoformat() if episodes else rel['last_contact_date']
  s.update(as_of_date=end.isoformat(),age_days=days,elapsed_months=max(m for m in range(25) if anniversary(birth,m)<=end),calendar_months_crossed=(end.year-birth.year)*12+end.month-birth.month,scenario_effects_enabled=enable_hypothetical_effects)
  self._body_at(days)
  reports=s['parent_observations'][before:]
  if span:
   event=self._event('ordinary_exposure',end,list(s['caregiver_relationships']),{'date_interval':[start.isoformat(),end.isoformat()],'days':span,'context':context,'effects_enabled':enable_hypothetical_effects,'environment':env},sorted({r['observer_id'] for r in reports}),'game_scenario' if enable_hypothetical_effects else 'exposure bookkeeping; no environmental developmental causal effect');event['observable_reaction']=copy.deepcopy(reports)
  s['history_chain']=digest([s['history_chain'],start.isoformat(),date,env,enable_hypothetical_effects]);return self
 def advance_one_month(self,environment=None,*,enable_hypothetical_effects=False):
  s=self._state;birth=dt.date.fromisoformat(s['child_identity']['birth_date']);month=s['elapsed_months']+1
  if month>24:raise ValueError('24-month research horizon')
  return self.advance_to_date(anniversary(birth,month).isoformat(),environment,enable_hypothetical_effects=enable_hypothetical_effects)
 def act(self,kind,*,caregiver_id,scenario_effects=False):
  s=self._state
  if caregiver_id not in s['caregiver_relationships']:raise PermissionError('unknown caregiver')
  if kind not in ['observe','offer_comfort','shared_play','keep_routine']:raise ValueError('unknown child action')
  if type(scenario_effects) is not bool:raise ValueError('explicit scenario flag required')
  key=['action',len(s['experience_ledger'])];before=copy.deepcopy(s['emotion_regulation']);behavior=self._probe(key=key,age=s['age_days']/30.4375,comfort=kind=='offer_comfort' and scenario_effects,context='parent_'+kind)
  reports=self._reports(behavior,{'caregivers':{caregiver_id:{'observation_opportunity':1.}}},key)
  event=self._event('parent_action',dt.date.fromisoformat(s['as_of_date']),[caregiver_id],{'requested_action':kind,'state_before':before,'state_after':copy.deepcopy(s['emotion_regulation']),'biological_carryover':False,'comfort_logit_offset':PARAMS['hypothetical_comfort_logit'] if kind=='offer_comfort' and scenario_effects else 0},[caregiver_id],'unvalidated acute scenario' if scenario_effects else 'action and observation bookkeeping; biological effect disabled');event['observable_reaction']=reports
  return copy.deepcopy(reports)
 def player_view(self,observer_id,*,since_date=None):return parent_observations(self,observer_id,since_date=since_date)
 def research_snapshot(self,*,compact=False):return copy.deepcopy(self._state)
 @classmethod
 def load(cls,path):
  env=json.loads(Path(path).read_text());s=env['payload']
  if digest(s)!=env['payload_sha256'] or s['model_version']!=VERSION or s['parameter_sha256']!=PARAMETER_HASH or s['schema_version']!=2:raise ValueError('snapshot version or integrity mismatch')
  obj=cls();obj._state=s;return obj
