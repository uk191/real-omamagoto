"""Incremental databases only: immutable legacy A/B databases are external pins."""
import json,zlib,sqlite3
SCHEMA='''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS b11_case(run_id TEXT PRIMARY KEY,prefecture TEXT NOT NULL,seed TEXT NOT NULL,geographic_weight REAL NOT NULL,identity BLOB NOT NULL,configuration BLOB NOT NULL,initial_a BLOB NOT NULL,initial_b BLOB NOT NULL);
CREATE TABLE IF NOT EXISTS b11_month(run_id TEXT NOT NULL REFERENCES b11_case,month INTEGER CHECK(month BETWEEN 1 AND 24),date TEXT NOT NULL,payload BLOB NOT NULL,sha256 TEXT NOT NULL,PRIMARY KEY(run_id,month));
CREATE TABLE IF NOT EXISTS b11_a_period(run_id TEXT NOT NULL REFERENCES b11_case,period INTEGER NOT NULL,payload BLOB NOT NULL,PRIMARY KEY(run_id,period));
CREATE TABLE IF NOT EXISTS b11_checkpoint(run_id TEXT NOT NULL REFERENCES b11_case,month INTEGER NOT NULL,payload BLOB NOT NULL,PRIMARY KEY(run_id,month));
CREATE TABLE IF NOT EXISTS b11_failure(prefecture TEXT,seed TEXT PRIMARY KEY,payload TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS b11_run(key TEXT PRIMARY KEY,value TEXT NOT NULL);
'''
def encode(obj):return zlib.compress(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode(),3)
def decode(blob):return json.loads(zlib.decompress(blob))
def connect(path):
 db=sqlite3.connect(path);db.executescript(SCHEMA);db.execute('PRAGMA synchronous=NORMAL');return db
def restore(db,run_id,month=24,*,engine=None):
 """Restore incremental checkpoint and replayable ledgers without copying old DBs."""
 from .integrated import Simulation,a18_engine_class
 from .engine import Child
 case=db.execute('SELECT initial_a,initial_b FROM b11_case WHERE run_id=?',(run_id,)).fetchone()
 checkpoint=db.execute('SELECT payload FROM b11_checkpoint WHERE run_id=? AND month=?',(run_id,month)).fetchone()
 if not case or not checkpoint:raise ValueError('case/checkpoint missing; stored boundaries12 or24 only')
 obj=Simulation(engine or a18_engine_class()());obj.initial_a=decode(case[0]);obj.initial_b=decode(case[1]);ck=decode(checkpoint[0])
 for k,v in ck.items():
  if k=='reconstruction':continue
  if k=='child':c=Child();c._state=v;obj.child=c
  else:setattr(obj,k,v)
 obj.records=[decode(b)for b, in db.execute('SELECT payload FROM b11_month WHERE run_id=? AND month<=? ORDER BY month',(run_id,month))]
 obj.a_periods=[decode(b)for b, in db.execute('SELECT payload FROM b11_a_period WHERE run_id=? AND period<=? ORDER BY period',(run_id,obj.a['elapsed_months']))]
 obj.exposures=[e for r in obj.records for e in r['A_exposures']]
 obj.child._state['experience_ledger']=obj.initial_b['experience_ledger']+[e for r in obj.records for e in r['events']]
 obj.child._state['parent_observations']=obj.initial_b['parent_observations']+[o for r in obj.records for o in r['parent_observations']]
 obj.assert_consistent();return obj
