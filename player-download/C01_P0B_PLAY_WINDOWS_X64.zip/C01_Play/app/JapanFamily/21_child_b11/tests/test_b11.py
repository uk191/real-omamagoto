import copy,datetime as dt,json,tempfile,unittest
from pathlib import Path
from child_b11.engine import Child,anniversary,PARAMS,PARAMETER_HASH
from child_b11.integrated import Simulation,a18_engine_class
class KernelTests(unittest.TestCase):
 def test_no_precise_future(self):
  c=Child.generate(seed=1);self.assertNotIn('milestone_onset_targets_months',c._state['transition_parameters']);self.assertTrue(all(v is None for v in c._state['developmental_state']['progress'].values()))
 def test_save_resume(self):
  a=Child.generate(seed=2,birth_date='2026-01-31');a.advance_to(12)
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'c.json';a.save(p);b=Child.load(p)
  a.advance_to(24);b.advance_to(24);self.assertEqual(a.research_snapshot(),b.research_snapshot())
 def test_date_partition(self):
  a=Child.generate(seed=3);b=Child.generate(seed=3);a.advance_to_date('2027-01-15');b.advance_to_date('2026-04-06');b.advance_to_date('2027-01-15')
  for key in ['physical_health','latent_state','emotion_regulation','sleep','growth_process','developmental_state']:self.assertEqual(a._state[key],b._state[key],key)
 def test_no_newborn_false_skills(self):
  for seed in range(20):
   c=Child.generate(seed=seed);c.advance_one_month({'caregivers':{'mother':{'observation_opportunity':1}}})
   self.assertTrue(all(not r['behaviors'].get(k) for r in c._state['parent_observations']for k in ['takes_independent_steps','uses_contextual_word']))
 def test_not_automatic_measurement(self):
  c=Child.generate(seed=1);c.advance_to(24);self.assertEqual(c.player_view('mother')['measurements'],[])
  self.assertNotIn('latent_state',json.dumps(c.player_view('mother')))
  with self.assertRaises(PermissionError):c.player_view('stranger')
 def test_no_action_development(self):
  c=Child.generate(seed=4);birth=c._state['physical_health']['length_cm'];c.advance_to(24);self.assertGreater(c._state['physical_health']['length_cm'],birth);self.assertIn('walking_independently',c._state['developmental_state']['milestones'])
 def test_unidentified_off(self):
  a=Child.generate(seed=5);b=Child.generate(seed=5);a.advance_to(24);b.advance_to(24,{i:{'sleep_disruption':1,'responsive_episode':1,'language_opportunities':1}for i in range(1,25)})
  for k in ['physical_health','latent_state','developmental_state','emotion_regulation','sleep']:self.assertEqual(a._state[k],b._state[k])
 def test_scenario_not_ability(self):
  a=Child.generate(seed=5);b=Child.generate(seed=5);a.advance_to(24);b.advance_to(24,{i:{'sleep_disruption':1}for i in range(1,25)},enable_hypothetical_effects=True)
  self.assertEqual(a._state['developmental_state'],b._state['developmental_state']);self.assertNotEqual(a._state['sleep'],b._state['sleep'])
 def test_medical_scope(self):
  for g in [252,294]:
   with self.assertRaises(NotImplementedError):Child.generate(seed=1,gestation_days=g)
 def test_growth_and_sequence(self):
  c=Child.generate(seed=5);last=0
  for m in range(24):c.advance_one_month();self.assertGreaterEqual(c._state['physical_health']['length_cm'],last);last=c._state['physical_health']['length_cm']
  self.assertEqual([e['date']for e in c._state['experience_ledger']],sorted(e['date']for e in c._state['experience_ledger']))
class IntegrationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.engine=a18_engine_class()()
 def test_midmonth_exact_age(self):
  for birth in ['2026-01-01','2026-01-31','2026-02-28','2026-12-17']:
   s=Simulation.initialize('13',seed=123,birth_date=birth,engine=self.engine);s.run(24,research_continue=True);s.assert_consistent();self.assertEqual(s.child._state['as_of_date'],anniversary(dt.date.fromisoformat(birth),24).isoformat());self.assertEqual(len(s.a_periods),24)
   self.assertEqual(bool(s.forecast),not birth.endswith('-01'));self.assertTrue(all(e['start_inclusive']>=birth for e in s.exposures));self.assertNotIn('A_forecast',s.player_view())
 def test_integrated_resume(self):
  a=Simulation.initialize('01',seed=5,birth_date='2026-04-17',engine=self.engine);a.run(12,research_continue=True)
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'s.json';a.save(p);b=Simulation.load(p,engine=self.engine)
  a.run(12,research_continue=True);b.run(12,research_continue=True);self.assertEqual(a.payload(),b.payload())
 def test_atomic_invalid_action(self):
  a=Simulation.initialize('13',seed=6,engine=self.engine);before=a.payload()
  with self.assertRaises(ValueError):a.step([{'action':'request_relative_support','person':a.identity['index_global_person_id']}],research_continue=True)
  self.assertEqual(before,a.payload())
 def test_no_future_parent_leak(self):
  a=Simulation.initialize('13',seed=7,birth_date='2026-04-17',engine=self.engine);a.run(24,research_continue=True);v=a.player_view();self.assertEqual(v['as_of_date'],'2028-04-17');self.assertEqual(v['A_accounting_through'],'2028-04-01');self.assertTrue(all(r['date']<=v['as_of_date']for r in v['child']['observations']))
 def test_actor_security(self):
  a=Simulation.initialize('13',seed=8,engine=self.engine)
  with self.assertRaises(PermissionError):a.child.act('observe',caregiver_id=a.identity['index_global_person_id'])
if __name__=='__main__':unittest.main()

class RegressionTests(unittest.TestCase):
 def test_plateau_interpolation_does_not_shrink(self):
  # Actual failed cohort seed: old arithmetic made a plateau shrink7e-15cm.
  from child_b11.engine import PARAMS
  c=Child.generate(seed=971);g=c._state['growth_process'];g['body']['head']=47.77694414175832;g['next_body']['head']=g['body']['head']
  for day in range(7):c._body_at(day);self.assertEqual(c._state['physical_health']['head_circumference_cm'],g['body']['head'])
 def test_json_schemas(self):
  import jsonschema
  from child_b11.engine import ROOT
  c=Child.generate(seed=42);c.advance_to(24);jsonschema.validate(c.research_snapshot(),json.loads((ROOT/'data/internal_state.schema.json').read_text()));jsonschema.validate(c.player_view('mother'),json.loads((ROOT/'data/player_response.schema.json').read_text()))
 def test_checkpoint_from_incremental_database(self):
  import sqlite3
  from child_b11.engine import ROOT
  from child_b11.storage import restore
  p=ROOT/'results/cohort_10340/shards/pref_01.sqlite'
  if not p.exists():self.skipTest('cohort data optional in light pack')
  db=sqlite3.connect('file:'+str(p)+'?mode=ro',uri=True);rid=db.execute('SELECT run_id FROM b11_checkpoint WHERE month=24 ORDER BY run_id LIMIT 1').fetchone()
  if rid is None:self.skipTest('cohort not generated yet')
  a=restore(db,rid[0],24);b=restore(db,rid[0],12,engine=a.engine);b.run(12,research_continue=True);self.assertEqual(a.payload(),b.payload());db.close()
