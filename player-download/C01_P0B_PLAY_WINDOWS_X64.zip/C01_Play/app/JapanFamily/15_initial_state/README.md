# 日本の出生家庭初期状態 A2.5-0.1

A2-0.4のFamilyModelとA-1 RegionModelをそのまま呼び、人物、出生当日の就業、2026年制度計算、所得源、資産勘定、初月の現金精算を加える研究版です。47都道府県に対応します。

**自動生成だけで翌月から全家庭を生活させる機能は未完成です。`financially_playable`はfalseを維持します。** 同時分布が未識別な値にはNULLを残します。具体値が必要な資産・支出・出生歴には、明示的に選択する推定シナリオを実装しています。

## 実行

Python3.11以上。実行時は標準ライブラリのみ、原表再変換には既存`requirements_A2.txt`のopenpyxlを使います。PDF再抽出だけpypdfが必要です。既存のA-1/A-2の実行手順は変更していません。

```bash
python 15_initial_state/initial_state.py --pref 13 --seed example --birth-date 2026-10-01
python 15_initial_state/api.py --port 8766
python run_initial_state_pipeline.py --validate --legacy-regression --install
```

最後のコマンドは同梱原表から核・台帳・生成例・検証を再作成し、新テーブルをDBに原子的に追加します。A-1/A-2の原表が同梱されています。`--refresh`は公式原本の再取得を試みます。URLが同じでも改訂されたファイルは再検証が必要です。認証・利用申請が必要な個票の取得は行いません。

APIはローカルの単一スレッドサーバーです。SQLite接続をその接続の作成スレッドで使い、既存RegionModelの互換性を保ちます。並行処理が必要なA3ではプロセスごとのモデル・接続を作る構成にしてください。

```bash
curl -X POST http://127.0.0.1:8766/initial-state \
  -H 'Content-Type: application/json' \
  -d '{"prefecture_code":"13","seed":"example","conditions":{"mother_age":32,"father_age":35,"birth_rank":2,"tenure":"private_rental"}}'
```

`POST /initial-state-batch`は`n:1..1000`を追加。`GET /health`はモデル版と外部検証未確立フラグを返します。生成結果をDBに自動保存するAPIではありません。DBの25例は検証用入力例です。

## 固定条件と推定

`conditions`はA2-0.4と同じ名前です。`mother_age`、`father_age`、`birth_rank`、`legal_status`、`partner_present`、`household_income_yen`、`mother_income_yen`、`father_income_yen`、`mother_education`、`father_education`、`mother_occupation`、`father_occupation`、`mother_employed`、`father_employed`、`tenure`、`municipality_code`。学歴・職業のコードと意味は既存辞書を参照します。所得固定は通常所得参照の条件であり出生月の給与ではありません。

`initialization`では人物`members`、`person_updates`、多胎`multiplicity`・`index_within_delivery`、出生当日`employment`、実際の入金・納税`benefit_cash_receipts`・`resident_tax_cash`など、資産`accounts`と返済契約`loans`、生活費`expense_items`を指定できます。完全なリクエスト25例は`data/example_requests.json`にあります。

確率的な点値の比較用には、次を明示指定します。

- `roster_scenario: backcast_under18_co_residence`。2025年の母年齢×出生順位表を過去へ移送し、18歳未満の既往子は生存同居すると仮定。実際の出生間隔・死亡・同居を同定した分布ではありません。
- `asset_scenario: deposit_holder_no_other_property_debt`。保有世帯の分位点を補間し、`asset_rho`のコピュラと純資産階級の制約を使います。`asset_tail`は`unresolved`、`lognormal`、`pareto`。受理不能な家庭は捨てず、資産を未確定として返します。その他物件・負債ゼロはこのシナリオの仮定です。
- `deposit_liquidity_fraction`。預金総額のうち使える現金の比率は原表では不明なので、指定が必要です。
- `spending_scenario: mean_anchored_compositional_sensitivity`。総支出を一度抽選し、構成比を同時に抽選します。`spending_parameters`の`cv`・`concentration`・`elasticity`は未観測の感度仮定です。`price_transport:true`は2024年10/11月から2026年8月の全国CPI連結であり、地方家賃・賃金・住宅価格への補正ではありません。

入力矛盾はHTTP400。正の公表支持がない場合と抽選上限はHTTP422で`unidentified_statistical_support`と`sampling_limit`を区別します。422は現実の不可能性の証明ではありません。未指定属性・未知の適用資格を勝手に確定しません。

## 出力と会計

`data/initial_state.schema.json`と`schema.sql`に構造を定義します。世帯内人物IDは世帯IDとの組で一意です。父というエンティティの存在、同居、扶養、親権、関与は別属性です。母の累積出生順位と現在同居する子ども数を区別します。

`roster.project_index_view`は一回生成した多胎の出産イベントから別の基準児のビューを作り、家族を再抽選しません。`deduplicate_delivery`は出産イベントIDで重複を除きます。多胎数を知らない個々の出生児抽選を、母・世帯の無偏抽選と称してはいけません。

通常年収2022、家賃2023、金融参照2024を2026年の観測や現金として扱いません。2023年家賃は参照フィールドに残し、現在の家賃の入金・出金には別途入力が必要です。

`accounting.settle_one_period`は一期間だけの純粋な精算関数です。借入は負債増、元本返済は負債減、利息は費用、評価損益は現金を動かさない変化です。現金不足は明示し、自動借入・架空の調整所得を作りません。20年間の遷移エンジンは含みません。

## 検証の読み方

`validation/summary.json`は新103400件、`legacy_regression.json`は旧108100件・A-122件等、`external_comparison.json`は独立資料との不一致、`sensitivity.json`は仮定変更、`model_api_tests.json`は実HTTP/入力/seed、`policy_accounting_tests.json`は公式数値例・恒等式です。

同じ原表へのモンテカルロ校正は実装検証です。独立統計への完全な出生家庭同時分布適合ではありません。初月を入力済みの25例は全件会計精算できますが、人口の代表標本ではありません。未完成・バックログ・A3への接続は統合報告と`A3_HANDOFF.md`を参照してください。
