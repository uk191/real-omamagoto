"""Verified CPI linking, separate from uncertain quantity/wage/housing transport."""
from decimal import Decimal
def link_price(amount,old_period_index,old_2025_mean,new_period_index,scope):
    if scope!='national_all_items_quantity_fixed':raise ValueError('Only the verified national all-items CPI linking convention is provided')
    if min(old_period_index,old_2025_mean,new_period_index)<=0:raise ValueError('Positive verified CPI indices required')
    connected=Decimal(str(old_period_index))/Decimal(str(old_2025_mean))*100
    factor=Decimal(str(new_period_index))/connected
    return {'amount':round(Decimal(str(amount))*factor),'factor':float(factor),'connected_source_index_2025_base':float(connected),'kind':'estimate_quantity_fixed_CPI_transport_not_2026_observation','scope':scope,'warning':'not a wage index or municipal rent/house-price index; changing household quantities or weights is not identified'}
def budget_2024_oct_nov_to_2026_aug(amount):
    return link_price(amount,(109.5+110.0)/2,111.9,102.2,'national_all_items_quantity_fixed')
