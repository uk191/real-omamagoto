"""Explicit accounting fixtures, not a claimed representative population sample."""
import json,copy
from pathlib import Path
from initial_state import InitialStateModel
ROOT=Path(__file__).resolve().parent
def profile(rank=1,owner=False,extra_members=None,liquidity=1500000,multiplicity=1,index=1):
    previous=rank-index
    members=[{'person_id':f'sibling_{i+1}','role':'maternal_prior_child','date_of_birth':f'{2023-3*i}-08-01','co_resident':True,'supported':True,'alive':True,'maternal_previous_live_birth':True}for i in range(previous)]
    members.extend(extra_members or[])
    balances={'cash':liquidity,'financial_other':1000000,'home':25000000 if owner else 0,'property_other':0,'mortgage':15000000 if owner else 0,'other_debt':0}
    accounts=[{'account_id':k,'name':k,'balance':v,'side':'liability'if k in('mortgage','other_debt')else'asset','liquid_cash':k=='cash','kind':'explicit_user_profile_for_accounting_verification'}for k,v in balances.items()]
    return {'members':members,'multiplicity':multiplicity,'index_within_delivery':index,'employment':{'mother':{'at_birth_status':'postpartum_leave','actual_hours_at_birth':0,'salary_cash':0,'kyokai_insured':True,'standard_monthly':200000,'average_12month_standard':200000,'premium_exemption_approved':True,'maternity_eligible':True,'maternity_days':31,'maternity_salary_paid':0,'annual_salary_2026_projection':2400000,'annual_social_paid_projection':300000,'other_deductions':0,'tax_credit':0},'father':{'at_birth_status':'working','salary_cash':350000,'kyokai_insured':True,'standard_monthly':340000,'source_dependent_count':0,'source_spouse':False,'leave_benefit_eligible':False,'support_benefit_eligible':False,'leave_days':0,'annual_salary_2026_projection':4200000,'annual_social_paid_projection':600000,'other_deductions':0,'tax_credit':0}},'accounts':accounts,'loans':[{'account_id':'mortgage','annual_rate':.012,'remaining_months':300}]if owner else[],'income_sources_complete':True,'cash_coverage_complete':True,'financial_profile_user_confirmed':True,'benefit_eligibility':{'child_allowance':True,'health_insured_birth':True,'obstetric_compensation_scheme':True},'benefit_cash_receipts':{'maternity':0,'paternal_leave':0,'child_allowance':0,'birth_lump_sum':0},'resident_tax_cash':{'mother':8000,'father':17000},'national_health_cash':0,'other_taxes_cash':0,'housing_costs':{'rent':0 if owner else 70000,'management_fee':4000,'property_tax':4000 if owner else 0,'repair_reserve':5000 if owner else 0},'expense_items':[{'code':'food','amount':60000,'fixed_or_variable':'variable','essential_or_discretionary':'mixed','regular_or_irregular':'regular'},{'code':'utilities','amount':18000},{'code':'communications','amount':10000},{'code':'transport','amount':15000},{'code':'daily_goods','amount':10000},{'code':'medical','amount':5000},{'code':'clothes','amount':6000},{'code':'private_insurance','amount':5000},{'code':'education_childcare','amount':0},{'code':'recreation_social_other','amount':12000}]}
def requests():
    cases=[]
    for i,pref in enumerate(['01','04','07','12','13','14','15','20','22','23','26','27','28','34','37','40','43','47','08','11']):
        rank=1+i%3;owner=i%2==1;init=profile(rank,owner);cond={'mother_age':32+i%5,'father_age':35+i%5,'birth_rank':rank,'partner_present':True,'tenure':'owner'if owner else'private_rental'}
        cases.append({'label':f'{pref}_rank{rank}_'+('owner'if owner else'rent'),'prefecture_code':pref,'conditions':cond,'seed':f'fixture/{i}','initialization':init,'include_region':True})
    # First maternal child can have a resident stepchild, without changing maternal rank.
    step={'person_id':'stepchild','role':'stepchild','date_of_birth':'2019-01-10','co_resident':True,'supported':True,'relationships':[{'from':'father','type':'biological_parent'}]}
    cases.append({'label':'maternal_first_birth_with_stepchild','prefecture_code':'13','conditions':{'mother_age':32,'father_age':38,'birth_rank':1,'partner_present':True,'tenure':'private_rental'},'seed':'fixture/step','initialization':profile(extra_members=[step]),'include_region':True})
    gp={'person_id':'maternal_grandmother','role':'co_resident_grandparent','date_of_birth':'1960-02-01','co_resident':True,'supported':False,'health':'user_declared_independent','residence':{'municipality_code':'12217'},'care_support':{'possible':True,'days_per_week':2},'relationships':[{'from':'maternal_grandmother','type':'biological_parent'}]}
    gp['relationships']=[{'from':'maternal_grandmother','to':'mother','type':'biological_parent'}]
    init=profile(extra_members=[gp]);init['extra_income_sources']=[{'source_id':'grandmother/pension','person_id':'maternal_grandmother','type':'pension_cash','cash_amount':100000,'kind':'explicit_user_profile'}]
    cases.append({'label':'co_resident_grandmother_with_separate_pension','prefecture_code':'12','conditions':{'mother_age':32,'father_age':35,'birth_rank':1,'partner_present':True,'tenure':'private_rental'},'seed':'fixture/gp','initialization':init,'include_region':True})
    cases.append({'label':'twin_second_index_not_one_prior_sibling','prefecture_code':'27','conditions':{'mother_age':32,'father_age':35,'birth_rank':2,'partner_present':True,'tenure':'private_rental'},'seed':'fixture/twins','initialization':profile(rank=2,multiplicity=2,index=2),'include_region':True})
    single=profile();single['person_updates']={'father':{'co_resident':False}};single['employment']['father']={'salary_cash':0,'kyokai_insured':False,'leave_benefit_eligible':False};single['employment']['mother']['salary_cash']=150000;single['employment']['mother']['maternity_salary_paid']=150000;single['resident_tax_cash']['father']=0;single['extra_income_sources']=[{'source_id':'maintenance','person_id':'mother','type':'maintenance_received','cash_amount':40000}]
    cases.append({'label':'nonmarital_separate_parent_with_declared_maintenance','prefecture_code':'13','conditions':{'mother_age':32,'birth_rank':1,'partner_present':False,'legal_status':'nonmarital','tenure':'private_rental'},'seed':'fixture/single','initialization':single,'include_region':True})
    poor=profile(liquidity=50000);poor['accounts'][-1]['balance']=2500000;poor['loans']=[{'account_id':'other_debt','annual_rate':.05,'remaining_months':120}]
    cases.append({'label':'negative_net_worth_and_low_deposits','prefecture_code':'47','conditions':{'mother_age':32,'father_age':35,'birth_rank':1,'partner_present':True,'tenure':'private_rental'},'seed':'fixture/negative','initialization':poor,'include_region':True})
    for x in cases:
        for who,emp in x['initialization']['employment'].items():
            emp['work_prefecture']=x['prefecture_code'];emp['premium_deduction_lag_months']=0
    cases[0]['initialization']['employment']['father'].update(premium_deduction_lag_months=1,social_cash_deduction=55000)
    for x in cases:
        for loan in x['initialization']['loans']:
            if loan['account_id']=='mortgage':loan['collateral_account_id']='home'
    return cases
def main():
    m=InitialStateModel();out=[];inputs=requests()
    for x in inputs:
        a=dict(x);label=a.pop('label');state=m.generate(**a);assert state==m.generate(**a)
        out.append({'label':label,'status':'generated','state':state});print(label,state['quality_flags']['initial_month_cash_ready'],flush=True)
    (ROOT/'data/example_requests.json').write_text(json.dumps(inputs,ensure_ascii=False,indent=2));(ROOT/'validation/examples.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
