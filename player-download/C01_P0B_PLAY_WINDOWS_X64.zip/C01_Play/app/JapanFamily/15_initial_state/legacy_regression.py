"""Run unchanged A1 tests, omitting only their SQLite result writeback.

The baseline validation_result is retained. All original test assertions and
47-prefecture470k draws still execute; files carry fresh actual test outputs.
"""
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parent;P=ROOT.parent
def main():
    p=P/'10_validation/validate.py';s=p.read_text()
    writer="C.executemany('INSERT OR REPLACE INTO validation_result VALUES(?,?,?,?,?)',[tuple(r.values()) for r in out]);C.commit();C.close();print(stats,flush=True)"
    assert s.count(writer)==1
    original_stdout=sys.stdout
    with(ROOT/'data/A1_regression.log').open('w')as f:
        sys.stdout=f
        try:exec(compile(s.replace(writer,"C.close();print(stats,flush=True)"),str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
        finally:sys.stdout=original_stdout
    a=json.loads((P/'10_validation/summary.json').read_text());assert a['tests_pass']==22 and a['tests_fail']==0
    for script,log in [('10_validation/runtime_validate.py','A1_runtime_regression.log'),('13_family/validate.py','A2_regression.log'),('13_family/external_diagnostics.py','A2_external.log'),('13_family/check_api.py','A2_api.log'),('13_family/release_checks.py','A2_release.log')]:
        print(script,flush=True)
        with(ROOT/'data'/log).open('w')as f:subprocess.run([sys.executable,str(P/script)],stdout=f,stderr=subprocess.STDOUT,check=True)
    (ROOT/'validation/legacy_regression.json').write_text(json.dumps({'A1_tests':a['tests_pass'],'A1_failures':a['tests_fail'],'original_test_code_modified':False,'result_writeback_omitted':True,'reason':'preserve original baseline validation_result rows; fresh results written to original validation output files','A2_summary':json.loads((P/'13_family/validation/summary.json').read_text()),'A1_runtime':json.loads((P/'10_validation/runtime_validation.json').read_text()),'A2_release':json.loads((P/'13_family/validation/release_checks.json').read_text())},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
