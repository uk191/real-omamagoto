"""Explicitly labelled conditional scenarios, not fabricated observations."""
import random,hashlib,math,bisect
from statistics import NormalDist
from policy import _policy
VERSION='A2.5-0.1'
def rng(seed,component):return random.Random(int.from_bytes(hashlib.sha256(f'{VERSION}:{seed}:{component}'.encode()).digest()[:16],'big'))
def draw_weighted(rows,r,weight='weight'):
    total=sum(x[weight]for x in rows)
    if total<=0:return None
    target=r.random()*total
    for x in rows:
        target-=x[weight]
        if target<0:return x
    return rows[-1]
def interpolate_quantile(points,u,tail='unresolved'):
    pairs=sorted((float(p),v)for p,v in points.items());ps=[p for p,v in pairs]
    if not pairs:return None
    if u<ps[0]:return round(pairs[0][1]*u/ps[0])
    if u>ps[-1]:
        if tail=='unresolved':return None
        q75=points.get('.75');q90=points.get('.9')
        if not q75 or not q90 or q90<=q75:return None
        if tail=='pareto':
            alpha=math.log(.25/.1)/math.log(q90/q75)
            return round(q90*(.1/(1-u))**(1/alpha))
        if tail=='lognormal':
            sigma=math.log(q90/q75)/(NormalDist().inv_cdf(.9)-NormalDist().inv_cdf(.75))
            return round(q90*math.exp(sigma*(NormalDist().inv_cdf(u)-NormalDist().inv_cdf(.9))))
        raise ValueError('Unknown tail extrapolation')
    j=max(1,bisect.bisect_left(ps,u));p0,y0=pairs[j-1];p1,y1=pairs[j]
    return round(y0+(y1-y0)*(u-p0)/(p1-p0))
def asset_scenario(base,seed,mode='unresolved',tail='unresolved',rho=0.,max_attempts=80):
    """Holder-conditioned quantiles with a constrained copula. No residual asset.

    A holder scenario assumes deposits/financial assets exist; absence probabilities
    are NOT identified by 7-101. Other property/debt are explicit zero-premise
    scenario components, not an inferred population frequency.
    """
    if mode=='unresolved':return {'accounts':None,'identified':False,'reason':'asset holder probabilities/components not jointly identified','conditional_estimates':None}
    if mode!='deposit_holder_no_other_property_debt':raise ValueError('Unsupported asset scenario')
    if not 0<=rho<=1:raise ValueError('Copula rho outside [0,1]')
    if base['housing']['tenure']!='owner'and base['finances']['mortgage_present_any_property']:return {'accounts':None,'identified':False,'scenario_complete':False,'mode':mode,'reason':'mortgage on a noncurrent property/collateral cannot be identified under the no-other-property premise; household retained'}
    n=base['housing']['household_size'];n=str(n)if n in range(1,7)else'0'
    mortgage=base['finances']['mortgage_present_any_property'];m='1'if mortgage else'2'
    qs=_policy()['asset_holder_quantiles'];r=rng(seed,'asset-components');normal=NormalDist()
    def sample(code,u):
        k='|'.join([m,n,code]);row=qs.get(k)
        if row is None:row=qs.get('|'.join([m,'0',code]))
        return interpolate_quantile(row['points'],u,tail)if row else None
    interval=base['finances']['net_total_assets']['interval'];last=None
    for attempt in range(max_attempts):
        shared=r.gauss(0,1)
        def u():return min(1-1e-12,max(1e-12,normal.cdf(math.sqrt(rho)*shared+math.sqrt(1-rho)*r.gauss(0,1))))
        cash,total_fin,home,debt=[sample(code,u())for code in ['211','21','31','221']]
        if not mortgage:debt=0
        if base['housing']['tenure']!='owner':home=0
        if any(v is None for v in [cash,total_fin,home,debt])or cash>total_fin:continue
        net=total_fin+home-debt
        last={'cash_deposits':cash,'other_financial_assets':total_fin-cash,'current_home_value':home,'housing_debt':debt,'net_worth':net}
        lo,hi=interval
        if(lo is not None and net<lo)or(hi is not None and net>=hi):continue
        return {'accounts':last,'identified':False,'scenario_complete':True,'attempts':attempt+1,'tail':tail,'rho':rho,'mode':mode,'kind':'estimate_conditional_holder_quantiles_copula_rejection_on_legacy_net_bin; absence probability and newborn joint unvalidated'}
    return {'accounts':None,'identified':False,'scenario_complete':False,'attempts':max_attempts,'tail':tail,'rho':rho,'mode':mode,'reason':'no accepted component decomposition; no balancing residual inserted'}
def spending_scenario(gross,size,seed,mode='unresolved',total=None,concentration=50,elasticity=.5,cv=.35,reference_annual_gross=None,price_transport=False):
    """Draw ONE total then a correlated composition, never independent category means.

    The source identifies a conditional mean vector, NOT CV/correlation/Engel
    elasticity. Those parameters are separate sensitivity premises. They do not
    become source estimates by passing accounting or Monte Carlo checks.
    """
    refs=_policy()['baby_budget'];components=[x for x in refs if x['code']!='2101'and x['code']!='210102']
    if mode=='unresolved'and total is None:return {'items':None,'total_nonhousing':None,'kind':'conditional total distribution not observed; reference means kept separate'}
    if mode not in('unresolved','mean_anchored_compositional_sensitivity'):raise ValueError('Unknown spending mode')
    if concentration<=0 or cv<0 or not 0<=elasticity<=1:raise ValueError('Invalid spending sensitivity parameter')
    user_fixed=total is not None
    r=rng(seed,'spending');mu=sum(x['reference_mean']for x in components)
    factor=1.
    if price_transport:
        from transport import budget_2024_oct_nov_to_2026_aug
        factor=budget_2024_oct_nov_to_2026_aug(mu)['factor'];mu*=factor
    if total is None:
        if gross is None or size is None or reference_annual_gross is None:return {'items':None,'total_nonhousing':None,'kind':'cannot condition spending without compatible household inputs'}
        mean=mu*(gross/reference_annual_gross)**elasticity*math.sqrt(size/3)
        sigma=math.sqrt(math.log1p(cv*cv));total=round(r.lognormvariate(math.log(max(1,mean))-sigma*sigma/2,sigma))
    if int(total)!=total or total<0:raise ValueError('Invalid spending total')
    source_total=sum(x['reference_mean']for x in components)
    weights=[r.gammavariate(max(.001,concentration*x['reference_mean']/source_total),1)for x in components];sw=sum(weights)
    values=[int(total*w/sw)for w in weights];values[-1]+=int(total)-sum(values)
    return {'items':[{'code':x['code'],'label':x['label'],'amount':v,'fixed_or_variable':'mixed_requires_contract_split','essential_or_discretionary':'mixed','regular_or_irregular':'calendar timing unidentified','reference_source':x['source']}for x,v in zip(components,values)],'total_nonhousing':int(total),'kind':'game_sensitivity_correlated_composition_from_conditional_mean_prior; not an observed household spending distribution','parameters':{'concentration':concentration,'cv':cv,'elasticity':elasticity,'total_user_fixed':user_fixed,'national_CPI_factor':factor,'price_transport_scope':'2026-08 national quantity-fixed sensitivity only; not local rent/wage'},'reference_population':'2024 Oct/Nov couple plus one child <=2; size/income transport assumptions'}
