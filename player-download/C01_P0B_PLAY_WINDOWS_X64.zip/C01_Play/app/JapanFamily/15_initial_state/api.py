"""Local HTTP API; legacy /generate remains available in 13_family/api.py."""
from http.server import BaseHTTPRequestHandler,HTTPServer
import json,argparse
from initial_state import InitialStateModel,InitialConditionError,VERSION
class Handler(BaseHTTPRequestHandler):
    model=None
    def log_message(self,*a):pass
    def send(self,status,payload):
        b=json.dumps(payload,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):self.send(200,{'model_version':VERSION,'legacy_model':'A2-0.4','population_joint_verified':False})if self.path=='/health'else self.send(404,{'error':'unknown_endpoint'})
    def do_POST(self):
        try:
            n=int(self.headers.get('Content-Length','0'))
            if not 0<n<=300000:raise InitialConditionError('Invalid request size')
            body=json.loads(self.rfile.read(n))
            if not isinstance(body,dict):raise InitialConditionError('JSON object required')
            if self.path not in('/initial-state','/initial-state-batch'):self.send(404,{'error':'unknown_endpoint'});return
            allowed={'prefecture_code','conditions','seed','birth_date','initialization','include_region','n'}
            if set(body)-allowed:raise InitialConditionError('Unknown request fields')
            kwargs={k:body[k]for k in allowed if k in body and k!='n'}
            if self.path=='/initial-state-batch':
                n=body.get('n',1)
                if not isinstance(n,int)or not 1<=n<=1000:raise InitialConditionError('HTTP batch size 1..1000')
                result=self.model.generate_batch(n=n,**kwargs)
            else:result=self.model.generate(**kwargs)
            self.send(200,result)
        except InitialConditionError as e:self.send(422 if e.kind!='input_contradiction' else 400,{'error':e.kind,'message':str(e)})
        except(ValueError,TypeError,KeyError)as e:self.send(400,{'error':'invalid_input','message':str(e)})
        except Exception as e:self.send(500,{'error':'internal_error','message':type(e).__name__})
def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8766);a=p.parse_args();Handler.model=InitialStateModel();HTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
if __name__=='__main__':main()
