"""Conformance checker for the exact documented JSON-Schema keyword subset.

Not advertised as a complete general-purpose JSON-Schema implementation.
Rejects unknown schema keywords instead of silently ignoring them.
"""
from pathlib import Path
from datetime import date
import json,re
from initial_state import InitialStateModel
ROOT=Path(__file__).resolve().parent
def validate(value,schema,root,path='$'):
    if '$ref'in schema:
        s=root
        for key in schema['$ref'].removeprefix('#/').split('/'):s=s[key]
        return validate(value,s,root,path)
    types={'object':lambda v:isinstance(v,dict),'array':lambda v:isinstance(v,list),'string':lambda v:isinstance(v,str),'integer':lambda v:isinstance(v,int)and not isinstance(v,bool),'boolean':lambda v:isinstance(v,bool),'null':lambda v:v is None}
    if 'type'in schema:
        kinds=schema['type']if isinstance(schema['type'],list)else[schema['type']]
        if not any(types[k](value)for k in kinds):raise ValueError(path+' type')
    if 'const'in schema and(type(value)!=type(schema['const'])or value!=schema['const']):raise ValueError(path+' const')
    if 'enum'in schema and value not in schema['enum']:raise ValueError(path+' enum')
    if isinstance(value,str):
        if 'pattern'in schema and re.search(schema['pattern'],value)is None:raise ValueError(path+' pattern')
        if schema.get('format')=='date':date.fromisoformat(value)
    if isinstance(value,(int,float))and not isinstance(value,bool):
        if 'minimum'in schema and value<schema['minimum']:raise ValueError(path+' minimum')
        if 'maximum'in schema and value>schema['maximum']:raise ValueError(path+' maximum')
    if isinstance(value,dict):
        if set(schema.get('required',[]))-set(value):raise ValueError(path+' required')
        for k,s in schema.get('properties',{}).items():
            if k in value:validate(value[k],s,root,path+'.'+k)
    if isinstance(value,list):
        if len(value)<schema.get('minItems',0)or len(value)>schema.get('maxItems',len(value)):raise ValueError(path+' array length')
        for i,x in enumerate(value):
            subs=schema.get('prefixItems',[])
            if i<len(subs):validate(x,subs[i],root,path+f'[{i}]')
            elif 'items'in schema:validate(x,schema['items'],root,path+f'[{i}]')
def main():
    schema=json.loads((ROOT/'data/initial_state.schema.json').read_text());states=[x['state']for x in json.loads((ROOT/'validation/examples.json').read_text())];m=InitialStateModel()
    states.extend(m.generate(f'{i:02d}',seed=f'schema/{i}',include_region=False)for i in range(1,48))
    for s in states:validate(json.loads(json.dumps(s)),schema,schema)
    report={'examples_checked':25,'prefecture_defaults_checked':47,'all_pass':True,'validator_scope':'exact supplied schema subset; not full arbitrary JSON-Schema validation'}
    (ROOT/'validation/schema_tests.json').write_text(json.dumps(report,indent=2));print(report)
if __name__=='__main__':main()
