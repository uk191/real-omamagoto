"""Fresh 47-prefecture Monte Carlo, separated from financial-ready fixtures."""
import json,gzip,hashlib,math,collections,statistics,sys,time
from pathlib import Path
from initial_state import InitialStateModel
ROOT=Path(__file__).resolve().parent
def moments(values):
    v=sorted(x for x in values if x is not None)
    return {'n_finite':len(v),'mean':statistics.mean(v)if v else None,'variance':statistics.pvariance(v)if v else None,'quantiles':{str(q):v[min(len(v)-1,int(q*(len(v)-1)))]if v else None for q in [.1,.25,.5,.75,.9]}}
def main(n=2200):
    m=InitialStateModel();N=47*n;stats={};counts=collections.Counter();births=collections.Counter();errors=[];internal=[];canonical=hashlib.sha256();start=time.time()
    path=ROOT/'validation/generated_A25_lite.jsonl.gz'
    with gzip.open(path,'wt',encoding='utf-8')as stream:
        for pi in range(1,48):
            p=f'{pi:02d}';gross=[];sizes=[];gaps=[];rent=[];co=collections.Counter();conditional=collections.Counter()
            for i in range(n):
                seed=f'A25-validation/{p}/{i}'
                try:s=m.generate(p,seed=seed,include_region=False)
                except Exception as e:errors.append({'pref':p,'seed':seed,'type':type(e).__name__,'error':str(e)});continue
                h=s['household'];pers=s['persons'];mother=next(z for z in pers if z['person_id']=='mother');child=next(z for z in pers if z['person_id']=='index_child');father=next(z for z in pers if z['person_id']=='father')
                rank=h['index_birth_rank_interval'][0];births[(p,mother['age_years'],min(rank,5))]+=1
                if h['resident_person_count']!=sum(z['co_resident']is True for z in pers)or child['age_years']!=0:internal.append(seed+'/roster')
                if len({z['person_id']for z in pers})!=len(pers):internal.append(seed+'/person_ids')
                if rank<10 and len(s['birth_history'])!=rank-1:internal.append(seed+'/history')
                if s['employment']['mother']['at_birth_status']=='postpartum_leave'and s['employment']['mother']['actual_hours_at_birth']!=0:internal.append(seed+'/maternity_hours')
                if s['quality_flags']['financially_playable']:internal.append(seed+'/unexpected_default_financial_certificate')
                g=h['reference_usual_household_income']['value'];rr=s['housing']['monthly_rent']['value'];gap=h['unexplained_reference_income_gap'];gross.append(g);sizes.append(h['resident_person_count']);gaps.append(gap);rent.append(rr)
                future=s['employment']['mother']['future_path'];st=future['observed_one_year_outcome']if future else None
                if future and '妊娠時の就業状況・従業上の地位'in future['source_row']:conditional[(future['source_row']['妊娠時の就業状況・従業上の地位'],st)]+=1
                co[(rank,h['resident_person_count'],s['housing']['tenure'],s['employment']['mother']['at_birth_status'])]+=1
                counts['generated']+=1;counts['default_financial_ready']+=int(s['quality_flags']['financially_playable']);counts['roster_resolved']+=int(s['quality_flags']['roster_resolved']);counts['income_gap_positive']+=int(gap is not None and gap>0);counts['income_gap_unidentified']+=int(gap is None)
                row={'model_version':s['model_version'],'pref':p,'seed':seed,'mother_age':mother['age_years'],'father_age':father['age_years'],'birth_rank_lower':rank,'legal':h['legal_birth_status'],'resident_person_count':h['resident_person_count'],'gross_reference':g,'rent_reference':rr,'reference_parent_income_gap':gap,'maternal_birth_status':s['employment']['mother']['at_birth_status'],'maternal_future_one_year_outcome_reference':st,'financial_ready':s['quality_flags']['financially_playable'],'roster_resolved':s['quality_flags']['roster_resolved'],'unresolved_count':len(s['quality_flags']['unresolved'])}
                line=json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':'));canonical.update(line.encode());canonical.update(b'\n');stream.write(line+'\n')
            stats[p]={'n':n,'gross_2022_reference':moments(gross),'rent_2023_reference':moments(rent),'resident_count':moments(sizes),'unexplained_reference_income_gap':moments(gaps),'attribute_combinations':[{'birth_rank':k[0],'resident_count':k[1],'tenure':k[2],'maternal_birth_status':k[3],'n':v}for k,v in co.items()],'maternal_pre_post_source_calibration':[{'pre':k[0],'one_year':k[1],'n':v}for k,v in conditional.items()]}
            print(p,counts['generated'],'failures',len(errors),'seconds',round(time.time()-start),flush=True)
    zmax=0.;birthfit=[]
    for p in stats:
        weights=collections.Counter()
        for x in m.base.g['birth_pref'][p]:
            if x['sex']!='all':continue
            label=x['mother_label'];age=int(label[:-1])if label.endswith('歳')and label[:-1].isdigit()else None
            weights[(age,x['rank'])]+=x['weight']or 0
        total=sum(weights.values())
        for (a,r),w in weights.items():
            probability=w/total;expected=n*probability;observed=births[(p,a,r)]
            z=(observed-expected)/math.sqrt(max(1e-9,n*probability*(1-probability)))if expected>=5 else None
            if z is not None:zmax=max(zmax,abs(z))
            birthfit.append({'pref':p,'mother_age':a,'parity':r,'source_probability':probability,'generated_n':observed,'z':z})
    summary={'model_version':'A2.5-0.1','requested_n':N,'generated_n':counts['generated'],'per_prefecture':n,'generation_failures':len(errors),'internal_violations':len(internal),'counts':dict(counts),'birth_max_abs_z_expected_at_least_5':zmax,'birth_MC_threshold':7,'payload_sha256':canonical.hexdigest(),'gzip_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'kernel_sha256':hashlib.sha256((ROOT/'data/state_kernels.json').read_bytes()).hexdigest(),'elapsed_seconds':time.time()-start,'certification':'Structural/source-calibration validation only. Default cash, assets and full newborn joint remain unresolved.'}
    for name,value in [('summary.json',summary),('prefecture_summary.json',stats),('birth_source_calibration.json',birthfit),('generation_failures.json',errors),('internal_violations.json',internal)]:
        (ROOT/'validation'/name).write_text(json.dumps(value,ensure_ascii=False,indent=2))
    assert not errors and not internal and counts['generated']==N and zmax<7
    print(json.dumps(summary,ensure_ascii=False),flush=True)
if __name__=='__main__':main(int(sys.argv[1])if len(sys.argv)>1 else 2200)
