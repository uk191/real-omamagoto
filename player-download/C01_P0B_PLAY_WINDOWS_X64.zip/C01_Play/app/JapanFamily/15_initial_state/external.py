"""External mismatches and source calibration reported separately."""
import json,gzip,collections,math,statistics
from pathlib import Path
from initial_state import InitialStateModel
ROOT=Path(__file__).resolve().parent;P=ROOT.parent
def tv(a,b):
    sa=sum(a.values());sb=sum(b.values())
    return sum(abs(a.get(k,0)/sa-b.get(k,0)/sb)for k in set(a)|set(b))/2 if sa and sb else None
def broad(value):
    if value is None:return 'unidentified'
    if value<10000000:return str(int(value)//1000000)
    return '10-12.5'if value<12500000 else'12.5-15'if value<15000000 else'15-20'if value<20000000 else'20+'
def main():
    m=InitialStateModel();totals={p:sum(x['weight']or 0 for x in rows if x['sex']=='all')for p,rows in m.base.g['birth_pref'].items()}
    rows=[json.loads(x)for x in gzip.open(ROOT/'validation/generated_A25_lite.jsonl.gz','rt')];ns=collections.Counter(x['pref']for x in rows);actual=collections.Counter();unidentified=0;sample=0;mother=collections.Counter()
    for x in rows:
        w=totals[x['pref']]/ns[x['pref']]
        if x['mother_age']is not None:mother[x['mother_age']]+=w
        if x['birth_rank_lower']==1 and x['legal']=='marital'and x['resident_person_count']==3:
            sample+=1
            if x['gross_reference']is None:unidentified+=1;continue
            actual[broad(x['gross_reference'])]+=w
    expected=collections.Counter()
    for code,row in m.k['baby_income_2024_profiles'].items():
        if code=='00'or row['weight']is None:continue
        lo,hi=row['interval'];expected[broad(lo)]+=row['weight']
    prior=json.loads((P/'13_family/validation/external_diagnostics_summary.json').read_text())
    comparison={'reference':'finance2024_3-32-1 couple plus one unmarried child <=2','model_proxy':'maternal_rank1, marital, materialized resident_count3; other-person kinship may be unresolved','finite_point_comparison':True,'proxy_n':sample,'unknown_income_n':unidentified,'weighted_TV_finite_broad_income':tv(actual,expected),'generated_weights':dict(actual),'reference_weights':dict(expected),'not_external_pass':True,'scope_difference':['2022 usual household gross vs2024 financial annual gross','birth-event age0 vs stock of resident one-child age<=2','maternal birth rank not count of current resident children','conditional birth/parity/municipality mixing vs survey household weighting','model finite-bin point allocation, open bins unavailable','retrospective onechild cohort duration/second birth selection'],'causal_decomposition_identified':False,'action':'No TV-targeting rescale. Need same-population joint/gross definitions and independent2026holdout.'}
    conditional=[];stats=json.loads((ROOT/'validation/prefecture_summary.json').read_text());ac=collections.defaultdict(collections.Counter)
    for p,s in stats.items():
        for x in s['maternal_pre_post_source_calibration']:ac[x['pre']][x['one_year']]+=x['n']
    for pre,counts in ac.items():
        ex=collections.Counter()
        for x in m.k['maternal_pre_post_joint']:
            if x['pre_status']==pre:ex[x['one_year_status']]+=x['weight']
        conditional.append({'pre_employment':pre,'n':sum(counts.values()),'TV':tv(counts,ex),'comparison_type':'same-source conditional implementation calibration; not independent/newborn causal validation','source_sample_n':sum(ex.values())})
    components=m.k['baby_income_2024_profiles']['00']['components']
    result={'model_version':'A2.5-0.1','legacy_external_results':prior,'new_A25_proxy_income':comparison,'maternal_one_year_conditional_calibration':conditional,'finance_same_table_2024_conditional_means':components,'same_table_mean_warning':'Means are coherent as survey aggregates, not a conditional individual cash-income decomposition. No residual assigned to persons.','independent_checks':'NTA/MHLW official numeric examples in policy/accounting tests; newborn entire joint external fit still not established','regional_cost_validation':'No current municipality price/commuting/budget joint available; 2023 rent unchanged reference, CPI scenario national only','financial_population_validation':'Cannot validate all103400 cash/asset states because defaults preserve unidentified values; 25 explicit accounting fixtures are separate'}
    (ROOT/'validation/external_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(comparison,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
