"""Actual multi-model draws, common seeds, no fabricated validation target."""
from pathlib import Path
import json,math,collections,statistics,hashlib
from initial_state import InitialStateModel
from estimators import asset_scenario,spending_scenario
from validate import moments
ROOT=Path(__file__).resolve().parent
def main(n=940):
    m=InitialStateModel();bases=[m.base.generate(f'{i%47+1:02d}',seed=f'sensitivity/{i}',include_region=False)for i in range(n)]
    scenarios=[]
    for rho in [0,.5,1]:
        for tail in ['unresolved','lognormal','pareto']:
            values=[];fails=collections.Counter();attempts=[];negative=0
            for i,b in enumerate(bases):
                a=asset_scenario(b,f'sensitivity/{i}','deposit_holder_no_other_property_debt',tail,rho)
                if a['accounts']is None:fails[a['reason']]+=1;continue
                x=a['accounts'];values.append(x['net_worth']);attempts.append(a['attempts']);negative+=int(x['net_worth']<0)
            row={'type':'assets','rho':rho,'tail':tail,'n_requested':n,'n_accepted':len(values),'negative_net_worth':negative,'unresolved_reasons':dict(fails),'net_worth_moments':moments(values),'attempt_moments':moments(attempts),'holder_presence_assumed':True,'statistical_validation':'NOT identified newborn joint; accepted sample conditional on feasibility, do not renormalize to population'};scenarios.append(row);print('assets',rho,tail,len(values),flush=True)
    for cv in [.2,.5]:
        for concentration in [20,100]:
            for elasticity in [0,.5]:
                totals=[];food=[];other=[];fraction=[];missing=0
                for i,b in enumerate(bases):
                    s=spending_scenario(b['household_income']['value'],b['housing']['household_size'],f'sensitivity/{i}','mean_anchored_compositional_sensitivity',concentration=concentration,cv=cv,elasticity=elasticity,reference_annual_gross=m.k['budget_income_anchor'],price_transport=True)
                    if s['items']is None:missing+=1;continue
                    totals.append(s['total_nonhousing']);food.append(s['items'][0]['amount']);other.append(s['items'][-1]['amount']);fraction.append(food[-1]/totals[-1]if totals[-1]else 0)
                def corr(a,b):
                    if len(a)<2:return None
                    return statistics.correlation(a,b)
                row={'type':'spending','cv':cv,'concentration':concentration,'elasticity':elasticity,'n_requested':n,'n_unresolved':missing,'total_moments':moments(totals),'food_moments':moments(food),'food_share_moments':moments(fraction),'food_other_correlation':corr(food,other),'statistical_validation':'source identifies means only; these are game assumptions, not external PASS'};scenarios.append(row);print('spending',cv,concentration,elasticity,len(totals),flush=True)
    roster=[]
    for scenario in ['unresolved','backcast_under18_co_residence']:
        size=[];co=[];resolved=0;unresolved=0
        for i,b in enumerate(bases):
            s=m.generate(b['prefecture_code'],seed=f'sensitivity/{i}',reference=b,include_region=False,initialization={'roster_scenario':scenario})
            size.append(s['household']['resident_person_count']);co.append(sum(p['role']=='maternal_prior_child'and p['co_resident']is True for p in s['persons']));resolved+=int(s['quality_flags']['roster_resolved']);unresolved+=sum(h['person_id']is None for h in s['birth_history'])
        roster.append({'scenario':scenario,'n':n,'resident_count':moments(size),'known_resident_maternal_prior_children':moments(co),'structurally_resolved':resolved,'unidentified_birth_history_records':unresolved,'external_validity':'NOT established; period-age backcast is not actual spacing/survival/co-residence data'})
    result={'model_version':'A2.5-0.1','base_draws':n,'sample_design':'20 per prefecture; comparisons use identical base states and component seeds','asset_and_spending_scenarios':scenarios,'roster_scenarios':roster,'warning':'Quantile moments are conditional on finite accepted values; missing/open tails not zeros. No marginal/CV/correlation in this report is a measured newborn distribution.'}
    (ROOT/'validation/sensitivity.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
