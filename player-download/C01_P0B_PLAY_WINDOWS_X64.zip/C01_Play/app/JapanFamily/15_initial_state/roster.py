"""Persons/relationships distinguish residence, biology, law and support."""
from datetime import date
from estimators import rng,draw_weighted
import hashlib,re
def age_at(dob,asof):
    if dob is None:return None
    b=date.fromisoformat(dob);d=date.fromisoformat(asof)
    return d.year-b.year-((d.month,d.day)<(b.month,b.day))
def birthdate_from_age(age,asof):
    if age is None:return None
    d=date.fromisoformat(asof);return date(d.year-age,d.month,min(d.day,28)).isoformat()
def materialize(base,seed,birth_date,multiplicity=1,index_within_delivery=1,members=None,scenario='unresolved',model=None,identity_context=''):
    if not isinstance(multiplicity,int)or not 1<=multiplicity<=5:raise ValueError('Multiplicity must be a known integer 1..5; 5+ exact support unobserved')
    if not isinstance(index_within_delivery,int)or not 1<=index_within_delivery<=multiplicity:raise ValueError('Index outside delivery')
    rank=base['child']['birth_rank'];previous=None if rank is None else rank-index_within_delivery
    if previous is not None and previous<0:raise ValueError('Cumulative birth rank smaller than index within delivery')
    token=hashlib.sha256(f'{seed}:{base["prefecture_code"]}:{birth_date}:{identity_context}'.encode()).hexdigest()[:20]
    hid='hh_'+token;eid='delivery_'+token;persons=[];relations=[];history=[]
    def add(pid,role,dob,co_resident,**attrs):
        p={'person_id':pid,'role':role,'date_of_birth':dob,'age_years':age_at(dob,birth_date),'age_months':0 if role=='newborn'else None,'co_resident':co_resident,'alive':True,'nationality':None,'legal_custody':None,'dependent_for_tax':None,'receives_care_from':None,'birthdate_kind':'game_point_from_published_age'if dob else'unknown',**attrs};persons.append(p);return p
    mom=add('mother','mother',birthdate_from_age(base['mother']['age'],birth_date),True,attributes=base['mother'],supported=False)
    # An unidentified biological parent is an entity, not a known co-resident.
    father=base['father'];co=base['partner_present'] if father else None
    dad=add('father','biological_father_or_unidentified_parent',birthdate_from_age(father['age'],birth_date)if father else None,co,attributes=father,supported=False,alive=True if father else None)
    if co is False:dad['co_resident']=False
    if base['partner_present']is True and father is None:add('partner','co_resident_partner',None,True,supported=False)
    for j in range(1,multiplicity+1):
        pid='index_child'if j==index_within_delivery else f'co_newborn_{j}'
        p=add(pid,'newborn',birth_date,True,sex=base['child']['sex']if j==index_within_delivery else None,supported=True,birthdate_kind='birth_event_input',maternal_cumulative_rank=None if rank is None else previous+j,delivery_event_id=eid,delivery_index=j)
        for parent in ['mother','father']:relations.append({'from':parent,'to':pid,'type':'biological_parent','legal_relationship':None,'care_involvement':None,'support_obligation':None})
    supplied=list(members or[])
    for i,spec in enumerate(supplied):
        if not isinstance(spec,dict):raise ValueError('Member must be an object')
        pid=spec.get('person_id',f'member_{i}')
        if pid in {x['person_id']for x in persons}:raise ValueError('Duplicate person identifier')
        dob=spec.get('date_of_birth');role=spec.get('role','other_relative')
        p=add(pid,role,dob,spec.get('co_resident',False),supported=spec.get('supported'),alive=spec.get('alive',True),birthdate_kind='user_fixed'if dob else'unknown',health=spec.get('health'),residence=spec.get('residence'),distance_km=spec.get('distance_km'),employment=spec.get('employment'),care_support=spec.get('care_support'),financial_support=spec.get('financial_support'))
        if p['co_resident']and p['alive']is False:raise ValueError('A deceased person cannot be a current resident')
        for rel in spec.get('relationships',[]):relations.append({'from':rel['from'],'to':rel.get('to',pid),'type':rel['type'],'legal_relationship':rel.get('legal_relationship'),'care_involvement':rel.get('care_involvement'),'support_obligation':rel.get('support_obligation')})
        if spec.get('maternal_previous_live_birth'):
            if dob and dob>=birth_date:raise ValueError('Previous maternal birth not before current delivery')
            history.append({'person_id':pid,'date':dob,'alive':p['alive'],'co_resident':p['co_resident'],'kind':'user_specified_previous_live_birth'})
            relations.append({'from':'mother','to':pid,'type':'biological_parent','legal_relationship':spec.get('legal_relationship'),'care_involvement':None,'support_obligation':None})
    if previous is not None and len(history)>previous:raise ValueError('More maternal previous births than observed index rank permits; step/adopted children must be labelled separately')
    known=previous-len(history)if previous is not None else None
    if scenario=='backcast_under18_co_residence'and known is not None and model is not None:
        current_age=mom['age_years'];r=rng(seed,'previous-births')
        if current_age is not None:
            for i in range(known):
                ordinal=previous-i;rows=[]
                for x in model.g['birth_pref'][base['prefecture_code']]:
                    if x['sex']!='all'or x['rank']!=min(ordinal,5):continue
                    m=re.fullmatch(r'(\d+)歳',x['mother_label'])
                    if m and int(m[1])<current_age:rows.append(x|{'age':int(m[1])})
                x=draw_weighted(rows,r)
                if x is None:break
                child_age=mom['age_years']-x['age'];pid=f'prior_child_{ordinal}'
                dob=birthdate_from_age(child_age,birth_date);co=child_age<18
                add(pid,'maternal_prior_child',dob,co,supported=co,birthdate_kind='estimate_period_maternal_age_backcast_not_observed_birth_spacing',alive=True if co else None)
                relations.append({'from':'mother','to':pid,'type':'biological_parent','legal_relationship':None,'care_involvement':None,'support_obligation':None})
                history.append({'person_id':pid,'date':dob,'alive':True if co else None,'co_resident':co,'kind':'scenario_all_under18_alive_at_home; survival unobserved'});current_age=x['age']
    if previous is not None:
        history.extend({'person_id':None,'date':None,'alive':None,'co_resident':None,'kind':'historical_birth_exists_but_person_unidentified'}for _ in range(previous-len(history)))
    co_count=sum(p['co_resident']is True for p in persons)
    target=base['housing']['household_size']
    if members is None and scenario=='unresolved'and target is not None:
        while co_count<target:
            i=co_count;role='co_resident_grandparent'if base['family']['co_resident_grandparent']and not any(p['role']=='co_resident_grandparent'for p in persons)else'unclassified_co_resident'
            add(f'unresolved_member_{i}',role,None,True,supported=None);co_count+=1
    known_ids={x['person_id']for x in persons}
    for rel in relations:
        if rel['from']not in known_ids or rel['to']not in known_ids:raise ValueError('Relationship refers to an unknown person')
        if rel['type']=='biological_parent':
            a=next(x for x in persons if x['person_id']==rel['from']);b=next(x for x in persons if x['person_id']==rel['to'])
            if a['date_of_birth']and b['date_of_birth']and a['date_of_birth']>=b['date_of_birth']:raise ValueError('Biological parent not older than child')
    if any(p['age_years']is not None and p['age_years']<0 for p in persons):raise ValueError('A member is not yet born')
    resolved=previous is not None and all(p['date_of_birth']is not None and p['co_resident']is not None and p['role']!='unclassified_co_resident'for p in persons if p['co_resident']is True)and all(x['person_id']is not None for x in history)
    return {'household_id':hid,'delivery_event_id':eid,'persons':persons,'relationships':relations,'historical_previous_live_births':history,'resident_count':co_count,'reference_household_size':target,'roster_resolved':resolved,'birth_unit':'index_liveborn_child; multiplicity explicitly supplied, no unobserved automatic liveborn-only correction','multiplicity':multiplicity,'index_within_delivery':index_within_delivery,'scenario':scenario,'unique_delivery_conversion_weight':1/multiplicity,'unique_delivery_conversion_warning':'weight only meaningful when liveborn multiplicity is known; official 4-37 includes stillbirth deliveries'}
def deduplicate_delivery(states):
    result={}
    for s in states:
        key=s['household']['delivery_event_id'];existing=result.get(key)
        if existing and(existing['household']['multiplicity']!=s['household']['multiplicity']or existing['household']['prefecture_code']!=s['household']['prefecture_code']):raise ValueError('Conflicting records share a delivery ID')
        result.setdefault(key,s)
    return list(result.values())
def project_index_view(state,index):
    """Multiple index views of ONE generated event, without sampling the family again."""
    import copy
    if not isinstance(index,int)or not 1<=index<=state['household']['multiplicity']:raise ValueError('Index outside generated delivery')
    result=copy.deepcopy(state);h=result['household'];p=next(p for p in result['persons']if p.get('delivery_index')==index)
    h['index_within_delivery']=index;h['index_person_id']=p['person_id']
    prior=h['maternal_previous_live_birth_count_interval'];h['index_birth_rank_interval']=[prior[0]+index,None if prior[1]is None else prior[1]+index]
    h['sampling_unit']='index view of one previously generated liveborn delivery; not a second statistical draw'
    result['quality_flags']['index_sex_unidentified']=p.get('sex')is None
    return result
