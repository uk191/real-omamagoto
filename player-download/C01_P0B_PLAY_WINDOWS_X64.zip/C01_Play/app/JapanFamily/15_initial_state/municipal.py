"""Restricted official 2026 municipal computations. Never an inferred cash bill.

Kashiwa only. Missing applicability/relief inputs remain unknown. NHI inputs are
annual equivalents: birth-month membership proration/rounding is not invented.
"""
from decimal import Decimal,ROUND_FLOOR
def basic_2025_resident(income):
    return 430000 if income<=24000000 else 290000 if income<=24500000 else 150000 if income<=25000000 else 0
def salary_income_2025_resident(gross,child_adjustment=False):
    if not isinstance(gross,int)or gross<0:raise ValueError('2025 salary must be nonnegative integer yen')
    if gross<=651000:x=0
    elif gross<=1900000:x=gross-650000
    elif gross<=3600000:x=int(Decimal(gross//4000*1000)*Decimal('2.8'))-80000
    elif gross<=6600000:x=int(Decimal(gross//4000*1000)*Decimal('3.2'))-440000
    elif gross<=8500000:x=int(Decimal(gross)*Decimal('.9'))-1100000
    else:x=gross-1950000
    if child_adjustment and gross>8500000:x-=int(Decimal(min(gross,10000000)-8500000)*Decimal('.1'))
    return x
def resident_tax_2026_kashiwa(prior_total_income,prior_deductions_excluding_basic=0,dependent_person_count=0,human_allowance_difference=50000,special_nontax_eligible=False,receives_livelihood_assistance=False,credits_city=0,credits_prefecture=0):
    """Ordinary aggregate income, taxpayer-supplied 2025 verified tax deductions.
    Separate income/capital taxation, credit eligibility and tax-form construction
    are out of scope. Newborn2026 is not automatically a dependent on2025 return.
    """
    values=[prior_total_income,prior_deductions_excluding_basic,dependent_person_count,human_allowance_difference,credits_city,credits_prefecture]
    if any(not isinstance(x,int)or x<0 for x in values):raise ValueError('Nonnegative integer inputs required')
    n=1+dependent_person_count
    exempt_flat=315000*n+100000+(189000 if n>1 else 0)
    exempt_income=350000*n+100000+(320000 if n>1 else 0)
    exempt=receives_livelihood_assistance or(special_nontax_eligible and prior_total_income<=1350000)or prior_total_income<=exempt_flat
    taxable=max(0,(prior_total_income-prior_deductions_excluding_basic-basic_2025_resident(prior_total_income))//1000*1000)
    adjustment_basis=0 if prior_total_income>25000000 else(min(human_allowance_difference,taxable)if taxable<=2000000 else max(50000,human_allowance_difference-(taxable-2000000)))
    city=max(0,int(Decimal(taxable)*Decimal('.06')-Decimal(adjustment_basis)*Decimal('.03'))-credits_city)//100*100
    prefecture=max(0,int(Decimal(taxable)*Decimal('.04')-Decimal(adjustment_basis)*Decimal('.02'))-credits_prefecture)//100*100
    if exempt or prior_total_income<=exempt_income:city=prefecture=0
    flat=0 if exempt else 5000
    return {'annual_liability':city+prefecture+flat,'city_income_levy':city,'prefecture_income_levy':prefecture,'flat_and_forest':flat,'taxable_income':taxable,'income_observation_year':2025,'assessment_year':2026,'municipality':'12217','cash_monthly_bill':None,'scope':'restricted ordinary-income computation; declared credits/deductions and eligibility; January1 address matters','source':'https://www.city.kashiwa.lg.jp/shiminzei/zeikin/kojin/kesan.html'}
def nhi_2026_kashiwa(members,relief_income=None,salary_pension_count=0,former_member_count=0,all_income_reported=False,no_special_relief_applies=False):
    """Components of full-year premium equivalent before final billing rounding.
    Members require assessed_income2025, age group at assessed period and
    preschool eligibility. Priorhead income is included in relief_income even
    if not insured. Special unemployment/maternity/reduction: supplied separately.
    """
    if not members:raise ValueError('At least one insured member required')
    for p in members:
        if any(k not in p for k in('assessed_income2025','age','preschool')):raise ValueError('Unknown assessed income, age or preschool status')
        if p['assessed_income2025']<0 or not 0<=p['age']<75:raise ValueError('Invalid NHI member scope')
    income=sum(max(0,p['assessed_income2025']-basic_2025_resident(p['assessed_income2025']))for p in members)
    care=[p for p in members if 40<=p['age']<65];adults=[p for p in members if p['age']>=18]
    care_income=sum(max(0,p['assessed_income2025']-basic_2025_resident(p['assessed_income2025']))for p in care)
    reduction=None
    if all_income_reported and relief_income is not None:
        addition=100000*max(0,salary_pension_count-1);n=len(members)+former_member_count
        reduction=.7 if relief_income<=430000+addition else .5 if relief_income<=430000+addition+310000*n else .2 if relief_income<=430000+addition+570000*n else 0
    multiplier=Decimal(1)-Decimal(str(reduction or 0))
    heads=sum(Decimal('.5')if p['preschool']else Decimal(1)for p in members)
    components={'medical':min(670000,Decimal(income)*Decimal('.072')+(heads*30000+14340)*multiplier),'support':min(260000,Decimal(income)*Decimal('.0268')+heads*14520*multiplier),'care':min(170000,Decimal(care_income)*Decimal('.0217')+len(care)*16260*multiplier),'child_fund':min(30000,Decimal(income)*Decimal('.0027')+len(adults)*(1800+84)*multiplier)}
    identified=reduction is not None and no_special_relief_applies is True
    return {'annual_components_before_final_rounding':{k:str(v)for k,v in components.items()},'annual_equivalent_before_final_rounding':str(sum(components.values()))if identified else None,'known_low_income_reduction':reduction,'calculation_reference_before_other_reliefs':str(sum(components.values())),'cash_bill':None,'scope':'Kashiwa FY2026 annual equivalent only; period enrollment/maternity/job-loss reductions and official final rounding must be verified from bill','municipality':'12217','income_observation_year':2025,'source':'https://www.city.kashiwa.lg.jp/hokennenkin/hokennenkin/kokuho/hokenryo/hokenryosante.html'}
