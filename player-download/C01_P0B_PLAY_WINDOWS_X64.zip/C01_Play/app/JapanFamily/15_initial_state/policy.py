"""2026 policy calculators. Eligibility and cash receipt require separate inputs.

Scope is explicit: Japanese resident, ordinary salary/general taxable income;
no implied eligibility, municipal approximation, tax credit or insurer enrollment.
"""
from decimal import Decimal,ROUND_CEILING,ROUND_FLOOR,ROUND_HALF_UP
from datetime import date,timedelta
import calendar
import json,bisect
from functools import lru_cache
from pathlib import Path
ROOT=Path(__file__).resolve().parent
D=lambda x:Decimal(str(x))
@lru_cache(maxsize=1)
def _policy():return json.loads((ROOT/'data/state_kernels.json').read_text())
def yen(x,mode=ROUND_FLOOR):return int(D(x).quantize(D(1),rounding=mode))
def salary_income(gross,year=2026,adjustment_eligible=False):
    if not isinstance(gross,int)or isinstance(gross,bool):raise ValueError('Salary must be integer yen')
    g=int(gross)
    if g<0:raise ValueError('Negative salary revenue')
    if year==2026:
        if g<=740999:y=0
        elif g<=2190999:y=g-740000
        elif g<=2192999:y=1451000
        elif g<=2195999:y=1453000
        elif g<=2199999:y=1456000
        elif g<3600000:y=yen(D(g//4000*1000)*D('2.8')-80000)
        elif g<6600000:y=yen(D(g//4000*1000)*D('3.2')-440000)
        elif g<8500000:y=yen(D(g)*D('.9')-1100000)
        else:y=g-1950000
    elif year==2025:
        if g<=1900000:y=max(0,g-650000)
        elif g<3600000:y=yen(D(g//4000*1000)*D('2.8')-80000)
        elif g<6600000:y=yen(D(g//4000*1000)*D('3.2')-440000)
        elif g<8500000:y=yen(D(g)*D('.9')-1100000)
        else:y=g-1950000
    else:raise ValueError('Only verified 2025/2026 salary years supported')
    if adjustment_eligible and g>8500000:y-=yen(D(min(g,10000000)-8500000)*D('.1'))
    return max(0,y)
def basic_deduction(total_income,year=2026):
    if year not in(2025,2026):raise ValueError('Unverified tax year')
    x=int(total_income)
    bands=[(4890000,1040000),(6550000,670000),(23500000,620000),(24000000,480000),(24500000,320000),(25000000,160000)] if year==2026 else [(1320000,950000),(3360000,880000),(4890000,680000),(6550000,630000),(23500000,580000),(24000000,480000),(24500000,320000),(25000000,160000)]
    return next((v for top,v in bands if x<=top),0)
def spouse_deduction(own_income,spouse_income,legally_married,elderly=False):
    if not legally_married or spouse_income is None or own_income>10000000:return 0
    column=0 if own_income<=9000000 else(1 if own_income<=9500000 else 2)
    if spouse_income<=620000:return ([480000,320000,160000] if elderly else [380000,260000,130000])[column]
    bands=[(950000,[380000,260000,130000]),(1000000,[360000,240000,120000]),(1050000,[310000,210000,110000]),(1100000,[260000,180000,90000]),(1150000,[210000,140000,70000]),(1200000,[160000,110000,60000]),(1250000,[110000,80000,40000]),(1300000,[60000,40000,20000]),(1330000,[30000,20000,10000])]
    return next((v[column]for top,v in bands if spouse_income<=top),0)
def annual_income_tax(gross_salary,social_paid=0,other_taxable_income=0,spouse_income=None,legally_married=False,dependent_deduction=0,other_deductions=0,tax_credit=0,adjustment_eligible=False,year=2026):
    if any(x<0 for x in [social_paid,dependent_deduction,other_deductions,tax_credit]):raise ValueError('Negative paid deduction or credit')
    income=salary_income(gross_salary,year,adjustment_eligible)+int(other_taxable_income)
    if income>330000000:raise ValueError('Ultra-high-income alternative minimum tax not implemented')
    basic=basic_deduction(income,year)
    spouse=spouse_deduction(income,spouse_income,legally_married) if year==2026 else 0
    taxable=max(0,income-int(social_paid)-basic-spouse-int(dependent_deduction)-int(other_deductions))//1000*1000
    bracket=next((x for x in [(1950000,'.05',0),(3300000,'.10',97500),(6950000,'.20',427500),(9000000,'.23',636000),(18000000,'.33',1536000),(40000000,'.40',2796000),(float('inf'),'.45',4796000)]if taxable<x[0]))
    ordinary=max(0,yen(D(taxable)*D(bracket[1])-bracket[2])-int(tax_credit))
    combined=yen(D(ordinary)*D('1.021'))//100*100
    return {'salary_income':salary_income(gross_salary,year,adjustment_eligible),'total_taxable_income_before_deductions':income,'basic_deduction':basic,'spouse_deduction':spouse,'taxable_income':taxable,'ordinary_income_tax':ordinary,'income_and_reconstruction_tax':combined,'year':year,'kind':'verified_rule_given_inputs; excluded deductions must be declared','cash_payment_schedule':None}
def monthly_withholding(net_salary_after_social,source_dependent_count=0,source_spouse=False):
    """NTA 2026 electronic-computation exception, ordinary 甲欄 only."""
    a=max(0,int(net_salary_after_social));n=int(source_dependent_count)+int(source_spouse)
    if n<0:raise ValueError('Negative source deduction count')
    deduction=54167 if a<=158333 else(yen(D(a)*D('.3')+6667,ROUND_CEILING)if a<=299999 else(yen(D(a)*D('.2')+36667,ROUND_CEILING)if a<=549999 else(yen(D(a)*D('.1')+91667,ROUND_CEILING)if a<=708330 else 162500)))
    basic=next((v for top,v in [(2120833,48334),(2162499,40000),(2204166,26667),(2245833,13334)]if a<=top),0)
    b=max(0,a-deduction-basic-31667*n)
    _,rate,offset=next(x for x in [(162500,'.05105',0),(275000,'.10210',8296),(579166,'.20420',36374),(750000,'.23483',54113),(1500000,'.33693',130688),(3333333,'.40840',237893),(float('inf'),'.45945',408061)]if b<=x[0])
    return max(0,int(((D(b)*D(rate)-offset)/10).quantize(D(1),rounding=ROUND_HALF_UP))*10)
def employee_social(prefecture,standard_monthly,age,employment_salary,asof,exemption_approved=False,agricultural_or_construction=False):
    policy=_policy();d=date.fromisoformat(asof)
    if not date(2026,4,1)<=d<=date(2027,2,28):raise ValueError('This insurer-rate snapshot covers 2026-04 through 2027-02 only')
    if age is None or not 0<=age<75:raise ValueError('Verified insurer age required; late-elderly scheme is separate')
    s=int(standard_monthly)
    if employment_salary<0:raise ValueError('Negative gross payroll wage')
    if s not in policy['standard_health_bands']:raise ValueError('Invalid standard monthly remuneration grade')
    def pay(rate):
        raw=D(s)*D(rate)/2
        return yen(raw) + int(raw-yen(raw)>D('.5'))
    health=0 if exemption_approved else pay(policy['health_rates'][str(prefecture).zfill(2)])
    care=0 if exemption_approved or age is None or not 40<=age<=64 else pay('.0162')
    support=0 if exemption_approved else pay('.0023')
    pension=0 if exemption_approved or age is None or age>=70 else yen(D(min(650000,max(88000,s)))*D('.183')/2)
    unemployment=yen(D(employment_salary)*D('.006'if agricultural_or_construction else'.005'))
    return {'health':health,'care':care,'child_support_contribution':support,'employees_pension':pension,'unemployment':unemployment,'total':health+care+support+pension+unemployment,'exemption_approved':exemption_approved,'source':'2026_kyokai_rates_and_grade_table; employed-insurer premise must be supplied'}
def standard_remuneration(monthly_total_remuneration):
    p=_policy();v=int(monthly_total_remuneration)
    if v<0:raise ValueError('Negative remuneration')
    return p['standard_health_bands'][bisect.bisect_right(p['standard_health_thresholds'],v)]
def maternity_allowance(average_standard_monthly,days,paid_salary=0,eligible=None,insured_continuous_months=12):
    if eligible is not True:return {'amount':0 if eligible is False else None,'eligibility':eligible,'actual_receipt':None}
    if not 0<=days<=31:raise ValueError('Monthly allowance days outside calendar')
    if average_standard_monthly<0 or paid_salary<0:raise ValueError('Negative allowance input')
    if insured_continuous_months<12:average_standard_monthly=min(average_standard_monthly,320000)
    daily=yen(D(average_standard_monthly)/300,ROUND_HALF_UP)*10
    daily=yen(D(daily)*2/3,ROUND_HALF_UP)
    return {'amount':max(0,daily*int(days)-int(paid_salary)),'eligibility':True,'actual_receipt':None,'source':'kyokai maternity allowance; average of 12 standard months required'}
def childcare_leave_benefit(daily_wage,days,wage_paid=0,eligible=None,post180=False,support_eligible=None,asof='2026-10-01',birth_leave=True):
    if eligible is not True:return {'base':0 if eligible is False else None,'support':0 if eligible is False else None,'eligibility':eligible,'actual_receipt':None}
    if not date(2026,8,1)<=date.fromisoformat(asof)<=date(2027,7,31):raise ValueError('Daily cap snapshot covers 2026-08 through 2027-07')
    if daily_wage<0 or wage_paid<0:raise ValueError('Negative leave wage')
    if not 0<=days<=(28 if birth_leave else 30):raise ValueError('Benefit-day limit')
    base_wage=D(min(float(daily_wage),16540))*int(days);paid=D(wage_paid);rate=D('.5'if post180 else'.67')
    benefit=max(D(0),min(base_wage*rate,base_wage*D('.8')-paid)) if paid<base_wage*D('.8') else D(0)
    support=None if support_eligible is None else(yen(base_wage*D('.13'))if support_eligible and benefit>0 else 0)
    return {'base':yen(benefit),'support':support,'eligibility':True,'support_eligibility':support_eligible,'actual_receipt':None,'daily_cap':16540,'asof':asof}
def national_pension(age,asof,category_one,raising_under_one_child,approved,postpartum_approved=False):
    if not date(2026,4,1)<=date.fromisoformat(asof)<=date(2027,3,31):raise ValueError('National pension premium snapshot is FY2026 only')
    if category_one is None or age is None:return {'amount':None,'eligibility':'unidentified_enrollment_or_age'}
    if not category_one or not 20<=age<60:return {'amount':0,'eligibility':'not_category1_or_age'}
    if postpartum_approved or(date.fromisoformat(asof)>=date(2026,10,1)and raising_under_one_child and approved):return {'amount':0,'eligibility':'verified_exemption_given_application'}
    return {'amount':17920,'eligibility':'ordinary_category1_premium; income-exemption application unresolved'}
def child_allowance(children,asof,eligible=None):
    if eligible is not True:return {'entitlement_monthly':0 if eligible is False else None,'actual_receipt':None,'eligibility':eligible}
    d=date.fromisoformat(asof)
    if d<date(2024,10,1):raise ValueError('Child-allowance rule snapshot starts 2024-10')
    # Eligibility through school-year-end, not a simple age<=18/22 cutoff.
    def fy_end_after_birthday(p,age):
        born=date.fromisoformat(p['date_of_birth']);y=born.year+age;b=date(y,born.month,min(born.day,calendar.monthrange(y,born.month)[1]))-timedelta(days=1)
        return date(b.year if b<=date(b.year,3,31)else b.year+1,3,31)
    counted=sorted([p for p in children if p.get('supported')is True and d<=fy_end_after_birthday(p,22)],key=lambda p:p['date_of_birth'])
    total=0;detail=[]
    for ordinal,p in enumerate(counted,1):
        born=date.fromisoformat(p['date_of_birth']);age=d.year-born.year-((d.month,d.day)<(born.month,born.day))
        y=born.year+3;turn3=date(y,born.month,min(born.day,calendar.monthrange(y,born.month)[1]))-timedelta(days=1)
        under3_rate=(d.year,d.month)<=(turn3.year,turn3.month)
        amount=30000 if ordinal>=3 else(15000 if under3_rate else 10000)
        if(d.year,d.month)==(born.year,born.month):amount=0
        if d>fy_end_after_birthday(p,18):amount=0
        detail.append({'person_id':p['person_id'],'benefit_count_ordinal':ordinal,'amount':amount});total+=amount
    return {'entitlement_monthly':total,'eligible_children':detail,'actual_receipt':None,'eligibility':True,'payment_months':[2,4,6,8,10,12],'birth_child_start':'normally following application month; 15-day exception requires application date'}
