"""Keep every old unresolved candidate and prioritize relevant connections."""
from pathlib import Path
import json,collections
ROOT=Path(__file__).resolve().parent
def main():
    catalogue=json.loads((ROOT/'data/expanded_catalogue_A25.json').read_text());rows=[]
    for x in catalogue['rows'][:634]:
        if x.get('A2_status')!='not_acquired_or_individually_verified':continue
        label=x.get('変数候補','');category=x.get('大分類','')+' '+x.get('中分類','')
        p0=any(k in label for k in('出生','配偶','所得','家賃','住宅ローン','預貯金','負債','育休','育児休業','就業','祖父母','兄弟','世帯人数','税','社会保険'))
        p1=any(k in category+label for k in('雇用','労働','保育','物価','支出','住宅','家族','家計','交通','通勤'))
        rows.append({'variable_id':x['variable_id'],'label':label,'priority':'P0'if p0 else'P1'if p1 else'P2','status':'not_acquired_or_individually_verified','source_candidates':x.get('候補ソースID',''),'next_action':'同一世帯の条件付き表/制度適用/時間差/地理対応を個別確認'if p0 else'公開原表の候補セル・定義・年次・秘匿・不足を個別対応付け','old_row_preserved':True})
    assert len(rows)==505
    report={'old_unresolved_candidates':505,'priority_counts':dict(collections.Counter(x['priority']for x in rows)),'priority_method':'label-based continuation triage, not a new acquisition/semantic verification','rows':rows,'new_P0_connections':['birth_history_and_live_co_resident_children','actual_birth_month_income_sources_and_prior_12months','gross_to_tax_to_DI_definition_and_payment_calendar','unconditional_holder_presence_with_asset_debt_joint','regional_income_conditional_expenditure_joint','national_municipal_policy_parameters_and_eligibility']}
    (ROOT/'data/backlog_505_A25.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report['priority_counts'])
if __name__=='__main__':main()
