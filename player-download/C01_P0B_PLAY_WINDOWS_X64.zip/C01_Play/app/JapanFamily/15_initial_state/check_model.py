"""Actual API, process reload, player constraints and accounting fixtures."""
import json,copy,threading,urllib.request,urllib.error,subprocess,sys,hashlib
from pathlib import Path
from http.server import HTTPServer
from initial_state import InitialStateModel,InitialConditionError
from api import Handler
from roster import deduplicate_delivery,project_index_view
from examples import requests
from municipal import *
from transport import budget_2024_oct_nov_to_2026_aug
ROOT=Path(__file__).resolve().parent
def main():
    tests=[]
    def check(name,ok,detail=''):tests.append({'name':name,'pass':bool(ok),'detail':detail});print(name,bool(ok),flush=True)
    m=InitialStateModel();req=requests();r=dict(req[0]);r.pop('label');s=m.generate(**r)
    check('full_fixture_reproducible',s==m.generate(**r))
    check('fixed_parent_age_and_rank',s['persons'][0]['age_years']==r['conditions']['mother_age']and s['household']['index_birth_rank_interval']==[1,1])
    check('game_flag_remains_false',s['quality_flags']['initial_month_cash_ready']and not s['quality_flags']['financially_playable'])
    check('fixture_cash_networth_identities',s['monthly_budget']['settlement_preview']['cash_identity_residual']==0 and s['monthly_budget']['settlement_preview']['net_worth_identity_residual']==0)
    check('lagged_premium_actual_cash',s['taxes_and_benefits']['taxes']['father']['employee_social_cash_deduction']==55000)
    t=dict(req[22]);t.pop('label');twin=m.generate(**t);v=project_index_view(twin,1)
    check('twins_one_event_two_views',len(deduplicate_delivery([twin,v]))==1 and v['household']['index_birth_rank_interval']==[1,1]and len(twin['birth_history'])==0)
    r2=copy.deepcopy(r);r2['initialization']['accounts'][0]['balance']+=1
    check('different_profile_different_id',m.generate(**r2)['household']['household_id']!=s['household']['household_id'])
    default=m.generate('13',seed='check-default',conditions={'birth_rank':3},include_region=False,initialization={'benefit_eligibility':{'child_allowance':True}})
    check('missing_prior_child_no_allowance_award',default['taxes_and_benefits']['benefits']['child_allowance']['entitlement_monthly']is None)
    missing=m.generate('13',seed='unknown-benefit-inputs',include_region=False,initialization={'employment':{'mother':{'maternity_eligible':True},'father':{'leave_benefit_eligible':True}}})
    check('eligible_missing_wage_is_not_zero',missing['taxes_and_benefits']['benefits']['maternity']['amount']is None and missing['taxes_and_benefits']['benefits']['paternal_leave']['base']is None)
    check('2023_rent_not_actual_2026_cash',default['housing']['monthly_rent_current_cash']is None and default['housing']['price_reference_year']==2023)
    bads=[('wrong_year',{'birth_date':'2025-10-01'}),('boolean_seed',{'seed':True}),('unknown_initializer',{'initialization':{'invented':1}}),('impossible_maternal_birth_history',{'conditions':{'birth_rank':1},'initialization':{'members':[{'role':'maternal_prior_child','date_of_birth':'2020-01-01','maternal_previous_live_birth':True}]}}),('negative_cash_bill',{'initialization':{'national_health_cash':-1}}),('mother_employee_working_at_birth',{'initialization':{'employment':{'mother':{'actual_employee_worker':True,'actual_hours_at_birth':40,'at_birth_status':'working'}}}})]
    for name,k in bads:
        try:m.generate('13',seed=0,include_region=False,**k)if 'seed'not in k else m.generate('13',include_region=False,**k);ok=False
        except ValueError:ok=True
        check(name,ok)
    for name,condition in [('young_parent',{'mother_age':18}),('older_parent',{'mother_age':46}),('rank10_open',{'birth_rank':10}),('nonmarital',{'legal_status':'nonmarital','partner_present':False}),('fixed_income',{'household_income_yen':9000000})]:
        try:
            z=m.generate('13',conditions=condition,seed='extreme/'+name,include_region=False);check(name,not z['quality_flags']['financially_playable'],{'outcome':'generated','rank_interval':z['household']['index_birth_rank_interval']})
        except InitialConditionError as e:check(name,e.kind in('unidentified_statistical_support','sampling_limit'),{'kind':e.kind,'message':str(e),'not_impossibility_proof':True})
    hashes=[]
    for _ in range(2):
        b=subprocess.run([sys.executable,str(ROOT/'initial_state.py'),'--pref','13','--seed','reload-test','--no-region'],capture_output=True,check=True).stdout;hashes.append(hashlib.sha256(b).hexdigest())
    check('independent_process_seed_reproduction',hashes[0]==hashes[1],hashes)
    server=HTTPServer(('127.0.0.1',0),Handler)
    def serve():Handler.model=InitialStateModel();server.serve_forever()
    th=threading.Thread(target=serve,daemon=True);th.start();url=f'http://127.0.0.1:{server.server_port}'
    def call(path,body=None):
        data=None if body is None else(json.dumps(body).encode()if not isinstance(body,bytes)else body)
        try:
            with urllib.request.urlopen(urllib.request.Request(url+path,data=data,headers={'Content-Type':'application/json'}),timeout=30)as response:return response.status,json.load(response)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    try:
        status,a=call('/health');check('HTTP_health',status==200 and a['model_version']=='A2.5-0.1')
        status,a=call('/initial-state',r)
        expected=json.loads(json.dumps(s))
        def difference(x,y,path=''):
            if type(x)!=type(y):return path+':type '+str(type(x))+str(type(y))
            if isinstance(x,dict):
                if x.keys()!=y.keys():return path+':keys '+str(x.keys())+str(y.keys())
                return next((d for k in x if(d:=difference(x[k],y[k],path+'/'+k))),None)
            if isinstance(x,list):
                if len(x)!=len(y):return path+':length'
                return next((d for i in range(len(x))if(d:=difference(x[i],y[i],path+'/'+str(i)))),None)
            return None if x==y else path+':values '+repr(x)+' vs '+repr(y)
        check('HTTP_fixture',status==200 and a==expected,{'status':status,'first_difference':difference(a,expected),'comparison':'JSON wire representation normalizes tuple source metadata to arrays'})
        status,a=call('/initial-state-batch',{'prefecture_code':'13','n':3,'seed':'batch','include_region':False});check('HTTP_batch',status==200 and len(a)==3)
        for name,path,b,status_expected in [('malformed_JSON','/initial-state',b'{',400),('batch_limit','/initial-state-batch',{'prefecture_code':'13','n':1001},400),('unknown_endpoint','/unknown',{},404),('bad_year','/initial-state',{'prefecture_code':'13','birth_date':'2025-01-01'},400),('unidentified_support','/initial-state',{'prefecture_code':'13','conditions':{'mother_age':100}},422)]:
            status,a=call(path,b);check('HTTP_'+name,status==status_expected,{'status':status,'body':a})
    finally:server.shutdown();server.server_close();th.join()
    c=resident_tax_2026_kashiwa(5200000,1488000,2,150000)
    check('resident_official_2019_example_with_2026_forest_levy',c['annual_liability']==330600,{'2026_formula_result':c,'note':'official worked example 329600 has pre-forest4000 levy; income component325600 retained'})
    check('resident_2025_not_2026_salary_table',salary_income_2025_resident(1065000)==415000 and resident_tax_2026_kashiwa(415000)['annual_liability']==0)
    nhi=nhi_2026_kashiwa([{'assessed_income2025':0,'age':30,'preschool':False},{'assessed_income2025':0,'age':0,'preschool':True}],0,all_income_reported=True,no_special_relief_applies=True)
    check('NHI_low_income_preschool_combination',nhi['known_low_income_reduction']==.7 and nhi['cash_bill']is None,nhi)
    check('CPI_connected_bases',budget_2024_oct_nov_to_2026_aug(298680)['amount']==311231)
    (ROOT/'validation/model_api_tests.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2));assert all(x['pass']for x in tests)
if __name__=='__main__':main()
