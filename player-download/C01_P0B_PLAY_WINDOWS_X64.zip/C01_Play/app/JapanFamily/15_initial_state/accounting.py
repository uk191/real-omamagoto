"""A3-facing one-period accounting, with no automatic residual financing."""
from decimal import Decimal,ROUND_HALF_UP
import copy
from policy import D,yen
def loan_payment(balance,annual_rate,remaining_months,payment_override=None):
    if not isinstance(balance,int)or not isinstance(remaining_months,int)or isinstance(remaining_months,bool):raise ValueError('Integer loan balance and months required')
    if payment_override is not None and(not isinstance(payment_override,int)or payment_override<0):raise ValueError('Integer nonnegative loan payment required')
    b=int(balance);n=int(remaining_months);r=D(annual_rate)/12
    if b<0 or n<1 or not r.is_finite()or r<0:raise ValueError('Invalid loan terms')
    payment=yen(D(b)/n,ROUND_HALF_UP)if not r else yen(D(b)*r/(1-(1+r)**(-n)),ROUND_HALF_UP)
    if payment_override is not None:payment=int(payment_override)
    interest=yen(D(b)*r,ROUND_HALF_UP)
    principal=min(b,payment-interest)
    if principal<0:raise ValueError('Negative amortization requires an explicitly supported loan contract')
    return {'payment':interest+principal,'interest':interest,'principal':principal,'closing_balance':b-principal,'annual_rate':float(r*12),'remaining_months':n}
def net_worth(accounts):
    values=[a.get('balance')for a in accounts]
    if any(x is None for x in values):return None
    return sum(int(a['balance'])*(1 if a['side']=='asset'else-1)for a in accounts)
def settle_one_period(accounts,cash_entries,loans=(),valuations=()):
    """Pure transition: does not simulate decisions, careers, growth or events.

    Each cash entry is one signed flow. Borrowing is a financing flow, never income;
    loan principal changes both cash and debt. Valuations do not create cash.
    """
    a=copy.deepcopy(accounts);by={x['account_id']:x for x in a}
    if len(by)!=len(a):raise ValueError('Duplicate account ID')
    if any(x.get('balance')is not None and(not isinstance(x['balance'],int)or isinstance(x['balance'],bool)or x['balance']<0)for x in a):raise ValueError('Opening positions must be nonnegative integer yen; debt has its own account')
    cash_ids=[k for k,x in by.items()if x.get('liquid_cash')]
    if len(cash_ids)!=1:raise ValueError('Exactly one liquid settlement account required')
    cid=cash_ids[0];opening=by[cid].get('balance')
    if opening is None:raise ValueError('Opening cash unidentified')
    if any(e.get('amount')is None for e in cash_entries):raise ValueError('A cash flow is unidentified; cannot silently treat as zero')
    flows=copy.deepcopy(list(cash_entries));seen=set()
    for entry in flows:
        if not isinstance(entry['amount'],int)or isinstance(entry['amount'],bool):raise ValueError('Cash entries must be integer yen')
        if entry['entry_id']in seen:raise ValueError('Duplicate cash entry ID')
        seen.add(entry['entry_id'])
        if entry.get('category')in('loan_drawdown','asset_sale')and not entry.get('counter_account_id'):raise ValueError('Financing needs a counter account')
        counter=entry.get('counter_account_id')
        if counter:
            if counter not in by or by[counter].get('balance')is None:raise ValueError('Financing counter account unidentified')
            value=int(entry['amount'])
            by[counter]['balance']+=value if by[counter]['side']=='liability'else-value
    if len({l['account_id']for l in loans})!=len(loans):raise ValueError('A loan contract appears twice')
    for l in loans:
        if l['account_id']not in by or by[l['account_id']]['side']!='liability':raise ValueError('Unknown loan account')
        balance=by[l['account_id']]['balance']
        if balance is None:raise ValueError('Loan balance unidentified')
        x=loan_payment(balance,l['annual_rate'],l['remaining_months'],l.get('payment_override'))
        by[l['account_id']]['balance']=x['closing_balance']
        flows.extend([{'entry_id':l['account_id']+'/principal','amount':-x['principal'],'category':'loan_principal'},{'entry_id':l['account_id']+'/interest','amount':-x['interest'],'category':'loan_interest'}])
    valuation_total=0
    for v in valuations:
        if not isinstance(v['change'],int)or isinstance(v['change'],bool):raise ValueError('Valuation change must be integer yen')
        if v['account_id']not in by or by[v['account_id']]['balance']is None:raise ValueError('Unknown valued asset')
        by[v['account_id']]['balance']+=int(v['change']);valuation_total+=int(v['change'])*(1 if by[v['account_id']]['side']=='asset'else-1)
    movement=sum(int(e['amount'])for e in flows)
    by[cid]['balance']=int(opening)+movement
    if any(x['balance']is not None and x['balance']<0 for x in a if x['account_id']!=cid):raise ValueError('Negative ordinary asset or debt balance')
    before=net_worth(accounts);after=net_worth(a)
    nonwealth={'loan_principal','loan_drawdown','asset_sale'}
    wealth_flows=sum(int(e['amount'])for e in flows if e['category']not in nonwealth)
    identity=None if before is None or after is None else after-before-wealth_flows-valuation_total
    assert identity in(None,0)
    return {'accounts':a,'cash_entries':flows,'opening_cash':int(opening),'closing_cash':by[cid]['balance'],'cash_receipts':sum(e['amount']for e in flows if e['amount']>0),'cash_payments':-sum(e['amount']for e in flows if e['amount']<0),'cash_identity_residual':by[cid]['balance']-opening-movement,'net_worth_identity_residual':identity,'cash_shortfall':max(0,-by[cid]['balance']),'financially_funded':by[cid]['balance']>=0}
