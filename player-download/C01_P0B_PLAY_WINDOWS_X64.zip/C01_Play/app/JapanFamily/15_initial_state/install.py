"""Atomic extension. Never write to inherited data tables or replace A1/A2 kernels."""
import sqlite3,hashlib,json,os,stat
from pathlib import Path
ROOT=Path(__file__).resolve().parent;P=ROOT.parent;DB=P/'data/region.sqlite';VERSION='A2.5-0.1'
BASELINE_SHA='968a61ca6fc0b689762a7737b00727f9e62db3ece7b07762915d47776ab5e0bb'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def fingerprint(c,table):
    assert table.replace('_','').isalnum();h=hashlib.sha256();n=0
    for row in c.execute('SELECT * FROM '+table+' ORDER BY rowid'):
        h.update(repr(row).encode());h.update(b'\n');n+=1
    return {'rows':n,'sha256':h.hexdigest()}
def encode(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def main():
    before_sha=sha(DB);src=sqlite3.connect(f'file:{DB}?mode=ro',uri=True)
    existing={x[0]for x in src.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    old_counts=json.loads((ROOT/'data/baseline_audit.json').read_text())['table_counts']
    if 'initial_model_manifest'not in existing:assert before_sha==BASELINE_SHA,('Source differs from frozen baseline',before_sha)
    for name,n in old_counts.items():assert src.execute('SELECT count(*) FROM '+name).fetchone()[0]==n,(name,'baseline row count changed')
    fingerprints={name:fingerprint(src,name)for name in ['observation','family_stat_cell','geo_unit','geo_crosswalk','scenario_path','source_catalog','artifact','dataset_catalog','variable_catalog','policy_rule','validation_result']}
    audit_file=ROOT/'validation/DB_inheritance_audit.json'
    if 'initial_model_manifest'in existing:assert fingerprints==json.loads(audit_file.read_text())['fingerprints'],'Previously frozen original table content changed'
    tmp=DB.with_name('region_A25.building.sqlite');tmp.unlink(missing_ok=True);dst=sqlite3.connect(tmp);src.backup(dst);src.close();dst.execute('PRAGMA foreign_keys=ON');dst.executescript((ROOT/'schema.sql').read_text())
    for table in ['initial_relationship','initial_person','initial_cash_entry','initial_generated_state','initial_validation_result','initial_stat_cell','initial_policy_rule','initial_variable_catalog','initial_model_manifest','initial_source_manifest']:dst.execute('DELETE FROM '+table)
    k=json.loads((ROOT/'data/state_kernels.json').read_text());dst.execute('INSERT INTO initial_model_manifest VALUES(?,?,?,?,?,?)',(VERSION,'A2-0.4',sha(ROOT/'data/state_kernels.json'),encode(k),'2026-10-14',0))
    for i,x in enumerate(json.loads((ROOT/'data/sources.json').read_text())):
        assert sha(ROOT/x['file'])==x['sha256'];dst.execute('INSERT INTO initial_source_manifest VALUES(?,?,?,?,?,?,?)',(f'A25SRC_{i+1:03d}',x['file'],x['sha256'],x['bytes'],int(x['original_binary']),encode(x['urls']),encode(x)))
    for name in ['health_rates','grade_sources','leave_industry','maternal_pre_post_joint','maternal_rank_patterns','grandparent_help','asset_holder_quantiles','baby_budget','baby_income_2024_profiles']:
        data=k[name];items=data.items()if isinstance(data,dict)else enumerate(data)
        for key,x in items:dst.execute('INSERT INTO initial_stat_cell VALUES(?,?,?,?,?)',(VERSION,name,str(key),encode(x),'administrative_rule'if name in('health_rates','grade_sources')else'observed_reference_not_newborn_full_joint'))
    for rid,start,end,scope,fn,applies in [
        ('income_tax','2026-01-01','2026-12-31','national','policy.annual_income_tax','salary/general taxable income; verified deductions/credit inputs; exclude ultra-high additional tax'),
        ('withholding','2026-01-01','2026-11-30','national','policy.monthly_withholding','NTA electronic甲欄 monthly computation; December year-end adjustment separate'),
        ('employee_insurance','2026-04-01','2027-02-28','47Kyokai_prefecture_branches','policy.employee_social','explicit insured/remuneration grade; workpref branch; monthly accrual is not cash deduction'),
        ('leave_benefit','2026-08-01','2027-07-31','national','policy.childcare_leave_benefit','employment insurance eligibility and approved support, wages and leave days'),
        ('maternity_allowance','2026-04-01',None,'Kyokai','policy.maternity_allowance','eligible insured employee; mean standard twelve months or short-enrollment rule'),
        ('national_pension','2026-04-01','2027-03-31','national','policy.national_pension','category1 age20-59; approved postpartum or under1raising exemption fromOct2026'),
        ('child_allowance','2024-10-01',None,'national','policy.child_allowance','all supported children known; recognition/application/entitlement differs from cash'),
        ('resident_tax','2026-06-01','2027-05-31','12217','municipal.resident_tax_2026_kashiwa','prior2025 ordinary taxable income and verified deductions/credits only'),
        ('NHI','2026-04-01','2027-03-31','12217','municipal.nhi_2026_kashiwa','annual components only; maternity/jobloss/proration/billing rounding unresolved')]:
        dst.execute('INSERT INTO initial_policy_rule VALUES(?,?,?,?,?,?,?)',(rid,VERSION,start,end,scope,fn,encode({'applies':applies,'cash_auto_award':False})))
    cat=json.loads((ROOT/'data/expanded_catalogue_A25.json').read_text())
    for i,x in enumerate(cat['rows']):dst.execute('INSERT INTO initial_variable_catalog VALUES(?,?,?,?)',(x['variable_id'],VERSION,int(i<690),encode(x)))
    examples=json.loads((ROOT/'validation/examples.json').read_text())
    for ex in examples:
        s=ex['state'];h=s['household'];sid=h['household_id'];geo=dst.execute("SELECT geo_id FROM geo_unit WHERE code=? AND geo_version='census2025-10-01'",(h['municipality_code'],)).fetchone();assert geo is not None
        payload=encode(s);dst.execute('INSERT INTO initial_generated_state VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(sid,VERSION,h['delivery_event_id'],h['prefecture_code'],h['municipality_code'],geo[0],s['birth_date'],encode(s['seed']),hashlib.sha256(payload.encode()).hexdigest(),payload,0,int(s['quality_flags']['initial_month_cash_ready']),'explicit_accounting_fixture'))
        for p in s['persons']:dst.execute('INSERT INTO initial_person VALUES(?,?,?,?,?,?,?)',(sid,p['person_id'],p['role'],p['date_of_birth'],p['co_resident'],p['alive'],encode(p)))
        for i,r in enumerate(s['relationships']):dst.execute('INSERT INTO initial_relationship VALUES(?,?,?,?,?,?)',(sid,i,r['from'],r['to'],r['type'],encode(r)))
        for e in s['monthly_budget']['settlement_preview']['cash_entries']:dst.execute('INSERT INTO initial_cash_entry VALUES(?,?,?,?,?)',(sid,e['entry_id'],e['amount'],e['category'],encode(e)))
    for name,kind in [('summary','execution_and_structure'),('birth_source_calibration','same_source_calibration'),('policy_accounting_tests','official_examples_and_accounting'),('model_api_tests','API_boundaries_reproduction'),('sensitivity','unidentified_assumption_sensitivity'),('external_comparison','independent_reference_diagnostics'),('catalogue_audit','inheritance'),('legacy_regression','A1_A2_regression')]:
        dst.execute('INSERT INTO initial_validation_result VALUES(?,?,?,?)',(VERSION,name,kind,(ROOT/'validation'/(name+'.json')).read_text()))
    dst.commit()
    assert dst.execute('PRAGMA integrity_check').fetchall()==[('ok',)];assert not dst.execute('PRAGMA foreign_key_check').fetchall()
    after_fp={name:fingerprint(dst,name)for name in fingerprints};assert after_fp==fingerprints,'Original row contents changed'
    allcounts={name:dst.execute('SELECT count(*) FROM '+name).fetchone()[0]for(name,)in dst.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    schema='\n\n'.join(row[0]+';'for row in dst.execute("SELECT sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type,name"))
    (ROOT/'data/complete_schema_A25.sql').write_text(schema);dst.close()
    with tmp.open('rb')as f:os.fsync(f.fileno())
    os.replace(tmp,DB);os.chmod(DB,stat.S_IRUSR|stat.S_IRGRP|stat.S_IROTH)
    dfd=os.open(DB.parent,os.O_DIRECTORY);os.fsync(dfd);os.close(dfd)
    c=sqlite3.connect(f'file:{DB}?mode=ro',uri=True);assert c.execute('PRAGMA integrity_check').fetchall()==[('ok',)];assert not c.execute('PRAGMA foreign_key_check').fetchall();c.close()
    audit={'baseline_file_sha256':BASELINE_SHA,'source_before_sha256':before_sha,'updated_db_sha256':sha(DB),'updated_db_bytes':DB.stat().st_size,'original_counts_unchanged':True,'critical_original_table_fingerprints_before_after_equal':True,'fingerprints':fingerprints,'table_counts':allcounts,'new_sqlite_integrity':'ok','foreign_key_violations':[],'installed_examples':len(examples),'atomic_install':True,'previous_unexplained_DB_truncation':'restored from exact frozen ZIP and verified; cause not identified; no causal resolution claim'}
    (ROOT/'validation/DB_inheritance_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2));print(json.dumps(audit,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
