"""Preserve all690 inherited rows/fields, add A25 distinct definitions."""
from pathlib import Path
import csv,json,collections
ROOT=Path(__file__).resolve().parent
GROUPS={
 'persons':('structural_user_or_estimated','person','2026','roster.py; NIPSS2025 inherited9-3/9-5; 2025birth tables','人物・法的関係・同居・支援は別属性。未識別値はNULL。推定生年月日は観測年齢からのゲーム仮定。'),
 'employment':('conditional_estimate_partial','person','2022/2023-24 births/2025survey','ESS2022; NIPSS2025; MHLW雇用均等基本調査R7table12','出生前の通常就業を出産前代理とする移送。1歳時就業・将来育休取得は出生当日の休業率ではない。'),
 'income_sources':('explicit_cash_partial','person/household','2022_reference/2026_user','ESS2022; finance2024_3-32-1','実際の入金と通常年収、税法上所得、統計可処分所得を区別。差額を架空収入にしない。'),
 'taxes_and_benefits':('verified_rules_restricted_scope','person/household','2026','NTA2026; Kyokai2026; MHLW2026; CFA; municipal.py Kashiwa only','対象資格・前年所得・申請・実際の入金日が必要。年間税額は月次控除額ではない。自治体制度全国未網羅。'),
 'assets_and_liabilities':('conditional_scenario_or_user','household','2024_reference/2026_user','finance2024_7-101-1; accounting.py','保有世帯分位点の補間・コピュラ・開放裾は仮定。保有率・出生世帯の同時分布は未識別。預金の流動性も未観測。'),
 'monthly_budget':('accounting_verified_scenario_partial','household/month','2024-10/11_reference/2026_user','finance2024baby416; CPI linked2026-08; accounting.py','原表は条件付き平均。CV・所得弾性・構成相関はゲーム用感度仮定。精算恒等式の合格は外部妥当性ではない。'),
 'housing':('inherited_reference_or_user','household','2023_reference/2026_user','housing2023; finance2024_7-101-1','現在住宅の家賃・所有と他物件の借入を区別。市区町村価格・面積の出生同時分布は未識別。'),
 'household':('structural_user_or_inherited','household','2025_reference/2026_birth','FamilyModel A2-0.4; roster.py','出生児抽選と世帯抽選を区別。多胎補正は生児数既知の場合だけ。出生順位から同居子数を決めない。'),
 'future_transition_inputs':('interface_partial','household','2026','initial_state.py; accounting.py','A3への入力のみ。長期遷移・次月入金スケジュールは未完成。'),
 'quality_flags':('implementation_status','household','2026','validation/*.json','financially_playable=false保持。内部・同原表校正・独立比較を混同しない。')}
FIELDS={
 'persons': 'person_id role date_of_birth age_years age_months co_resident alive nationality legal_custody dependent_for_tax supported health residence distance_km care_support financial_support delivery_index maternal_cumulative_rank birthdate_kind'.split(),
 'employment':'at_birth_status normal_hours actual_hours_at_birth workplace_size tenure_months position contract_hours commute_minutes return_date reduced_hours_schedule future_path ever_leave_requested probability observed_one_year_outcome'.split(),
 'income_sources':'source_id type annual_reference reference_year current_month_gross_cash standard_monthly_remuneration past12_actual_income cash_amount'.split(),
 'taxes_and_benefits':'annual_income_tax salary_income monthly_withholding employee_social_accrual employee_social_cash_deduction premium_deduction_lag_months resident_tax_cash national_health_cash national_pension maternity paternal_leave child_allowance birth_lump_sum actual_cash_receipt Kashiwa_resident_annual Kashiwa_NHI_annual_components'.split(),
 'assets_and_liabilities':'cash_deposits deposits_nonliquid other_financial_assets current_home_value other_property_value housing_debt other_debt net_worth asset_holder_quantiles asset_rho asset_tail deposit_liquidity_fraction'.split(),
 'monthly_budget':'cash_entries opening_cash closing_cash cash_shortfall loan_payment loan_interest loan_principal cash_identity_residual net_worth_identity_residual expense_items spending_total_nonhousing spending_cv spending_elasticity spending_concentration national_CPI_factor'.split(),
 'housing':'monthly_rent_current_cash management_fee_cash property_tax_cash repair_reserve_cash floor_area_m2 actual_roster_occupancy'.split(),
 'household':'household_id delivery_event_id resident_person_count multiplicity index_within_delivery index_person_id index_birth_rank_interval maternal_previous_live_birth_count_interval unexplained_reference_income_gap sampling_unit unique_delivery_conversion_weight'.split(),
 'future_transition_inputs':'postpartum_end leave_plans unknowns_to_resolve_before_A3 next_month_state_not_simulated'.split(),
 'quality_flags':'financially_playable initial_month_cash_ready roster_resolved newborn_full_joint_externally_validated unresolved game_start_blockers'.split()}
def main():
    inherited=list(csv.DictReader((ROOT.parent/'13_family/data/expanded_variable_catalogue.csv').open(encoding='utf-8-sig')));assert len(inherited)==690
    rows=[]
    for x in inherited:
        rows.append({**x,'A25_status':'inherited_unmodified','A25_path':x.get('A2_reference',''),'A25_method':'A2-0.4継承、今回の取得数に重複算入しない','A25_definition':x.get('definition',''),'A25_missing_policy':x.get('missing_policy','NULL'),'A25_next_action':x.get('A2_next_action','')})
    for group,fields in FIELDS.items():
        status,grain,year,source,note=GROUPS[group]
        for field in fields:
            pid=f'A25_{len(rows)-689:03d}';unit='JPY'if any(w in field for w in('cash','income','loan','debt','worth','deposit','tax','rent','fee','spending_total'))else'years'if field=='age_years'else'months'if field in('age_months','tenure_months','premium_deduction_lag_months')else'category/boolean/identifier/object; definition-specific'
            field_status='unimplemented'if field in('floor_area_m2','national_pension')else status
            rows.append({'variable_id':pid,'catalogue_namespace':'A25_added','label':field,'unit':unit,'observed_year':year,'requested_year':'2026','status':field_status,'source_id':source,'uncertainty':note,'A25_status':field_status,'A25_path':group+'.'+field,'A25_definition':note,'A25_method':'see '+group+' model documentation','A25_missing_policy':'NULL when support/eligibility/date/value not identified; no balancing residual','A25_next_action':'P0: newborn joint data and cash schedule'if group in('persons','income_sources','monthly_budget')else'P1: verify applicability and exact geographic/period scope'})
    assert len({x['variable_id']for x in rows})==len(rows)
    keys=list(dict.fromkeys(k for x in rows for k in x));matrix=[[x.get(k,'')for k in keys]for x in rows]
    (ROOT/'data/expanded_catalogue_A25.json').write_text(json.dumps({'model_version':'A2.5-0.1','inherited_rows':690,'added_rows':len(rows)-690,'columns':keys,'rows':rows},ensure_ascii=False,indent=2))
    for x,y in zip(inherited,rows):assert all(y[k]==v for k,v in x.items())
    (ROOT/'validation/catalogue_audit.json').write_text(json.dumps({'inherited_rows':690,'added_rows':len(rows)-690,'all_inherited_columns_preserved':True,'original_634_unacquired_or_individually_unverified':505,'warning':'new A25 rows do not resolve old505 without item-by-item source mapping'},ensure_ascii=False,indent=2));print(len(rows))
if __name__=='__main__':main()
