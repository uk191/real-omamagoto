"""Build A2.5 inputs from frozen original sources and identified official extracts."""
from pathlib import Path
import json,csv,re,unicodedata,collections,hashlib
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent;BASE=PROJECT/'13_family'
NAMES='北海道 青森県 岩手県 宮城県 秋田県 山形県 福島県 茨城県 栃木県 群馬県 埼玉県 千葉県 東京都 神奈川県 新潟県 富山県 石川県 福井県 山梨県 長野県 岐阜県 静岡県 愛知県 三重県 滋賀県 京都府 大阪府 兵庫県 奈良県 和歌山県 鳥取県 島根県 岡山県 広島県 山口県 徳島県 香川県 愛媛県 高知県 福岡県 佐賀県 長崎県 熊本県 大分県 宮崎県 鹿児島県 沖縄県'.split()
def text(name):
    d=json.loads((ROOT/'raw'/name).read_text())
    return unicodedata.normalize('NFKC','\n'.join(c['text']for c in d['result']['content']if c['type']=='text'))
def csvrows(name):
    lines=(BASE/'raw'/name).read_text(encoding='cp932').splitlines()
    return list(csv.DictReader(lines[1:]))
def main():
    ROOT.joinpath('validation').mkdir(exist_ok=True)
    s=text('web_extract_0.json');health={}
    for i,n in enumerate(NAMES,1):
        lines=[l for l in s.splitlines()if re.search(r':\s*'+n+r'\s*\|',l)]
        if lines:
            rates=re.findall(r'(\d+[.\s]?\d*)\s*%',lines[0]);health[f'{i:02d}']=float(rates[-1])/100
    assert len(health)==47,('Missing official regional rates',len(health))
    s=text('web_extract_health_grade_full.json');grades=[]
    for line in s.splitlines():
        m=re.match(r'L\d+@P0:\s*(\d+)(?:\(\d+\))?\s+([\d,]+)\s+(?:(\d[\d,]*)\s+)?~\s*(\d[\d,]*)?',line.replace('〜','~'))
        if not m:continue
        grades.append({'grade':int(m[1]),'standard':int(m[2].replace(',','')),'lower':int(m[3].replace(',',''))if m[3]else 0,'upper':int(m[4].replace(',',''))if m[4]else None,'source_line':line})
    assert len(grades)==50,('Grade source extraction incomplete',len(grades))
    leave={};s=text('web_extract_3.json')
    for line in s.splitlines():
        m=re.match(r'L(\d+)@P11:\s*(.+?)\s+100\.0\s+(\d+\.\d+)\s+100\.0\s+(\d+\.\d+)',line)
        if m and 386<=int(m[1])<=408:
            leave[m[2]]={'female':float(m[3])/100,'male':float(m[4])/100,'source_line':line,'kind':'2023-10 to 2024-09 births, surveyed 2025-10; prospective timing unobserved'}
    assert '製造業'in leave and '医療、福祉'in leave
    maternal=[]
    for row in csvrows('ipss17_9-5.csv'):
        if row['第1子出生年']=='2020～24年':maternal.append({'pre_status':row['妊娠時の就業状況・従業上の地位'],'one_year_status':row['第1子1歳時の従業上の地位および育児休業制度の利用の有無'],'weight':int(row['度数']),'raw_row':row})
    byrank=[]
    for row in csvrows('ipss17_9-3.csv'):
        if row['出生年']=='2020～24年':byrank.append({'birth_rank':int(re.search(r'\d+',row['子ども'])[0]),'status':row['出産前後の妻の就業パターン'],'weight':int(row['度数']),'raw_row':row})
    support=[row for row in csvrows('ipss17_9-11.csv')if row['第1子出生年']=='2020～22年']
    refs=json.loads((BASE/'data/finance_7-101-1_reference_cells.json').read_text());quant={};qmap={'第1・十分位数':'.1','第1・四分位数':'.25','中位数':'.5','第3・四分位数':'.75','第9・十分位数':'.9'}
    for row in refs:
        d=row['dimensions'];n=d.get('世帯人員');m=d['住宅ローン残高の有無'].split('_')[0];asset=d['資産・負債の種類'].split('_')[0]
        if not n or m not in('0','1','2')or row['measure']not in qmap or row['value']is None:continue
        key='|'.join([m,n.split('_')[0],asset]);q=quant.setdefault(key,{'points':{},'sources':[],'population':'holders/valid respondents as defined by finance_notes; NOT an unconditional newborn marginal'})
        q['points'][qmap[row['measure']]]=int(row['value']*1000);q['sources'].append(row['source'])
    budget=[]
    for row in csv.DictReader((BASE/'data/young_child_budget_reference.csv').open(encoding='utf-8-sig')):
        co=row['budget_item'].split('_')[0]
        if row['measure']=='1世帯当たり1か月間の収入と支出'and(co=='2101'or(len(co)==6 and co.startswith('2101')))and row['value']:
            budget.append({'code':co,'label':row['budget_item'].split('_',1)[1],'reference_mean':float(row['value']),'source':json.loads(row['source_cell']),'reference_months':'2024-10/11, not full year','population':'couple plus one unmarried child <=2'})
    assert len(budget)==11,len(budget)
    # Extract a coherent same-table gross/income-components/disposable reference.
    # Means constrain conditional references, not observed individual residuals.
    import sys,openpyxl
    sys.path.insert(0,str(BASE));from tables import interval
    w=openpyxl.load_workbook(BASE/'raw/finance_3-32-1.xlsx',read_only=True,data_only=True);sh=w.worksheets[0]
    income_profiles={};anchor=None
    for rn,row in enumerate(sh.values,1):
        if rn<8 or len(row)<20 or row[1]!='00000_全国':continue
        family_col=19;label=unicodedata.normalize('NFKC',str(row[3]));ic=label.split('_')[0]
        if not ic.isdigit()or int(ic)>43:continue
        component=unicodedata.normalize('NFKC',str(row[6])).split('_')[0];value=row[family_col]
        if not isinstance(value,(int,float)):continue
        group=income_profiles.setdefault(ic,{'income_label':label,'interval':interval(label,10000),'components':{},'weight':None,'source_cells':[]})
        group['source_cells'].append({'table_id':'finance_3-32-1','sheet':sh.title,'row':rn,'column':family_col+1,'raw_value':str(value)})
        if row[4]=='世帯数分布':group['weight']=value
        if row[4]=='1世帯当たり年間収入額':group['components'][component]=int(value*1000)
        if ic=='00'and component=='2'and row[4]=='1世帯当たり年間収入額':anchor=int(value*1000)
    w.close()
    assert anchor is not None
    kernel={'version':'A2.5-0.1','health_rates':health,'standard_health_bands':[g['standard']for g in grades],'standard_health_thresholds':[g['lower']for g in grades[1:]],'grade_sources':grades,'leave_industry':leave,'maternal_pre_post_joint':maternal,'maternal_rank_patterns':byrank,'grandparent_help':support,'asset_holder_quantiles':quant,'baby_budget':budget,'CPI_2026_08':{'base_year':2025,'index':102.2,'transport_from_2024':None,'kind':'new base must be connected to 2024; do not multiply 2024 amounts by 1.022'},'calibration_warning':'Sources do not identify a complete newborn roster, monthly consumption joint or holder-presence probabilities'}
    kernel['baby_income_2024_profiles']=income_profiles;kernel['budget_income_anchor']=anchor
    from transport import budget_2024_oct_nov_to_2026_aug
    kernel['CPI_2026_08']['transport_from_2024']=budget_2024_oct_nov_to_2026_aug(298680)
    (ROOT/'data/state_kernels.json').write_text(json.dumps(kernel,ensure_ascii=False,indent=2))
    source_ledger=[]
    for f in sorted((ROOT/'raw').glob('*.json')):
        doc=json.loads(f.read_text());s='\n'.join(c['text']for c in doc['result']['content']if c['type']=='text')
        urls=sorted(set(re.findall(r'https://[^\s)"}]+',s)))
        source_ledger.append({'file':str(f.relative_to(ROOT)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'retrieval':'official_search_service_extraction','original_binary':False,'urls':urls,'retrieved_at':doc.get('retrieved_at','2026-10-14')})
    attempts=ROOT/'data/acquisition_attempts.json'
    if attempts.exists():
        for a in json.loads(attempts.read_text()):
            if a.get('status')in('acquired_original','bundled_original'):
                f=ROOT/'raw'/a['filename'];assert hashlib.sha256(f.read_bytes()).hexdigest()==a['sha256']
                source_ledger.append({'file':str(f.relative_to(ROOT)),'sha256':a['sha256'],'bytes':f.stat().st_size,'retrieval':'direct_official_binary','original_binary':True,'urls':[a['url']],'retrieved_at':a['attempt_date'],'semantic_review':'selected calculation pages reviewed; ancillary microdata guides not model observations'})
    (ROOT/'data/sources.json').write_text(json.dumps(source_ledger,ensure_ascii=False,indent=2))
    print(json.dumps({'health_prefectures':len(health),'insurance_grades':len(grades),'leave_conditional_rows':len(leave),'maternal_joint_cells':len(maternal),'asset_conditional_quantile_groups':len(quant),'budget_major_categories':len(budget)-1,'web_capture_files':len(source_ledger)}),flush=True)
if __name__=='__main__':main()
