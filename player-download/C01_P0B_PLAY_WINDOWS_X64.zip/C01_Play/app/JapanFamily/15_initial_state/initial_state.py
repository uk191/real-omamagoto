"""A2.5 initial-state API composed over the unchanged A2-0.4 FamilyModel.

Default unresolved values remain unresolved. Complete user-declared profiles can
be tested for a funded initial month, without claiming population calibration.
"""
from pathlib import Path
import sys,json,copy,calendar
from datetime import date,timedelta
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent
sys.path.append(str(PROJECT/'13_family'))
from family import FamilyModel,ConditionSupportError
from estimators import rng,draw_weighted,asset_scenario,spending_scenario,VERSION
from policy import _policy,employee_social,standard_remuneration,monthly_withholding,annual_income_tax,maternity_allowance,childcare_leave_benefit,child_allowance
from roster import materialize,age_at
from accounting import settle_one_period,net_worth
class InitialConditionError(ValueError):
    def __init__(self,message,kind='input_contradiction'):super().__init__(message);self.kind=kind
ACCOUNT_FIELDS=[('cash','cash_deposits','asset',True),('financial_other','other_financial_assets','asset',False),('home','current_home_value','asset',False),('property_other','other_property_value','asset',False),('mortgage','housing_debt','liability',False),('other_debt','other_debt','liability',False)]
class InitialStateModel:
    def __init__(self,base_model=None):self.base=base_model or FamilyModel();self.k=_policy()
    def employment(self,base,seed,birth_date,profile):
        out={};rank=base['child']['birth_rank'];pre_map={'regular':'妊娠時正規の職員','nonregular':'妊娠時パート・派遣','self_employed':'妊娠時自営業主・家族従業者・内職'}
        for who in ['mother','father']:
            p=base[who];fixed=profile.get('employment',{}).get(who,{})
            if p is None:out[who]={'reference':None,'at_birth_status':'unidentified','normal_hours':None,'actual_hours_at_birth':None,'future_path':None};continue
            work=p.get('work_context',{});kind=work.get('employment_type');employed=p['employed'];future=None
            if who=='mother':
                # This is a proxy for pre-pregnancy employment, never a causal effect.
                pre=pre_map.get(kind,'妊娠時無職・学生'if employed is False else None)
                rows=[x for x in self.k['maternal_pre_post_joint']if x['pre_status']==pre]if rank==1 else[]
                if not rows:rows=[x for x in self.k['maternal_rank_patterns']if x['birth_rank']==rank]if rank in(1,2,3)else[]
                x=draw_weighted(rows,rng(seed,'mother-future-work'))
                future=None if x is None else {'observed_one_year_outcome':x.get('one_year_status',x.get('status')),'source_row':x['raw_row'],'kind':'estimate_2020_24_first_married_couple_cohort_transport; legacy usual work used as pre-birth proxy; exit timing unidentified'}
                status='postpartum_leave'if employed and kind in('regular','nonregular','employee_other')else('nonemployed'if employed is False else'unidentified_self_employed_postpartum_work')
                hours=0 if status=='postpartum_leave'else None
            else:
                label=work.get('industry')or'';rows=self.k['leave_industry'];row=next((v for n,v in rows.items()if n.replace(' ','')==label.replace(' ','')),rows.get('総 数'))
                size=fixed.get('workplace_size')
                if isinstance(size,int):
                    key='500人以上'if size>=500 else('100~499人'if size>=100 else('30~99人'if size>=30 else'5~29人'))
                    row=rows.get(key,row)
                in_scope='公務'not in label and not(isinstance(size,int)and size<5)
                probability=row['male']if in_scope and row and employed and kind not in('self_employed','other_or_unknown')else None
                future={'ever_leave_requested':None if probability is None else rng(seed,'father-ever-leave').random()<probability,'probability':probability,'birth_day_leave':None,'source':row,'kind':'eventual uptake among employees with spouse birth, not day-zero uptake'}
                status='usual_work_reference_only'if employed else'nonemployed';hours=None
            if fixed:
                status=fixed.get('at_birth_status',status);hours=fixed.get('actual_hours_at_birth',hours)
                if who=='mother'and fixed.get('actual_employee_worker')is True and hours not in(0,None):raise InitialConditionError('An employee worker cannot work on the birth day within the compulsory postpartum period')
                if who=='mother'and status=='postpartum_leave'and hours not in(0,None):raise InitialConditionError('Postpartum employee cannot have normal actual birth-day hours')
                if status=='nonemployed'and fixed.get('salary_cash',0)>0:raise InitialConditionError('Nonemployed cash salary requires a separately labelled lagged wage payment')
            out[who]={'reference':work,'usual_employed_reference':employed,'usual_main_job_annual_income_reference':p['main_job_income'],'at_birth_status':status,'normal_hours':work.get('reference_hours'),'actual_hours_at_birth':hours,'future_path':future,'birth_user_parameters':fixed,'workplace_size':fixed.get('workplace_size'),'tenure_months':fixed.get('tenure_months'),'position':fixed.get('position'),'contract_hours':fixed.get('contract_hours'),'commute_minutes':fixed.get('commute_minutes'),'return_date':fixed.get('return_date'),'reduced_hours_schedule':fixed.get('reduced_hours_schedule')}
        return out
    def generate(self,prefecture_code,conditions=None,seed=0,birth_date='2026-10-01',initialization=None,include_region=True,reference=None):
        birth=date.fromisoformat(birth_date)
        if birth.year!=2026:raise InitialConditionError('Birth date must be in target year 2026')
        if not isinstance(seed,(str,int))or isinstance(seed,bool):raise InitialConditionError('Seed must be a string or integer')
        profile=copy.deepcopy(initialization or{})
        allowed={'members','person_updates','multiplicity','index_within_delivery','roster_scenario','employment','accounts','loans','asset_scenario','asset_tail','asset_rho','deposit_liquidity_fraction','spending_scenario','spending_total_nonhousing','spending_parameters','expense_items','extra_income_sources','income_sources_complete','cash_coverage_complete','benefit_eligibility','benefit_cash_receipts','resident_tax_cash','national_health_cash','other_taxes_cash','housing_costs','financial_profile_user_confirmed'}
        if set(profile)-allowed:raise InitialConditionError('Unknown initialization fields '+str(sorted(set(profile)-allowed)))
        if profile.get('roster_scenario','unresolved')not in('unresolved','backcast_under18_co_residence'):raise InitialConditionError('Unknown roster scenario')
        for field in ['national_health_cash','other_taxes_cash','spending_total_nonhousing']:
            if profile.get(field)is not None and profile[field]<0:raise InitialConditionError('Negative '+field)
        for collection in ['resident_tax_cash','benefit_cash_receipts','housing_costs']:
            if any(v is not None and v<0 for v in profile.get(collection,{}).values()):raise InitialConditionError('Negative amount in '+collection)
        try:b=copy.deepcopy(reference)if reference else self.base.generate(prefecture_code,conditions,seed,include_region=include_region)
        except ConditionSupportError as e:raise InitialConditionError(str(e),'sampling_limit'if 'No accepted draw'in str(e)else'unidentified_statistical_support')from e
        if b['prefecture_code']!=str(prefecture_code).zfill(2):raise InitialConditionError('Reference prefecture differs from requested prefecture')
        identity=json.dumps({'conditions':conditions or{},'initialization':profile},sort_keys=True,ensure_ascii=False,separators=(',',':'))
        roster=materialize(b,seed,birth_date,profile.get('multiplicity',1),profile.get('index_within_delivery',1),profile.get('members'),profile.get('roster_scenario','unresolved'),self.base,identity)
        for pid,updates in profile.get('person_updates',{}).items():
            p=next((x for x in roster['persons']if x['person_id']==pid),None)
            if p is None:raise InitialConditionError('Unknown person update '+pid)
            if set(updates)-{'co_resident','date_of_birth','supported','legal_custody','dependent_for_tax','nationality','health','care_support','alive'}:raise InitialConditionError('Unsupported person attribute override')
            if 'date_of_birth'in updates and p['age_years']is not None and age_at(updates['date_of_birth'],birth_date)!=p['age_years']:raise InitialConditionError('Fixed age and birthday differ')
            p.update(updates);p['age_years']=age_at(p['date_of_birth'],birth_date)
            if p['co_resident']and p['alive']is False:raise InitialConditionError('A deceased person cannot be a current resident')
        residents=[p for p in roster['persons']if p['co_resident']is True];roster['resident_count']=len(residents)
        employment=self.employment(b,seed,birth_date,profile)
        cash_entries=[];income_sources=[];taxes={};benefits={};unknown=[]
        def entry(eid,amount,category,person=None):cash_entries.append({'entry_id':eid,'amount':amount,'category':category,'person_id':person,'kind':'user_declared_cash'if amount is not None else'unidentified_cash'})
        verified_date=birth>=date(2026,8,1)
        for who in ['mother','father']:
            p=b[who];emp=profile.get('employment',{}).get(who,{})
            usual=p['main_job_income']['value']if p else None
            income_sources.append({'source_id':who+'/main_job_reference','person_id':who,'type':'usual_main_job_salary_or_business','annual_reference':usual,'reference_year':2022,'observed_or_point':p['main_job_income']['kind']if p else'unknown','current_month_gross_cash':emp.get('salary_cash'),'standard_monthly_remuneration':emp.get('standard_monthly'),'past12_actual_income':emp.get('past12_actual_income'),'kind':'reference_and_actual_cash_are_different_fields'})
            # Payroll applies only when the insurer/status is explicitly supplied.
            salary=emp.get('salary_cash');insured=emp.get('kyokai_insured')
            if p and p['employed']is False and not emp:salary=0
            social=None
            if insured is True and salary is not None and verified_date and p and p['age']is not None:
                standard=emp.get('standard_monthly')
                if standard is not None:social=employee_social(emp.get('work_prefecture',b['prefecture_code']),standard,p['age'],salary,birth_date,emp.get('premium_exemption_approved',False),emp.get('agriculture_construction_rate',False))
            elif insured is False:social={'total':0,'kind':'employee_insurance_not_enrolled; NHI/pension still separate'}
            social_cash=emp.get('social_cash_deduction')
            if social_cash is None and emp.get('premium_deduction_lag_months')==0 and social is not None:social_cash=social['total']
            if insured is False:social_cash=0
            withholding=None if salary is None or social_cash is None else monthly_withholding(max(0,salary-social_cash),emp.get('source_dependent_count',0),emp.get('source_spouse',False))
            if salary==0:withholding=0
            taxes[who]={'employee_social_accrual':social,'employee_social_cash_deduction':social_cash,'premium_deduction_lag_months':emp.get('premium_deduction_lag_months'),'insurance_branch_basis':'user_supplied'if emp.get('work_prefecture')else'residence_proxy_if_not_supplied','monthly_withholding':withholding,'resident_tax_cash':profile.get('resident_tax_cash',{}).get(who),'actual_annual_income_tax':None,'projected_usual_salary_annual_tax':None}
            annual=emp.get('annual_salary_2026_projection')
            if annual is not None and emp.get('annual_social_paid_projection')is not None:
                taxes[who]['projected_usual_salary_annual_tax']=annual_income_tax(annual,emp.get('annual_social_paid_projection',0),other_taxable_income=emp.get('other_taxable_income',0),spouse_income=emp.get('spouse_taxable_income'),legally_married=emp.get('legally_married',False),dependent_deduction=emp.get('dependent_deduction',0),other_deductions=emp.get('other_deductions',0),tax_credit=emp.get('tax_credit',0),adjustment_eligible=emp.get('salary_adjustment_eligible',False))
            entry(who+'/salary',salary,'salary',who);entry(who+'/social',None if social_cash is None else-social_cash,'social_insurance',who);entry(who+'/withholding',None if withholding is None else-withholding,'income_tax_withheld',who)
            rt=taxes[who]['resident_tax_cash'];entry(who+'/resident_tax',None if rt is None else-rt,'resident_tax_prior_year_bill',who)
            if who=='mother':
                complete=all(emp.get(k)is not None for k in('average_12month_standard','maternity_days','maternity_salary_paid'))
                eligibility=emp.get('maternity_eligible')if complete or emp.get('maternity_eligible')is not True else None
                benefits['maternity']=maternity_allowance(emp.get('average_12month_standard')or 0,emp.get('maternity_days')or 0,emp.get('maternity_salary_paid')or 0,eligibility,emp.get('insured_continuous_months',12))
                benefits['maternity']['calculation_inputs_complete']=complete
            else:
                complete=all(emp.get(k)is not None for k in('leave_daily_wage','leave_days','leave_salary_paid'))
                eligibility=emp.get('leave_benefit_eligible')if complete or emp.get('leave_benefit_eligible')is not True else None
                benefits['paternal_leave']=childcare_leave_benefit(emp.get('leave_daily_wage')or 0,emp.get('leave_days')or 0,emp.get('leave_salary_paid')or 0,eligibility,support_eligible=emp.get('support_benefit_eligible'),asof=birth_date)if verified_date else{'base':None,'support':None,'kind':'pre-August cap not loaded'}
                benefits['paternal_leave']['calculation_inputs_complete']=complete
        elig=profile.get('benefit_eligibility',{});children=[p for p in roster['persons']if p['role']in('newborn','maternal_prior_child','child','stepchild','adopted_child')and p['date_of_birth']]
        child_roster_complete=all(h['person_id']is not None for h in roster['historical_previous_live_births'])and all(p.get('date_of_birth')is not None and p.get('supported')is not None for p in roster['persons']if p['role']in('newborn','maternal_prior_child','child','stepchild','adopted_child'))
        benefits['child_allowance']=child_allowance(children,birth_date,elig.get('child_allowance')if child_roster_complete else None)
        benefits['child_allowance']['supported_child_roster_complete']=child_roster_complete
        benefits['birth_lump_sum']={'entitlement':500000 if elig.get('health_insured_birth')is True and elig.get('obstetric_compensation_scheme')is True else(488000 if elig.get('health_insured_birth')is True and elig.get('obstetric_compensation_scheme')is False else None),'actual_cash_receipt':None,'direct_hospital_payment':'unknown; never add the lump sum to spendable cash automatically'}
        for name in ['maternity','paternal_leave','child_allowance','birth_lump_sum']:
            paid=profile.get('benefit_cash_receipts',{}).get(name)
            benefits[name]['actual_cash_receipt']=paid;entry('benefit/'+name,paid,'benefit_received')
        for x in profile.get('extra_income_sources',[]):
            if x.get('person_id')not in {p['person_id']for p in roster['persons']}and x.get('person_id')is not None:raise InitialConditionError('Income source person does not exist')
            if x.get('type')not in('business_net_cash','maintenance_received','family_assistance','pension_cash','investment_cash','other_declared_income'):raise InitialConditionError('Income source must have an explicit type')
            income_sources.append(x);entry(x['source_id'],x.get('cash_amount'),x['type'],x.get('person_id'))
        for key,category in [('national_health_cash','national_health_pension_bill'),('other_taxes_cash','other_declared_tax')]:entry(key,None if profile.get(key)is None else-profile[key],category)
        parent_known=[p['main_job_income']['value']for p in [b['mother'],b['father']]if p is not None];reference_sum=sum(parent_known)if all(x is not None for x in parent_known)else None
        gap=None if b['household_income']['value']is None or reference_sum is None else b['household_income']['value']-reference_sum
        assets=asset_scenario(b,seed,profile.get('asset_scenario','unresolved'),profile.get('asset_tail','unresolved'),profile.get('asset_rho',0))
        if 'accounts'in profile:accounts=profile['accounts'];account_kind='user_supplied_complete_or_partial_positions'
        else:
            estimates=assets.get('accounts')or{}
            accounts=[{'account_id':pid,'name':name,'side':side,'liquid_cash':liquid,'balance':estimates.get(name,0 if assets.get('scenario_complete')and name in('other_property_value','other_debt')else None)}for pid,name,side,liquid in ACCOUNT_FIELDS];account_kind='unidentified_positions'if not estimates else'conditional_holder_scenario_not_observed_components'
            deposits=estimates.get('cash_deposits');fraction=profile.get('deposit_liquidity_fraction')
            if fraction is not None and not 0<=fraction<=1:raise InitialConditionError('Deposit liquidity fraction outside [0,1]')
            if deposits is not None:
                accounts[0]['balance']=None if fraction is None else round(deposits*fraction)
                accounts.append({'account_id':'deposits_nonliquid','name':'deposits_nonliquid','side':'asset','liquid_cash':False,'balance':None if fraction is None else deposits-accounts[0]['balance'],'kind':'unidentified_liquidity_split'if fraction is None else'user_game_liquidity_share_not_observed'})
        costs=profile.get('housing_costs',{});rent=costs.get('rent');housing=copy.deepcopy(b['housing']);housing.update(actual_roster_occupancy=len(residents),monthly_rent_current_cash=rent,management_fee_cash=costs.get('management_fee'),property_tax_cash=costs.get('property_tax'),repair_reserve_cash=costs.get('repair_reserve'),price_reference_year=2023)
        if housing['tenure']=='owner'and rent not in(0,None):raise InitialConditionError('Owner has nonzero rent for current dwelling; other property expenses need a separate source')
        for key in ['rent','management_fee','property_tax','repair_reserve']:
            val=rent if key=='rent'else costs.get(key);entry('housing/'+key,None if val is None else-val,'housing_'+key)
        spending=spending_scenario(b['household_income']['value'],len(residents),seed,profile.get('spending_scenario','unresolved'),profile.get('spending_total_nonhousing'),reference_annual_gross=self.k['budget_income_anchor'],**profile.get('spending_parameters',{}))
        expenses=profile.get('expense_items',spending['items'])
        if expenses is None:entry('nonhousing_spending',None,'consumption')
        else:
            for i,x in enumerate(expenses):entry('expense/'+str(x.get('code',i)),-int(x['amount']),'consumption')
        if not profile.get('income_sources_complete'):unknown.append('current_income_sources_not_declared_complete; reference household income gap is not an income source')
        if not profile.get('cash_coverage_complete'):unknown.append('calendar_cash_bills_and_receipts_not_declared_complete')
        if any(x['amount']is None for x in cash_entries):unknown.append('one_or_more_monthly_cash_flows_unidentified')
        if any(x.get('balance')is None for x in accounts):unknown.append('one_or_more_asset_liability_positions_unidentified')
        covered_loans={x['account_id']for x in profile.get('loans',[])}
        if any(x['side']=='liability'and(x.get('balance')or 0)>0 and x['account_id']not in covered_loans for x in accounts):unknown.append('positive_debt_has_no_declared_repayment_or_deferral_contract')
        roster_ready=all(p['date_of_birth']is not None and p['role']!='unclassified_co_resident'for p in residents)and all(p['co_resident']is not None for p in roster['persons'])and all(h['person_id']is not None for h in roster['historical_previous_live_births'])
        if not roster_ready:unknown.append('roster_or_previous_birth_history_unresolved')
        preview=None
        if all(x['amount']is not None for x in cash_entries)and all(x.get('balance')is not None for x in accounts):
            try:preview=settle_one_period(accounts,cash_entries,profile.get('loans',[]))
            except ValueError as e:raise InitialConditionError(str(e))from e
            if not preview['financially_funded']:unknown.append('cash_shortfall_requires_explicit_funding_or_budget_change')
        if not profile.get('financial_profile_user_confirmed'):unknown.append('unvalidated_statistical_connection_cannot_certify_game_start')
        ready=not unknown and preview is not None
        out={'model_version':VERSION,'baseline_model_version':'A2-0.4','seed':seed,'birth_date':birth_date,'household':{'household_id':roster['household_id'],'delivery_event_id':roster['delivery_event_id'],'prefecture_code':b['prefecture_code'],'municipality_code':b['municipality_code'],'resident_person_count':len(residents),'multiplicity':roster['multiplicity'],'index_within_delivery':roster['index_within_delivery'],'sampling_unit':roster['birth_unit'],'reference_usual_household_income':b['household_income'],'known_parent_main_job_income_sum_reference':reference_sum,'unexplained_reference_income_gap':gap,'unexplained_gap_action':'retained as diagnostic; never added as other income or financing'},'persons':roster['persons'],'relationships':roster['relationships'],'birth_history':roster['historical_previous_live_births'],'region_context':b.get('region_context',b.get('region')),'employment':employment,'income_sources':income_sources,'taxes_and_benefits':{'taxes':taxes,'benefits':benefits,'yearly_tax_cash_distinction':True,'municipal_coverage':'declared bill or unresolved; no countrywide NHI/resident-tax proxy advertised as exact'},'housing':housing,'assets_and_liabilities':{'accounts':accounts,'net_worth':net_worth(accounts),'kind':account_kind,'conditional_estimate':assets,'legacy_2024_reference':b['finances']},'monthly_budget':{'calendar_month':birth_date[:7],'cash_entries':cash_entries,'expense_scenario':spending,'settlement_preview':preview,'cash_disposable_before_consumption':None if any(e['amount']is None for e in cash_entries if not e['category'].startswith('housing')and e['category']!='consumption')else sum(e['amount']for e in cash_entries if not e['category'].startswith('housing')and e['category']!='consumption'),'annual_disposable_reference_not_cash':b['finances']['disposable_income_OECD']},'future_transition_inputs':{'next_month_state_not_simulated':True,'postpartum_end':(birth+timedelta(days=56)).isoformat(),'leave_plans':{k:v.get('future_path')for k,v in employment.items()},'ledger_update_function':'accounting.settle_one_period','unknowns_to_resolve_before_A3':unknown,'unique_delivery_conversion_weight':roster['unique_delivery_conversion_weight'],'unique_delivery_weight_warning':roster['unique_delivery_conversion_warning']},'provenance':{'legacy_source_trace':b['source_trace'],'legacy_assumptions':b['assumptions'],'policy_snapshot':'2026-10-14 official extracts; original binary restrictions recorded','price_wage_transport':'2022 usual income/2023 rent/2024 financial reference not relabelled as 2026; no unverified multiplier','initialization':profile},'quality_flags':{'financially_playable':ready,'financially_playable_scope':'only fully specified funded user-declared initial month; NOT population calibration','roster_resolved':roster_ready,'newborn_full_joint_externally_validated':False,'unresolved':unknown,'original_bin_points_are_assumptions':True}}
        out['household']['index_birth_rank_interval']=b['child']['birth_rank_interval']
        rank=b['child']['birth_rank']
        out['household']['maternal_previous_live_birth_count_interval']=[rank-roster['index_within_delivery']]*2 if rank is not None else [b['child']['birth_rank_interval'][0]-roster['index_within_delivery'],None]
        out['household']['legal_birth_status']=b['legal_birth_status']
        out['household']['birth_population']=b['birth_population']
        out['household']['index_person_id']='index_child'
        # A funded fixture month does not certify the next-month game handoff.
        out['quality_flags']['initial_month_cash_ready']=ready
        out['quality_flags']['financially_playable']=False
        out['quality_flags']['financially_playable_scope']='A3 handoff with complete next-month income/leave/benefit schedules is not verified; original false flag retained'
        out['quality_flags']['game_start_blockers']=['automatic_roster_and_birth_history_joint_not_calibrated','next_month_leave_and_receipt_dates_not_fully_identified','annual_fiscal_and_municipal_coverage_incomplete']
        return out
    def generate_batch(self,prefecture_code,n,seed=0,**kwargs):
        if not isinstance(n,int)or not 1<=n<=1000000:raise InitialConditionError('Invalid batch size')
        return [self.generate(prefecture_code,seed=f'{seed}/{i}',**kwargs)for i in range(n)]
if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--pref',default='13');a.add_argument('--seed',default='demo');a.add_argument('--birth-date',default='2026-10-01');a.add_argument('--conditions',default='{}');a.add_argument('--initialization');a.add_argument('--no-region',action='store_true');v=a.parse_args()
    print(json.dumps(InitialStateModel().generate(v.pref,json.loads(v.conditions),v.seed,v.birth_date,json.loads(Path(v.initialization).read_text())if v.initialization else None,not v.no_region),ensure_ascii=False,indent=2))
