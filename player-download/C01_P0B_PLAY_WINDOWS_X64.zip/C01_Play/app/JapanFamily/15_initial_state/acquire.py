"""Repeat official binary acquisition without disguising restricted downloads.

Frozen web extracts have distinct hashes/identity and are never substituted for
the requested PDF bytes. --refresh attempts originals; ordinary execution
verifies bundled retrieval artifacts without network.
"""
import argparse,json,hashlib,urllib.request,urllib.error
from datetime import date
from pathlib import Path
ROOT=Path(__file__).resolve().parent
JOBS=[{'id':'NTA_monthly_2026','url':'https://www.nta.go.jp/publication/pamph/gensen/zeigakuhyo2026/data/18.pdf','filename':'NTA_monthly_2026.pdf'}, {'id':'Kashiwa_NHI_formula_2026','url':'https://www.city.kashiwa.lg.jp/documents/1091/4.pdf','filename':'Kashiwa_NHI_formula_2026.pdf'}, {'id':'CPI_2025_annual','url':'https://www.stat.go.jp/data/cpi/sokuhou/nen/pdf/zen-n.pdf','filename':'CPI_2025_annual.pdf'}]
def main(refresh=False):
    ledger=[]
    import re
    urls=set()
    for capture in(ROOT/'raw').glob('web_extract*.json'):
        doc=json.loads(capture.read_text());s='\n'.join(c['text']for c in doc['result']['content']if c['type']=='text')
        urls.update(u for u in re.findall(r'https://[^\s)"}]+',s)if u.endswith('.pdf'))
    jobs=JOBS+[{'id':'official_pdf_'+hashlib.sha256(u.encode()).hexdigest()[:12],'url':u,'filename':'official_pdf_'+hashlib.sha256(u.encode()).hexdigest()[:12]+'.pdf'}for u in sorted(urls-{x['url']for x in JOBS})]
    for job in jobs:
        path=ROOT/'raw'/job['filename'];r={**job,'attempt_date':date.today().isoformat(),'original_binary':True}
        if refresh:
            try:
                with urllib.request.urlopen(urllib.request.Request(job['url'],headers={'User-Agent':'JapanFamily reproducible research'}),timeout=15)as response:b=response.read()
                if not b.startswith(b'%PDF'):raise ValueError('Response is not PDF original')
                path.write_bytes(b);r.update(status='acquired_original',sha256=hashlib.sha256(b).hexdigest(),bytes=len(b))
            except Exception as e:r.update(status='not_acquired',error=type(e).__name__,detail=str(e),alternative='official search-service textual extract stored separately; no original-binary hash claimed')
        elif path.exists():r.update(status='bundled_original',sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size)
        else:r.update(status='not_acquired',detail='Run --refresh to attempt exact official URL; live URL content can change and must be revalidated')
        ledger.append(r);print(json.dumps(r,ensure_ascii=False),flush=True)
    (ROOT/'data/acquisition_attempts.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
    captures=json.loads((ROOT/'data/sources.json').read_text())
    assert all(hashlib.sha256((ROOT/x['file']).read_bytes()).hexdigest()==x['sha256']for x in captures)
    return ledger
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--refresh',action='store_true');main(p.parse_args().refresh)
