"""Package verified integrated project, preserving both inherited manifests."""
from pathlib import Path
import hashlib,json,zipfile,shutil,sqlite3
ROOT=Path(__file__).resolve().parent;P=ROOT.parent
def sha(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()
def main(out,baseline):
    out=Path(out);out.mkdir(exist_ok=True,parents=True)
    db=P/'data/region.sqlite';expected=json.loads((ROOT/'validation/DB_inheritance_audit.json').read_text());assert sha(db)==expected['updated_db_sha256']
    c=sqlite3.connect(f'file:{db}?mode=ro',uri=True);assert c.execute('PRAGMA integrity_check').fetchall()==[('ok',)];assert not c.execute('PRAGMA foreign_key_check').fetchall();c.close()
    changed=[];missing=[];bad=[]
    with zipfile.ZipFile(baseline)as z:
        for n in z.namelist():
            if n.endswith('/')or not n.startswith('JapanFamily/'):continue
            rel=Path(n).relative_to('JapanFamily');f=P/rel
            if not f.exists():missing.append(str(rel));continue
            old=hashlib.sha256(z.read(n)).hexdigest();new=sha(f)
            if old!=new:
                changed.append({'path':str(rel),'baseline_sha256':old,'updated_sha256':new,'reason':'integrated_DB_extension'if str(rel)=='data/region.sqlite'else'reexecuted_validation_output'})
                if f.suffix=='.py'or'/raw/'in '/'+str(rel)or str(rel)in('04_variables.csv','04_native_variables.csv','03_sources.csv'):bad.append(str(rel))
    assert not missing and not bad,(missing,bad)
    (ROOT/'validation/baseline_change_audit.json').write_text(json.dumps({'missing_inherited_files':missing,'modified_inherited_code_or_raw_or_original_catalogues':bad,'changed_files':changed,'baseline_archive_sha256':sha(Path(baseline))},ensure_ascii=False,indent=2))
    shutil.copy2(out/'A25_拡張変数台帳.xlsx',ROOT/'data/expanded_catalogue_A25.xlsx')
    shutil.copy2(out/'catalogue_render_audit.json',ROOT/'validation/catalogue_render_audit.json')
    manifest=P/'MANIFEST_A25_SHA256.json';files=[]
    for f in sorted(P.rglob('*')):
        if not f.is_file()or f==manifest or'__pycache__'in f.parts or f.name.startswith('.')or f.name=='package.log'or f.name.endswith(('.pyc','-journal','-wal','-shm','.building.sqlite')):continue
        files.append({'path':str(f.relative_to(P)),'bytes':f.stat().st_size,'sha256':sha(f)})
    manifest.write_text(json.dumps({'model_version':'A2.5-0.1','files':files,'source':str(P.name),'DB_sha256':expected['updated_db_sha256'],'baseline_model':'A2-0.4','financially_playable':False},ensure_ascii=False,indent=2))
    path=out/'A1_A25_日本出生家庭初期状態基盤_A2.5-0.1.zip'
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True)as z:
        for x in files:z.write(P/x['path'],'JapanFamily/'+x['path'])
        z.write(manifest,'JapanFamily/'+manifest.name)
    with zipfile.ZipFile(path)as z:assert z.testzip()is None
    result={'zip_path':str(path),'zip_bytes':path.stat().st_size,'zip_sha256':sha(path),'manifest_members':len(files),'CRC_all_members_pass':True,'DB_integrity':'ok','financially_playable':False}
    (out/'A25_配布物検証.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':
    import sys;main(sys.argv[1],sys.argv[2])
