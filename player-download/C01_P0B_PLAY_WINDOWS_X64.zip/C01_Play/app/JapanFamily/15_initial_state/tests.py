"""Independent official numerical examples, invariants and boundary tests."""
import json,copy
from pathlib import Path
from policy import *
from accounting import *
from estimators import interpolate_quantile
ROOT=Path(__file__).resolve().parent
def main():
    tests=[]
    def check(name,ok,detail):tests.append({'test':name,'pass':bool(ok),'detail':detail});print(name,bool(ok),flush=True)
    tax=annual_income_tax(5000000,social_paid=600000,spouse_income=0,legally_married=True,dependent_deduction=760000,other_deductions=100000)
    check('NTA_national_example_2026_34700',tax['income_and_reconstruction_tax']==34700,tax)
    check('2026_salary_low_threshold',salary_income(740999)==0 and salary_income(741000)==1000 and salary_income(1780000)==1040000,{'source':'NTA salary table 2026'})
    check('2026_salary_microsteps',salary_income(2191999)==1451000 and salary_income(2193999)==1453000 and salary_income(2196999)==1456000,'NTA statutory integer bands, not continuous annual deduction formula')
    check('2026_basic_1040k_through_4890k',basic_deduction(4890000)==1040000 and basic_deduction(4890001)==670000 and basic_deduction(6550001)==620000,'2026 reform screenshot columns visually confirmed')
    check('high_salary_child_adjustment',salary_income(10000000,adjustment_eligible=True)==7900000,'850万円超、23歳未満扶養等の条件を明示した場合だけ')
    check('legal_spouse_only',spouse_deduction(3000000,0,False)==0 and spouse_deduction(3000000,0,True)==380000,'Cohabitation/nonmarital birth does not establish legal-spouse deduction')
    benefit=childcare_leave_benefit(10000,14,eligible=True,support_eligible=True)
    check('MHLW_example_93800_18200',benefit['base']==93800 and benefit['support']==18200,benefit)
    benefit=childcare_leave_benefit(10000,14,wage_paid=30000,eligible=True,support_eligible=True)
    check('MHLW_paid_wage_example_82000',benefit['base']==82000 and benefit['support']==18200,benefit)
    benefit=childcare_leave_benefit(25000,28,eligible=True,support_eligible=True)
    check('2026_08_daily_cap',benefit['base']==310290 and benefit['support']==60205,benefit)
    check('unknown_eligibility_not_awarded',childcare_leave_benefit(10000,28)['base']is None and maternity_allowance(300000,30)['amount']is None,'Unknown eligibility is NULL, not an automatic grant')
    check('maternity_daily_rounding',maternity_allowance(240000,30,eligible=True)['amount']==159990,'日額8000×2/3→5333、30日。給付日額の端数処理を保持')
    check('Kyokai_official_maternity_example_3780_daily',maternity_allowance(170000,30,eligible=True)['amount']==113400,'Official mean170000 → 5670 (10-yen rounding) → 3780 per day')
    check('maternity_salary_offset',maternity_allowance(240000,30,paid_salary=180000,eligible=True)['amount']==0,'No duplicate employer salary plus full allowance')
    s=employee_social('13',300000,32,300000,'2026-10-01')
    check('Tokyo_official_grade_300000',s['health']==14775 and s['child_support_contribution']==345 and s['employees_pension']==27450 and s['unemployment']==1500,s)
    s2=employee_social('13',300000,40,300000,'2026-10-01')
    check('care_age40',s2['care']==2430 and s['care']==0,s2)
    check('standard_grade_boundary',standard_remuneration(289999)==280000 and standard_remuneration(290000)==300000,'Verified remuneration band boundary')
    s3=employee_social('13',300000,32,0,'2026-10-01',True)
    check('approved_leave_social_exemption',s3['total']==0,s3)
    check('national_pension_October_new_exemption',national_pension(35,'2026-09-01',True,True,True)['amount']==17920 and national_pension(35,'2026-10-01',True,True,True)['amount']==0,'2026-10 effective month; application is required')
    children=[{'person_id':'old','date_of_birth':'2004-04-02','supported':True},{'person_id':'mid','date_of_birth':'2023-08-01','supported':True},{'person_id':'baby','date_of_birth':'2026-10-01','supported':True}]
    allowance=child_allowance(children,'2026-11-01',True)
    check('child_allowance_22year_count_not_birth_rank',allowance['entitlement_monthly']==40000 and allowance['eligible_children'][-1]['amount']==30000,allowance)
    check('child_allowance_unknown_claim',child_allowance(children,'2026-10-01')['entitlement_monthly']is None,'No automatic enrollment')
    check('Feb29_fiscal_year_boundary',child_allowance([{'person_id':'leap','date_of_birth':'2008-02-29','supported':True}],'2026-03-01',True)['entitlement_monthly']==10000,'Leap-day birthday must not crash school-year rules')
    check('birth_month_not_monthly_entitlement',child_allowance([children[-1]],'2026-10-01',True)['entitlement_monthly']==0,'Entitlement starts following birth/application month, not as cash on birth day')
    check('April1_school_year_cutoff',child_allowance([{'person_id':'a','date_of_birth':'2008-04-01','supported':True}],'2026-04-01',True)['entitlement_monthly']==0 and child_allowance([{'person_id':'b','date_of_birth':'2008-04-02','supported':True}],'2026-04-01',True)['entitlement_monthly']==10000,'Age is attained on day before birthday')
    check('third_birthday_month_amount',child_allowance([{'person_id':'a','date_of_birth':'2023-10-15','supported':True}],'2026-10-15',True)['entitlement_monthly']==15000 and child_allowance([{'person_id':'b','date_of_birth':'2023-10-01','supported':True}],'2026-10-01',True)['entitlement_monthly']==10000,'Month including third age attainment; first-day birthday exception')
    accounts=[{'account_id':'cash','side':'asset','liquid_cash':True,'balance':100000},{'account_id':'loan','side':'liability','balance':500000}]
    entries=[{'entry_id':'income','category':'salary','amount':200000},{'entry_id':'spending','category':'consumption','amount':-150000}]
    x=settle_one_period(accounts,entries,[{'account_id':'loan','annual_rate':.06,'remaining_months':60}])
    check('cash_and_networth_accounting',x['cash_identity_residual']==0 and x['net_worth_identity_residual']==0 and net_worth(accounts)==-400000,x)
    z=settle_one_period(accounts,entries+[{'entry_id':'borrowing','category':'loan_drawdown','amount':30000,'counter_account_id':'loan'}])
    check('borrowing_not_income_or_wealth',net_worth(z['accounts'])-net_worth(accounts)==50000,z)
    x=settle_one_period(accounts,[{'entry_id':'cost','category':'consumption','amount':-200000}])
    check('cash_shortfall_not_auto_financed',x['closing_cash']==-100000 and x['cash_shortfall']==100000 and not x['financially_funded'],x)
    bad=[('unidentified_cash',[{'entry_id':'x','category':'salary','amount':None}]),('noninteger_yen',[{'entry_id':'x','category':'salary','amount':.5}]),('unbalanced_borrowing',[{'entry_id':'x','category':'loan_drawdown','amount':1000}])]
    for name,flows in bad:
        try:settle_one_period(accounts,flows);ok=False
        except ValueError:ok=True
        check(name,ok,'Explicit rejection, no dummy zero/residual')
    check('open_tail_no_cap',interpolate_quantile({'.1':100000,'.25':200000,'.5':400000,'.75':800000,'.9':1600000},.99)is None,'Top tail unidentified by default')
    check('alternative_tail_estimates',interpolate_quantile({'.75':800000,'.9':1600000},.99,'pareto')>1600000 and interpolate_quantile({'.75':800000,'.9':1600000},.99,'lognormal')>1600000,'Parametric tails are alternatives, not clipped/fixed source maxima')
    (ROOT/'validation/policy_accounting_tests.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2));assert all(x['pass']for x in tests)
if __name__=='__main__':main()
