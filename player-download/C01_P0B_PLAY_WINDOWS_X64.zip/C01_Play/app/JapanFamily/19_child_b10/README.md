# B-1.0-preintegration.2：子ども本人モデルの研究試作

**正式なB-1.0統合リリースではありません。** 最新A統合ZIPが32 MiBの転送上限で取得できず、Aの実コード・SQLite・統計核の保全監査、旧新API回帰、47県家庭生成基盤との接続が未完です。取得できた5添付は `handover_available/` に原形のまま保持しています。

独立した出生生成、0〜24か月更新、養育者別の関係履歴、観測機会と誤報を含む親向けAPI、保存・復元を実装しました。2023年乳幼児身体発育調査の原表9点と、WHO公式身体発育原表3点を取得しています。研究の根拠とゲーム用仮定は分離します。

現時点の出生生成は**在胎37〜41週の病院調査参照シナリオ**です。全出生児、早産児、多胎児、先天疾患の分布を再現しません。気質の出生時分布・相関、心理過程、縦断発育、観測誤差、養育環境の効果は未識別です。生後24か月より先の進行は明示的に拒否します。

## 使い方

作業ディレクトリは `JapanFamily/19_child_b10`。既存チェックアウトを使ってください。クラウドの各タスクは既に隔離されており、明示的な依頼がない限りGit worktreeを作成する必要はありません。

モデル本体はPython標準ライブラリで実行できます。原表変換・検証・図の再作成には `requirements-research.txt` の依存を使います。現在の実行環境では導入済みです。新規環境では任意の仮想環境内で次を実行します。

```bash
python -m pip install -r requirements-research.txt
python -m unittest discover -s tests -v
```

```python
from child_b10 import Child
from child_b10.player_api import parent_observations

child = Child.generate(seed=42, birth_date="2026-01-17")
def environment(month):
    return {"context": "home", "caregivers": {
        "mother": {"contact_episodes_per_day": 2, "observation_opportunity": .8},
        "father": {"contact_episodes_per_day": 1, "observation_opportunity": .5}}}

# 上の接触・観測頻度は明示的な架空シナリオであり、日本の実測値ではありません。
child.advance_to(12, environment)
child.save("child12.snapshot.json")  # 研究者用。親やプレイヤーへ渡さない。
restored = Child.load("child12.snapshot.json")
restored.advance_to(24, environment)
player_response = parent_observations(restored, "mother")
```

`research_snapshot()` と保存ファイルは内部真実を含みます。プレイヤーの返却値には必ず `player_api.parent_observations()` の射影を使います。これは信頼済みPython側での情報分離であり、未実装のWeb認証・認可を代替しません。

## 成果物の読み方

- `docs/構築報告.md`：実施結果、未達、次に必要なもの。
- `docs/model_design.md`：数理モデル・時間・観測・履歴・2〜20歳への拡張。
- `docs/research_review.md`：取得資料と根拠の限界。
- `data/variable_ledger.csv`、`relationship_ledger.json`：実装変数・関係と根拠。
- `data/japan_reference.json`：日本原表のセル座標と分布フィット。
- `results/population_10000/`：B単独1万人・24万更新、出生を含む25万状態のSQLiteと集計。
- `results/examples/`：3児の各月内部状態・親観測、同一児の環境比較、A保存履歴17経路との接続。
- `results/independent_comparisons.json`：別標本の2010年調査との記述的比較。2026年の合格判定ではありません。

再現・検証は `docs/rebuild.md` に記載します。保存したZIPのCRC・全ファイルSHA256・再展開後の検証結果は、ZIP外の `B1.0_PREINTEGRATION_RELEASE_VERIFICATION.json` を参照してください。これは正式統合の合格証明ではありません。
