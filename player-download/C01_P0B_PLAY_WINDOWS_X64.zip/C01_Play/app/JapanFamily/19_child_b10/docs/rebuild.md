# 再構築・再検証

Python3.12で実施。モデル本体は標準ライブラリ、研究用依存は `requirements-research.txt` の実検証版。実行ディレクトリはすべて `JapanFamily/19_child_b10`。元のAコード・DB・ロックファイルを変更するコマンドは含まない。

## 保存済み成果物の検査

```bash
python scripts/check_sources.py
python -m unittest discover -s tests -v
```

モデル版、パラメータと原表ハッシュ、source manifestを保持する。原資料が更新された場合に期待チェックサムを書き換えて一致させない。`check_sources.py --fetch-missing` は不足した固定原資料だけ取得し、期待SHA256と一致したものだけ保存する。TLS検証は有効のまま。

## 正規化・フィットの再作成

```bash
python scripts/compile_japan.py
python scripts/build_catalogues.py
```

同じ原表から同じ参照データを再作成する。新しい原表・仮定・アルゴリズムを採用する場合は、版と根拠台帳を更新し、旧出力は別名で保全する。旧モデルの状態を新しいパラメータで暗黙に再開しない。

## 大量生成

```bash
python scripts/validate_population.py --n 10000 --workers 3 --output /workspace/scratch/B10_new_run
```

既存DBを上書きしないため、新しい出力ディレクトリを指定する。今回の本試行は `results/population_10000` に保存済み。3ワーカーで約180秒、SQLite約1.1 GiB。十分な空き容量を用意する。

birthを月0として25状態/児、月1〜24で24更新/児。各月の内部状態・観測・出来事差分を全児について保存する。`storage.restore_child()` で出生静的情報と差分を結合して復元できる。検査を兼ねるため小標本でも動くが、n<1000の共分散検査、セルn<30の平均検査は `null/unassessed` とし、通過に数えない。

今回の暦カバレッジは12出生月×1〜28日を回転する人工的検査設計であり、現実の出生季節分布ではない。31日・うるう日出生は別の単体検査で確認する。県名だけ付けて47県接続済みと称することはしない。

## 比較例・分析

```bash
python scripts/experiments.py
python scripts/analyze.py
```

実施済みの比較例は派生出力であり、上記コマンドはそれらを再生成する。手で編集した出力を保全する場合は先に別場所へ複写する。一次添付ファイルは変更しない。`analyze.py` は保存済みの `results/population_10000` を読む。新規本試行を分析する場合は別の検証コピーで入力パスを合わせる。GUIやサーバー起動は不要。Matplotlibのキャッシュは `/tmp` を使用する。

## 保存後の独立検証

```bash
python scripts/verify_release.py /path/to/B1.0_PREINTEGRATION.zip --destination /workspace/scratch/B10_fresh_check --report /workspace/scratch/B10_release_check.json
```

新しい空の展開先を使う。ZIPのCRC・全ファイルSHA256、元添付との一致、SQLite整合性・外部キー・件数、旧Aの未検証表示、B APIの単体検査、保存12か月からの再開と保存24か月状態の完全一致を確認する。

正式A統合ZIPの転送が可能になったら、まず元ZIPのCRC・SHA256を確認する。添付Aリリース証明に記載された元ZIP SHA256は `7dca730f3622bb72a46e6b26c88ea5e4b97155a7674043e8f45bd1b7776f8fff`。別の旧基盤ZIPのハッシュと混同しない。内部マニフェストを照合し、元DB全テーブルをハッシュしてからBを追加する。Aの回帰は検証用の別展開先で行い、出力を書き戻す旧検証コードが引継ぎ元を変更しないようにする。

原ZIPをバイト分割して受け取る場合は各片を25 MiB程度にし、順に再結合して元ZIP SHA256を確認する。分割のために内容を削った代替ZIPを正式原本と混同しない。
