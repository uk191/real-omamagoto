import copy
import datetime as dt
import json
import math
import tempfile
import unittest
from pathlib import Path

from child_b10 import Child, compare
from child_b10.engine import PARAMS, anniversary
from child_b10.growth import from_z, to_z
from child_b10.player_api import parent_observations
from child_b10.randomness import digest, normal


def routine(month):
    return {"caregivers": {"mother": {"contact_episodes_per_day": 2, "observation_opportunity": .8},
                           "father": {"contact_episodes_per_day": 1, "observation_opportunity": .5}},
            "context": "home"}


class ModelTests(unittest.TestCase):
    def test_24_month_replay(self):
        a = Child.generate(seed=123).advance_to(24, routine)
        b = Child.generate(seed=123).advance_to(24, routine)
        self.assertEqual(a.research_snapshot(), b.research_snapshot())

    def test_serialized_split(self):
        child = Child.generate(seed=456).advance_to(12, routine)
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp)/"state.json"
            child.save(file)
            restored = Child.load(file).advance_to(24, routine)
        expected = Child.generate(seed=456).advance_to(24, routine)
        self.assertEqual(restored.research_snapshot(), expected.research_snapshot())

    def test_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp)/"state.json"
            Child.generate(seed=1).save(file)
            doc = json.loads(file.read_text())
            doc["payload"]["elapsed_months"] = 24
            file.write_text(json.dumps(doc))
            with self.assertRaises(ValueError):
                Child.load(file)

    def test_parameter_drift_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp)/"state.json"
            Child.generate(seed=1).save(file)
            doc = json.loads(file.read_text())
            doc["payload"]["parameter_sha256"] = "x"
            doc["payload_sha256"] = digest(doc["payload"])
            file.write_text(json.dumps(doc))
            with self.assertRaises(ValueError):
                Child.load(file)

    def test_month_end_and_leap_birth(self):
        self.assertEqual(anniversary(dt.date(2026,1,31),1),dt.date(2026,2,28))
        self.assertEqual(anniversary(dt.date(2026,1,31),2),dt.date(2026,3,31))
        self.assertEqual(anniversary(dt.date(2024,2,29),12),dt.date(2025,2,28))
        a = Child.generate(seed=1,birth_date="2026-01-31").advance_to(24)
        self.assertEqual(a.research_snapshot()["age_days"],730)

    def test_maturation_without_explicit_player_action(self):
        # Ordinary endogenous maturation proceeds without explicit player actions.
        child = Child.generate(seed=9)
        before = child.research_snapshot()["physical_health"]["weight_kg"]
        child.advance_to(24)
        s = child.research_snapshot()
        self.assertGreater(s["physical_health"]["weight_kg"],before)
        self.assertTrue(all(x>0 for x in s["developmental_state"]["progress"].values()))

    def test_scope_limit(self):
        child = Child.generate(seed=1).advance_to(24)
        with self.assertRaises(NotImplementedError):
            child.advance_one_month()
        with self.assertRaises(NotImplementedError):
            Child.generate(seed=2,gestation_days=240)

    def test_ranges_prerequisites_and_time(self):
        for seed in range(15):
            child = Child.generate(seed=seed)
            length = child.research_snapshot()["physical_health"]["length_cm"]
            for _ in range(24):
                child.advance_one_month(routine(1))
                s = child.research_snapshot()
                self.assertTrue(all(math.isfinite(x) and 0<=x<=1 for x in s["emotion_regulation"].values()))
                self.assertGreaterEqual(s["physical_health"]["length_cm"],length)
                length = s["physical_health"]["length_cm"]
                milestones = s["developmental_state"]["milestones"]
                for name in milestones:
                    for prerequisite in PARAMS["milestones"][name][2]:
                        self.assertIn(prerequisite,milestones)
                dates = [e["date"] for e in s["experience_ledger"]]
                self.assertEqual(dates,sorted(dates))
                self.assertEqual(len({e["history_id"] for e in s["experience_ledger"]}),len(dates))

    def test_birth_has_no_future_abilities_or_diagnoses(self):
        s = Child.generate(seed=1).research_snapshot()
        self.assertEqual(s["developmental_state"]["milestones"],{})
        self.assertEqual(s["physical_health"]["diagnoses"],[])
        for item in s["developmental_state"]["future_domains"].values():
            self.assertIsNone(item["value"])

    def test_new_skill_not_observed_in_earlier_segment(self):
        child = Child.generate(seed=6)
        for m in range(1,25):
            old = child.research_snapshot()["developmental_state"]["milestones"]
            child.advance_one_month(routine(m))
            s = child.research_snapshot()
            if "walking_independently" not in old:
                self.assertTrue(all(not b["signals"]["takes_independent_steps"] for b in s["observed_behaviors"][:-1]))

    def test_player_projection_and_no_mutation(self):
        child = Child.generate(seed=3).advance_to(2,routine)
        state_hash = digest(child.research_snapshot())
        visible = parent_observations(child,"mother")
        self.assertEqual(set(visible),{"child_id","as_of_date","observations","measurements"})
        text = json.dumps(visible)
        for field in ["growth_z","latent_state","development_speed","reactivity","familiarity","seed","history_chain"]:
            self.assertNotIn(field,text)
        visible["observations"].clear()
        self.assertEqual(state_hash,digest(child.research_snapshot()))
        self.assertTrue(parent_observations(child,"mother")["observations"])

    def test_no_opportunity_no_knowledge(self):
        child = Child.generate(seed=3).advance_to(24)
        self.assertEqual(parent_observations(child,"mother")["observations"],[])

    def test_unknown_observer_rejected(self):
        with self.assertRaises(PermissionError):
            parent_observations(Child.generate(seed=1),"stranger")

    def test_observation_queries_do_not_consume_rng(self):
        a = Child.generate(seed=6).advance_to(12,routine)
        for _ in range(30):
            parent_observations(a,"mother")
            normal(6,"unrelated",999)
        a.advance_to(24,routine)
        b = Child.generate(seed=6).advance_to(24,routine)
        self.assertEqual(a.research_snapshot(),b.research_snapshot())

    def test_only_informed_parent_receives_measurement(self):
        child = Child.generate(seed=6)
        child.record_measurement(observer_id="clinic",metric="weight_kg",value=3.1,known_by=["mother"])
        self.assertEqual(len(parent_observations(child,"mother")["measurements"]),1)
        self.assertEqual(parent_observations(child,"father")["measurements"],[])

    def test_missing_contact_is_not_zero_contact(self):
        a = Child.generate(seed=2).advance_one_month(routine(1))
        b = copy.deepcopy(a)
        before = a.research_snapshot()["caregiver_relationships"]["mother"]["familiarity"]
        a.advance_one_month({})
        b.advance_one_month({"caregivers":{"mother":{"contact_episodes_per_day":0}}})
        self.assertEqual(a.research_snapshot()["caregiver_relationships"]["mother"]["familiarity"],before)
        self.assertLess(b.research_snapshot()["caregiver_relationships"]["mother"]["familiarity"],before)

    def test_caregivers_are_separate_no_attachment_score(self):
        s = Child.generate(seed=3).advance_to(12,routine).research_snapshot()
        rel = s["caregiver_relationships"]
        self.assertGreater(rel["mother"]["contact_episodes"],rel["father"]["contact_episodes"])
        self.assertIsNone(rel["mother"]["attachment_classification"])

    def test_income_and_unrecognized_inputs_rejected(self):
        with self.assertRaises(ValueError):
            Child.generate(seed=3).advance_one_month({"parent_income":100000000})
        with self.assertRaises(ValueError):
            Child.generate(seed=3).advance_one_month({"caregivers":{"nobody":{}}})

    def test_invalid_environment_does_not_mutate(self):
        child = Child.generate(seed=3)
        before = digest(child.research_snapshot())
        with self.assertRaises(ValueError):
            child.advance_one_month({"sleep_disruption":float("nan")})
        self.assertEqual(before,digest(child.research_snapshot()))

    def test_reference_effects_off_and_hypothesis_on(self):
        a = Child.generate(seed=99).advance_to(24,{m:{"sleep_disruption":1,"language_opportunities":1} for m in range(1,25)})
        b = Child.generate(seed=99).advance_to(24)
        self.assertEqual(a.research_snapshot()["developmental_state"],b.research_snapshot()["developmental_state"])
        self.assertEqual(a.research_snapshot()["emotion_regulation"],b.research_snapshot()["emotion_regulation"])
        c = Child.generate(seed=99).advance_to(24,{m:{"sleep_disruption":1,"language_opportunities":1} for m in range(1,25)},enable_hypothetical_effects=True)
        self.assertGreater(c.research_snapshot()["developmental_state"]["progress"]["expressive_language"],b.research_snapshot()["developmental_state"]["progress"]["expressive_language"])
        self.assertGreater(c.research_snapshot()["emotion_regulation"]["fatigue"],b.research_snapshot()["emotion_regulation"]["fatigue"])

    def test_lms_roundtrip_and_official_cell(self):
        self.assertEqual(from_z("weianthro","male",0,0),3.3464)
        for sex in ["male","female"]:
            for day in [0,90,365,730]:
                for z in [-2,0,2]:
                    for name in ["weianthro","lenanthro","hcanthro"]:
                        self.assertAlmostEqual(to_z(name,sex,day,from_z(name,sex,day,z)),z,places=10)

    def test_same_family_different_children(self):
        a = Child.generate(seed=1).advance_to(24,routine).research_snapshot()
        b = Child.generate(seed=2).advance_to(24,routine).research_snapshot()
        self.assertNotEqual(a["latent_state"],b["latent_state"])
        self.assertNotEqual(a["parent_observations"],b["parent_observations"])

    def test_comparison_is_labeled(self):
        result = compare(lambda:Child.generate(seed=8),{"a":{},"b":{}},month=2)
        self.assertIn("not_causal",result["interpretation"])
        self.assertEqual(result["scenarios"]["a"],result["scenarios"]["b"])

    def test_generation_parameter_provenance(self):
        s = Child.generate(seed=25).research_snapshot()
        self.assertIn("Gaussian",s["generation_record"]["distributions"]["traits"])
        self.assertEqual(s["random_streams"]["seed"],25)


if __name__ == "__main__":
    unittest.main()
