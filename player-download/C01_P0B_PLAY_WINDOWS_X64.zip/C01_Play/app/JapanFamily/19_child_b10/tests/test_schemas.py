import json
import unittest
from pathlib import Path

import jsonschema
from child_b10 import Child
from child_b10.player_api import parent_observations
from tests.test_model import routine

ROOT=Path(__file__).resolve().parents[1]


class SchemaTests(unittest.TestCase):
    def test_internal_birth_and_24month_schemas(self):
        schema=json.loads((ROOT/'data/internal_state.schema.json').read_text())
        child=Child.generate(seed=59)
        jsonschema.validate(child.research_snapshot(),schema)
        child.advance_to(24,routine)
        jsonschema.validate(child.research_snapshot(),schema)

    def test_player_schema_forbids_latent_field(self):
        schema=json.loads((ROOT/'data/player_response.schema.json').read_text())
        child=Child.generate(seed=59).advance_to(1,routine)
        response=parent_observations(child,'mother');jsonschema.validate(response,schema)
        response['latent_state']=child.research_snapshot()['latent_state']
        with self.assertRaises(jsonschema.ValidationError):jsonschema.validate(response,schema)
