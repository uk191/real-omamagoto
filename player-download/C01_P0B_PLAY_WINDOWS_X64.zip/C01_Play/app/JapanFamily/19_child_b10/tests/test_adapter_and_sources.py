import json
import unittest
import zipfile
from pathlib import Path

from child_b10.adapter_a3 import from_a3_saved_state, unpack
from child_b10.engine import Child, PARAMS
from child_b10.japan_reference import reference, from_z, to_z
from child_b10.randomness import digest

ROOT=Path(__file__).resolve().parents[1]


class AdapterAndSourceTests(unittest.TestCase):
    def test_japanese_quantile_roundtrip(self):
        for metric in ['weianthro','lenanthro','hcanthro']:
            for sex in ['male','female']:
                for age in [0,30,365,730]:
                    for z in [-3,-1,0,1,3]:
                        self.assertAlmostEqual(to_z(metric,sex,age,from_z(metric,sex,age,z)),z,places=10)

    def test_original_xlsx_cell_not_conflicting_pdf(self):
        record=reference()['milestone_fits']['head_control']['raw'][1]
        self.assertAlmostEqual(record['pass_proportion'],.5333333333333333)

    def test_gestation_condition_and_body_supported(self):
        for seed in range(30):
            child=Child.generate(seed=seed,sex='female',gestation_days=273)
            s=child.research_snapshot()
            self.assertEqual(s['birth_conditions']['gestation_days'],273)
            self.assertEqual(s['child_identity']['sex_for_growth_reference'],'female')
            self.assertEqual(s['birth_conditions']['conditional_birth_provenance']['weight']['source_id'],'000040240407')

    def test_all_saved_a_paths_and_no_mutation(self):
        archive=next((ROOT/'handover_available').glob('*.zip'))
        count=0
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                if '/' in name or not name.endswith('.json'):continue
                obj=json.loads(z.read(name));before=digest(obj)
                child,environments=from_a3_saved_state(obj,seed=77)
                child.advance_to(24,environments)
                self.assertEqual(before,digest(obj))
                self.assertEqual(child.research_snapshot()['elapsed_months'],24)
                self.assertFalse(any(x['attachment_classification'] is not None for x in child.research_snapshot()['caregiver_relationships'].values()))
                count+=1
        self.assertEqual(count,17)

    def test_partial_birth_month_a_history_is_explicitly_rejected(self):
        archive=next((ROOT/'handover_available').glob('*.zip'))
        with zipfile.ZipFile(archive) as z:obj=json.loads(z.read('urban_first.json'))
        obj['birth_date']='2026-01-17'
        with self.assertRaises(NotImplementedError):from_a3_saved_state(obj,seed=77)


if __name__=='__main__':unittest.main()
