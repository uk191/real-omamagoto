"""B1 research checks."""
