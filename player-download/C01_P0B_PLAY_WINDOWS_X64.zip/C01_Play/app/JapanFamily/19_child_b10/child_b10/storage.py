"""B-only SQLite storage. Cumulative state reconstructed from monthly deltas."""
import copy
import json
import sqlite3
import zlib

from .engine import Child, VERSION, PARAMETER_HASH

DYNAMIC = ["latent_state","developmental_state","physical_health","emotion_regulation",
           "caregiver_relationships","experience_memory","experience_ledger","observed_behaviors",
           "parent_observations","measurement_history","uncertainty_flags","as_of_date",
           "elapsed_months","age_days","calendar_months_crossed","history_chain","scenario_effects_enabled"]


def encode(value):
    return zlib.compress(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode(),1)


def decode(value):
    return json.loads(zlib.decompress(value))


def restore_child(connection, child_id, month=24):
    row=connection.execute('SELECT birth_json_zlib FROM b10_child WHERE child_id=?',(child_id,)).fetchone()
    if row is None:raise KeyError(child_id)
    state=decode(row[0]);events=[];observations=[]
    rows=connection.execute('SELECT month,internal_json_zlib FROM b10_month WHERE child_id=? AND month<=? ORDER BY month',(child_id,month)).fetchall()
    if [r[0] for r in rows]!=list(range(month+1)):raise ValueError('incomplete stored trajectory')
    for _,blob in rows:
        delta=decode(blob)
        events.extend(delta.pop('experience_ledger'))
        observations.extend(delta.pop('parent_observations'))
        state.update(delta)
    state['experience_ledger']=events;state['parent_observations']=observations
    if state['model_version']!=VERSION or state['parameter_sha256']!=PARAMETER_HASH:
        raise ValueError('database requires its original model parameters')
    child=Child();child._state=state
    return child
