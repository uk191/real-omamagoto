"""Research-only latent process and persistence, independent of the A engines.

Psychological dynamics and five milestones are uncalibrated assumptions;
seven milestone proxies are calibrated to cross-sectional parent reports.
No causal attachment, intelligence, diagnosis, disease, or parenting-score output.
"""
import calendar
import copy
import datetime as dt
import json
import math
from pathlib import Path

from .growth import ROOT
from .japan_reference import from_z, to_z, reference, term_birth_draw
from .randomness import digest, normal, uniform

PARAMS = json.loads((ROOT / "data/parameters.json").read_text())
VERSION = PARAMS["version"]
PARAMETER_HASH = digest([PARAMS, reference()])
DOMAINS = list(PARAMS["development_domains"])
TRAITS = list(PARAMS["trait_loadings"])
FUTURE_DOMAINS = ["self_concept", "self_esteem", "self_efficacy", "values",
                  "academic_learning", "peer_belonging", "motivation",
                  "identity", "self_determination", "autobiographical_memory"]


def anniversary(birth, month):
    index = birth.year * 12 + birth.month - 1 + month
    year, m = divmod(index, 12)
    return dt.date(year, m + 1, min(birth.day, calendar.monthrange(year, m + 1)[1]))


def unit(x):
    return max(0.0, min(1.0, x))


def logistic(x):
    return 1 / (1 + math.exp(-max(-30, min(30, x))))


def finite(value, lower, upper, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name} must be numeric")
    if not math.isfinite(value) or not lower <= value <= upper:
        raise ValueError(f"{name} outside [{lower}, {upper}]")
    return value


def validate_environment(env, caregiver_ids):
    env = copy.deepcopy(env)
    allowed = {"caregivers", "sleep_disruption", "responsive_episode",
               "language_opportunities", "context", "provenance", "a3_context"}
    if set(env) - allowed:
        raise ValueError(f"unknown environment fields: {sorted(set(env) - allowed)}")
    for name in ["sleep_disruption", "responsive_episode", "language_opportunities"]:
        finite(env.get(name, 0), 0, 1, name)
    cg = env.get("caregivers", {})
    if not isinstance(cg, dict) or set(cg) - set(caregiver_ids):
        raise ValueError("caregiver environment must refer to registered people")
    for ident, values in cg.items():
        if set(values) - {"contact_episodes_per_day", "observation_opportunity"}:
            raise ValueError("unsupported caregiver input")
        if values.get("contact_episodes_per_day") is not None:
            finite(values["contact_episodes_per_day"], 0, 100, "contact_episodes_per_day")
        finite(values.get("observation_opportunity", 0), 0, 1, "observation_opportunity")
    if not isinstance(env.get("context", "home"), str):
        raise ValueError("context must be a string")
    return env


class Child:
    """Trusted research API. Never serialize this object directly to a player."""

    @classmethod
    def generate(cls, *, seed, birth_date="2026-01-15", child_id=None,
                 caregiver_ids=("mother", "father"), sex=None,
                 gestation_days=None, birth_weight_kg=None, birth_length_cm=None):
        if type(seed) is not int:
            raise ValueError("integer seed required")
        birth = dt.date.fromisoformat(birth_date)
        requested_sex, requested_gestation = sex, gestation_days
        if gestation_days is not None and (type(gestation_days) is not int or not 259 <= gestation_days <= 293):
            raise NotImplementedError("pre/post-term birth distribution and growth not calibrated")
        if sex not in [None, "male", "female"]:
            raise ValueError("physical reference requires recorded sex male/female")
        caregivers = list(caregiver_ids)
        if (not caregivers or any(not isinstance(c, str) or not c for c in caregivers)
                or len(caregivers) != len(set(caregivers))):
            raise ValueError("distinct nonempty caregiver IDs required")
        caregivers.sort()  # Canonical ordering survives JSON sort_keys and restoration.
        ident = child_id if child_id is not None else "child_" + digest([seed, birth_date])[:16]
        if not isinstance(ident, str) or not ident or ident in caregivers:
            raise ValueError("child ID must differ from caregiver IDs")
        factors = [normal(seed, "trait_factor", i) for i in range(3)]
        traits = {}
        for name, loads in PARAMS["trait_loadings"].items():
            residual = math.sqrt(1 - sum(x*x for x in loads))
            traits[name] = sum(x*y for x, y in zip(loads, factors)) + residual*normal(seed, "trait_residual", name)
        length_z = normal(seed, "length_z")
        a = PARAMS["growth_weight_length_loading"]
        b = PARAMS["growth_head_length_loading"]
        growth_z = {"length": length_z,
                    "weight": a*length_z + math.sqrt(1-a*a)*normal(seed, "weight_z"),
                    "head": b*length_z + math.sqrt(1-b*b)*normal(seed, "head_z")}
        sex, gestation_days, birth_values, birth_provenance = term_birth_draw(seed, sex, gestation_days, growth_z)
        growth_z = {name: to_z(table, sex, 0, birth_values[name]) for name, table in
                    [("weight","weianthro"),("length","lenanthro"),("head","hcanthro")]}
        if birth_weight_kg is not None:
            finite(birth_weight_kg, 0.5, 7, "birth_weight_kg")
            growth_z["weight"] = to_z("weianthro", sex, 0, birth_weight_kg)
        if birth_length_cm is not None:
            finite(birth_length_cm, 30, 65, "birth_length_cm")
            growth_z["length"] = to_z("lenanthro", sex, 0, birth_length_cm)
        shared = normal(seed, "development_factor")
        loading = PARAMS["development_common_loading"]
        speed = {name: math.exp(PARAMS["development_speed_log_sd"] *
                 (loading*shared + math.sqrt(1-loading*loading)*normal(seed, "development_speed", name)))
                 for name in DOMAINS}
        milestone_onsets = {}
        for name, (domain, threshold, _) in PARAMS["milestones"].items():
            fit = reference()["milestone_fits"].get(name)
            if fit:
                score = loading*shared + math.sqrt(1-loading*loading)*normal(seed,"milestone_onset",name)
                milestone_onsets[name] = math.exp(fit["log_mu"] + fit["log_sd"]*score)
            else:
                milestone_onsets[name] = threshold / speed[domain]
        obj = cls()
        obj._state = {
            "schema_version": 1, "model_version": VERSION, "parameter_sha256": PARAMETER_HASH,
            "child_identity": {"child_id": ident, "birth_date": birth.isoformat(), "sex_for_growth_reference": sex},
            "birth_conditions": {"gestation_days": gestation_days, "multiplicity": 1,
                "distribution_scope": "term37to41week_hospital_reference_not_national_joint; multiplicity1_scenario_not_conditioned_in_source",
                "gestation_source": "explicit_input" if requested_gestation is not None else "hospital_weight_counts_by_sex_week_conditioned_on37to41; withinweek_uniform_assumption",
                "conditional_birth_provenance": birth_provenance,
                "clinical_diagnoses": [], "birth_weight_input": birth_weight_kg,
                "birth_length_input": birth_length_cm},
            "initial_dispositions": copy.deepcopy(traits), "latent_state": traits,
            "developmental_state": {"progress": {name: 0.0 for name in DOMAINS}, "milestones": {},
                "hypothetical_clock_offset_months": 0.0,
                "future_domains": {name: {"status": "not_applicable", "value": None} for name in FUTURE_DOMAINS}},
            "physical_health": {"growth_z": growth_z, "diagnoses": [],
                "sensory_assessments": {"hearing": "unmeasured", "vision": "unmeasured"},
                "infection_exposure": "not_modeled", "healthcare_support": "external_input_required"},
            "emotion_regulation": {"distress": 0.2, "fatigue": 0.2, "hunger": 0.3,
                "arousal": 0.4, "settling": 0.5, "sleep_pressure": 0.3},
            "caregiver_relationships": {c: {"familiarity": 0.0, "contact_episodes": 0.0,
                "last_contact_date": None, "attachment_classification": None,
                "attachment_status": "not_inferred"} for c in caregivers},
            "experience_memory": {"contexts": {}, "autobiographical_recall": None,
                "mechanism": "procedural_familiarity_scenario_not_adult_episodic_memory"},
            "experience_ledger": [], "observed_behaviors": [], "parent_observations": [],
            "measurement_history": [], "transition_parameters": {"development_speed": speed,
                "milestone_onset_targets_months": milestone_onsets},
            "evidence_provenance": {"growth_marginals": "Japanese2023_original_XLSX_quantiles; bin_midpoint_log_interpolation_assumption",
                "birth_conditional_moments": "Japanese2023_hospital_table47; shape_and_copula_unidentified",
                "seven_milestones": "same_source_parent_report_CDF_fit; latent_onset_measurement_model_dependent",
                "all_psychological_coefficients": "unidentified_assumption",
                "treatment_effects": "none_identified", "scale_scores": "not_computed"},
            "uncertainty_flags": ["Japanese_external_validity_unverified", "term_reference_only",
                "joint_birth_distribution_unidentified", "five_development_times_uncalibrated; seven_partly_calibrated_to_reports",
                "temperament_covariance_unidentified", "observation_model_unvalidated",
                "longitudinal_growth_copula_unidentified", "no_diagnostic_inference"],
            "random_streams": {"algorithm": "sha256_keyed_box_muller_v1", "seed": seed,
                "identity_role": "seed defines random identity; child_id is metadata",
                "streams": ["birth", "traits", "growth", "development", "short_state", "behavior", "observation", "measurement"]},
            "as_of_date": birth.isoformat(), "elapsed_months": 0, "age_days": 0,
            "calendar_months_crossed": 0, "history_chain": "0"*64,
            "scenario_effects_enabled": False,
        }
        obj._update_physical()
        obj._state["birth_conditions"]["reference_weight_kg"] = obj._state["physical_health"]["weight_kg"]
        obj._state["birth_conditions"]["reference_length_cm"] = obj._state["physical_health"]["length_cm"]
        obj._state["generation_record"] = {
            "seed": seed, "version": VERSION, "parameters": PARAMETER_HASH,
            "conditional_inputs": {"sex_input": requested_sex, "gestation_days_input": requested_gestation,
                "birth_weight_kg": birth_weight_kg, "birth_length_cm": birth_length_cm},
            "distributions": {"sex_gestation": "hospital_table47_sex_by_week_weight_counts; restricted37to41weeks; selection_not_national_births",
                "traits": "three_factor_Gaussian_plus_independent_residuals; implied_covariance=L L' + D",
                "birth_body": "conditional_lognormal_matching_published_mean_sd; Gaussian_residual_copula_unidentified",
                "growth": "Japanese2023_quantile_marginals; log_interpolation; longitudinal_and_joint_copula_unidentified",
                "milestones": "7_lognormal_CDF_fits_to_Japanese_parent_reports;5_scenarios;correlations_unidentified",
                "speed": "shared_factor_lognormal; uncalibrated; not_IQ"}}
        obj._event("birth", birth, [], {"generation_record": obj._state["generation_record"]}, [], "mixed_reference_and_assumption")
        return obj

    def _event(self, kind, date, people, change, known_by, evidence):
        s = self._state
        event = {"history_id": f'{s["child_identity"]["child_id"]}/event/{len(s["experience_ledger"]):05d}',
                 "date": date.isoformat(), "year_month": date.strftime("%Y-%m"), "kind": kind,
                 "people": people, "state_context": {"age_days": (date - dt.date.fromisoformat(s["child_identity"]["birth_date"])).days,
                     "as_of_previous_state": s["as_of_date"]},
                 "internal_change": change, "observable_reaction": None,
                 "evidence": evidence, "known_by": list(known_by)}
        s["experience_ledger"].append(event)
        return event

    def _update_physical(self):
        s = self._state
        sex = s["child_identity"]["sex_for_growth_reference"]
        for name, table in [("weight", "weianthro"), ("length", "lenanthro"), ("head", "hcanthro")]:
            key = {"weight": "weight_kg", "length": "length_cm", "head": "head_circumference_cm"}[name]
            proposal = from_z(table, sex, s["age_days"], s["physical_health"]["growth_z"][name])
            previous = s["physical_health"].get(key)
            # A latent bone/head trajectory cannot shrink like a noisy measurement.
            # Explicit scenario constraint, not a fitted longitudinal growth law.
            if name in ["length", "head"] and previous is not None and proposal < previous:
                proposal = previous
                s["physical_health"]["growth_z"][name] = to_z(table, sex, s["age_days"], proposal)
                s["physical_health"]["monotonic_constraint_count"] = s["physical_health"].get("monotonic_constraint_count", 0)+1
            s["physical_health"][key] = proposal
        s["physical_health"]["measured_or_latent"] = "latent_reference_trajectory"

    def advance_one_month(self, environment=None, *, enable_hypothetical_effects=False):
        s = self._state
        month = s["elapsed_months"] + 1
        if month > 24:
            raise NotImplementedError("Only birth through 24 months implemented; no 2–20y probabilities")
        env = validate_environment(environment or {}, s["caregiver_relationships"])
        seed = s["random_streams"]["seed"]
        start = dt.date.fromisoformat(s["as_of_date"])
        birth = dt.date.fromisoformat(s["child_identity"]["birth_date"])
        end = anniversary(birth, month)
        days = (end-start).days
        before_emotion = copy.deepcopy(s["emotion_regulation"])
        if env.get("a3_context") and "A3_unverified_environment_not_causal" not in s["uncertainty_flags"]:
            s["uncertainty_flags"].append("A3_unverified_environment_not_causal")
        s["scenario_effects_enabled"] = bool(enable_hypothetical_effects)
        if enable_hypothetical_effects and "environment_effects_are_hypothetical" not in s["uncertainty_flags"]:
            s["uncertainty_flags"].append("environment_effects_are_hypothetical")
        # Slow trait drift; AR(1) covariance retention is an assumption, not a scale estimate.
        rho = PARAMS["trait_monthly_retention"]
        innovations = [normal(seed, "trait_month_factor", month, i) for i in range(3)]
        for name, loads in PARAMS["trait_loadings"].items():
            innovation = sum(x*y for x, y in zip(loads, innovations)) + math.sqrt(1-sum(x*x for x in loads))*normal(seed, "trait_month_residual", month, name)
            s["latent_state"][name] = rho*s["latent_state"][name] + math.sqrt(1-rho*rho)*innovation
        # Stationary marginal z-score evolution. Correlated innovations retain the assumed joint law.
        rho = PARAMS["growth_z_monthly_retention"]
        length_noise = normal(seed, "growth", month, "length")
        noises = {"length": length_noise}
        for name, loading in [("weight", PARAMS["growth_weight_length_loading"]), ("head", PARAMS["growth_head_length_loading"])]:
            noises[name] = loading*length_noise + math.sqrt(1-loading*loading)*normal(seed, "growth", month, name)
        for name in s["physical_health"]["growth_z"]:
            s["physical_health"]["growth_z"][name] = rho*s["physical_health"]["growth_z"][name] + math.sqrt(1-rho*rho)*noises[name]
        dev = s["developmental_state"]
        for name in DOMAINS:
            speed = s["transition_parameters"]["development_speed"][name]
            noise = math.exp(PARAMS["development_progress_noise_sd"]*normal(seed, "development", month, name))
            multiplier = 1.0
            if enable_hypothetical_effects and name in ["receptive_language", "expressive_language"]:
                multiplier += PARAMS["hypothetical_scenario"]["language_opportunity_progress_multiplier"]*env.get("language_opportunities", 0)
            dev["progress"][name] += days/30.4375*speed*noise*multiplier
        new_milestones = []
        if enable_hypothetical_effects:
            dev["hypothetical_clock_offset_months"] += days/30.4375*PARAMS["hypothetical_scenario"]["language_opportunity_progress_multiplier"]*env.get("language_opportunities",0)
        for name, (domain, threshold, prerequisites) in PARAMS["milestones"].items():
            effective_age = (end-birth).days/30.4375
            if domain in ["expressive_language","receptive_language"]:
                effective_age += dev["hypothetical_clock_offset_months"]
            if name not in dev["milestones"] and effective_age >= s["transition_parameters"]["milestone_onset_targets_months"][name] and all(x in dev["milestones"] for x in prerequisites):
                # Interval-censored onset: never invent an exact day from monthly observation.
                dev["milestones"][name] = {"onset_interval": [start.isoformat(), end.isoformat()],
                    "age_days_interval": [(start-birth).days, (end-birth).days],
                    "evidence": "same_source_calibration_and_measurement_model_dependent" if name in reference()["milestone_fits"] else "game_scenario_uncalibrated"}
                new_milestones.append(name)
        # Submonthly state: exact AR decay over <=7-day segments, NOT a daily behavior log.
        date = start
        week_behaviors = []
        while date < end:
            next_date = min(date + dt.timedelta(days=7), end)
            span = (next_date-date).days
            age = (next_date-birth).days/30.4375
            traits = s["latent_state"]
            target = {"distress": logistic(-1.0+0.4*traits["reactivity"]-0.2*traits["soothability"]),
                      "fatigue": 0.3, "hunger": logistic(-0.6+0.2*traits["feeding_reactivity"]),
                      "arousal": logistic(-0.3+0.3*traits["activity"]),
                      "settling": logistic(0.1+0.35*traits["soothability"]+0.01*age),
                      "sleep_pressure": 0.35}
            if enable_hypothetical_effects:
                target["fatigue"] += PARAMS["hypothetical_scenario"]["sleep_disruption_to_fatigue"]*env.get("sleep_disruption", 0)
                target["distress"] += PARAMS["hypothetical_scenario"]["responsive_episode_to_distress"]*env.get("responsive_episode", 0)
            retention = PARAMS["short_state_daily_retention"]**span
            for name, mean in target.items():
                noise = PARAMS["short_state_daily_noise_sd"]*math.sqrt(1-retention*retention)*normal(seed, "short_state", next_date.isoformat(), name)
                s["emotion_regulation"][name] = unit(mean + retention*(s["emotion_regulation"][name]-mean) + noise)
            for caregiver, relation in s["caregiver_relationships"].items():
                episodes = env.get("caregivers", {}).get(caregiver, {}).get("contact_episodes_per_day")
                if episodes is None:
                    continue  # Unknown contact is missing, never zero and never inferred from employment.
                if episodes > 0:
                    relation["contact_episodes"] += episodes*span
                    relation["last_contact_date"] = next_date.isoformat()
                    relation["familiarity"] = 1-(1-relation["familiarity"])*math.exp(-episodes*span/PARAMS["familiarity_time_constant_days"])
                else:
                    relation["familiarity"] *= 2**(-span/PARAMS["familiarity_half_life_days"])
            em = s["emotion_regulation"]
            probs = {"crying": logistic(-1.0+2*em["distress"]+0.5*em["hunger"]),
                     "settles_after_comfort": logistic(-0.2+1.3*em["settling"]-em["distress"]),
                     "orients_to_unfamiliar_object": logistic(0.2+0.45*traits["approach"]-0.4*traits["inhibition"]-em["fatigue"]),
                     "looks_toward_voice": logistic(0.1+0.3*traits["social_orientation"]-0.2*em["fatigue"]),
                     "difficulty_settling": logistic(-0.6+em["fatigue"]-0.4*traits["sleep_regularity"]),
                     "takes_independent_steps": 0.65 if "walking_independently" in dev["milestones"] else 0.0,
                     "uses_contextual_word": 0.65 if "first_contextual_word" in dev["milestones"] else 0.0}
            # A capacity first crossing in this monthly interval is not assumed present
            # in the preceding weeks. Only the endpoint sample can show a new skill.
            if next_date < end:
                for milestone, signal in [("walking_independently", "takes_independent_steps"),
                                           ("first_contextual_word", "uses_contextual_word")]:
                    if milestone in new_milestones:
                        probs[signal] = 0.0
            behavior = {"date": next_date.isoformat(), "sampling": "one_synthetic_situation_per_segment_not_daily_prevalence",
                        "context": env.get("context", "home"),
                        "signals": {name: uniform(seed, "behavior", next_date.isoformat(), name)<p for name, p in probs.items()},
                        "caregiver_signals": {}}
            for caregiver, relation in s["caregiver_relationships"].items():
                episodes = env.get("caregivers", {}).get(caregiver, {}).get("contact_episodes_per_day")
                if episodes is not None and episodes > 0:
                    probability = logistic(-0.2+relation["familiarity"]-em["distress"]+0.2*traits["social_orientation"])
                    behavior["caregiver_signals"][caregiver] = {
                        "orients_to_this_caregiver": uniform(seed, "caregiver_response", next_date.isoformat(), caregiver)<probability}
            week_behaviors.append(behavior)
            date = next_date
        s["observed_behaviors"] = week_behaviors
        memory = s["experience_memory"]["contexts"]
        for name in memory:
            memory[name]["strength"] *= 2**(-days/PARAMS["procedural_familiarity_half_life_days"])
        context = env.get("context", "home")
        if context not in memory:
            memory[context] = {"strength": 0.0, "exposure_days": 0, "last_date": None}
        memory[context].update(strength=1-(1-memory[context]["strength"])*math.exp(-days/30),
                               exposure_days=memory[context]["exposure_days"]+days, last_date=end.isoformat())
        s.update(as_of_date=end.isoformat(), elapsed_months=month, age_days=(end-birth).days,
                 calendar_months_crossed=(end.year-birth.year)*12+end.month-birth.month)
        self._update_physical()
        reports = []
        for caregiver in s["caregiver_relationships"]:
            opportunity = env.get("caregivers", {}).get(caregiver, {}).get("observation_opportunity", 0)
            for behavior in week_behaviors:
                observed = {}
                signals = {**behavior["signals"], **behavior["caregiver_signals"].get(caregiver, {})}
                for signal, actual in signals.items():
                    keys = (caregiver, behavior["date"], signal)
                    if uniform(seed, "observation_opportunity", *keys) < opportunity:
                        # Sensitivity=.85 / specificity=.90 are unvalidated measurement assumptions.
                        p_report = 0.85 if actual else 0.10
                        observed[signal] = uniform(seed, "observation_error", *keys) < p_report
                if observed:
                    reports.append({"observer_id": caregiver, "date": behavior["date"],
                        "source": "caregiver_report", "behaviors": observed,
                        "interpretation": "行動の観察記録。内面・病気・愛着の診断ではない。",
                        "uncertain": True})
        s["parent_observations"].extend(reports)
        observed_by = sorted({r["observer_id"] for r in reports})
        event = self._event("ordinary_month", end, list(s["caregiver_relationships"]),
            {"emotion_before": before_emotion, "emotion_after": copy.deepcopy(s["emotion_regulation"]),
             "new_milestones": new_milestones, "environment": env,
             "effects_enabled": bool(enable_hypothetical_effects)}, observed_by,
             "game_scenario" if enable_hypothetical_effects else "unidentified_assumption")
        event["observable_reaction"] = copy.deepcopy(reports)
        for milestone in new_milestones:
            # Capacity onset is latent, so no automatic parental knowledge.
            self._event("latent_milestone", end, [], {"milestone": milestone}, [], "game_scenario_uncalibrated")
        s["history_chain"] = digest([s["history_chain"], month, env, bool(enable_hypothetical_effects),
            s["physical_health"], dev, s["emotion_regulation"], s["caregiver_relationships"]])
        return self

    def advance_to(self, month, environments=None, *, enable_hypothetical_effects=False):
        if type(month) is not int or not self._state["elapsed_months"] <= month <= 24:
            raise ValueError("target must be an integer from current month through 24")
        while self._state["elapsed_months"] < month:
            next_month = self._state["elapsed_months"]+1
            env = environments(next_month) if callable(environments) else (environments or {}).get(next_month, {})
            self.advance_one_month(env, enable_hypothetical_effects=enable_hypothetical_effects)
        return self

    def record_measurement(self, *, observer_id, metric, value, source="clinical_external_input", known_by=()):
        s = self._state
        if not isinstance(observer_id, str) or not observer_id:
            raise ValueError("observer ID required")
        if metric not in ["weight_kg", "length_cm", "head_circumference_cm"]:
            raise ValueError("unsupported measured quantity; no diagnosis inference")
        finite(value, 0.01, 200, metric)
        if set(known_by)-set(s["caregiver_relationships"]):
            raise ValueError("unknown recipient")
        s["measurement_history"].append({"id": f'measurement/{len(s["measurement_history"])}',
             "date": s["as_of_date"], "observer_id": observer_id, "metric": metric,
             "value": value, "source": source, "known_by": list(known_by)})

    def research_snapshot(self, *, compact=False):
        """Trusted internal state. Not a player response."""
        state = dict(self._state)
        if compact:
            # Monthly records are deltas for cumulative ledgers; the initial record carries parameters.
            state["experience_ledger"] = [e for e in state["experience_ledger"] if e["date"] == state["as_of_date"]]
            state["parent_observations"] = [e for e in state["parent_observations"] if e["date"] >
                anniversary(dt.date.fromisoformat(state["child_identity"]["birth_date"]), max(0,state["elapsed_months"]-1)).isoformat()]
        return copy.deepcopy(state)

    def save(self, path):
        body = self.research_snapshot()
        envelope = {"payload": body, "payload_sha256": digest(body)}
        path = Path(path)
        temp = path.with_name(path.name+".tmp")
        temp.write_text(json.dumps(envelope, ensure_ascii=False, sort_keys=True, allow_nan=False), encoding="utf-8")
        temp.replace(path)

    @classmethod
    def load(cls, path):
        envelope = json.loads(Path(path).read_text())
        body = envelope["payload"]
        if digest(body) != envelope["payload_sha256"]:
            raise ValueError("snapshot integrity failure")
        if body["model_version"] != VERSION or body["parameter_sha256"] != PARAMETER_HASH:
            raise ValueError("snapshot requires its original model version and parameters")
        if body["schema_version"] != 1:
            raise ValueError("unsupported schema")
        obj = cls()
        obj._state = body
        return obj


def compare(child_factory, environments_by_name, *, month=24, hypothetical=False):
    """Paired scenarios; not an estimator of real causal treatment effects."""
    out = {}
    for name, environments in environments_by_name.items():
        child = child_factory()
        child.advance_to(month, environments, enable_hypothetical_effects=hypothetical)
        out[name] = child.research_snapshot()
    return {"interpretation": "paired_game_scenarios_not_causal_evidence", "scenarios": out}
