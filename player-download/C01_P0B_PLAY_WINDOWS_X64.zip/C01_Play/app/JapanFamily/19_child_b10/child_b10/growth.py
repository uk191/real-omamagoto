"""WHO LMS marginal reference. The longitudinal copula is NOT WHO evidence."""
import csv
import hashlib
import json
import math
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=1)
def tables():
    sources = json.loads((ROOT / "data/source_acquisition.json").read_text())
    out = {}
    for name in ["weianthro", "lenanthro", "hcanthro"]:
        record = next(x for x in sources if x["id"] == name)
        path = ROOT / record["file"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != record["sha256"]:
            raise ValueError(f"source integrity failure: {name}")
        with path.open() as f:
            out[name] = {(int(r["sex"]), int(r["age"])):
                         tuple(float(r[k]) for k in ["l", "m", "s"])
                         for r in csv.DictReader(f, delimiter="\t")}
    return out


def lms(name, sex, age_days):
    # Exact day tables; no calendar-month/30 conversion for physical growth.
    return tables()[name][(1 if sex == "male" else 2, age_days)]


def from_z(name, sex, age_days, z):
    l, m, s = lms(name, sex, age_days)
    if abs(l) < 1e-12:
        return m * math.exp(s * z)
    if 1 + l * s * z <= 0:
        raise ValueError("LMS transform outside positive support")
    return m * (1 + l * s * z) ** (1 / l)


def to_z(name, sex, age_days, value):
    if not math.isfinite(value) or value <= 0:
        raise ValueError("measurement must be finite and positive")
    l, m, s = lms(name, sex, age_days)
    return math.log(value / m) / s if abs(l) < 1e-12 else ((value / m) ** l - 1) / (l * s)
