"""Read-only A3.0-0.2 saved-history adapter, not an A engine replacement."""
import copy
import datetime as dt

from .engine import Child
from .randomness import digest


def unpack(state):
    return state["final"] if "final" in state and "monthly_history" not in state else state


def from_a3_saved_state(state, *, seed, observation_opportunities=None):
    state = unpack(state)
    if state.get("model_version") != "A3.0-0.2":
        raise ValueError("adapter tested only on A3.0-0.2 saved JSON")
    digest_before = digest(state)
    caregivers = list(state["parents"])
    person_id = state["household"]["index_person_id"]
    person = next(p for p in state["persons"] if p["person_id"] == person_id)
    child = Child.generate(seed=seed, birth_date=state["birth_date"],
        child_id=state["household"]["household_id"]+"/"+person_id,
        caregiver_ids=caregivers, sex=person.get("sex"))
    history = state["monthly_history"]
    if [r["elapsed_months"] for r in history] != list(range(1, len(history)+1)):
        raise ValueError("noncontiguous A3 monthly history")
    dates = [r["month"][:7] for r in history]
    birth = dt.date.fromisoformat(state["birth_date"])
    # A3 records are calendar months, whereas B advances birth anniversaries.
    # Partial-calendar exposure cannot be reconstructed from monthly totals alone.
    if birth.day != 1:
        raise NotImplementedError("partial birth-month A3 exposure requires dated/daily intervals")
    environments = {}
    for i, row in enumerate(history, 1):
        if row.get("model_version") != "A3.0-0.2":
            raise ValueError("mixed A model versions")
        expected_month = (birth.year*12+birth.month-1)+(i-1)
        year, m = divmod(expected_month, 12)
        if dates[i-1] != f"{year:04d}-{m+1:02d}":
            raise ValueError("A3 calendar month gap")
        environments[i] = {
            "caregivers": {c: {"contact_episodes_per_day": None,
                "observation_opportunity": (observation_opportunities or {}).get(c, 0)} for c in caregivers},
            "context": "nursery" if row.get("care", {}).get("status") == "enrolled" else "home_or_other_unresolved",
            "provenance": "A3.0-0.2 monthly saved history; no time-to-attachment effect",
            "a3_context": {"source_month": row["month"], "source_elapsed_months": row["elapsed_months"],
                "household": copy.deepcopy(state["household"]),
                "quality_flags": copy.deepcopy(state.get("quality_flags", {})),
                "time": copy.deepcopy(row.get("time")), "care": copy.deepcopy(row.get("care")),
                "parent_employment": {c: copy.deepcopy(r.get("employment_measurement", {}))
                    for c, r in row["parents"].items()},
                "events": copy.deepcopy(row.get("events", [])),
                "decision_requests": copy.deepcopy(row.get("paused_decisions", [])),
                "income_effect": "not_connected", "contact_hours_effect": "not_connected"}}
    if digest(state) != digest_before:
        raise AssertionError("adapter modified A input")
    return child, environments
