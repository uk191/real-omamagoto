"""B-1.0 research prototype. No Japanese external-validity claim."""
from .engine import Child, VERSION, compare

__all__ = ["Child", "VERSION", "compare"]
