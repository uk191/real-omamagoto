"""Player-facing projection only. No research serialization route."""
import copy


def parent_observations(child, observer_id, *, since_date=None):
    s = child._state
    if observer_id not in s["caregiver_relationships"]:
        raise PermissionError("observer not registered")
    observations = [r for r in s["parent_observations"] if r["observer_id"] == observer_id
                    and (since_date is None or r["date"] >= since_date)]
    measurements = []
    for row in s["measurement_history"]:
        if observer_id in row["known_by"] and (since_date is None or row["date"] >= since_date):
            measurements.append({k: row[k] for k in ["id", "date", "metric", "value", "source", "observer_id"]})
    return copy.deepcopy({"child_id": s["child_identity"]["child_id"], "as_of_date": s["as_of_date"],
                          "observations": observations, "measurements": measurements})
