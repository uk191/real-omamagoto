"""Japanese 2023 marginal-reference scenario; not a 2026 birth-cohort model."""
import bisect
import json
import math
import statistics
from functools import lru_cache

from .growth import ROOT
from .randomness import normal, uniform


@lru_cache(maxsize=1)
def reference():
    return json.loads((ROOT/"data/japan_reference.json").read_text())


@lru_cache(maxsize=6)
def curves(metric,sex):
    return sorted([r for r in reference()["growth_quantiles"] if r["metric"]==metric and r["sex"]==sex],key=lambda r:r["age_days_anchor"])


def interpolate(x,xs,ys):
    i=max(0,min(len(xs)-2,bisect.bisect_right(xs,x)-1))
    return ys[i]+(ys[i+1]-ys[i])*(x-xs[i])/(xs[i+1]-xs[i])


ZKNOTS=[statistics.NormalDist().inv_cdf(p) for p in [.03,.10,.25,.5,.75,.9,.97]]
METRICS={"weianthro":"weight","lenanthro":"length","hcanthro":"head"}


@lru_cache(maxsize=6000)
def day_quantiles(name,sex,age_days):
    rows=curves(METRICS[name],sex)
    times=[r["age_days_anchor"] for r in rows]
    if not 0<=age_days<=times[-1]:raise ValueError("Japanese reference interpolation outside available anchors")
    # Log-quantile interpolation preserves positivity and quantile ordering.
    return [math.exp(interpolate(age_days,times,[math.log(r["values"][i]) for r in rows])) for i in range(7)]


def from_z(name,sex,age_days,z):
    values=day_quantiles(name,sex,age_days)
    # Tail extrapolation beyond p3/p97 is an assumption, not observed extremes.
    return math.exp(interpolate(z,ZKNOTS,[math.log(v) for v in values]))


def to_z(name,sex,age_days,value):
    if not math.isfinite(value) or value<=0:raise ValueError("positive finite measurement required")
    values=day_quantiles(name,sex,age_days)
    return interpolate(math.log(value),[math.log(v) for v in values],ZKNOTS)


def term_birth_draw(seed,sex,gestation_days,residuals):
    rows=[r for r in reference()["birth_conditional_moments"]
          if r["metric"]=="weight" and 37<=r["gestation_week"]<=41
          and (sex is None or sex==r["sex"])
          and (gestation_days is None or gestation_days//7==r["gestation_week"])]
    target=uniform(seed,"birth_joint_sex_week")*sum(r["n"] for r in rows)
    chosen=rows[-1]
    for row in rows:
        target-=row["n"]
        if target<0:chosen=row;break
    sex=chosen["sex"];week=chosen["gestation_week"]
    if gestation_days is None:
        gestation_days=week*7+int(uniform(seed,"gestation_day_within_week")*7)
    values={};provenance={}
    for metric in ["weight","length","head"]:
        row=next(r for r in reference()["birth_conditional_moments"] if r["metric"]==metric and r["sex"]==sex and r["gestation_week"]==week)
        mean=row["mean"]/1000 if metric=="weight" else row["mean"]
        sd=row["sd"]/1000 if metric=="weight" else row["sd"]
        sigma=math.sqrt(math.log1p((sd/mean)**2));mu=math.log(mean)-sigma*sigma/2
        values[metric]=math.exp(mu+sigma*residuals[metric])
        provenance[metric]={"source_id":row["source_id"],"cell_range":row["cell_range"],"n":row["n"],"mean":mean,"sd":sd,
                            "shape":"lognormal moment matching; unidentified shape and cross-trait covariance"}
    return sex,gestation_days,values,provenance
