"""Keyed random streams: inspection and unrelated draws cannot shift trajectories."""
import hashlib
import json
import math


def uniform(seed, stream, *keys):
    payload = json.dumps([seed, stream, *keys], ensure_ascii=False, separators=(",", ":"))
    bits = int.from_bytes(hashlib.sha256(payload.encode()).digest()[:8], "big") >> 11
    return (bits + 0.5) / (2**53)


def normal(seed, stream, *keys):
    u = uniform(seed, stream, *keys, 0)
    v = uniform(seed, stream, *keys, 1)
    return math.sqrt(-2 * math.log(u)) * math.cos(2 * math.pi * v)


def digest(value):
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(data.encode()).hexdigest()
