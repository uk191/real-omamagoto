"""Executable metadata catalogue; assumptions are not empirical findings."""
import csv
import hashlib
import importlib.metadata
import json
import shutil
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from child_b10.engine import PARAMS,TRAITS,DOMAINS,VERSION,PARAMETER_HASH


def main():
    definitions={
        'activity':'運動・覚醒の活動傾向の潜在的な個人差',
        'approach':'未知刺激へ注意・行動を向ける傾向',
        'inhibition':'未知場面で行動が控えられる傾向',
        'reactivity':'不快刺激への情動反応傾向',
        'sensory_sensitivity':'感覚刺激への反応の個人差（本版では保持のみ）',
        'distress_persistence':'反応の持続傾向（本版では保持のみ）',
        'soothability':'慰めの場面で鎮静しやすい傾向',
        'attention_orientation':'注意定位の個人差（本版では保持のみ）',
        'attention_persistence':'注意持続の個人差（本版では保持のみ）',
        'sleep_regularity':'生活リズムの潜在傾向。睡眠時間や医学的障害ではない',
        'feeding_reactivity':'空腹・摂食関連の反応傾向。摂取量や栄養充足ではない',
        'social_orientation':'人の声などへの定位傾向',
        'exploration':'探索の潜在傾向（本版では保持のみ）'}
    rows=[]
    def add(path,layer,definition,unit,distribution,timescale,evidence,source,observation,gap,use):
        rows.append(dict(variable_id=path,layer=layer,definition_ja=definition,unit=unit,
             distribution=distribution,timescale=timescale,evidence_class=evidence,source=source,
             measurement_or_observation=observation,unidentified=gap,game_use=use,scope='0–24months only'))
    add('birth_conditions.gestation_days','A','出生時在胎日数','day',
        'sex×completed_week hospital weight-count categorical conditioned37..41; withinweek uniform',
        'birth','partially_identified','2023 table47 weight counts; not all-livebirth register',
        'external birth record when supplied','sample selection; withinweek days; multiplicity conditional distribution','physical input; no diagnosis')
    for path,unit in [('weight_kg','kg'),('length_cm','cm'),('head_circumference_cm','cm')]:
        add('physical_health.'+path,'A/B','体格の潜在的参照軌道。医療測定値とは別',unit,
            'birth: sex×week conditional lognormal moment match; growth: Japanese2023 quantile interpolation',
            'monthly/days','same_source_calibrated; partially_identified',
            'tables1–3 and47; data/japan_reference.json cell coordinates',
            'measurement_history only when explicitly provided',
            'longitudinal copula; nonterm/multiple births; 2026 transport; tails beyondp3/p97',
            'body trajectory and clinical measurement input; no impairment/value score')
    for name in TRAITS:
        add('initial_dispositions/latent_state.'+name,'A/B',definitions[name],'arbitrary latent z; NOT scale score',
            'three-factor multivariate Gaussian; marginalN(0,1); AR(1) retention.995',
            'initial archive fixed; current tendency slow monthly drift','unidentified_assumption; measurement_model_dependent',
            'conceptual motivation only: IBQ-R/ECBQ Japanese-use studies PMID22897933/39234187; NOT covariance estimates',
            'no validated birth assessment; indirect noisy behavior reports only',
            'birth prior, factor loadings, persistence and behavior coefficients unidentified',
            'retained only' if '保持のみ' in definitions[name] else 'short state/behavior scenario')
    for name in DOMAINS:
        add('developmental_state.progress.'+name,'B',name+' の成熟時計の研究用代理量','arbitrary developmental month units',
            'correlated lognormal individual speed × positive noisy day increment','monthly',
            'game_scenario','parameters.json; not a psychometric developmental quotient',
            'not visible to parent; five uncalibrated proxy milestone thresholds only',
            'not standardized ability, IQ, clinical developmental age or verified longitudinal process',
            'future process placeholder and scenario progress; seven calibrated milestones use separate CDF sampler')
    for name in PARAMS['milestones']:
        calibrated=name in ['head_control','rolling','sitting_unsupported','crawling','standing_with_support','walking_independently','first_contextual_word']
        add('developmental_state.milestones.'+name,'B',name+' の能力獲得区間代理','date interval / attained',
            'lognormal CDF calibrated to parent report' if calibrated else 'uncalibrated threshold / random speed',
            'monthly interval censored','same_source_calibrated; measurement_model_dependent' if calibrated else 'game_scenario',
            '2023 table12/13; fit and raw cell coordinates' if calibrated else 'parameters.json; no empirical timing claim',
            'behavior opportunity plus reporting error; capacity not automatically known',
            'cross-sectional report to latent onset; prereq and cross-domain copula; bin age distribution',
            'observed steps/contextual words when sampled; other milestones retained research events')
    for name in ['distress','fatigue','hunger','arousal','settling','sleep_pressure']:
        add('emotion_regulation.'+name,'C',name+' の短期状態代理','arbitrary0..1',
            'bounded AR process; daily retention.55 evaluated in <=7day segments',
            'days; four/five samples per month','unidentified_assumption; game_scenario','engine.py explicit coefficients',
            'crying, settling, orientation; unvalidated sensitivities/specificities',
            'not a clinically calibrated emotion/physiology index; no feeding or sleep-hours measurement',
            'contextual variation in behavior; no welfare or parenting score')
    add('caregiver_relationships.{person}.familiarity','D','養育者別の接触に伴う慣れの記憶代理。愛着安全性ではない','arbitrary0..1',
        'saturating contact-episode familiarity; half-life60days on explicit zero contact; missing contact leaves value unknown/no update',
        'days','game_scenario','parameters.json; NO contact-hour attachment effect',
        'caregiver-specific orientation under explicit contact; no attachment classification',
        'time constant, decay, response curve unidentified','familiar person reactions only')
    add('experience_memory.contexts','E','場面の頻度・直近性・慣れの履歴代理','days,date,arbitrary strength',
        'exponential forgetting plus repeated exposure; no adult episodic memory',
        'days','game_scenario','PMID24532837 conceptual only; half-life30days is NOT its estimate',
        'not reported as infant recollection','does not yet drive behavior; retained research history','future contextual adaptation')
    add('experience_ledger','E','研究用の出生・平凡な月・能力獲得の記録','event',
        'deterministic IDs and ordered event deltas','monthly','engineering_record','engine.py',
        'known_by flags; latent milestone never automatically parent-known',
        'not child autobiographical memory','family record/research audit')
    add('observed_behaviors','F','外に表れたと仮定する真の行動サンプル','boolean situation',
        'Bernoulli logistic behavior; one synthetic situation per <=7day segment','submonthly',
        'measurement_model_dependent; game_scenario','engine.py; no clinical behavioral prevalence calibration',
        'parent may miss or misinterpret','opportunity weights and outcome probabilities unidentified','parent projection input')
    add('parent_observations','F','観察機会と報告誤差を通った養育者別記録','report',
        'opportunity × sensitivity.85/specificity.90; assumed, not validated instrument',
        'submonthly','measurement_model_dependent','player_api.py whitelist; simulation error model',
        'parent-facing observable response only','observer sampling/misclassification unvalidated','player information')
    add('measurement_history','F','医療・第三者が測った値の外部入力','metric-specific',
        'explicit supplied measurement; no fabricated clinic visits','dated external input',
        'external_input','caller-provided provenance and known recipients',
        'only informed caregivers receive it','no diagnostic assessment workflow implemented','third-party reports')
    target=ROOT/'data/variable_ledger.csv'
    with target.open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    relations=[
        ('sex+gestation_week','birth_body','conditional_marginal_moments','same_source_calibrated; partially_identified','table47','hospital selection; lognormal shape and body copula not identified'),
        ('age_days+physical_rank','body_size','marginal_reference_interpolation','same_source_calibrated','tables1–3','within-bin age and longitudinal transport not identified'),
        ('age','7_milestone_report_proxies','cross_sectional_CDF','same_source_calibrated; measurement_model_dependent','table12/13','not observed latent onset; no design uncertainty'),
        ('maternal_soothing+distress','attention_regulation','longitudinal_association_not_applied','longitudinal_association','PMID39234187 N1892','SEM beta is not a randomized individual child effect'),
        ('threat_disengagement','negative_affect','longitudinal_association_not_applied','longitudinal_association','PMID22897933 N26','small sample; age12–36; not a birth correlation matrix'),
        ('sensitivity','attachment_security','observational_association_not_applied','longitudinal_or_concurrent_association','PMID9306636','r.24 is not an hourly attachment gain'),
        ('video_feedback_intervention','parental_sensitivity','intervention_package_not_applied','causal_effect_supported_for_specific_intervention','PMID31782528','SMD.34; outcome/population/time-specific; attachment evidence very low'),
        ('paternal_sensitivity','father_infant_attachment','association_not_applied','association','PMID22004434','r.12 not a generic relationship-state coefficient'),
        ('milk_feeding_type','sleep','association_not_applied','partially_identified','PMID34836365','inconsistent observational definitions; no direct feeding-policy effect'),
        ('early_experience','autobiographical_recall','developmental_explanation_not_applied','explanatory_hypothesis','PMID24532837','animal/human evidence; no numeric adult recall curve inferred'),
        ('contact_episodes','caregiver_familiarity','saturating_memory_scenario','game_scenario','parameters.json','not attachment; missing inputs not imputed from active-care hours'),
        ('familiarity+social_orientation+short_distress','caregiver_orientation','logistic_response_scenario','game_scenario','engine.py','unvalidated behavior probability'),
        ('latent_traits+short_state','behavior','measurement_scenario','measurement_model_dependent','engine.py','no validated item thresholds'),
        ('behavior+opportunity+report_error','parent_report','measurement_scenario','measurement_model_dependent','engine.py','sens.85/spec.90 are arbitrary'),
        ('sleep_disruption','fatigue','optional_effect','game_scenario','parameters.json','default off; .22 not causal estimate'),
        ('language_opportunities','language_clock','optional_effect','game_scenario','parameters.json','default off; .08 not SEM beta or intervention effect'),
        ('parent_income+education','innate_ability','no_connection','not_implemented','adapter_a3.py','no deterministic socioeconomic ability mapping'),
        ('A_active_care_hours','attachment_security','no_connection','unidentified_assumption_not_applied','adapter_a3.py','no hour-to-attachment function'),
        ('child_behavior','parent_decision','interface_direction_only','not_implemented','docs/model_design.md','no empirical bidirectional parent-response policy implemented')]
    links=[dict(zip(['from','to','relation','evidence_class','source','limitation'],r)) for r in relations]
    (ROOT/'data/relationship_ledger.json').write_text(json.dumps(links,ensure_ascii=False,indent=2))
    articles=json.loads((ROOT/'data/literature_metadata.json').read_text())
    notes={
        '9306636':('観察研究のメタ分析。母の応答性と愛着に関連があるが、接触時間に対する個人別増分は得られない。','observational_association'),
        '12696839':('介入パッケージのメタ分析。特定の介入と転帰の効果を、日常の育児時間係数へ変換しない。','intervention_meta_analysis'),
        '24532837':('乳児期健忘と記憶痕跡に関する説明レビュー。乳児の成人同様の自伝的回想は仮定しない。','explanatory_review'),
        '22897933':('日本版IBQ-R/ECBQを使用した26児・12〜36か月の縦断研究。出生時の多変量分布や日本版尺度全体の独立妥当性検証ではない。','Japanese_longitudinal_association'),
        '39234187':('JECSサブコホート1892組、6・24か月、SEMによる調整と養育者の関連。βをゲームの因果効果に転用しない。','Japanese_longitudinal_association'),
        '36049373':('6〜24か月の視覚的注意と気質の縦断的関連。潜在状態から診断名を生成する根拠にはしない。','longitudinal_association'),
        '35455866':('ベトナム292母子・3〜18か月のIBQR-VSF因子構造・測定不変性。日本の尺度検証・出生時尺度ではない。','overseas_scale_validation'),
        '34836365':('12か月未満6225児・21論文の睡眠と授乳のレビュー。用語・研究方法の不均一性があり、乳汁選択の固定効果を置かない。','systematic_review'),
        '22004434':('父の応答性と父子の愛着のメタ分析。関係は養育者ごとに区別するが、好感度へ換算しない。','observational_meta_analysis'),
        '31782528':('22研究・1889組の介入レビュー。応答性の根拠と、測定法で異なる愛着の低確実性を分離する。','intervention_systematic_review')}
    for article in articles['articles']:
        abstract=article.pop('abstract',None)
        if abstract is not None:
            article['abstract_sha256']=hashlib.sha256(json.dumps(abstract,ensure_ascii=False).encode()).hexdigest()
        article['research_note_ja'],article['evidence_class']=notes[article['pmid']]
        article['abstract_review_status']='abstract_and_metadata_reviewed; fulltext_not_reviewed'
        article['numeric_effect_in_engine']=False
    (ROOT/'data/literature_metadata.json').write_text(json.dumps(articles,ensure_ascii=False,indent=2))
    raw=ROOT/'data/raw/literature.xml'
    if raw.exists():
        cache=Path('/workspace/scratch/b10_research_cache');cache.mkdir(exist_ok=True)
        shutil.copy2(raw,cache/'literature.xml');raw.unlink()
    requirements=[]
    for pkg in ['numpy','scipy','openpyxl','xlrd','matplotlib','jsonschema']:
        requirements.append(pkg+'=='+importlib.metadata.version(pkg))
    (ROOT/'requirements-research.txt').write_text('\n'.join(requirements)+'\n')
    categories=['independently_supported','same_source_calibrated','longitudinal_association',
        'causal_effect_supported','measurement_model_dependent','partially_identified',
        'unidentified_assumption','game_scenario']
    (ROOT/'data/evidence_classes.json').write_text(json.dumps({'classes':categories,
        'rule':'classes apply per relationship/quantity, not to the entire runnable program; trial completion is not external validity',
        'unverified_sources':['Dedicated Japanese IBQ-R/ECBQ validation full texts and usage/licensing terms',
            'WHO motor original windows table; site403, no numeric values borrowed',
            'IPSS relevant child-person data; redirect-only entry not confirmed',
            'latest 21st-century cohort detailed infant outcome tables not yet extracted']},ensure_ascii=False,indent=2))
    print(json.dumps({'variables':len(rows),'relationship_groups':len(links),'literature_abstracts_reviewed':len(articles['articles']),'model':VERSION,'parameter_sha256':PARAMETER_HASH}))


if __name__=='__main__':main()
