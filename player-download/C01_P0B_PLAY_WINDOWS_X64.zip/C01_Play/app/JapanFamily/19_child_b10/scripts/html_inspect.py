from html.parser import HTMLParser


class Document(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.links=[]
        self.text=[]
        self.current=None
        self.skipping=0
        self.feed(source)

    def handle_starttag(self,tag,attrs):
        if tag in ['script','style']:
            self.skipping+=1
        if tag=='a':
            self.current=[dict(attrs).get('href',''),'']

    def handle_endtag(self,tag):
        if tag in ['script','style']:
            self.skipping=max(0,self.skipping-1)
        if tag=='a' and self.current is not None:
            self.links.append(tuple(self.current));self.current=None

    def handle_data(self,data):
        if self.skipping:
            return
        data=data.strip()
        if data:
            self.text.append(data)
            if self.current is not None:
                self.current[1]+=' '+data
