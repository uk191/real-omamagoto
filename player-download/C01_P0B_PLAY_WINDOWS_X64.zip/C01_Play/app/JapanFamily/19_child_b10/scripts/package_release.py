"""Save explicitly pre-integration archives. This does not publish an environment."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from child_b10.engine import VERSION,PARAMETER_HASH


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def main():
    out=ROOT.parents[1]/'artifacts';out.mkdir(exist_ok=True)
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts
           and not p.name.endswith(('.tmp','.pending.sqlite'))]
    hashes={str(p.relative_to(ROOT.parents[1])):sha(p) for p in files}
    receipts=[]
    for label,include_db in [('B1.0_PREINTEGRATION_CODE_AND_REPORTS',False),('B1.0_PREINTEGRATION',True)]:
        selected=[p for p in files if include_db or p.suffix!='.sqlite']
        target=out/(label+'.zip')
        if target.exists():raise FileExistsError('Preserve prior release archive: '+str(target))
        manifest={'model_version':VERSION,'parameter_sha256':PARAMETER_HASH,
            'formal_A_integrated':False,'release_accepted':False,'includes_population_database':include_db,
            'files':{str(p.relative_to(ROOT.parents[1])):hashes[str(p.relative_to(ROOT.parents[1]))] for p in selected}}
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True) as z:
            for p in selected:z.write(p,str(p.relative_to(ROOT.parents[1])))
            z.writestr('MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        receipt={'file':target.name,'sha256':sha(target),'bytes':target.stat().st_size,
            'members':len(selected)+1,'includes_population_database':include_db,'formal_A_integrated':False}
        receipts.append(receipt);print(json.dumps(receipt),flush=True)
    (out/'B1.0_PREINTEGRATION_ARCHIVES.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
