"""Normalize pinned Japanese original XLSX with cell-level provenance.

Marginal percentiles and cross-sectional parent reports do not identify joint
longitudinal biological trajectories. Fits below explicitly retain that limit.
"""
import hashlib
import json
import math
import statistics
from pathlib import Path

import numpy as np
import openpyxl
from scipy.optimize import least_squares
from scipy.special import ndtr

ROOT = Path(__file__).resolve().parents[1]


def sheet(suffix):
    ident = "000040240"+str(suffix)
    source = next(x for x in json.loads((ROOT/"data/jp_tables_acquisition.json").read_text()) if x["id"] == ident)
    path = ROOT/source["file"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == source["sha256"]
    return openpyxl.load_workbook(path, data_only=True).active, ident


def main():
    quantiles = []
    for suffix, metric in [(361,"weight"),(362,"length"),(363,"head")]:
        s, ident = sheet(suffix)
        for row in range(6, s.max_row+1):
            label = s.cell(row,1).value
            if not isinstance(label,str) or not isinstance(s.cell(row,2).value,(float,int)):
                continue
            normalized = label.translate(str.maketrans("０１２３４５６７８９", "0123456789"))
            if "出生時" in label: day=0.; interval=[0.,0.]
            elif "日" in normalized:
                day=float(normalized.replace("日",""));interval=[day,day]
            else:
                # Original tables publish monthly bins <1 year and 6-month bins >=1 year.
                import re
                match=re.search(r"(?:(\d+)年)?(\d+)～(\d+)月",normalized)
                if not match:raise ValueError(label)
                years,lo,hi=match.groups();lo=int(lo);hi=int(hi)
                # Rows with omitted year below age1 are consecutive; later rows state year.
                y=int(years or 0)
                lo += y*12;hi += y*12
                interval=[lo*30.4375,hi*30.4375]
                day=sum(interval)/2
            if day > 27*30.4375:
                continue
            for sex, start in [("male",2),("female",9)]:
                vals=[float(s.cell(row,c).value) for c in range(start,start+7)]
                assert all(a<b for a,b in zip(vals,vals[1:])), (label,vals)
                quantiles.append({"metric":metric,"sex":sex,"age_days_anchor":day,
                    "published_age_label":label,"published_age_days_interval":interval,
                    "percentiles":[.03,.10,.25,.50,.75,.90,.97],"values":vals,
                    "source_id":ident,"cell_range":f'{s.title}!{s.cell(row,start).coordinate}:{s.cell(row,start+6).coordinate}',
                    "temporal_interpolation":"bin midpoint using30.4375days/month; unidentified within-bin age mix"})
    births = []
    s, ident=sheet(407)
    metric=None
    for row in range(6,42):
        if s.cell(row,1).value is not None:
            metric={"体重":"weight","身長":"length","胸囲":"chest","頭囲":"head"}[s.cell(row,1).value]
        week=int(s.cell(row,2).value)
        for sex,start in [("male",3),("female",6)]:
            births.append({"metric":metric,"sex":sex,"gestation_week":week,
                          "n":int(s.cell(row,start).value),"mean":float(s.cell(row,start+1).value),
                          "sd":float(s.cell(row,start+2).value),"source_id":ident,
                          "cell_range":f'{s.title}!{s.cell(row,start).coordinate}:{s.cell(row,start+2).coordinate}',
                          "population":"hospital survey infants attending one-month check; selected, not all live births",
                          "distribution_shape":"not_observed; lognormal moment-match assumption"})
    # Fit normal CDF in log age to observed cross-sectional pass proportions.
    # No denominators/design SE are reconstructed from rounded percentages.
    fitted={}
    cases=[(372,2,"head_control"),(372,3,"rolling"),(372,4,"sitting_unsupported"),
           (372,5,"crawling"),(372,6,"standing_with_support"),
           (372,7,"walking_independently"),(373,2,"first_contextual_word")]
    for suffix,col,name in cases:
        s,ident=sheet(suffix);xs=[];ys=[];raw=[]
        for row in range(5,27):
            value=s.cell(row,col).value
            if not isinstance(value,(float,int)):continue
            age=row-5+2.5  # row5=2–3mo, row15=12–13mo; source cell labels retained.
            xs.append(age);ys.append(value/100)
            raw.append({"age_midpoint_months":age,"published_age_bin":s.cell(row,1).value,
                        "pass_proportion":value/100,"cell":f'{s.title}!{s.cell(row,col).coordinate}'})
        x=np.asarray(xs);y=np.asarray(ys)
        fit=least_squares(lambda theta:ndtr((np.log(x)-theta[0])/math.exp(theta[1]))-y,
                          [math.log(float(x[np.argmin(abs(y-.5))])),math.log(.2)],
                          bounds=([math.log(.5),math.log(.03)],[math.log(36),math.log(2)]))
        mu,logsd=fit.x;pred=ndtr((np.log(x)-mu)/math.exp(logsd))
        fitted[name]={"log_mu":float(mu),"log_sd":math.exp(float(logsd)),
                      "median_months":math.exp(float(mu)),"source_id":ident,"raw":raw,
                      "rmse_probability":float(np.sqrt(np.mean((pred-y)**2))),
                      "max_abs_probability_error":float(max(abs(pred-y))),
                      "status":"same_source_calibration_and_measurement_model_dependent",
                      "fit_assumptions":["cross-sectional parent report transported to latent onset CDF",
                                         "bin midpoint rather than integrated within-bin age distribution",
                                         "unweighted least squares; sample design uncertainty unavailable",
                                         "lognormal smooth monotone CDF; cross-sectional reversals are not individual regression"]}
    result={"version":1,"growth_quantiles":quantiles,"birth_conditional_moments":births,
            "milestone_fits":fitted,
            "scope":"Not a nationally validated joint or longitudinal distribution",
            "raw_summary_conflict":{"source":"PDF table9 vs original XLSX table12",
                "cell":"表12!B6", "XLSX_percent":53.333333333333336,"PDF_percent":53.7,
                "resolution":"Use original XLSX value; retain discrepancy; neither estimate is exact latent prevalence"}}
    target=ROOT/"data/japan_reference.json"
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps({"growth_rows":len(quantiles),"birth_moment_rows":len(births),
          "fits":{k:{a:v[a] for a in ['median_months','log_sd','rmse_probability']} for k,v in fitted.items()}},indent=2))


if __name__=="__main__":main()
