"""Audit available attachments; do not substitute reports for unavailable A code."""
import datetime as dt
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    source=Path('/workspace/attachments')
    destination=ROOT/'handover_available'
    destination.mkdir(exist_ok=True)
    rows=[]
    for path in sorted(p for p in source.rglob('*') if p.is_file()):
        data=path.read_bytes()
        entry={'file':path.name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
        if path.suffix=='.zip':
            with zipfile.ZipFile(path) as z:
                entry.update(zip_crc_pass=z.testzip() is None,members=len(z.infolist()),
                    member_sha256={n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()})
        target=destination/path.name
        if target.exists() and target.read_bytes()!=data:raise ValueError('preserve differing existing attachment')
        target.write_bytes(data)
        rows.append(entry)
    validation=json.loads(next(destination.glob('*全国検証*')).read_text())
    report=json.loads(next(destination.glob('*RELEASE*')).read_text())
    audit={'audited_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'available_attachments':rows,
        'formal_integrated_archive':{'file':'A1_A3_日本家庭月次シミュレーション基盤_A3.0-0.2.zip',
           'acquired':False,'failure':'download_file: file exceeds the executor transfer limit of 32 MiB',
           'reported_sha256_only_not_recomputed':report['zip_sha256'],
           'required_action':'Provide original ZIP as byte-split parts each <=32 MiB, or put original ZIP in workspace'},
        'A_summary_from_attachment_not_rerun':validation['summary_v02'],
        'A_database_row_hashes_from_attachment_not_rerun':validation['database_v02'],
        'reported_A_API_checks_not_rerun':report['old_new_monthly_HTTP_APIs'],
        'unverified_A_maternal_unpaid_at18months_birth_weighted':.454,
        'financially_playable':False,'newborn_full_joint_externally_validated':False,
        'old_code_db_API_preservation_verified':False,
        'missing_audit_targets':['JapanFamily/inputs/ゲーム全体仕様と地域モデル構築_完全指示書(1).md',
            'A1_statistics_and_catalogues','A2_family_generator','A2.5_persons_initial_state',
            '17_monthly_A3.0-0.1','18_monthly_v02_A3.0-0.2','original_SQLite_and_all_source_ledgers'],
        'document_instruction_boundary':'Attached old A1 instructions are historical design context; current user request is B-1.0; no old-document command is executed'}
    (ROOT/'results/handover_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    print(json.dumps({'available':len(rows),'formal_archive_acquired':False,'A_regression_status':'not_run_missing_code'}))


if __name__=='__main__':main()
