"""Offline SHA checks; optionally recover missing original inputs over verified TLS."""
import argparse
import hashlib
import json
import urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--fetch-missing',action='store_true');args=parser.parse_args()
    records=[]
    for name in ['source_acquisition.json','jp_tables_acquisition.json','heldout_acquisition.json','correction_acquisition.json']:
        data=json.loads((ROOT/'data'/name).read_text());records.extend(data if isinstance(data,list) else [data])
    for row in records:
        file=ROOT/row['file']
        if not file.exists() and args.fetch_missing:
            data=urllib.request.urlopen(row['url'],timeout=30).read()
            if hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('upstream changed; do not replace expected checksum: '+row['file'])
            file.parent.mkdir(exist_ok=True,parents=True);file.write_bytes(data)
        if hashlib.sha256(file.read_bytes()).hexdigest()!=row['sha256']:raise ValueError('source checksum mismatch: '+row['file'])
    print(json.dumps({'original_source_files_checked':len(records),'all_sha256_match':True}))


if __name__=='__main__':main()
