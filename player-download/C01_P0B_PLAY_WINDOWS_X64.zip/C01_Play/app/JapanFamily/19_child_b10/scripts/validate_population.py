"""10k reference-scenario trajectories, not a national A-connected cohort."""
import argparse
import concurrent.futures
import datetime as dt
import json
import math
import os
import sqlite3
import sys
import time
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from child_b10 import Child, VERSION
from child_b10.engine import DOMAINS, PARAMS, PARAMETER_HASH, TRAITS, anniversary
from child_b10.japan_reference import reference
from child_b10.player_api import parent_observations
from child_b10.storage import DYNAMIC, encode, restore_child
from child_b10.randomness import digest
from scripts.experiments import routine

MILESTONES=list(PARAMS['milestones'])
EMOTIONS=['distress','fatigue','hunger','arousal','settling','sleep_pressure']
FIELDS=['weight_kg','length_cm','head_cm']+[f'trait.{x}' for x in TRAITS]+[f'progress.{x}' for x in DOMAINS]+[f'short.{x}' for x in EMOTIONS]+[f'milestone.{x}' for x in MILESTONES]


def simulate(index):
    seed=1_000_000+index
    # Deterministic test-calendar coverage, not observed monthly seasonality.
    birth=dt.date(2026,1+index%12,1+(index//12)%28).isoformat()
    child=Child.generate(seed=seed,birth_date=birth)
    birth_state=child.research_snapshot();ident=birth_state['child_identity']
    rows=[];vectors=[];constraint_count=0
    previous_progress=None;previous_size=None
    for month in range(25):
        if month:child.advance_one_month(routine(month))
        s=child.research_snapshot(compact=True);ph=s['physical_health'];dev=s['developmental_state']
        if not all(math.isfinite(x) and 0<=x<=1 for x in s['emotion_regulation'].values()):raise AssertionError('short state range')
        if not all(math.isfinite(ph[x]) and ph[x]>0 for x in ['weight_kg','length_cm','head_circumference_cm']):raise AssertionError('physical support')
        if previous_progress and any(dev['progress'][x]<previous_progress[x] for x in DOMAINS):raise AssertionError('maturation regression')
        if previous_size and (ph['length_cm']<previous_size[0] or ph['head_circumference_cm']<previous_size[1]):raise AssertionError('latent physical shrinkage')
        for name in dev['milestones']:
            if not all(pre in dev['milestones'] for pre in PARAMS['milestones'][name][2]):raise AssertionError('prerequisite')
        if s['age_days']!=(dt.date.fromisoformat(s['as_of_date'])-dt.date.fromisoformat(birth)).days:raise AssertionError('calendar')
        if set(s['caregiver_relationships'])!={'mother','father'}:raise AssertionError('caregiver identity')
        previous_progress=dict(dev['progress']);previous_size=(ph['length_cm'],ph['head_circumference_cm'])
        delta={k:s[k] for k in DYNAMIC}
        delta['measurement_history']=s['measurement_history']
        since=(anniversary(dt.date.fromisoformat(birth),month-1)+dt.timedelta(days=1)).isoformat() if month else birth
        public=parent_observations(child,'mother',since_date=since)
        rows.append((ident['child_id'],month,s['age_days'],ph['weight_kg'],ph['length_cm'],ph['head_circumference_cm'],encode(delta),encode(public)))
        vectors.append([ph['weight_kg'],ph['length_cm'],ph['head_circumference_cm']]+[s['latent_state'][x] for x in TRAITS]+[dev['progress'][x] for x in DOMAINS]+[s['emotion_regulation'][x] for x in EMOTIONS]+[float(x in dev['milestones']) for x in MILESTONES])
    s=child._state
    events=s['experience_ledger']
    if [e['date'] for e in events]!=sorted(e['date'] for e in events):raise AssertionError('event chronology')
    if len({e['history_id'] for e in events})!=len(events):raise AssertionError('event IDs')
    # Population measurement errors conditional on an observed opportunity.
    actual={(b['date'],k):v for b in s['observed_behaviors'] for k,v in b['signals'].items()}
    confusion=[0,0,0,0]
    for report in s['parent_observations']:
        for k,reported in report['behaviors'].items():
            if (report['date'],k) in actual:
                true=actual[(report['date'],k)]
                confusion[(2 if true else 0)+(1 if reported else 0)]+=1
    return index,(ident['child_id'],VERSION,seed,birth,ident['sex_for_growth_reference'],'term_hospital_reference_not_national',encode(birth_state)),rows,vectors,{
        'sex':ident['sex_for_growth_reference'],'week':birth_state['birth_conditions']['gestation_days']//7,
        'birth_weight':birth_state['physical_health']['weight_kg'],'birth_length':birth_state['physical_health']['length_cm'],
        'birth_head':birth_state['physical_health']['head_circumference_cm'],
        'constraint_count':s['physical_health'].get('monotonic_constraint_count',0),'confusion':confusion,
        'final_chain':s['history_chain']}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--n',type=int,default=10000)
    parser.add_argument('--workers',type=int,default=3);parser.add_argument('--output',default='results/population_10000')
    args=parser.parse_args()
    if args.n<2 or args.workers<1:raise ValueError('n>=2,workers>=1 required')
    output=Path(args.output).resolve();output.mkdir(exist_ok=True,parents=True)
    target=output/'child_b10.sqlite';temp=output/'child_b10.pending.sqlite'
    if target.exists() or temp.exists():raise FileExistsError('Choose a fresh output directory; never overwrite a prior run')
    started=time.monotonic();connection=sqlite3.connect(temp)
    connection.executescript((ROOT/'data/schema.sql').read_text());connection.execute('PRAGMA journal_mode=DELETE')
    connection.execute('INSERT INTO b10_model VALUES(?,?,?)',(VERSION,PARAMETER_HASH,json.dumps({'population_scope':'term hospital reference; A generator unavailable; not national births','fields':FIELDS})))
    data=np.empty((args.n,25,len(FIELDS)));metadata=[None]*args.n
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        for done,(index,child_row,rows,vectors,meta) in enumerate(pool.map(simulate,range(args.n),chunksize=8),1):
            connection.execute('INSERT INTO b10_child VALUES(?,?,?,?,?,?,?)',child_row)
            connection.executemany('INSERT INTO b10_month VALUES(?,?,?,?,?,?,?,?)',rows)
            data[index]=vectors;metadata[index]=meta
            if done%200==0 or done==args.n:
                connection.commit();print(json.dumps({'completed':done,'target':args.n,'elapsed_seconds':round(time.monotonic()-started,1)}),flush=True)
    distributions={}
    for month in range(25):
        by_field={}
        for i,name in enumerate(FIELDS):
            values=data[:,month,i]
            qs=np.quantile(values,[.01,.03,.1,.25,.5,.75,.9,.97,.99])
            by_field[name]={'mean':float(np.mean(values)),'sd':float(np.std(values,ddof=1)),
                            'quantiles':dict(zip(['p01','p03','p10','p25','p50','p75','p90','p97','p99'],map(float,qs)))}
        distributions[str(month)]=by_field
    trait_slice=slice(3,3+len(TRAITS))
    load=np.array([PARAMS['trait_loadings'][x] for x in TRAITS]);expected_cov=load@load.T
    np.fill_diagonal(expected_cov,1)
    empirical=np.corrcoef(data[:,0,trait_slice],rowvar=False)
    covariance_error=float(np.max(abs(empirical-expected_cov)))
    persistence={name:float(np.corrcoef(data[:,0,3+i],data[:,24,3+i])[0,1]) for i,name in enumerate(TRAITS)}
    birth_calibration=[]
    for row in reference()['birth_conditional_moments']:
        if not 37<=row['gestation_week']<=41 or row['metric']=='chest':continue
        cases=[r for r in metadata if r['sex']==row['sex'] and r['week']==row['gestation_week']]
        values=np.array([r['birth_'+row['metric']] for r in cases]);scale=1000 if row['metric']=='weight' else 1
        mean=row['mean']/scale;sd=row['sd']/scale
        se=sd/math.sqrt(len(values)) if len(values) else None
        birth_calibration.append({'sex':row['sex'],'week':row['gestation_week'],'metric':row['metric'],'generated_n':len(values),
            'source_n':row['n'],'source_mean':mean,'generated_mean':float(np.mean(values)) if len(values) else None,
            'source_sd':sd,'generated_sd':float(np.std(values,ddof=1)) if len(values)>1 else None,
            'mean_MC_z':float((np.mean(values)-mean)/se) if len(values)>=30 else None,'cell':row['cell_range'],
            'MC_check_status':'assessed' if len(values)>=30 else 'unassessed_generated_n_below30',
            'classification':'same_source_moment_calibration_NOT_external_validation'})
    checks={
        'generated_complete':connection.execute('SELECT count(*) FROM b10_child').fetchone()[0]==args.n,
        'monthly_rows':connection.execute('SELECT count(*) FROM b10_month').fetchone()[0]==args.n*25,
        'trait_prior_covariance_max_abs_error_below_0_06':covariance_error<.06 if args.n>=1000 else None,
        'birth_cell_means_within_5_MC_SE':all(abs(x['mean_MC_z'])<5 for x in birth_calibration if x['mean_MC_z'] is not None) if any(x['mean_MC_z'] is not None for x in birth_calibration) else None,
    }
    replays=[]
    for index in sorted({0,args.n//2,args.n-1}):
        ident=connection.execute('SELECT child_id FROM b10_child WHERE seed=?',(1_000_000+index,)).fetchone()[0]
        restored=restore_child(connection,ident,12).advance_to(24,routine)
        final=restore_child(connection,ident,24)
        exact=restored.research_snapshot()==final.research_snapshot()
        replays.append({'seed':1_000_000+index,'stored12_plus12_equals_stored24':exact})
    checks['database_restore_replays']=all(x['stored12_plus12_equals_stored24'] for x in replays)
    integrity=connection.execute('PRAGMA integrity_check').fetchall();fk=connection.execute('PRAGMA foreign_key_check').fetchall()
    checks['SQLite_integrity']=integrity==[('ok',)];checks['SQLite_FK']=not fk
    summary={'version':VERSION,'parameter_sha256':PARAMETER_HASH,'requested_children':args.n,
        'completed24':len(metadata),'child_month_transitions':args.n*24,'stored_states_including_birth':args.n*25,
        'calendar_sampling':'deterministic rotating12 months and days1to28; not birth seasonality',
        'population':'term37to41week hospital-reference scenario; singleton scenario; no severe medical event generator',
        'A47_generator_connected':False,'Japanese_national_external_validity':False,
        'longitudinal_psychological_external_validity':False,'causal_effects_validated':False,
        'checks':checks,'replays':replays,'elapsed_seconds':time.monotonic()-started,
        'growth_monotonic_constraints_total':sum(m['constraint_count'] for m in metadata),
        'growth_constraints_interpretation':'structural positivity/monotonicity correction; can alter target marginals; not an empirical growth law',
        'trait_covariance_theoretical_assumed':expected_cov.tolist(),'trait_covariance_generated':empirical.tolist(),
        'trait_names':TRAITS,'trait_covariance_max_abs_error':covariance_error,
        'trait_persistence_birth_to24':persistence,'trait_persistence_target_assumption':PARAMS['trait_monthly_retention']**24,
        'birth_calibration':birth_calibration,'fields':FIELDS,'distributions':distributions}
    (output/'validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False))
    connection.execute('INSERT INTO b10_validation VALUES(?,?)',('population_summary',json.dumps({k:v for k,v in summary.items() if k!='distributions'},ensure_ascii=False)))
    connection.commit();connection.close();temp.replace(target)
    print(json.dumps({'checks':checks,'database':str(target),'elapsed_seconds':round(summary['elapsed_seconds'],1)}),flush=True)
    if any(value is False for value in checks.values()):sys.exit(1)


if __name__=='__main__':main()
