import copy
import gzip
import json
import sys
import zipfile
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from child_b10 import Child, compare
from child_b10.adapter_a3 import from_a3_saved_state, unpack
from child_b10.player_api import parent_observations
from child_b10.randomness import digest

ROOT = Path(__file__).resolve().parents[1]


def routine(month):
    return {'context':'home','caregivers':{
        'mother':{'contact_episodes_per_day':2,'observation_opportunity':.8},
        'father':{'contact_episodes_per_day':1,'observation_opportunity':.5}},
        'provenance':'explicit fictitious routine; not measured Japanese care or observation rates'}


def write_gzip(path,value):
    with gzip.GzipFile(filename=str(path),mode='wb',mtime=0) as f:
        f.write(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode())


def main():
    out=ROOT/'results/examples';out.mkdir(exist_ok=True,parents=True)
    same_family=[]
    for seed in [104,327,811]:
        child=Child.generate(seed=seed,birth_date='2026-01-17')
        frames=[child.research_snapshot(compact=True)]
        for month in range(1,25):
            child.advance_one_month(routine(month));frames.append(child.research_snapshot(compact=True))
        write_gzip(out/f'child_{seed}_24months.json.gz',{'definition':'research internal truth + separately sampled parent reports; not clinical history','frames':frames})
        child.save(out/f'child_{seed}_final.snapshot.json')
        same_family.append({'seed':seed,'24month_progress':child._state['developmental_state'],
            '24month_temperament':child._state['latent_state'],
            'parent_view':parent_observations(child,'mother')})
    (out/'same_family_different_children.json').write_text(json.dumps(same_family,ensure_ascii=False,indent=2))
    environments={
        'reference':{m:routine(m) for m in range(1,25)},
        'sleep_disruption_language_opportunity':{m:{**routine(m),'sleep_disruption':1,'language_opportunities':1} for m in range(1,25)},
        'caregiver_contact_change':{m:{**routine(m),'caregivers':{
            'mother':{'contact_episodes_per_day':1,'observation_opportunity':.8},
            'father':{'contact_episodes_per_day':2,'observation_opportunity':.5}}} for m in range(1,25)}}
    for hypothetical in [False,True]:
        result=compare(lambda:Child.generate(seed=104,birth_date='2026-01-17'),environments,hypothetical=hypothetical)
        write_gzip(out/f'same_child_environments_effects_{hypothetical}.json.gz',result)
    archive=next((ROOT/'handover_available').glob('*.zip'))
    a3rows=[]
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for name in z.namelist():
            if '/' in name or not name.endswith('.json'):continue
            obj=json.loads(z.read(name));state=unpack(obj);before=digest(state)
            child,environments=from_a3_saved_state(obj,seed=271828,
                observation_opportunities={c:.6 for c in state['parents']})
            frames=[]
            for month in range(1,len(state['monthly_history'])+1):
                child.advance_one_month(environments[month]);frames.append(child.research_snapshot(compact=True))
            assert before==digest(state)
            write_gzip(out/('A3_saved_'+name+'.gz'),{'A_source_sha256':before,'observation_opportunities':'.6 fictitious observation sampling, not inferred from A time grid',
                'scope':'saved-history adapter only; A generator/API not executed','frames':frames})
            a3rows.append({'file':name,'prefecture_code':state['household']['prefecture_code'],
                'household_id':state['household']['household_id'],'months':len(frames),
                'A_input_unchanged':True,'B_chain':child._state['history_chain']})
        fixed_family=json.loads(z.read('urban_first.json'))
        alternatives=[]
        for seed in [104,327,811]:
            child,envs=from_a3_saved_state(fixed_family,seed=seed,
                observation_opportunities={c:.6 for c in fixed_family['parents']})
            frames=[child.research_snapshot(compact=True)]
            for month in range(1,25):
                child.advance_one_month(envs[month]);frames.append(child.research_snapshot(compact=True))
            alternatives.append({'run_id':f'alternative_birth_{seed}', 'seed':seed,'frames':frames})
        write_gzip(out/'same_A_household_different_children.json.gz',{
            'A_initial_family_hash':fixed_family['initial_family_hash'],
            'A_saved_history_sha256':digest(fixed_family),
            'interpretation':'same saved A household and policy path; different hypothetical children; run IDs distinguish worldlines',
            'observation_opportunity':'.6 explicit assumption, not measured time-use conversion',
            'alternatives':alternatives})
    (out/'A3_saved_history_connections.json').write_text(json.dumps({'cases':a3rows,
        'distinct_households':len({r['household_id'] for r in a3rows}),
        'prefectures':sorted({r['prefecture_code'] for r in a3rows}),
        'connected_47prefecture_generator':False,'A_generator_code_available':False},ensure_ascii=False,indent=2))
    print(json.dumps({'A_saved_cases':len(a3rows),'A_saved_child_months':sum(r['months'] for r in a3rows),'representative_children':3}))


if __name__=='__main__':main()
