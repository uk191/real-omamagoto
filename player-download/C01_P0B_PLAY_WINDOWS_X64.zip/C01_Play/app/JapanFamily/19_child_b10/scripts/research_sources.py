"""Fetch candidate authoritative pages, recording failures; never fabricate tables."""
import concurrent.futures
import datetime as dt
import hashlib
import json
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    ("JP_growth", "乳幼児身体発育調査：最新版・原表・対象母集団の確認が必要", "https://www.cfa.go.jp/policies/boshihoken/"),
    ("JP_longitudinal", "21世紀出生児縦断調査：入口、各回の個別原表確認は未了", "https://www.mhlw.go.jp/toukei/list/27-9.html"),
    ("JP_estat", "e-Stat：出生時の在胎週数×体重等の原表取得待ち", "https://www.e-stat.go.jp/"),
    ("JP_ipss", "人口問題研究所：乳児個人モデルに利用できる資料を未特定", "https://www.ipss.go.jp/"),
    ("WHO_motor", "WHO motor milestones：原表未取得、数値を校正に使用しない", "https://www.who.int/tools/child-growth-standards/standards/motor-development-milestones"),
    ("temperament_JP", "日本の乳児気質尺度の妥当性研究を検索：尺度項目は転載しない", "https://pubmed.ncbi.nlm.nih.gov/?term=Japanese+infant+behavior+questionnaire+validation"),
    ("sleep_review", "乳幼児睡眠の系統的レビューを検索：推奨睡眠時間と人口分布を区別", "https://pubmed.ncbi.nlm.nih.gov/?term=infant+sleep+systematic+review+longitudinal"),
    ("language_JP", "日本語の受容・表出言語発達と縦断研究を検索", "https://www.jstage.jst.go.jp/"),
    ("attachment_review", "養育応答性と愛着の縦断研究・介入を別に検索", "https://pubmed.ncbi.nlm.nih.gov/?term=parental+sensitivity+attachment+meta+analysis+infant"),
    ("memory_review", "乳児の記憶・幼児期健忘を検索", "https://pubmed.ncbi.nlm.nih.gov/?term=infant+memory+infantile+amnesia+review"),
]


def fetch(item):
    ident, goal, url = item
    row = {"id":ident,"goal":goal,"url":url,"attempted_utc":dt.datetime.now(dt.timezone.utc).isoformat(),
           "latest_version_confirmed":False,"original_table_confirmed":False,"population_confirmed":False}
    try:
        with urllib.request.urlopen(url,timeout=20) as response:
            data=response.read()
            row.update(http_status=response.status,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),status="entry_page_fetched_not_yet_reviewed")
        path=ROOT/"data/raw"/(ident+".html")
        path.write_bytes(data)
        row["file"]=str(path.relative_to(ROOT))
    except Exception as exc:
        row.update(status="not_acquired",error=str(exc))
    return row


if __name__ == "__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        rows=list(pool.map(fetch,SOURCES))
    (ROOT/"data/research_access_attempts.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    print(json.dumps({"pages_fetched":sum(r["status"]!="not_acquired" for r in rows),"attempted":len(rows)},ensure_ascii=False))
    # Acquisition failure is an explicit nonzero outcome, not a passing research check.
    sys.exit(0 if all(r["status"]!="not_acquired" for r in rows) else 2)
