"""Independent 2010 sample comparisons are descriptive, never a 2026 pass flag."""
import gzip
import json
import math
import os
import sqlite3
import sys
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR','/tmp/b10-matplotlib')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/b10-font-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import openpyxl

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from child_b10.japan_reference import reference,from_z
from child_b10.growth import from_z as who_from_z


def cdf(fit,month):
    return .5*(1+math.erf((math.log(month)-fit['log_mu'])/(fit['log_sd']*math.sqrt(2))))


def main():
    out=ROOT/'results';summary=json.loads((out/'population_10000/validation.json').read_text())
    manifest=json.loads((ROOT/'data/heldout_acquisition.json').read_text())
    row=next(r for r in manifest if r['id']=='000012673583')
    sheet=openpyxl.load_workbook(ROOT/row['file'],data_only=True).active
    names=['head_control','rolling','sitting_unsupported','crawling','standing_with_support','walking_independently']
    comparisons={}
    for name,col in zip(names,range(3,9)):
        points=[]
        for ri in range(6,21):
            cell=sheet.cell(ri,col)
            if not isinstance(cell.value,(float,int)):continue
            month=ri-6+2.5;rate=cell.value/100;pred=cdf(reference()['milestone_fits'][name],month)
            points.append({'age_midpoint_months':month,'observed2010':rate,'B_fit_to2023':pred,
                           'difference':pred-rate,'cell':f'{sheet.title}!R{ri}C{col}'})
        comparisons[name]={'points':points,'classification':'independent2010_crosssectional_sample_different_cohort',
            'RMSE':math.sqrt(sum(p['difference']**2 for p in points)/len(points))}
    first_word_row=next(ri for ri in range(1,sheet.max_row+1) if '7月～8月' in str(sheet.cell(ri,2).value))
    points=[]
    for ri in range(first_word_row,sheet.max_row+1):
        cell=sheet.cell(ri,3)
        if not isinstance(cell.value,(float,int)):continue
        month=ri-first_word_row+7.5;rate=cell.value/100;pred=cdf(reference()['milestone_fits']['first_contextual_word'],month)
        points.append({'age_midpoint_months':month,'observed2010':rate,'B_fit_to2023':pred,
                       'difference':pred-rate,'cell':f'{sheet.title}!R{ri}C3'})
    comparisons['first_contextual_word']={'points':points,'classification':'independent2010_crosssectional_sample_different_cohort',
        'RMSE':math.sqrt(sum(p['difference']**2 for p in points)/len(points))}
    result={'independent_comparisons':comparisons,'national_2026_external_validity':False,
        'interpretation':'No pass/fail: 2010 and2023 populations/time differ; reports not latent ability; design SE unavailable. First-word cohort difference is material.',
        'heldout_source':row}
    (out/'independent_comparisons.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    con=sqlite3.connect('file:'+str(out/'population_10000/child_b10.sqlite')+'?mode=ro',uri=True)
    grouped={(sex,m):[] for sex in ['male','female'] for m in range(25)}
    for sex,m,w,l,h in con.execute('SELECT c.sex,m.month,m.weight_kg,m.length_cm,m.head_cm FROM b10_month m JOIN b10_child c USING(child_id)'):
        grouped[(sex,m)].append([w,l,h])
    con.close();physical=[]
    for (sex,month),values in grouped.items():
        arr=np.array(values)
        for i,(metric,table) in enumerate([('weight_kg','weianthro'),('length_cm','lenanthro'),('head_cm','hcanthro')]):
            original=[from_z(table,sex,month*30.4375,z) for z in [-1.8807936081512509,0,1.8807936081512509]]
            physical.append({'sex':sex,'month':month,'metric':metric,'n':len(arr),
                'generated_p03_p50_p97':np.quantile(arr[:,i],[.03,.5,.97]).tolist(),
                'Japanese2023_reference_p03_p50_p97':original,
                'fraction_outside_reference_p03_p97':float(np.mean((arr[:,i]<original[0])|(arr[:,i]>original[2]))),
                'classification':'same_source_reference_comparison; term_hospital_selection_and_longitudinal_copula_unidentified; no_calibration_pass_claim'})
    (out/'physical_reference_comparisons.json').write_text(json.dumps(physical,ensure_ascii=False,indent=2))
    scenarios={}
    for mode in [False,True]:
        with gzip.open(out/f'examples/same_child_environments_effects_{mode}.json.gz','rt') as f:data=json.load(f)['scenarios']
        a=data['reference'];b=data['sleep_disruption_language_opportunity'];c=data['caregiver_contact_change']
        scenarios[str(mode)]={'hypothetical_effects_enabled':mode,
            'language_progress_delta':b['developmental_state']['progress']['expressive_language']-a['developmental_state']['progress']['expressive_language'],
            'fatigue_delta':b['emotion_regulation']['fatigue']-a['emotion_regulation']['fatigue'],
            'initial_dispositions_identical':a['initial_dispositions']==b['initial_dispositions']==c['initial_dispositions'],
            'physical_trajectories_final_identical':a['physical_health']==b['physical_health']==c['physical_health'],
            'contact_episodes_reference':a['caregiver_relationships'],
            'contact_episodes_changed':c['caregiver_relationships'],
            'interpretation':'Hypothetical coefficients and familiarity-memory mechanics; no established attachment or language intervention effects'}
    (out/'paired_scenario_summary.json').write_text(json.dumps(scenarios,ensure_ascii=False,indent=2))
    figure,axes=plt.subplots(1,2,figsize=(12,4.7))
    for name,color in [('walking_independently','tab:blue'),('first_contextual_word','tab:orange')]:
        fit=reference()['milestone_fits'][name];grid=np.linspace(4,24,250)
        axes[0].plot(grid,[cdf(fit,x) for x in grid],color=color,label=name+' fit (2023 reports)')
        axes[0].scatter([r['age_midpoint_months'] for r in fit['raw']],[r['pass_proportion'] for r in fit['raw']],color=color,s=13)
        pts=comparisons[name]['points'];axes[0].plot([p['age_midpoint_months'] for p in pts],[p['observed2010'] for p in pts],color=color,ls=':',alpha=.6,label=name+' held-out 2010')
    axes[0].set(xlabel='Age in months (bin midpoint assumption)',ylabel='Parent-reported achievement proportion',ylim=(0,1.02),title='Reports do not identify latent acquisition exactly')
    axes[0].legend(fontsize=7)
    female=[r for r in physical if r['sex']=='female' and r['metric']=='weight_kg']
    axes[1].plot([r['month'] for r in female],[r['generated_p03_p50_p97'][1] for r in female],label='Generated term hospital-reference median')
    axes[1].plot(range(25),[from_z('weianthro','female',m*30.4375,0) for m in range(25)],label='Japan 2023 marginal-reference median')
    axes[1].plot(range(25),[who_from_z('weianthro','female',round(m*30.4375),0) for m in range(25)],ls=':',label='WHO median (different reference population)')
    axes[1].set(xlabel='Age in months',ylabel='Weight (kg), female reference',title='Population and longitudinal transport are unvalidated')
    axes[1].legend(fontsize=7);figure.tight_layout();figure.savefig(out/'reference_comparison.png',dpi=180);plt.close(figure)
    print(json.dumps({'independent2010_RMSE':{k:v['RMSE'] for k,v in comparisons.items()},'paired_scenarios':{k:v['language_progress_delta'] for k,v in scenarios.items()}},indent=2))


if __name__=='__main__':main()
