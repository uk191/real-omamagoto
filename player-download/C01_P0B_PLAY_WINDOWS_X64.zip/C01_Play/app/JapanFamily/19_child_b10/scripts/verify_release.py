"""Read saved ZIP from another location, extract and independently verify bytes/API/data."""
import argparse
import datetime as dt
import hashlib
import json
import math
import shutil
import sqlite3
import subprocess
import sys
import time
import zipfile
import zlib
from pathlib import Path,PurePosixPath


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def main():
    p=argparse.ArgumentParser();p.add_argument('archive');p.add_argument('--destination',required=True);p.add_argument('--report',required=True);args=p.parse_args()
    archive=Path(args.archive).resolve();destination=Path(args.destination).resolve();report=Path(args.report).resolve()
    if destination.exists():raise FileExistsError('A fresh verification destination is required')
    destination.mkdir(parents=True);saved=destination/'saved_archive.zip';shutil.copyfile(archive,saved)
    result={'checked_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'archive':str(archive),
        'storage_scope':'local workspace saved ZIP copied and read back; no remote service durability claim',
        'zip_sha256':sha(archive),'copied_zip_sha256':sha(saved),'saved_bytes_identical':sha(archive)==sha(saved),
        'formal_A_integrated':False,'release_accepted':False,
        'old_A_APIs':'not_run_missing_formal_source_archive','old_A_database_preservation':'not_verified_missing_formal_source_archive',
        'A47_household_generator_connection':'not_run_missing_generator',
        'Japanese_national_external_validity':False,'causal_effect_validation':False}
    started=time.monotonic()
    try:
        with zipfile.ZipFile(saved) as z:
            bad=z.testzip();result['zip_crc_pass']=bad is None
            if bad:raise ValueError('ZIP CRC failure: '+bad)
            for name in z.namelist():
                path=PurePosixPath(name)
                if path.is_absolute() or '..' in path.parts:raise ValueError('unsafe archive member')
            manifest=json.loads(z.read('MANIFEST.json'))
            if not manifest['includes_population_database']:raise ValueError('Use the full pre-integration ZIP for DB validation')
            extracted=destination/'unpacked';z.extractall(extracted)
        for name,expected in manifest['files'].items():
            if sha(extracted/name)!=expected:raise ValueError('payload mismatch: '+name)
        result['manifest_files_checked']=len(manifest['files']);result['all_payload_sha256_match']=True
        module=extracted/'JapanFamily/19_child_b10'
        subprocess.run([sys.executable,'scripts/check_sources.py'],cwd=module,check=True,capture_output=True,text=True)
        tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=module,capture_output=True,text=True)
        (destination/'fresh_tests.log').write_text(tests.stdout+'\n'+tests.stderr)
        result['fresh_B_API_unit_tests_exit_code']=tests.returncode
        import re
        count=re.search(r'Ran (\d+) tests?',tests.stderr)
        result['fresh_tests_count']=int(count.group(1)) if count else 0
        if tests.returncode!=0 or result['fresh_tests_count']==0:raise ValueError('fresh API/unit suite did not pass')
        audit=json.loads((module/'results/handover_audit.json').read_text())
        checks=[]
        for attachment in audit['available_attachments']:
            file=module/'handover_available'/attachment['file']
            if sha(file)!=attachment['sha256']:raise ValueError('inherited attachment modified')
            checks.append({'file':attachment['file'],'unchanged':True})
        result['available_inherited_attachments']=checks
        db=module/'results/population_10000/child_b10.sqlite'
        con=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
        result['SQLite_integrity_check']=con.execute('PRAGMA integrity_check').fetchall()
        result['SQLite_foreign_key_check']=con.execute('PRAGMA foreign_key_check').fetchall()
        result['children']=con.execute('SELECT count(*) FROM b10_child').fetchone()[0]
        result['monthly_states_including_birth']=con.execute('SELECT count(*) FROM b10_month').fetchone()[0]
        if result['SQLite_integrity_check']!=[('ok',)] or result['SQLite_foreign_key_check']:raise ValueError('database integrity')
        if (result['children'],result['monthly_states_including_birth'])!=(10000,250000):raise ValueError('population count')
        checked=0
        for ident,month,age,w,l,h,internal,public in con.execute('SELECT * FROM b10_month'):
            state=json.loads(zlib.decompress(internal));parent=json.loads(zlib.decompress(public));ph=state['physical_health']
            if state['elapsed_months']!=month or state['age_days']!=age:raise ValueError('stored date/age mismatch')
            if (ph['weight_kg'],ph['length_cm'],ph['head_circumference_cm'])!=(w,l,h):raise ValueError('stored body mismatch')
            if not all(math.isfinite(x) and 0<=x<=1 for x in state['emotion_regulation'].values()):raise ValueError('short state support')
            if set(parent)!={'child_id','as_of_date','observations','measurements'} or parent['child_id']!=ident:raise ValueError('parent projection boundary')
            if any(r['observer_id']!='mother' for r in parent['observations']):raise ValueError('observer mix')
            checked+=1
            if checked%50000==0:print(json.dumps({'fresh_monthly_states_read':checked}),flush=True)
        result['compressed_monthly_states_and_public_payloads_read']=checked
        con.close()
        # New Python interpreter imports ONLY the extracted module and current saved DB.
        script='''
import json,sqlite3
from child_b10.storage import restore_child
from scripts.experiments import routine
c=sqlite3.connect("file:results/population_10000/child_b10.sqlite?mode=ro",uri=True)
out=[]
for seed in [1000000,1005000,1009999]:
 ident=c.execute("SELECT child_id FROM b10_child WHERE seed=?",(seed,)).fetchone()[0]
 a=restore_child(c,ident,12).advance_to(24,routine)
 b=restore_child(c,ident,24)
 out.append({"seed":seed,"serialized12_plus12_exact":a.research_snapshot()==b.research_snapshot()})
assert all(r["serialized12_plus12_exact"] for r in out)
print(json.dumps(out))
'''
        replay=subprocess.run([sys.executable,'-c',script],cwd=module,check=True,capture_output=True,text=True)
        result['fresh_database_restore_B_API_replays']=json.loads(replay.stdout)
        result['preintegration_engineering_checks_pass']=True
    except Exception as exc:
        result['preintegration_engineering_checks_pass']=False;result['error']=repr(exc)
    result['elapsed_seconds']=time.monotonic()-started
    report.parent.mkdir(exist_ok=True,parents=True);report.write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
    if not result['preintegration_engineering_checks_pass']:sys.exit(1)


if __name__=='__main__':main()
