import gzip,json,bisect,time
from pathlib import Path
from region import rng
class RuntimeSampler:
    def __init__(self,path=None):
        self.data=json.loads(gzip.decompress(Path(path or Path(__file__).resolve().parents[1]/'data/runtime_cache.json.gz').read_bytes()));self.cdfs={}
    def choose(self,key,rows,seed,stream):
        if key not in self.cdfs:
            total=sum(r[1] for r in rows);acc=0;cdf=[]
            for r in rows:acc+=r[1]/total;cdf.append(acc)
            cdf[-1]=1;self.cdfs[key]=cdf
        return rows[bisect.bisect_left(self.cdfs[key],rng(seed,stream).random())]
    def sample(self,pref,seed=0,frame='child_under18'):
        pref=str(pref).zfill(2);d=self.data['prefectures'][pref][frame];cityrows=[[r[0],r[2],r[1]] for r in d['units']];city=self.choose(('city',pref,frame),cityrows,seed,'municipality')
        code=city[0];z=self.data['zones'][code+':'+frame];zone=None
        if z['complete'] and z['units']:zone=self.choose(('zone',code,frame),z['units'],seed,'zone')
        return {'municipality_code':code,'municipality_name':city[2],'zone_ref':None if zone is None else zone[0],'zone_hierarchy':None if zone is None else zone[2],'weight_basis':d['basis_date'],'source_id':d['source_id'],'full_provenance':'data/region.sqlite','kind':'empirical_region_sampling'}
if __name__=='__main__':print(RuntimeSampler().sample('12',42))
