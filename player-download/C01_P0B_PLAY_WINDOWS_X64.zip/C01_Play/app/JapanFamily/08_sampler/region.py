"""Reproducible A-1 region sampler. Samples statistics, never private individuals."""
import sqlite3,json,random,hashlib,datetime,bisect,functools
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];DB=ROOT/'data/region.sqlite'
CURRENT='census2025-10-01';AREA='census2020-10-01_smallarea'
class MissingDataError(ValueError):pass
def rng(seed,stream):return random.Random(int.from_bytes(hashlib.sha256(f'{seed}:{stream}:A1-0.1'.encode()).digest()[:8],'big'))
class RegionModel:
    def __init__(self,db=DB):
        self.db=sqlite3.connect(db);self.db.row_factory=sqlite3.Row;self.cache={}
    def distribution(self,pref,frame='child_under18'):
        """Published municipality totals. Wards replace designated-city parent for sampling."""
        pref=str(pref).zfill(2)
        if frame not in ('child_under18','child_under6','couple_children','general_household','resident'):raise ValueError('Unsupported sampling frame')
        key=(pref,frame)
        if key in self.cache:return self.cache[key]
        cols={'child_under18':'under18_households','child_under6':'under6_households','couple_children':'couple_children','general_household':'general_households'}
        if frame=='resident':
            rows=self.db.execute("SELECT g.geo_id,g.code,g.name,g.geo_type,o.value weight FROM geo_unit g JOIN observation o ON o.geo_id=g.geo_id WHERE g.geo_version=? AND g.pref_code=? AND g.geo_type IN ('city','town_or_village','designated_city','special_ward') AND o.variable_id='POP_001' AND o.period='2025-10-01' AND o.value>0",(CURRENT,pref)).fetchall();basis='2025-10-01';sid='CENSUS25'
        else:
            col=cols[frame]
            rows=[dict(r) for r in self.db.execute(f"SELECT g.geo_id,g.code,g.name,g.geo_type,s.{col} weight,s.family_dataset_id FROM geo_unit g JOIN smallarea_record s ON s.municipality_code=g.code AND s.hyosyo=1 WHERE g.geo_version=? AND g.pref_code=? AND g.geo_type IN ('city','town_or_village','special_ward') AND s.{col}>0",(CURRENT,pref)).fetchall()]
            for city in self.db.execute("SELECT * FROM geo_unit WHERE geo_version=? AND pref_code=? AND geo_type='designated_city'",(CURRENT,pref)):
                totals=self.db.execute(f"SELECT sum(s.{col}) FROM smallarea_record s JOIN geo_unit g ON g.geo_id=s.geo_id WHERE s.hyosyo=1 AND g.name LIKE ?",(city['name']+'%',)).fetchone()[0]
                if totals and totals>0:rows.append({'geo_id':city['geo_id'],'code':city['code'],'name':city['name'],'geo_type':city['geo_type'],'weight':totals,'family_dataset_id':'sum_of_2020_administrative_wards'})
            basis='2020-10-01';sid='SMALLAREA20'
        if not rows:raise MissingDataError('No eligible observed weights for prefecture '+pref)
        rows=sorted(rows,key=lambda r:r['code'])
        weights=[float(r['weight']) for r in rows];total=sum(weights)
        out={'rows':[dict(r) for r in rows],'probabilities':[w/total for w in weights],'total':total,'basis_date':basis,'source_id':sid,'sampling_frame':frame}
        out['cdf']=[];acc=0
        for p in out['probabilities']:acc+=p;out['cdf'].append(acc)
        out['cdf'][-1]=1.0;self.cache[key]=out;return out
    def zone_distribution(self,code,frame):
        col={'child_under18':'under18_households','child_under6':'under6_households','couple_children':'couple_children','general_household':'general_households','resident':'population'}[frame]
        key=('zone',code,frame)
        if key in self.cache:return self.cache[key]
        city=self.db.execute('SELECT name,geo_type FROM geo_unit WHERE geo_id=?',(CURRENT+':'+code,)).fetchone()
        codes=[code]
        if city['geo_type']=='designated_city':codes=[r[0] for r in self.db.execute('SELECT s.municipality_code FROM smallarea_record s JOIN geo_unit g ON g.geo_id=s.geo_id WHERE s.hyosyo=1 AND g.name LIKE ?',(city['name']+'%',))]
        placeholders=','.join('?'*len(codes))
        raw=self.db.execute(f"SELECT s.*,g.name FROM smallarea_record s JOIN geo_unit g ON g.geo_id=s.geo_id WHERE municipality_code IN ({placeholders}) AND hyosyo IN (2,3,4)",codes).fetchall()
        # Use a nonoverlapping partition. If a parent count cannot be reconciled to its
        # children, retain the observed parent as a coarser anonymous environment.
        rows=[r for r in raw if r['hyosyo']==2 and r[col] is not None and r[col]>0]
        parents=[r for r in raw if r['hyosyo']==3]
        children={}
        for r in raw:
            if r['hyosyo']==4:children.setdefault(r['geo_id'].split(':')[-1][:9],[]).append(r)
        coarsened=[]
        for parent in parents:
            key=parent['geo_id'].split(':')[-1];kids=children.get(key,[])
            observed=[r for r in kids if r[col] is not None and r[col]>0]
            subtotal=sum(r[col] for r in observed)
            if parent[col] is not None and subtotal==parent[col]:rows.extend(observed)
            elif parent[col] is not None and parent[col]>0:rows.append(parent);coarsened.append(parent['geo_id'])
            else:rows.extend(observed)
        municipal=self.db.execute(f'SELECT sum({col}) FROM smallarea_record WHERE municipality_code IN ({placeholders}) AND hyosyo=1',codes).fetchone()
        total=sum(float(r[col]) for r in rows);reference=None if municipal is None else municipal[0]
        # If counts do not reconcile, do not quietly renormalize a biased incomplete sample.
        complete=reference is not None and total==reference
        rows=sorted(rows,key=lambda r:r['geo_id'])
        out={'rows':rows,'col':col,'total':total,'reference_total':reference,'complete':complete,'coarsened_parent_areas':coarsened,'cdf':[]}
        acc=0
        if total>0:
            for r in rows:acc+=r[col]/total;out['cdf'].append(acc)
            out['cdf'][-1]=1
        self.cache[key]=out;return out
    def make_region_context(self,pref_code,household_constraints=None,year=2026,seed=0):
        if not isinstance(year,int) or not 2026<=year<=2046:raise ValueError('This snapshot context supports requested years2026-2046 only; historical as-of access is not implemented')
        hc=household_constraints or {};unsupported=set(hc)-{'sampling_frame','municipality_code'}
        if unsupported:raise NotImplementedError('Joint conditioning not calibrated: '+','.join(sorted(unsupported)))
        frame=hc.get('sampling_frame','child_under18');dist=self.distribution(pref_code,frame)
        fixed=hc.get('municipality_code')
        if fixed:
            fixed=str(fixed).zfill(5);matches=[r for r in dist['rows'] if r['code']==fixed]
            if not matches:raise ValueError('Fixed municipality not in eligible prefecture/frame')
            row=matches[0];decision={'method':'user_fixed','probability':None}
        else:
            i=bisect.bisect_left(dist['cdf'],rng(seed,'municipality').random());row=dist['rows'][i];decision={'method':'empirical_count_weight','probability':dist['probabilities'][i],'weight':row['weight'],'denominator':dist['total']}
        code=row['code'];zone=self.zone_distribution(code,frame);zout={'status':'municipality_only_due_to_incomplete_smallarea_weights','reconciled':zone['complete'],'observed_weight_total':zone['total'],'municipality_reference':zone['reference_total']}
        if zone['complete'] and zone['total']>0:
            k=bisect.bisect_left(zone['cdf'],rng(seed,'zone').random());z=dict(zone['rows'][k]);zout.update(status='sampled_statistical_living_environment',statistical_area_ref=z['geo_id'],kind='processed_observed_sampling',basis_date='2020-10-01',weight_kind=frame,probability=z[zone['col']]/zone['total'],census_hierarchy_level=z['hyosyo'],coarsened_for_suppression_or_nonreconciliation=z['hyosyo']==3,suppression_group=z['htksyori']=='1',combined_area_codes=z['gassan'],table_specific_flags={key:json.loads(z[key]) if z[key] else None for key in ['pop_flags_json','family_flags_json','housing_flags_json']},housing_marginals={'housing_households':z['housing_households'],'owner_households':z['owner_households'],'private_rental_households':z['private_rental_households']},source_datasets=[z['pop_dataset_id'],z['family_dataset_id'],z['housing_dataset_id']],joint_household_tenure='unobserved; no individual tenure sampled')
        uea=self.db.execute("SELECT a.area_id,a.name,m.role,m.suburb_order,m.commute_ratio FROM area_membership m JOIN geo_unit u ON u.geo_id=m.geo_id JOIN functional_area a ON a.area_id=m.area_id WHERE u.code=?",(code,)).fetchall()
        if not uea and row['geo_type'] in ('administrative_ward','special_ward'):
            parent=self.db.execute('SELECT parent_geo_id FROM geo_unit WHERE geo_id=?',(row['geo_id'],)).fetchone()[0]
            parentcode='13100' if row['geo_type']=='special_ward' else parent.split(':')[-1]
            uea=self.db.execute("SELECT a.area_id,a.name,m.role,m.suburb_order,m.commute_ratio FROM area_membership m JOIN geo_unit u ON u.geo_id=m.geo_id JOIN functional_area a ON a.area_id=m.area_id WHERE u.code=?",(parentcode,)).fetchall()
        authority=code
        if row['geo_type']=='administrative_ward':authority=self.db.execute('SELECT parent_geo_id FROM geo_unit WHERE geo_id=?',(row['geo_id'],)).fetchone()[0].split(':')[-1]
        obs=self.db.execute("SELECT variable_id,period,value,missing_flag,kind,dataset_id,source_locator,demographic_dims_json FROM observation WHERE geo_id=? AND source_id IN ('CENSUS25','CFA26','CPI25') AND (source_id!='CFA26' OR demographic_dims_json LIKE '%合計%')",(CURRENT+':'+authority,)).fetchall()
        return {'model_version':'A1-0.1','seed':seed,'requested_year':year,'prefecture_code':str(pref_code).zfill(2),'municipality_code':code,'municipality_name':row['name'],'statistical_geo_type':row['geo_type'],'administrative_authority_code':authority,'geography_version':CURRENT,'sampling':decision|{'frame':frame,'weight_basis':dist['basis_date'],'source_id':dist['source_id'],'limitation':'2020 household pattern is not estimated 2026 pattern' if frame!='resident' else 'population weights select residents, not child households'},'living_environment':zout,'functional_areas':[dict(r) for r in uea],'authority_metrics':[dict(r) for r in obs],'missing_features':['individual_rent_distribution','routed_travel_times','school_catchment','income_education_joint_conditioning','nationwide_municipal_policy_rules'],'simulation_time_effect':'year parameter does not relabel or update observations'}
def fiscal_age_end(birth,age):
    birth=datetime.date.fromisoformat(birth);d=birth.replace(year=birth.year+age) if not (birth.month==2 and birth.day==29) else datetime.date(birth.year+age,2,28)
    # Japanese age attainment is the day before birthday. April 1 birthdays belong to prior school year.
    attained=d-datetime.timedelta(days=1)
    return datetime.date(attained.year if attained<=datetime.date(attained.year,3,31) else attained.year+1,3,31)
def ordinary_child_allowance(child_birth,date,third_plus=False,domestic=True,parent_support=True,application_approved=True):
    """Ordinary accrual eligibility illustration, not payment schedule/retroactivity engine."""
    date=datetime.date.fromisoformat(date);birth=datetime.date.fromisoformat(child_birth)
    if date<datetime.date(2024,10,1):raise NotImplementedError('Pre-reform rules not implemented')
    if date<birth or not(domestic and parent_support and application_approved) or date>fiscal_age_end(child_birth,18):return 0
    if third_plus:return 30000
    third=birth.replace(year=birth.year+3) if not(birth.month==2 and birth.day==29) else datetime.date(birth.year+3,2,28)
    attained=third-datetime.timedelta(days=1)
    return 15000 if (date.year,date.month)<=(attained.year,attained.month) else 10000
if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--pref',default='12');p.add_argument('--seed',type=int,default=42);p.add_argument('--frame',default='child_under18');a=p.parse_args()
    print(json.dumps(RegionModel().make_region_context(a.pref,{'sampling_frame':a.frame},2026,a.seed),ensure_ascii=False,indent=2))
