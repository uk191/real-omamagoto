"""Small game cache: observed-count sampling only. Full provenance remains in SQLite."""
import gzip,json,time,bisect,sys
from pathlib import Path
from region import RegionModel,rng
ROOT=Path(__file__).resolve().parents[1];model=RegionModel();data={'version':'A1-0.1','prefectures':{},'zones':{},'frames':['child_under18','child_under6','resident'],'limitations':['2020 child-household patterns','no income conditioning','no routed access times','provenance references resolve against full SQLite']}
for pref in range(1,48):
    key=str(pref).zfill(2);data['prefectures'][key]={}
    for frame in data['frames']:
        d=model.distribution(key,frame);data['prefectures'][key][frame]={'basis_date':d['basis_date'],'source_id':d['source_id'],'units':[[r['code'],r['name'],r['weight']] for r in d['rows']]}
        for r in d['rows']:
            z=model.zone_distribution(r['code'],frame);data['zones'][r['code']+':'+frame]={'reference_total':z['reference_total'],'observed_total':z['total'],'complete':z['complete'],'units':[[q['geo_id'],q[z['col']],q['hyosyo']] for q in z['rows']] if z['complete'] else []}
path=ROOT/'data/runtime_cache.json.gz';payload=json.dumps(data,ensure_ascii=False,separators=(',',':')).encode();path.write_bytes(gzip.compress(payload,compresslevel=6,mtime=0))
print('runtime_cache',len(payload),path.stat().st_size)
