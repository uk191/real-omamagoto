"""Independent population diagnostic, never relabelled as joint validation."""
import json,gzip,collections,hashlib,zipfile
from pathlib import Path
from model import Model,VERSION
ROOT=Path(__file__).resolve().parent;P=ROOT.parent
def main():
    k=json.loads((P/'15_initial_state/data/state_kernels.json').read_text());anchor=k['baby_income_2024_profiles']['00'];c=anchor['components'];source_jobs=c['211']+c['212']-c['2123'];m=Model()
    pref_birth_weight={p:sum(x['weight']or 0 for x in rs if x['sex']=='all')for p,rs in m.base.g['birth_pref'].items()};sums=collections.defaultdict(lambda:[0,0.])
    with gzip.open(ROOT/'validation/states.jsonl.gz','rt',encoding='utf-8')as f:
        for line in f:
            r=json.loads(line);h=r['household']
            if h['index_birth_rank_interval'][0]==1 and h['legal_birth_status']=='marital'and h['resident_person_count']==3 and not h.get('reference_co_resident_grandparent',False) and all(v is not None for v in r['jobs'].values()):
                sums[r['prefecture']][0]+=1;sums[r['prefecture']][1]+=sum(r['jobs'].values())
    weights=sum(pref_birth_weight[p]for p in sums);generated=sum((v[1]/v[0])*pref_birth_weight[p]for p,v in sums.items())/weights
    result={'model_version':VERSION,'comparison':'2024 couple+one child<=2 main-job wage/business means versus generated first-marital-newborn households; prefectures reweighted with2025 births','source_job_income_mean_2024':source_jobs,'generated_income_reference_2022':generated,'ratio_different_years_and_populations':generated/source_jobs,'unadjusted_nominal_difference':generated-source_jobs,'source_cells':anchor['source_cells'],'cohort_and_year_transport_not_verified':True,'ESS_partial_year_vs_normal_monthly_income_unidentified':True,'maternal_phase_connection':'legacy current mothers-of-under6 work distribution, not pregnancy-phase joint; NIPSS firstborn source retained but incomplete automatic phase transport','independent_full_joint_validated':False,'unvalidated_relations':['gross_vs_disposable_vs_assets','pregnancy_vs_birth_vs_oneyear_work_phase','household_specific_expenditure_variance_and_cross_covariance','actual_employer_qualification_leave_claim_dates','all_municipality_exact_tax_NHI_billing','grandparent_income_and_assets_ownership','annual_realized2026_income_and_bonus_and_yearend_adjustment','rent_and_house_prices2026_vs2023'],'population_shortfall_rate_validated':False}
    result['maternal_phase_connection']='NIPSS first-married firstborn pregnancy-to-one-year joint transported to first-marital newborns; age/education/job linkage and exit dates estimated; later births retain legacy under6 proxy'
    (ROOT/'validation/external_comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    # The code and source baseline is byte-identical to the saved0.1 ZIP.
    zpath=P.parent.parent/'recover_saved/A1_A25_日本出生家庭初期状態基盤_A2.5-0.1.zip';checks=[]
    manifest=ROOT/'data/inherited_code_hashes.json'
    if zpath.exists():
        with zipfile.ZipFile(zpath)as z:original_hashes={name:hashlib.sha256(z.read(name)).hexdigest()for name in z.namelist()if name.endswith(('.py','.mjs','.sql'))}
        manifest.write_text(json.dumps(original_hashes,ensure_ascii=False,indent=2))
    else:original_hashes=json.loads(manifest.read_text())
    for name,digest in original_hashes.items():
        relative=Path(name);local=P/Path(*relative.parts[1:])if relative.parts[0]=='JapanFamily'else P/relative
        checks.append({'file':name,'same':local.exists()and digest==hashlib.sha256(local.read_bytes()).hexdigest()})
    assert checks and all(x['same']for x in checks);(ROOT/'validation/legacy_code_audit.json').write_text(json.dumps({'unchanged_files':len(checks),'checks':checks},ensure_ascii=False,indent=2))
    print(json.dumps({k:v for k,v in result.items()if k!='source_cells'}),flush=True)
if __name__=='__main__':main()
