"""Atomic extension; compare every inherited table's ordered row digest."""
from pathlib import Path
import json,gzip,sqlite3,hashlib,os,stat
from model import VERSION,DEFAULT
ROOT=Path(__file__).resolve().parent;DB=ROOT.parent/'data/region.sqlite'
def fingerprints(c):
    out={}
    for(name,)in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'recovery_%' ORDER BY name").fetchall():
        h=hashlib.sha256();n=0
        for row in c.execute('SELECT * FROM "'+name.replace('"','""')+'" ORDER BY rowid'):
            h.update(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=lambda v:v.hex()if isinstance(v,bytes)else str(v)).encode());h.update(b'\n');n+=1
        out[name]={'rows':n,'sha256':h.hexdigest()}
    return out
def main():
    src=sqlite3.connect(f'file:{DB}?mode=ro',uri=True);before=fingerprints(src);tmp=DB.with_name('region.recovery-install.sqlite')
    if tmp.exists():raise RuntimeError('Unexpected staging DB; inspect before reuse')
    dst=sqlite3.connect(tmp);src.backup(dst);src.close()
    dst.executescript('CREATE TABLE IF NOT EXISTS recovery_manifest(version TEXT PRIMARY KEY,payload TEXT NOT NULL);CREATE TABLE IF NOT EXISTS recovery_stat_cell(dataset TEXT,group_key TEXT,asset_code TEXT,payload TEXT,PRIMARY KEY(dataset,group_key,asset_code));CREATE TABLE IF NOT EXISTS recovery_variable(variable_id TEXT PRIMARY KEY,payload TEXT);CREATE TABLE IF NOT EXISTS recovery_example(example_index INTEGER PRIMARY KEY,payload TEXT);CREATE TABLE IF NOT EXISTS recovery_validation(name TEXT PRIMARY KEY,payload TEXT);CREATE TABLE IF NOT EXISTS recovery_backlog(variable_id TEXT PRIMARY KEY,payload TEXT);')
    for t in ['recovery_manifest','recovery_stat_cell','recovery_variable','recovery_example','recovery_validation','recovery_backlog']:dst.execute('DELETE FROM '+t)
    sources=json.loads((ROOT/'data/sources.json').read_text());dst.execute('INSERT INTO recovery_manifest VALUES(?,?)',(VERSION,json.dumps({'defaults':DEFAULT,'sources':sources,'full_joint_validated':False,'financially_playable':False},ensure_ascii=False)))
    with gzip.open(ROOT/'data/kernels.json.gz','rt',encoding='utf-8')as f:k=json.load(f)
    for name in ['holders','means']:
        dst.executemany('INSERT INTO recovery_stat_cell VALUES(?,?,?,?)',[(name,key,a,json.dumps(v,ensure_ascii=False))for key,row in k[name].items()for a,v in row.items()])
    fees=json.loads((ROOT/'data/birth_fees.json').read_text());dst.executemany('INSERT INTO recovery_stat_cell VALUES(?,?,?,?)',[('birth_fees',key,'basic_fee',json.dumps(v,ensure_ascii=False))for key,v in fees.items()])
    cat=json.loads((ROOT/'data/expanded_catalogue.json').read_text());dst.executemany('INSERT INTO recovery_variable VALUES(?,?)',[(v['variable_id'],json.dumps(v,ensure_ascii=False))for v in cat['rows']])
    examples=json.loads((ROOT/'data/examples.json').read_text());dst.executemany('INSERT INTO recovery_example VALUES(?,?)',[(i,json.dumps(v,ensure_ascii=False))for i,v in enumerate(examples)])
    for p in sorted((ROOT/'validation').glob('*.json')):dst.execute('INSERT INTO recovery_validation VALUES(?,?)',(p.stem,p.read_text()))
    backlog=json.loads((ROOT/'data/backlog.json').read_text());dst.executemany('INSERT INTO recovery_backlog VALUES(?,?)',[(v['variable_id'],json.dumps(v,ensure_ascii=False))for v in backlog['rows']]);dst.commit()
    after=fingerprints(dst);assert before==after;assert dst.execute('PRAGMA integrity_check').fetchall()==[('ok',)];assert not dst.execute('PRAGMA foreign_key_check').fetchall()
    counts={name:dst.execute('SELECT count(*) FROM '+name).fetchone()[0]for(name,)in dst.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'recovery_%'").fetchall()}
    dst.close()
    with tmp.open('rb')as f:os.fsync(f.fileno())
    os.replace(tmp,DB);os.chmod(DB,stat.S_IRUSR|stat.S_IRGRP|stat.S_IROTH)
    result={'model_version':VERSION,'all_inherited_tables_unchanged':before==after,'inherited_table_count':len(before),'fingerprints':before,'new_table_counts':counts,'integrity_check':'ok','foreign_key_violations':[],'atomic_install':True,'db_sha256':hashlib.file_digest(DB.open('rb'),'sha256').hexdigest(),'db_bytes':DB.stat().st_size}
    (ROOT/'validation/database_audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in result.items()if k!='fingerprints'}),flush=True)
if __name__=='__main__':main()
