"""Compare assumptions and retain actual geographic examples."""
from pathlib import Path
import json,collections,time
from model import Model,VERSION
ROOT=Path(__file__).resolve().parent
def main():
    m=Model();scenarios=[('default',{}),('legacy_mortgage',{'mortgage_tenure_conditioning':False}),('asset_independent',{'asset_rho':0}),('asset_comonotonic',{'asset_rho':1}),('pareto_tail',{'asset_tail':'pareto'}),('budget_cv_0',{'budget_cv':0}),('budget_cv_0.7',{'budget_cv':.7}),('benefit_lag_0',{'benefit_lag_months':0}),('benefit_lag_3',{'benefit_lag_months':3}),('birth_extra_100k',{'birth_extra':100000}),('debt_union_lower',{'nonhousing_union_position':0}),('debt_union_upper',{'nonhousing_union_position':1})];results=[]
    for name,sc in scenarios:
        counts=collections.Counter();errors=[]
        for pref in range(1,48):
            for i in range(10):
                try:
                    s=m.generate(f'{pref:02d}',seed=f'sensitivity/{pref}/{i}',include_region=False,scenario=sc);counts['generated']+=1;counts['two_month_estimated_funded']+=s['quality_flags']['automatic_two_months_funded'];counts['source_fallback']+=int(s['automatic_accounts']['trace']['mortgage_connection']['probability']is None)
                except Exception as e:errors.append(repr(e))
        results.append({'scenario':name,'parameters':sc,'counts':dict(counts),'errors':errors,'scope':'unobserved assumption comparison; not empirical household shortfall rate'});print(name,dict(counts),flush=True)
    (ROOT/'validation/sensitivity.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));assert all(not r['errors']for r in results)
    requests=[{'prefecture_code':f'{i:02d}','seed':f'geographic-example/{i}'}for i in range(1,26)]
    for j,c in enumerate([{'partner_present':False,'legal_status':'nonmarital'},{'mother_age':22},{'mother_age':42},{'household_income_yen':6000000},{'mother_education':'4','tenure':'private_rental'}]):requests.append({'prefecture_code':'13','seed':f'condition-example/{j}','conditions':c})
    examples=[{'request':r,'state':m.generate(**r)}for r in requests]
    for e in examples:assert e['state']['region_context']is not None and len(e['state']['household']['municipality_code'])==5
    (ROOT/'data/examples.json').write_text(json.dumps(examples,ensure_ascii=False,indent=2));print('examples',len(examples),flush=True)
if __name__=='__main__':main()
