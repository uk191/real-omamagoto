"""Resumable validation; never import metrics from lost trials."""
import collections,gzip,hashlib,json,math,os,statistics,time,sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from model import Model,VERSION
ROOT=Path(__file__).resolve().parent
def moments(v):
    v=sorted(x for x in v if isinstance(x,(int,float)) and math.isfinite(x))
    return {'n':len(v),'mean':statistics.mean(v) if v else None,'variance':statistics.pvariance(v) if v else None,'quantiles':{str(q):v[int(q*(len(v)-1))] if v else None for q in [.01,.1,.25,.5,.75,.9,.99]}}
def worker(arg):
    p,n=arg;p=f'{p:02d}';out=ROOT/'validation'/'prefectures';out.mkdir(parents=True,exist_ok=True)
    done=out/(p+'.json');gz=out/(p+'.jsonl.gz')
    if done.exists() and gz.exists():
        d=json.loads(done.read_text())
        if d['version']==VERSION and d['requested']==n:return d
    m=Model();errors=[];viol=[];counts=collections.Counter();rows=[];t=time.time()
    with gzip.open(str(gz)+'.tmp','wt',encoding='utf-8',compresslevel=1) as f:
        for i in range(n):
            seed=f'restored-r2/{p}/{i}'
            try:
                s=m.generate(p,seed=seed,include_region=False);h=s['household'];ps=s['persons'];a=s['automatic_accounts'];q=s['quality_flags']
                checks={'newborn_zero':next(x for x in ps if x['person_id']=='index_child')['age_years']==0,'unique_ids':len(set(x['person_id']for x in ps))==len(ps),'roster_count':h['resident_person_count']==sum(x['co_resident']is True for x in ps),'uncertainty_not_certified':not q['financially_playable'],'prefecture':h['municipality_code'][:2]==p}
                for key,ok in checks.items():
                    if not ok:viol.append({'seed':seed,'check':key})
                jobs=s['automatic_jobs_annual'];acc=a['accounts'];rank=h['index_birth_rank_interval'][0]
                values={'jobs_total':sum(jobs.values()) if all(v is not None for v in jobs.values()) else None,'rent':s['housing']['monthly_rent']['value'],'resident_count':h['resident_person_count'],'birth_rank_lower':rank,'net_worth':a['net_worth']}
                r={'model_version':VERSION,'prefecture':p,'seed':seed,'household':h,'jobs':jobs,'persons':ps,'housing':s['housing'],'accounts':a,'periods':s['automatic_periods'],'quality':q,'phase':s['maternal_phase_connection'],'statistics_values':values,'combination':[rank,h['resident_person_count'],s['housing']['tenure'],s['employment']['mother']['at_birth_status']]}
                f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n');counts['generated']+=1;counts['two_month_estimated_funded']+=int(q['automatic_two_months_funded']);counts['pregnancy_phase_applied']+=int(r['phase'].get('applied',False))
            except Exception as e:errors.append({'seed':seed,'error':repr(e)})
    os.replace(str(gz)+'.tmp',gz)
    # Read through EOF to verify compression before marking this prefecture complete.
    with gzip.open(gz,'rt',encoding='utf-8') as f:assert sum(1 for _ in f)==counts['generated']
    d={'version':VERSION,'prefecture':p,'requested':n,'counts':dict(counts),'errors':errors,'violations':viol,'seconds':time.time()-t};tmp=done.with_suffix('.tmp');tmp.write_text(json.dumps(d,ensure_ascii=False));os.replace(tmp,done);print(p,counts['generated'],len(errors),flush=True);return d
def main(n=2200):
    start=time.time();out=ROOT/'validation';out.mkdir(exist_ok=True)
    with ProcessPoolExecutor(max_workers=2) as pool:results=list(pool.map(worker,[(p,n) for p in range(1,48)]))
    counts=collections.Counter();errors=[];viol=[];mom=collections.defaultdict(list);conditional=collections.defaultdict(lambda:collections.defaultdict(list));comb=collections.Counter();birth=collections.Counter();sha=hashlib.sha256()
    for d in results:counts.update(d['counts']);errors+=d['errors'];viol+=d['violations']
    with gzip.open(out/'states.jsonl.gz.tmp','wt',encoding='utf-8',compresslevel=1) as dst:
        for p in range(1,48):
            with gzip.open(out/'prefectures'/f'{p:02d}.jsonl.gz','rt',encoding='utf-8') as f:
                for line in f:
                    r=json.loads(line);dst.write(line);sha.update(line.encode());comb[tuple(r['combination'])]+=1
                    mother=next(x for x in r['persons'] if x['person_id']=='mother');birth[(r['prefecture'],mother['age_years'],min(r['statistics_values']['birth_rank_lower'],5))]+=1
                    for k,v in r['statistics_values'].items():
                        mom[k].append(v)
                        for c in ['pref:'+r['prefecture'],'tenure:'+str(r['housing']['tenure']),'birth_rank:'+str(r['statistics_values']['birth_rank_lower'])]:conditional[c][k].append(v)
    os.replace(out/'states.jsonl.gz.tmp',out/'states.jsonl.gz');m=Model();fit=[]
    for p in range(1,48):
        code=f'{p:02d}';weights=collections.Counter()
        for x in m.base.g['birth_pref'][code]:
            if x['sex']!='all':continue
            label=x['mother_label'];age=int(label[:-1]) if label.endswith('歳') and label[:-1].isdigit() else None;weights[(age,x['rank'])]+=x['weight'] or 0
        total=sum(weights.values())
        for (a,r),w in weights.items():
            pr=w/total;ex=n*pr;ob=birth[(code,a,r)];z=(ob-ex)/math.sqrt(n*pr*(1-pr)) if ex>=5 and pr<1 else None;fit.append({'prefecture':code,'mother_age':a,'rank':r,'expected':ex,'observed':ob,'z':z})
    summary={'model_version':VERSION,'requested':47*n,'generated':counts['generated'],'failures':len(errors),'internal_violations':len(viol),'counts':dict(counts),'birth_MC_max_abs_z':max(abs(x['z']) for x in fit if x['z'] is not None),'MC_acceptance_threshold':7,'payload_sha256':sha.hexdigest(),'elapsed_seconds':time.time()-start,'full_joint_externally_validated':False,'financially_playable':False,'scope':'Fresh restored-source trials. Checks limited to named invariants and source birth calibration; no recovery of lost prior103400 results.'}
    outputs={'summary':summary,'moments':{k:moments(v) for k,v in mom.items()},'conditional_moments':{c:{k:moments(v) for k,v in vs.items()} for c,vs in conditional.items()},'attribute_combinations':[{'values':k,'n':v} for k,v in comb.items()],'birth_calibration':fit,'failures':errors,'violations':viol}
    for key,value in outputs.items():(out/(key+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2))
    print(json.dumps(summary),flush=True);assert counts['generated']==47*n and not errors and not viol and summary['birth_MC_max_abs_z']<7
if __name__=='__main__':main(int(sys.argv[1]) if len(sys.argv)>1 else 2200)
