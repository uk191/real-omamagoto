"""Source positive-holder quantiles under explicitly unconditioned DI00.

This detects inadvertent truncation of magnitude ranks by the holder indicator.
It is kernel implementation calibration, not an independent newborn fit.
"""
from pathlib import Path
import collections,json,math
from model import Model,DEFAULT
from policy import _policy
ROOT=Path(__file__).resolve().parent
def main(n=20000):
    m=Model();b=m.base.generate('13',seed='quantile-fixture',include_region=False);b['housing']['household_size']=3;b['housing']['tenure']='owner';b['finances']['disposable_income_OECD']['value']=None;values=collections.defaultdict(list)
    for i in range(n):
        a,_,t=m.assets(b,f'positive-quantile/{i}',DEFAULT);mort=next(x for x in a if x['account_id']=='mortgage')['balance']>0;k='1'if mort else'2'
        for code,acc in [('212','insurance_reserve'),('213','securities'),('32','other_property')]:
            v=next(x for x in a if x['account_id']==acc)['balance']
            if v>0:values[(k,code)].append(v)
    results=[]
    for(mort,code),v in values.items():
        q=_policy()['asset_holder_quantiles'].get(f'{mort}|3|{code}');assert q
        for p,amount in q['points'].items():
            pp=float(p);observed=sum(x<=amount for x in v);expected=pp*len(v);z=(observed-expected)/math.sqrt(len(v)*pp*(1-pp));results.append({'mortgage':mort,'asset':code,'n_positive':len(v),'quantile':pp,'source_yen':amount,'generated_fraction_below':observed/len(v),'z':z})
    maxz=max(abs(r['z'])for r in results);result={'trials':n,'max_abs_z':maxz,'threshold':7,'type':'same-source positive-holder quantile calibration under DI00; not newborn population validation','results':results}
    (ROOT/'validation/asset_quantile_calibration.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print('positive asset quantile maxz',maxz,flush=True);assert maxz<7
if __name__=='__main__':main()
