"""Preserve all inherited801 variables and505 backlog rows verbatim."""
import json,hashlib
from pathlib import Path
from model import VERSION
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'15_initial_state/data'
def main():
    d=json.loads((OLD/'expanded_catalogue_A25.json').read_text());old=json.loads(json.dumps(d['rows']));labels=[('mortgage_tenure_conditional','ローン有無×所有関係×可処分所得','2024条件付き比率。出生母集団への移送は未検証'),('asset_holder_conditional','資産種類別の保有率','可処分所得×世帯人数×住宅ローン別。非保有をゼロとして抽選'),('asset_component_amount','保有時資産額','分位形状は全所得層。可処分所得別の保有平均で移送。形状未検証'),('currency_deposit','決済用通貨性預金','通貨性・定期性の同時保有率を反映。金額の条件付き構成はBeta感度仮定'),('term_deposit','定期性預金','決済用現金と区別'),('insurance_reserve','生命保険積立額','支払保険料ではない'),('other_financial','その他金融資産','公表平均と保有率による推定'),('other_property','現住居以外の不動産','保有分位点から推定。賃貸収入は未接続'),('other_debt_union','住宅以外・割賦負債','同時保有未観測。Fréchet上下限の感度仮定'),('birth_basic_fee','正常分娩の都道府県別基本費用','FY2024行政請求平均。室料差額・その他除外。CV未観測'),('birth_invoice','出産請求額','基本費用＋掛金。その他費用はシナリオ'),('monthly_salary','出生月・翌月給与','2022通常年収÷12の感度仮定。2026観測でも正常月賃金の検証でもない'),('benefit_timing','産休育休給付の入金月','請求承認と入金遅れは仮定。観測の資格・処理期間ではない'),('municipal_reserve','税・国保の月次引当','柏市の制度基準を移送。47都道府県の実額ではない'),('loan_contract','ローン利率・残期間','公表残高と分離。契約条件は感度仮定'),('two_month_ledger','初月と翌月の元本・現金精算','内部会計恒等式のみ検証。人口同時分布の証明ではない'),('parent_cache_age','親の年齢別条件分布の検索索引','原表は10歳階級。旧キャッシュに不具合はない。新経路で年齢別索引を追加'),('birth_history_scenario','既往出生と同居子の名簿','旧版の年齢遡及シナリオ。実際の間隔・死亡・同居分布ではない')]
    labels += [('maternal_pregnancy_phase','妊娠前就業から1歳時就業への接続','NIPSS初婚・第一子の公表同時分布を初回嫡出出生に推定移送。離職日・年齢学歴職業との接合は未検証'),('fixed_job_total','入力された両親通常就業所得の固定','原表所得階級内の和を指定額に制約。総所得・実現年収とは異なる。1000提案で支持不明を返す')]
    for i,(path,label,note)in enumerate(labels,1):d['rows'].append({'variable_id':f'A25R_{i:03d}','catalogue_namespace':'A2.5-0.2r2','label':label,'A25_status':'implemented_estimate_with_scope_limits','A25_path':path,'A25_definition':note,'A25_missing_policy':'unknown stays explicit; no complete household certificate','observed_year':2024 if i<=11 else None,'requested_year':2026,'source_id':'16_recovery/data/sources.json; inherited15/13','unit':('probability'if i in(1,2)else'JPY/month'if i in(12,13,14)else'JPY'if i in(3,4,5,6,7,8,9,10,11)else'structured; field units in definition'),'uncertainty':note})
    d['acquired_not_implemented']=[{'source':'finance_7-111-1.xlsx; finance_7-81-1.xlsx','dimensions':['有業人員','世帯主の年齢階級','世帯主の従業上の地位','世帯主の学歴','世帯主の就業時間','世帯類型','主な年間収入の種類'],'status':'originals_acquired; columns_not_connected_to_generator','next_action':'元表の重複区分・母集団・粒度を確認し出生世帯への条件接続を実装'}, {'source':'finance_7-111-1.xlsx','dimensions':['資産額階級×可処分所得×所有関係'],'status':'raw_cross_cells_acquired; this kernel selects pooled00R only','next_action':'純資産階級と各保有・額の条件分布を相互校正。原表があるのに推定不能と称さない'}]
    d.update(model_version=VERSION,inherited_rows=len(old),added_rows=len(labels),inherited_sha256=hashlib.sha256(json.dumps(old,ensure_ascii=False,sort_keys=True).encode()).hexdigest())
    assert d['rows'][:len(old)]==old;assert len({x['variable_id']for x in d['rows']})==len(d['rows'])
    for row in d['rows']:
        for k in row:
            if k not in d['columns']:d['columns'].append(k)
    (ROOT/'data/expanded_catalogue.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
    backlog=json.loads((OLD/'backlog_505_A25.json').read_text());(ROOT/'data/backlog.json').write_text(json.dumps(backlog,ensure_ascii=False,indent=2))
    print('catalogue',len(d['rows']),'unchanged_backlog',backlog['old_unresolved_candidates'])
if __name__=='__main__':main()
