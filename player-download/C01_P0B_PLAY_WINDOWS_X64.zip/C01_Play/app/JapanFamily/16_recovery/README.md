# A2.5-0.2r2 復元・再検証版

既存A1／A2-0.4／A2.5-0.1を保持し、住宅ローン×所有関係×可処分所得、資産保有率・構成、正常分娩費用、二か月の推定会計を追加する。47都道府県対応。**完全な出生家庭同時分布とゲーム開始の外部検証は未完成。financially_playable=falseを保持する。**

直前の未保存0.2は作業領域から失われた。0.2r2は保存済み0.1と再取得原表から独立して再構築・再検証した版であり、失われた0.2の数値やコードを復元できたと称していない。

```bash
python3 16_recovery/model.py --pref 13 --seed example
python3 16_recovery/model.py --pref 12 --seed fixed --conditions '{"mother_age":32,"birth_rank":2,"tenure":"private_rental"}'
python3 16_recovery/api.py --port 8767
```

`POST /generate`のJSONは`prefecture_code`、`conditions`、`seed`、`birth_date`、`initialization`、`scenario`、`include_region`。`POST /generate-batch`は追加`n:1..1000`。`GET /health`。旧13_familyと15_initial_stateのAPIも保持している。

生成時の外部依存は不要。原表の再変換のみopenpyxlとPyMuPDF。同梱核で生成可能。

```bash
python3 16_recovery/acquire.py
python3 16_recovery/compile.py
python3 16_recovery/catalogue.py
python3 16_recovery/tests.py
python3 16_recovery/check_asset_quantiles.py
python3 16_recovery/validate.py 2200 # 47都道府県×2200世帯、2プロセス、県別再開可能
python3 16_recovery/experiments.py
python3 15_initial_state/legacy_regression.py
python3 16_recovery/external.py
python3 16_recovery/install.py
python3 16_recovery/release.py
```

入力所得は旧A2の2022通常年収参照条件。出生月の手取り・実際の2026年年収ではない。極端条件は生成または支持未識別として明示。源泉徴収と給付、税・保険の資格・承認・契約には仮定を含む。

出生日は2026年8～11月を受理する。12月は翌年ルール未取得として422。11月から12月の年末調整は未実装。初月・翌月の給与、給付入金、税・国保の引当、預金、元本、利息、生活費を試算する。実額の行政請求・給与明細・完全な育休経路ではない。資金不足は自動借入せず表示する。

原表にない相関・支出分散・預金構成分散・返済条件はscenarioで比較する。`automatic_two_months_funded`は推定条件下の結果。実際の家庭の資金不足率ではない。`automatic_periods`と`automatic_accounts`が新規試算で、旧15の参照・未確定フィールドは別に保持する。

100k保存データは名簿・収支・資産の実体とseedを含む。重複原表情報は核のキーで参照する。全API出力は同一版・原表・seedで再実行する。地域情報を含む30件の完全出力はdata/examples.json。
