"""Partition47 prefectures across4 processes; combine exact stored values."""
import multiprocessing as mp,json,gzip,collections,hashlib,math,time
from pathlib import Path
import validate
from model import VERSION
ROOT=Path(__file__).resolve().parent
def worker(i,prefs,n):
    validate.ROOT=ROOT/'shards'/f'part{i}';validate.ROOT.mkdir(parents=True,exist_ok=True);validate.main(n,prefs)
def main(n=2200):
    start=time.time();groups=[list(range(1,13)),list(range(13,25)),list(range(25,37)),list(range(37,48))];procs=[]
    for i,g in enumerate(groups):
        p=mp.Process(target=worker,args=(i,g,n));p.start();procs.append(p)
    for p in procs:p.join();assert p.exitcode==0,p.exitcode
    out=ROOT/'validation';out.mkdir(exist_ok=True);mom=collections.defaultdict(list);cond=collections.defaultdict(lambda:collections.defaultdict(list));counts=collections.Counter();mc={};combo=collections.Counter();birth=[];fail=[];viol=[];sha=hashlib.sha256()
    with gzip.open(out/'states.jsonl.gz','wt',encoding='utf-8',compresslevel=1)as dst:
        for i in range(4):
            d=ROOT/'shards'/f'part{i}'/'validation';summary=json.loads((d/'summary.json').read_text());counts.update(summary['counts']);birth+=json.loads((d/'birth_calibration.json').read_text());fail+=json.loads((d/'failures.json').read_text());viol+=json.loads((d/'violations.json').read_text())
            for r in json.loads((d/'source_calibration.json').read_text()):
                key=tuple(r['group']);x=mc.setdefault(key,{'group':key,'n':0,'expected':0.,'variance_MC':0.,'observed':0})
                for k in ['n','expected','variance_MC','observed']:x[k]+=r[k]
            for r in json.loads((d/'attribute_combinations.json').read_text()):combo[tuple(r['values'])]+=r['n']
            with gzip.open(d/'states.jsonl.gz','rt',encoding='utf-8')as src:
                for line in src:
                    sha.update(line.encode());dst.write(line);r=json.loads(line)
                    for k,v in r['statistics_values'].items():mom[k].append(v)
                    for c in r['conditional_groups']:
                        for k,v in r['statistics_values'].items():cond[c][k].append(v)
    for r in mc.values():r['z']=(r['observed']-r['expected'])/math.sqrt(r['variance_MC'])if r['variance_MC']>=5 else None
    z=max(abs(r['z'])for r in mc.values()if r['z']is not None);bz=max(abs(r['z'])for r in birth if r['z']is not None)
    summary={'model_version':VERSION,'requested':47*n,'generated':counts['generated'],'failures':len(fail),'internal_violations':len(viol),'counts':dict(counts),'source_MC_max_abs_z':z,'birth_MC_max_abs_z':bz,'MC_acceptance_threshold':7,'payload_sha256':sha.hexdigest(),'elapsed_seconds':time.time()-start,'workers':4,'full_joint_externally_validated':False,'financially_playable':False,'recovery_warning':'Unsaved earlier0.2 not recovered; current0.2r1 actual trials only'}
    results={'summary':summary,'moments':{k:validate.moments(v)for k,v in mom.items()},'conditional_moments':{c:{k:validate.moments(v)for k,v in vals.items()}for c,vals in cond.items()},'source_calibration':list(mc.values()),'birth_calibration':birth,'attribute_combinations':[{'values':k,'n':v}for k,v in combo.items()],'failures':fail,'violations':viol}
    for k,v in results.items():(out/(k+'.json')).write_text(json.dumps(v,ensure_ascii=False,indent=2))
    assert counts['generated']==47*n and not fail and not viol and z<7 and bz<7;print('FINAL',json.dumps(summary),flush=True)
if __name__=='__main__':validate.main()
