"""Stream all selected original cells; suppressed values stay unknown."""
from pathlib import Path
import json,gzip,openpyxl,unicodedata,hashlib
ROOT=Path(__file__).resolve().parent
def code(x):return unicodedata.normalize('NFKC',str(x)).split('_')[0]
def value(x):
    if isinstance(x,(float,int)):return x
    if x in ('-','－'):return 0
    return None
def main():
    holders={};means={};meta={}
    for name,target in [('finance_7-111-1.xlsx',holders),('finance_7-81-1.xlsx',means)]:
        w=openpyxl.load_workbook(ROOT/'raw'/name,read_only=True,data_only=True);s=w.worksheets[0];head=None;groups=None;kept=0
        for rn,row in enumerate(s.values,1):
            if rn==5:groups=row
            if rn==6:head=row
            isholder=target is holders
            if rn<8:continue
            if isholder:
                if code(row[2])!='00000' or code(row[8])!='00R' or code(row[6]) not in [f'{i:02d}'for i in range(11)] or row[0]!='世帯数分布':continue
                m,di,asset=code(row[4]),code(row[6]),code(row[10]);firstcol=12
            else:
                if code(row[1])!='00000' or code(row[5]) not in [f'{i:02d}'for i in range(11)] or row[6]!='1世帯当たり資産現在高・負債現在高':continue
                m,di,asset=code(row[3]),code(row[5]),code(row[8]);firstcol=10
            for col in range(firstcol,len(row)):
                group=str(groups[col]);c=code(head[col])
                kind='size'if group=='世帯人員' else 'tenure'if group=='現住居の所有関係'else None
                if kind is None or c=='R':continue
                k=f'{m}|{di}|{kind}:{c}'
                target.setdefault(k,{})[asset]={'value':value(row[col]),'raw':row[col],'source':{'file':name,'sheet':s.title,'row':rn,'column':col+1},'unit':'weighted_households'if target is holders else'thousand_JPY'};kept+=1
        meta[name]={'rows':s.max_row,'columns':s.max_column,'kept_cells':kept,'sha256':hashlib.file_digest((ROOT/'raw'/name).open('rb'),'sha256').hexdigest()};w.close();print(name,kept,flush=True)
    d={'holders':holders,'means':means,'source_metadata':meta,'observed_year':2024,'target_year':2026,'transport':'2024 national conditional associations transported to newborn population; not observed newborn joint'}
    with gzip.open(ROOT/'data/kernels.json.gz','wt',encoding='utf-8')as f:json.dump(d,f,ensure_ascii=False)
    assert all(f'1|00|tenure:{c}'in holders and f'2|00|tenure:{c}'in holders for c in ['01','02'])
    compile_birth()
def compile_birth():
    import fitz,re
    p=ROOT/'raw/birth_cost_2025.pdf';doc=fitz.open(p);page=doc[12]
    nums=[w for w in page.get_text('words')if w[0]>80 and re.fullmatch(r'\d{3},\d{3}',w[4])]
    nums.sort(key=lambda w:w[0]);assert len(nums)==48
    vals=[int(w[4].replace(',',''))for w in nums]
    assert vals[12]==648309 and vals[42]==404411 and vals[-1]==519805
    fees={f'{i:02d}':{'mean_basic_fee':v,'source':{'file':p.name,'page':13,'x':nums[i-1][0]},'observation_period':'FY2024 normal birth direct-payment claims','excludes':['room_extra','obstetric_premium','other_fees']}for i,v in enumerate(vals[:-1],1)}
    (ROOT/'data/birth_fees.json').write_text(json.dumps(fees,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
