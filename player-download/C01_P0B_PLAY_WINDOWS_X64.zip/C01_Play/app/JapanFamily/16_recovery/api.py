"""Local reproducible generation API; no automatic database mutation."""
import json,argparse
from http.server import BaseHTTPRequestHandler,HTTPServer
from model import Model,VERSION,InitialConditionError
class Handler(BaseHTTPRequestHandler):
    model=None
    def log_message(self,*args):pass
    def send(self,status,data):
        b=json.dumps(data,ensure_ascii=False,allow_nan=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):self.send(200,{'model_version':VERSION,'policy_birth_window':['2026-08-01','2026-11-30'],'full_joint_validated':False,'financially_playable':False})if self.path=='/health'else self.send(404,{'error':'not_found'})
    def do_POST(self):
        if self.path not in ['/generate','/generate-batch']:return self.send(404,{'error':'not_found'})
        try:
            if int(self.headers.get('Content-Length',0))>1000000:raise ValueError('Request too large')
            p=json.loads(self.rfile.read(int(self.headers.get('Content-Length',0))))
            if not isinstance(p,dict):raise ValueError('JSON object required')
            if self.path=='/generate-batch':
                n=p.pop('n');seed=p.pop('seed',0)
                if not isinstance(n,int)or isinstance(n,bool)or not 1<=n<=1000:raise ValueError('Batch n 1..1000')
                result=[self.model.generate(seed=f'{seed}/{i}',**p)for i in range(n)]
            else:result=self.model.generate(**p)
            self.send(200,result)
        except InitialConditionError as e:self.send(422 if e.kind!='input_contradiction'else 400,{'error':str(e),'kind':e.kind})
        except (ValueError,TypeError,KeyError)as e:self.send(400,{'error':str(e)})
def main():
    a=argparse.ArgumentParser();a.add_argument('--port',type=int,default=8767);v=a.parse_args();Handler.model=Model();HTTPServer(('127.0.0.1',v.port),Handler).serve_forever()
if __name__=='__main__':main()
