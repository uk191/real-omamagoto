"""Actual restored-release functional and HTTP tests."""
import json,subprocess,sys,threading,urllib.request,urllib.error,hashlib
from pathlib import Path
from http.server import HTTPServer
from model import Model,VERSION,InitialConditionError
import importlib.util
api_spec=importlib.util.spec_from_file_location('recovery_api',Path(__file__).resolve().parent/'api.py')
api_module=importlib.util.module_from_spec(api_spec);api_spec.loader.exec_module(api_module);Handler=api_module.Handler
ROOT=Path(__file__).resolve().parent
def main():
    m=Model();results=[]
    def check(name,test):
        try:assert test();results.append({'name':name,'passed':True})
        except Exception as e:results.append({'name':name,'passed':False,'error':repr(e)})
    def generated(**kwargs):return m.generate('13',seed='restored-functional',include_region=False,**kwargs)
    base=generated();check('same_seed',lambda:base==generated())
    foreign=subprocess.check_output([sys.executable,str(ROOT/'model.py'),'--pref','13','--seed','restored-functional','--no-region'])
    check('independent_process_reproducibility',lambda:base==json.loads(foreign))
    for age in [18,22,42,46]:
        check('fixed_mother_age_'+str(age),lambda age=age:next(x for x in generated(conditions={'mother_age':age})['persons'] if x['person_id']=='mother')['age_years']==age)
    check('fixed_household_job_income_6m',lambda:sum(generated(conditions={'household_income_yen':6000000})['automatic_jobs_annual'].values())==6000000)
    check('fixed_private_rental',lambda:generated(conditions={'tenure':'private_rental'})['housing']['tenure']=='private_rental')
    check('single_parent',lambda:generated(conditions={'partner_present':False,'legal_status':'nonmarital'})['household']['legal_birth_status']=='nonmarital')
    check('certificate_false',lambda:not base['quality_flags']['financially_playable'])
    check('two_months_present',lambda:len(base['automatic_periods'])==2)
    for name,kwargs in [('negative_invoice',{'scenario':{'birth_invoice':-1}}),('nan_rate',{'scenario':{'mortgage_rate':float('nan')}}),('unknown_scenario',{'scenario':{'invent':0}}),('invalid_seed',{'seed':True}),('unsupported_december',{'birth_date':'2026-12-01'})]:
        def rejects(kwargs=kwargs):
            try:m.generate('13',include_region=False,**kwargs)
            except (InitialConditionError,ValueError):return True
            return False
        check(name,rejects)
    Handler.model=m;server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}'
    check('HTTP_health',lambda:json.load(urllib.request.urlopen(url+'/health'))['model_version']==VERSION)
    def post(path,payload):
        req=urllib.request.Request(url+path,data=payload,headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req) as r:return r.status,json.load(r)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    check('HTTP_generate',lambda:post('/generate',json.dumps({'prefecture_code':'12','seed':'http','include_region':False}).encode())[0]==200)
    check('HTTP_bad_JSON',lambda:post('/generate',b'{')[0]==400)
    check('HTTP_policy_window_422',lambda:post('/generate',b'{"prefecture_code":"13","birth_date":"2026-12-01"}')[0]==422)
    check('HTTP_invalid_batch',lambda:post('/generate-batch',b'{"n":0}')[0]==400)
    server.shutdown();server.server_close()
    result={'model_version':VERSION,'tests':results,'passed':sum(x['passed'] for x in results),'total':len(results)}
    (ROOT/'validation/tests.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result),flush=True);assert result['passed']==result['total']
if __name__=='__main__':main()
