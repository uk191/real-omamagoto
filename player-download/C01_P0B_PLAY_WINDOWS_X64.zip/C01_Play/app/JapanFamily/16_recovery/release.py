"""Build an honest complete research distribution, with independently saved trials."""
import json,hashlib,zipfile,shutil,datetime,sqlite3,gzip
from pathlib import Path
ROOT=Path(__file__).resolve().parent;P=ROOT.parent;OUT=P.parent.parent/'outputs/A25_02r2'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def main():
    OUT.mkdir(parents=True,exist_ok=True);v=ROOT/'validation';s=read(v/'summary.json');tests=read(v/'tests.json');db=read(v/'database_audit.json');ext=read(v/'external_comparison.json');legacy=read(P/'15_initial_state/validation/legacy_regression.json');q=read(v/'asset_quantile_calibration.json');sens=read(v/'sensitivity.json');cat=read(ROOT/'data/expanded_catalogue.json');back=read(ROOT/'data/backlog.json')
    assert s['generated']==103400 and s['failures']==s['internal_violations']==0
    digest=hashlib.sha256();n=0
    with gzip.open(v/'states.jsonl.gz','rt',encoding='utf-8') as f:
        for line in f:digest.update(line.encode());n+=1
    assert n==103400 and digest.hexdigest()==s['payload_sha256'],'Trial file is incomplete or changed'
    assert tests['passed']==tests['total'] and q['max_abs_z']<7 and all(not x['errors'] for x in sens)
    assert db['all_inherited_tables_unchanged'] and db['integrity_check']=='ok' and legacy['A1_tests']==22 and legacy['A1_failures']==0
    assert len(cat['rows'])==821 and back['old_unresolved_candidates']==505
    old=read(P/'15_initial_state/data/expanded_catalogue_A25.json');assert old['rows']==cat['rows'][:len(old['rows'])]
    sources=read(ROOT/'data/sources.json')
    for x in sources:assert x['status']=='acquired_original' and sha(ROOT/'raw'/x['file'])==x['sha256']
    c=sqlite3.connect(f'file:{P / "data/region.sqlite"}?mode=ro',uri=True);assert c.execute('pragma integrity_check').fetchall()==[('ok',)];c.close()
    report=f'''# A-1～A-2.5 統合構築報告：A2.5-0.2r2

2026年10月15日更新。これは動作する研究版であり、2026年全出生家庭の同時分布を外部検証済みの完成モデルではない。

## 今回の実装

保存済みA2.5-0.1を継承し、A-1のRegionModel、地理キー、変数・原表・出典・将来人口・検証コードを保持。追加コードは16_recoveryに分離した。旧コードの改変を避け、母親年齢の検索索引、入力された通常就業所得の制約、第一子嫡出出生に対する妊娠時就業の接続、資産・負債の構成と二か月の推定会計を追加した。

実在市区町村と匿名生活圏は既存出生家庭モデルを介して接続する。子あり世帯ストックと出生フローを区別する既存地域比較と出生順位別抽選を保持。全国抽選と47都道府県指定に対応する。

## 一次資料と推定

追加原表は2024年全国家計構造調査7-111-1、7-81-1、および厚労省の正常分娩費用資料の3ファイル。ファイル名、取得日時、SHA256、URLを追加一次資料台帳に記録した。2026年公表資料であっても観測年は2024年度等であり、2026年観測値とは称しない。従来の原表・23出典も別名前空間で継承する。

住宅ローン有無は住宅所有関係×可処分所得に条件付けた2024年保有数から抽選。資産の保有率は所得・世帯人数・ローン有無の公表セルを使用し、正の保有額は公表分位形状を所得別平均で移送する。通貨性・定期性預金の同時保有は公表率から接続するが、保有額の細かい構成と相関は推定。その他負債の重複保有はFréchet上下限間のシナリオであり実測の同時分布ではない。金利・残期間・支出分散も観測ではなく感度仮定。

第一子の嫡出出生で入力条件に抵触しない場合、NIPSSの初婚・第一子についての妊娠時→1歳時就業の同時分布を利用する。年齢・学歴・職業との接合、妊娠中の離職日、出生時の実際の資格は推定。第二子以降は従来の6歳未満児のいる母親の就業参照を残す。稀な年齢を恣意的に除外せず、原表の支持が確認できない条件は支持不明として返す。

入力世帯所得は両親の通常就業所得の合計を原表階級内で指定値に制約するもの。財産所得を含む総所得、出生年の実現年収、出生月給与ではない。通常就業所得2022年、家賃2023年、資産2024年など時点が混在し、2026年への賃金・地価の完全な時点補正は未実装。

## 今回実際に再実行した検証

- 47都道府県×2200＝{s['generated']:,}世帯。生成失敗{s['failures']}件、検査対象の内部違反{s['internal_violations']}件。
- 独立プロセスの同一seed再現、固定年齢18/22/42/46歳、所得600万円、賃貸、単親、極端入力・欠測方針・HTTP境界：{tests['passed']}/{tests['total']}件通過。
- 出生年齢×出生順位の同一出典モンテカルロ校正：最大|z|={s['birth_MC_max_abs_z']:.4f}、閾値7。
- 資産保有者の正の保有額分位点：{q['trials']:,}試行、最大|z|={q['max_abs_z']:.4f}、閾値7。これは実装の同一出典校正であって出生世帯への外部適合ではない。
- 12感度シナリオ×470件。所得・家賃・資産・人数・出生順位について平均、分散、1/10/25/50/75/90/99%分位、地域・住宅・順位別条件付き分布、属性の組み合わせを別JSONに保存。
- A-1回帰22件通過、既存A-2の回帰と地域キャッシュ試験も再実行。旧DBの{db['inherited_table_count']}テーブルは全行の順序付き指紋が追加前後で一致。SQLite整合性検査ok、外部キー違反なし。

内部検査は新生児0歳、人物ID一意、名簿人数、市区町村の県整合、未検証の証明フラグがfalseであること等に限定される。会計関数は旧版テストを別実行。未測定の相関や全制度の正しさまで検証済みとはしない。

## 外部比較で残る乖離

2024年の夫婦と2歳以下の子1人の公表就業所得平均{ext['source_job_income_mean_2024']:,.0f}円に対し、生成された第一子嫡出・3人・参照祖父母なし家庭の通常就業所得は{ext['generated_income_reference_2022']:,.0f}円（2025年県別出生重み）。比率{ext['ratio_different_years_and_populations']:.4f}。観測年・母集団・年所得と正常月への変換が異なり、適合通過とは判定しない。この差を根拠なく所得倍率で埋めていない。

## 未解決と制限

変数台帳821項目（従来801をそのまま保持＋20）、既存未取得・個別未検証505候補を保持。追加取得済みだが未接続の世帯主年齢・学歴・従業上地位・就業時間・世帯類型・純資産階級等の原表列も台帳で区別した。全548候補の取得が終わったとは称しない。

出生履歴と既存同居子は年齢遡及シナリオであり、死亡・別居・再婚・祖父母扶養を含む完全な出生歴同時分布ではない。外国籍、複数出生、実際の税・社会保険加入、全市区町村の国保、勤務先制度、就業中断・復職の月単位経路は未完成。

二か月の現金試算は、通常年収÷12、給与と給付の入金遅れ、柏市税国保ベンチマーク、資格・承認の仮定を含む。初月給与を通常月で初期化し、児童手当の偶数月処理は年齢境界の厳密な前2か月計算ではない。年末調整、賞与、複数出生の給付、極低所得時の支出下限等に未解決がある。2026年8～11月出生のみ受理し、12月等は未取得の翌年制度を必要とするため明示拒否する。

automatic_two_months_fundedは指定仮定内で二か月の会計が資金化できたかだけを示す。実人口の貧困率ではない。financially_playableとnewborn_full_joint_externally_validatedはfalseを維持する。

## 復元・破損と配布

作業場所の更新が失われ、前回の試行結果は復元できなかった。今回の数値はすべて再試行したもの。保存済みコードZIPは途中切断していたためCRC一致したメンバーのみ救出し、不足原表を公式URLから再取得した。基盤DBの展開ファイルも切断を検出し、ハッシュ一致の保存済みZIPから欠損末尾を補い、全SQLite整合性検査を実行した。切断の原因は未解明で、原因解決を宣言しない。

統合ZIPにコード、追加原表、更新DB、30件の生成例、全検証集計を収録する。大量試行の個票は別のA25_02r2_103400世帯検証個票.jsonl.gzに分けた。これは合成家庭であり個人情報ではない。旧版の過去検証は各旧ディレクトリに保存し、今回の再試行と混同しない。

## 再実行

Python3と同梱核だけで生成可能。原表変換にはopenpyxl/PyMuPDFを使用する。

```bash
python3 16_recovery/model.py --pref 13 --seed demo
python3 16_recovery/model.py --pref 12 --seed fixed --conditions '{{"mother_age":32,"birth_rank":2}}'
python3 16_recovery/api.py --port 8767
python3 16_recovery/acquire.py
python3 16_recovery/compile.py
python3 16_recovery/catalogue.py
python3 16_recovery/tests.py
python3 16_recovery/validate.py 2200
python3 16_recovery/check_asset_quantiles.py
python3 16_recovery/experiments.py
python3 15_initial_state/legacy_regression.py
python3 16_recovery/external.py
python3 16_recovery/install.py
python3 16_recovery/release.py
```

API: POST /generate、POST /generate-batch（n=1～1000）、GET /health。条件・seed・モデル版・入力原表を揃えることで再現する。未観測値を行政実績として穴埋めしない。
'''
    (ROOT/'INTEGRATED_REPORT.md').write_text(report)
    files={'report':OUT/'A1_A25_統合構築報告_A2.5-0.2r2.md','catalogue':OUT/'A25_02r2_全変数台帳.json','sources':OUT/'A25_02r2_追加一次資料台帳.json','backlog':OUT/'A25_02r2_未解決候補台帳.json','examples':OUT/'A25_02r2_生成事例30件.json','validation':OUT/'A25_02r2_統計検証結果.json','trials':OUT/'A25_02r2_103400世帯検証個票.jsonl.gz','zip':OUT/'A1_A25_日本出生家庭初期状態基盤_A2.5-0.2r2.zip','release':OUT/'A25_02r2_RELEASE.json'}
    files['report'].write_text(report)
    for key,src in [('catalogue',ROOT/'data/expanded_catalogue.json'),('backlog',ROOT/'data/backlog.json'),('examples',ROOT/'data/examples.json'),('trials',v/'states.jsonl.gz')]:shutil.copyfile(src,files[key])
    files['sources'].write_text(json.dumps({'model_version':s['model_version'],'inherited':{'root':'JapanFamily/15_initial_state','entries':read(P/'15_initial_state/data/sources.json')},'added':{'root':'JapanFamily/16_recovery/raw','entries':sources}},ensure_ascii=False,indent=2))
    files['validation'].write_text(json.dumps({p.stem:read(p) for p in sorted(v.glob('*.json'))},ensure_ascii=False,indent=2))
    included=[]
    with zipfile.ZipFile(files['zip'],'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in sorted(P.rglob('*')):
            if not p.is_file() or any(k.startswith('.') for k in p.relative_to(P).parts) or any(k in p.parts for k in ['__pycache__','prefectures','shards','resume_runs']):continue
            if p.name.endswith(('.pyc','.tmp')) or p.name in ['states.jsonl.gz','region.restored.sqlite','region.truncated-preserved.sqlite']:continue
            relative=p.relative_to(P.parent);z.write(p,str(relative));included.append(str(relative))
    with zipfile.ZipFile(files['zip']) as z:assert z.testzip() is None
    release={'model_version':s['model_version'],'generated':s['generated'],'failures':s['failures'],'internal_violations':s['internal_violations'],'functional_tests_passed':tests['passed'],'financially_playable':False,'full_joint_externally_validated':False,'package_crc':'ok','package_entries':len(included),'files':{k:{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in files.items() if k!='release'}}
    files['release'].write_text(json.dumps(release,ensure_ascii=False,indent=2));print(json.dumps(release,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
