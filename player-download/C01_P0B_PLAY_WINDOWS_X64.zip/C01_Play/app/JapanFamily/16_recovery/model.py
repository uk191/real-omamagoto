"""Recovery release: preserve A1/A2/A25; explicit estimated automatic cash scope.

No unobserved quantity is advertised as an administrative observation. The full
population game certificate stays false, even when two estimated months fund.
"""
from pathlib import Path
import sys,json,gzip,random,hashlib,copy,math,calendar
from datetime import date,timedelta
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent
sys.path.insert(0,str(PROJECT/'15_initial_state'))
from initial_state import InitialStateModel,InitialConditionError
from policy import _policy,employee_social,standard_remuneration,monthly_withholding,maternity_allowance,childcare_leave_benefit,child_allowance
from municipal import resident_tax_2026_kashiwa,salary_income_2025_resident,nhi_2026_kashiwa
from estimators import interpolate_quantile,spending_scenario,draw_weighted
from accounting import settle_one_period,net_worth
from family import FamilyModel,Dist,age_match,overlaps,amount
VERSION='A2.5-0.2r2'
DEFAULT={'asset_rho':.5,'asset_tail':'lognormal','budget_cv':.35,'budget_concentration':50,'liquidity_concentration':20,'mortgage_rate':.02,'mortgage_months':240,'other_debt_rate':.08,'other_debt_months':60,'benefit_lag_months':1,'father_leave_days':28,'birth_invoice':None,'birth_invoice_cv':.2,'birth_extra':0,'nonhousing_union_position':.5,'mortgage_tenure_conditioning':True}
def rng(seed,component):return random.Random(int.from_bytes(hashlib.sha256(f'{VERSION}:{seed}:{component}'.encode()).digest()[:16],'big'))
DEFAULT['maternal_phase']='nipss_pregnancy'
def di_code(v):
    if v is None:return '00'
    for i,up in enumerate([2,3,4,5,6,8,10,12.5,15],1):
        if v<up*1000000:return f'{i:02d}'
    return '10'
class IndexedFamily(FamilyModel):
    """Index age-supported source rows without changing legacy source weights.

    Original decade cache matches the actual source decades and is NOT a bug.
    An exact-age index makes lookup explicit in the new implementation.
    """
    def __init__(self):
        super().__init__();self.parent_age_rows={}
        for sex,rows in self.g['jobs'].items():
            for age in range(15,91):self.parent_age_rows[(sex,age)]=[x for x in rows if age_match(x['age_interval'],age)]
    def parent(self,who,sex,a,employed,hh,r,coarse=None,inc=None):
        if not employed:return super().parent(who,sex,a,employed,hh,r,coarse,inc)
        def build():
            def select(rows):return [x for x in rows if(coarse is None or x['coarse']==coarse)and(inc is None or overlaps(x['income_interval'],inc))and(hh[1]is None or x['income_interval'][0]<hh[1])]
            rows=select(self.parent_age_rows.get((sex,a),[]));fb=False
            if not any(x['weight']for x in rows):rows=select(self.g['jobs'][sex]);fb=True
            return Dist(rows),fb
        dist,fb=self.memo(('parent_exact_age',sex,a,coarse,tuple(inc or[None,None]),tuple(hh)),build);x=dist.draw(r)
        return {'age':a,'employed':True,'education_coarse':x['coarse'],'education':x['education'],'occupation_code':x['occupation'],'occupation':x['occupation_label'],'main_job_income':amount(x['income_interval'],r),'reference_year':2022,'source':x['source'],'age_backoff':fb}
class Model:
    def __init__(self):
        self.old=InitialStateModel(base_model=IndexedFamily());self.base=self.old.base
        with gzip.open(ROOT/'data/kernels.json.gz','rt',encoding='utf-8')as f:self.k=json.load(f)
        self.fees=json.loads((ROOT/'data/birth_fees.json').read_text())
    def prepare_reference(self,pref,conditions,seed,include_region,sc):
        h=conditions or{};b=None
        for attempt in range(1000):
            b=self.base.generate(pref,conditions,seed=f'{VERSION}/{seed}/{attempt}',include_region=include_region)
            if 'household_income_yen'not in h:break
            target=h['household_income_yen'];parents=[(who,b[who])for who in ['mother','father']if b[who]is not None]
            limits=[]
            for who,p in parents:
                if who+'_income_yen'in h:lo=hi=h[who+'_income_yen']
                else:
                    lo,hi=p['main_job_income']['interval'];hi=None if hi is None else hi if hi==lo else hi-1
                if lo is None:break
                limits.append((who,round(lo),target if hi is None else round(hi)))
            if len(limits)!=len(parents)or not sum(x[1]for x in limits)<=target<=sum(x[2]for x in limits):continue
            if len(limits)==1:b[limits[0][0]]['main_job_income']['value']=target
            else:
                (who,lo,hi),(other,ol,oh)=limits;lower=max(lo,target-oh);upper=min(hi,target-ol)
                v=rng(seed,'fixed-total-allocation').randint(lower,upper);b[who]['main_job_income']['value']=v;b[other]['main_job_income']['value']=target-v
            b['fixed_total_allocation']='User2026 normal-job total, source2022 bin likelihood proxy; no residual other income';break
        else:raise InitialConditionError('No source-bin supported allocation for fixed household total within1000 proposals','sampling_limit')
        eligible=sc['maternal_phase']=='nipss_pregnancy'and b['legal_birth_status']=='marital'and b['child']['birth_rank']==1 and b['mother']['age']is not None and b['mother']['age']>=15 and not any(k in h for k in ['mother_employed','mother_occupation','mother_income_yen','household_income_yen'])
        phase={'kind':'legacy_under6_or_input_conditioned_phase','applied':False}
        if eligible:
            joint=draw_weighted(_policy()['maternal_pre_post_joint'],rng(seed,'pregnancy-phase'));pre=joint['pre_status'];wanted={'妊娠時正規の職員':'regular','妊娠時パート・派遣':'nonregular','妊娠時自営業主・家族従業者・内職':'self_employed','妊娠時無職・学生':None}[pre]
            original=copy.deepcopy(b['mother']);candidate=None
            if wanted is None:
                candidate=copy.deepcopy(original);candidate.update(employed=False,occupation_code=None,occupation=None,main_job_income={'value':0,'interval':[0,0],'kind':'estimated_pregnancy_nonemployment'});candidate['work_context']={'employment_type':None,'reference_hours':None,'industry':None}
            else:
                r=rng(seed,'pregnancy-job')
                for j in range(200):
                    try:
                        p=self.base.parent('mother','2',original['age'],True,[0,None],r,coarse=original['education_coarse']);p['work_context']=self.base.work(b['prefecture_code'],'2',p,r)
                    except ValueError:continue
                    if p['work_context'].get('employment_type')==wanted:candidate=p;break
            phase={'kind':'NIPSS2020_24_first_married_firstbirth_joint_transported_to2026_first_marital_birth; age_education_job_join_estimated','applied':candidate is not None,'joint':joint,'pregnancy_status':wanted,'source':joint['raw_row'],'exit_timing':'one_year_nonwork_assumed_exit_at_prenatal_start; not observed','quit_before_birth_scenario':wanted in ['regular','nonregular']and joint['one_year_status']=='無職・学生','legacy_mother_reference':original}
            if candidate:
                candidate.update({k:original[k]for k in ['age_interval','source_age_category']if k in original});b['mother']=candidate
        b['maternal_phase_connection']=phase
        return b
    def select(self,table,m,di,kind,c,required):
        for key in dict.fromkeys([f'{m}|{di}|{kind}:{c}',f'{m}|00|{kind}:{c}',f'{m}|00|size:0','0|00|size:0']):
            row=self.k[table].get(key)
            if row and all(row.get(a,{}).get('value')is not None for a in required) and (table!='holders' or row['2']['value']>0):return key,row
        return None,None
    def mortgage(self,b,seed,sc):
        legacy=b['finances']['mortgage_present_any_property'];di=di_code(b['finances']['disposable_income_OECD']['value']);ten='01'if b['housing']['tenure']=='owner'else'02'
        if not sc['mortgage_tenure_conditioning']:return legacy,{'kind':'legacy_mortgage_association','legacy':legacy,'probability':None}
        for d in dict.fromkeys([di,'00']):
            a=self.k['holders'].get(f'1|{d}|tenure:{ten}',{}).get('2');z=self.k['holders'].get(f'2|{d}|tenure:{ten}',{}).get('2')
            if a and z and a['value']is not None and z['value']is not None and a['value']+z['value']>0:
                p=a['value']/(a['value']+z['value']);v=rng(seed,'mortgage-tenure').random()<p
                return v,{'kind':'observed_2024_conditional_transported_to_newborns_2026','legacy':legacy,'probability':p,'tenure':ten,'DI_requested':di,'DI_used':d,'counts':[a,z],'cohort_transport_unverified':True}
        return legacy,{'kind':'unidentified_source_support_legacy_fallback','legacy':legacy,'probability':None}
    def assets(self,b,seed,sc):
        mort,mt=self.mortgage(b,seed,sc);m='1'if mort else'2';di=di_code(b['finances']['disposable_income_OECD']['value']);n=b['housing']['household_size'];size=str(n)if n and n<6 else'6'if n and n>=6 else'0'
        req=['2','211','2111','2112','212','213','214','31','32','222','223']
        hk,h=self.select('holders',m,di,'size',size,req);mk,mu=self.select('means',m,di,'size',size,['211','2111','212','213','214','32','222','223'])
        trace={'mortgage_connection':mt,'holder_key':hk,'mean_key':mk,'observed_year':2024,'DI_code':di,'amount_shape_income_joint_unverified':True,'component_dependence':{'rho':sc['asset_rho'],'kind':'unobserved_sensitivity'},'legacy_net_reference_never_balanced':b['finances']['net_total_assets']}
        if h is None or mu is None:return None,[],{**trace,'reason':'unidentified_holder_or_mean_support'}
        den=h['2']['value'];p={a:max(0,min(1,h[a]['value']/den))for a in req};r=rng(seed,'assets');shared=r.random()
        amount_r=rng(seed,'positive-asset-amounts');shared_amount=amount_r.random()
        def u():return shared if r.random()<sc['asset_rho']else r.random()
        def au():return shared_amount if amount_r.random()<sc['asset_rho']else amount_r.random()
        def amount(a,prob=None):
            q=_policy()['asset_holder_quantiles'].get(f'{m}|{size}|{a}')or _policy()['asset_holder_quantiles'].get(f'{m}|0|{a}')
            v=interpolate_quantile(q['points'],min(1-1e-12,max(1e-12,au())),sc['asset_tail'])if q else None
            # Quantile shape comes from all DI levels; only mean is DI-adjusted.
            if v is not None:
                key0=f'{m}|00|size:{size}';h0=self.k['holders'].get(key0);mu0=self.k['means'].get(key0)
                if a in mu and h0 and mu0 and a in h0 and a in mu0 and h0['2']['value'] and h0[a]['value'] and mu0[a]['value'] and prob and mu[a]['value']is not None:
                    v=round(v*(mu[a]['value']/prob)/(mu0[a]['value']/(h0[a]['value']/h0['2']['value'])))
                return max(1,v)
            if a in mu and prob and mu[a]['value']is not None and mu[a]['value']>0:
                mean=mu[a]['value']*1000/prob;s=math.sqrt(math.log(2));return max(1,round(r.lognormvariate(math.log(mean)-s*s/2,s)))
            return None
        accounts=[]
        def add(a,name,side,liquid,bal):accounts.append({'account_id':a,'name':name,'side':side,'liquid_cash':liquid,'balance':bal})
        dep=max(p['211'],p['2111'],p['2112']);pc=min(dep,p['2111']);pt=min(dep,p['2112']);both=max(0,pc+pt-dep)
        # Fréchet-consistent four-state deposit union; no two independent zero draws.
        x=r.random();currency=x<pc;term=(x<both or pc<=x<dep)
        if currency or term:
            total=amount('211',dep)
            if total is None:return None,[],{**trace,'reason':'unidentified_positive_deposit_amount'}
            if currency and term:
                total=max(2,total);fraction=max(.001,min(.999,mu['2111']['value']/mu['211']['value']))if mu['211']['value']else .5
                fraction=r.betavariate(fraction*sc['liquidity_concentration'],(1-fraction)*sc['liquidity_concentration']);cash=max(1,min(total-1,round(total*fraction)))
            else:cash=total if currency else 0
        else:total=cash=0
        add('cash','currency_deposit','asset',True,cash);add('term','term_deposit','asset',False,total-cash)
        for a,name in [('212','insurance_reserve'),('213','securities'),('214','other_financial'),('32','other_property')]:add(name,name,'asset',False,amount(a,p[a])if u()<p[a]else 0)
        add('home','current_home','asset',False,amount('31',1)if b['housing']['tenure']=='owner'else 0)
        add('mortgage','housing_and_land_debt','liability',False,amount('221',1)if mort else 0)
        lower=max(p['222'],p['223']);upper=min(1,p['222']+p['223']);union=lower+(upper-lower)*sc['nonhousing_union_position']
        add('other_debt','nonhousing_and_installment_debt','liability',False,amount('222',union)if u()<union else 0)
        loans=[]
        for a,rate,months in [('mortgage',sc['mortgage_rate'],sc['mortgage_months']),('other_debt',sc['other_debt_rate'],sc['other_debt_months'])]:
            v=next(x for x in accounts if x['account_id']==a)['balance']
            if v:loans.append({'account_id':a,'annual_rate':rate,'remaining_months':months,'kind':'unobserved_contract_sensitivity'})
        trace['holder_probabilities']=p;trace['deposit_mix_unverified']=True;trace['nonhousing_union_bounds']=[lower,upper];trace['nonhousing_union_probability']=union
        return accounts,loans,trace
    def generate(self,prefecture_code,conditions=None,seed=0,birth_date='2026-10-01',initialization=None,include_region=True,scenario=None):
        if not isinstance(seed,(int,str))or isinstance(seed,bool):raise InitialConditionError('Seed must be string or integer')
        birth=date.fromisoformat(birth_date)
        if not date(2026,8,1)<=birth<=date(2026,11,30):raise InitialConditionError('Policy window is August-November 2026; older/2027 rules not loaded','unidentified_statistical_support')
        sc={**DEFAULT,**(scenario or{})}
        if set(sc)-set(DEFAULT):raise InitialConditionError('Unknown scenario key')
        for k in ['asset_rho','nonhousing_union_position']:
            if not isinstance(sc[k],(float,int))or not 0<=sc[k]<=1:raise InitialConditionError('Invalid '+k)
        if sc['asset_tail']not in ['lognormal','pareto']:raise InitialConditionError('Invalid tail')
        if sc['maternal_phase']not in ['nipss_pregnancy','legacy_under6']:raise InitialConditionError('Invalid maternal phase')
        for k in ['budget_cv','budget_concentration','liquidity_concentration','mortgage_rate','other_debt_rate','birth_extra','birth_invoice_cv']:
            if not isinstance(sc[k],(int,float))or not math.isfinite(sc[k])or sc[k]<0 or(k.endswith('concentration')and sc[k]==0):raise InitialConditionError('Invalid '+k)
        for k in ['mortgage_months','other_debt_months','benefit_lag_months','father_leave_days']:
            if not isinstance(sc[k],int)or isinstance(sc[k],bool)or sc[k]<0 or(k.endswith('months')and k!='benefit_lag_months'and sc[k]==0):raise InitialConditionError('Invalid '+k)
        if sc['father_leave_days']>28 or sc['benefit_lag_months']>3:raise InitialConditionError('Scenario outside implemented leave/receipt scope')
        if not isinstance(sc['birth_extra'],int)or isinstance(sc['birth_extra'],bool)or not isinstance(sc['mortgage_tenure_conditioning'],bool):raise InitialConditionError('Integer extra invoice and boolean mortgage scenario required')
        b=self.prepare_reference(prefecture_code,conditions,seed,include_region,sc)
        if sc['birth_invoice']is None:
            mu=self.fees[b['prefecture_code']]['mean_basic_fee'];sigma=math.sqrt(math.log1p(sc['birth_invoice_cv']**2))
            invoice=round(rng(seed,'birth-invoice').lognormvariate(math.log(mu)-sigma*sigma/2,sigma))+12000
        else:invoice=sc['birth_invoice']
        if not isinstance(invoice,int)or isinstance(invoice,bool)or invoice<0:raise InitialConditionError('Invalid birth invoice')
        init=copy.deepcopy(initialization or{});init.setdefault('roster_scenario','backcast_under18_co_residence')
        if 'accounts'in init:
            aa=init['accounts']
            if not isinstance(aa,list)or any(not isinstance(a,dict)for a in aa):raise InitialConditionError('Accounts must be an array of objects')
            if len({a.get('account_id')for a in aa})!=len(aa)or sum(a.get('liquid_cash')is True for a in aa)!=1:raise InitialConditionError('Unique accounts and one settlement account required')
            if any(a.get('balance')is not None and(not isinstance(a['balance'],int)or isinstance(a['balance'],bool)or a['balance']<0)for a in aa):raise InitialConditionError('Nonnegative integer account balances required')
        state=self.old.generate(prefecture_code,conditions,seed,birth_date,init,include_region,reference=b)
        accounts,loans,trace=self.assets(b,seed,sc)
        if 'accounts'in init:accounts=copy.deepcopy(init['accounts']);trace['account_override']='explicit_user_values'
        if 'loans'in init:loans=copy.deepcopy(init['loans'])
        jobs={};unknown=[]
        for who in ['mother','father']:
            p=b[who];value=p['main_job_income']['value']if p else 0
            if p and value is None:
                lo,hi=p['main_job_income']['interval']
                if lo is not None and hi is None and lo>0:value=max(round(lo),round(lo/(1-rng(seed,who+'-income-tail').random())**(1/2.5)))
            jobs[who]=value
            if value is None:unknown.append(who+'_income_unidentified')
        pay=copy.deepcopy(init.get('employment',{}));periods=[];current=accounts
        for offset in [0,1]:
            month=birth.month+offset;year=birth.year+(month-1)//12;month=(month-1)%12+1;start=date(year,month,1);end=date(year,month,calendar.monthrange(year,month)[1]);entries=[];calc={}
            def entry(eid,amount,kind):entries.append({'entry_id':eid,'amount':amount,'category':kind})
            for who in ['mother','father']:
                p=b[who];annual=jobs[who];kind=p['work_context'].get('employment_type')if p else None;employee=kind in ['regular','nonregular','employee_other'];fixed=pay.get(who,{})
                normal=None if annual is None else round(annual/12);hours=p['work_context'].get('reference_hours')if p else None
                quit_job=who=='mother'and b['maternal_phase_connection'].get('applied',False)and b['maternal_phase_connection'].get('quit_before_birth_scenario',False)
                insured=fixed.get('kyokai_insured',employee and (normal or 0)>0 and not quit_job)
                # Automatic insurance qualification is an explicit scenario, not verified enrollment.
                eligible=fixed.get('leave_benefit_eligible',insured and employee)
                days=sc['father_leave_days']if who=='father'and eligible else 0
                a=birth if who=='father'else birth-timedelta(days=41);z=birth+timedelta(days=days-1)if who=='father'else birth+timedelta(days=56)
                overlap=max(0,(min(end,z)-max(start,a)).days+1)if who=='mother'or days else 0
                wage=None if normal is None else(0 if who=='mother'and employee else round(normal*(1-overlap/calendar.monthrange(year,month)[1]))if who=='father'and employee else round(normal*(0 if offset==0 else .25))if who=='mother'and annual else normal)
                if quit_job:wage=0
                # Salary lag one month, no fabricated same-day benefit payment.
                salary=normal if offset==0 else previous_wage[who];salary=fixed.get(f'salary_cash_{offset}',salary)
                if quit_job:salary=0
                if salary is not None and(not isinstance(salary,int)or isinstance(salary,bool)or salary<0):raise InitialConditionError('Invalid cash salary')
                standard=standard_remuneration(normal or 0);age=p['age']if p else None
                exempt=(who=='mother'and start.month<=z.month)or(who=='father'and days>=14 and offset==0)
                social=employee_social(b['prefecture_code'],standard,age or 30,salary or 0,start.isoformat(),exempt)if insured else{'total':0,'kind':'nonemployee scenario'}
                withholding=None if salary is None else monthly_withholding(max(0,salary-social['total']),0,False)
                benefit=maternity_allowance(standard,overlap,0,insured)if who=='mother'else childcare_leave_benefit(round((normal or 0)/30),overlap,0,eligible,support_eligible=eligible and days>=14,asof=start.isoformat())
                accrued=benefit.get('amount')if who=='mother'else None if benefit.get('base')is None else benefit['base']+(benefit.get('support')or 0)
                receipt=accrued if sc['benefit_lag_months']==0 else previous_benefit[who]if offset==1 and sc['benefit_lag_months']==1 else 0
                prior=max(0,annual or 0);tax=resident_tax_2026_kashiwa(max(0,salary_income_2025_resident(prior)) if employee else prior,round(prior*.14))
                resident=round(tax['annual_liability']/12)if p else 0
                entry(who+'/salary',salary,'salary_or_business');entry(who+'/social',-social['total'],'social_insurance');entry(who+'/withholding',None if withholding is None else-withholding,'income_tax_withheld');entry(who+'/resident_reserve',-resident,'estimated_tax_reserve');entry(who+'/benefit',receipt,'benefit_received')
                if p and not insured:
                    nhi=nhi_2026_kashiwa([{'assessed_income2025':max(0,salary_income_2025_resident(prior))if employee else prior,'age':age or 30,'preschool':False}],relief_income=prior,all_income_reported=True,no_special_relief_applies=True)
                    entry(who+'/NHI_reserve',-round(float(nhi['annual_equivalent_before_final_rounding'])/12),'estimated_insurance_reserve')
                    entry(who+'/pension',0 if birth.month>=10 else-17920,'scenario_pension_child_under1_exemption')
                calc[who]={'normal_monthly':normal,'earned_wage':wage,'salary_cash':salary,'insured_scenario':insured,'benefit_accrual':accrued,'benefit_cash':receipt,'leave_days_this_period':overlap,'social':social,'resident_tax_benchmark':tax}
            children=[p for p in state['persons']if p['role']in ['newborn','maternal_prior_child','child']and p['date_of_birth']]
            ca=child_allowance(children,start.isoformat(),True)['entitlement_monthly']
            # Birth month cannot create newborn entitlement; payment schedule even months.
            oldchildren=[p for p in children if p['date_of_birth']<birth_date]
            earlier=child_allowance(oldchildren,start.isoformat(),True)['entitlement_monthly']
            cash_ca=2*earlier if month%2==0 else 0
            entry('child_allowance',cash_ca,'benefit_received')
            parents=sum(v for v in jobs.values()if v is not None)if all(v is not None for v in jobs.values())else None
            budget=spending_scenario(parents,state['household']['resident_person_count'],f'{seed}/month{offset}',mode='mean_anchored_compositional_sensitivity',reference_annual_gross=_policy()['budget_income_anchor'],price_transport=True,cv=sc['budget_cv'],concentration=sc['budget_concentration'])
            entry('consumption',None if budget['total_nonhousing']is None else-budget['total_nonhousing'],'consumption')
            rent=b['housing']['monthly_rent']['value'];entry('rent',None if rent is None else-rent,'housing_rent_2023_constant_scenario')
            birth_payment=max(0,invoice+sc['birth_extra']-500000)
            if offset==0:entry('birth_net_invoice',None if birth_payment is None else-birth_payment,'hospital_direct_payment_scenario')
            try:preview=settle_one_period(current,entries,loans)if current is not None else None
            except ValueError as e:preview=None;unknown.append('cash_scope/'+str(e))
            periods.append({'month':start.isoformat()[:7],'cash_entries':entries,'calculations':calc,'child_allowance_entitlement':ca,'expense_scenario':budget,'settlement':preview})
            previous_wage={k:v['earned_wage']for k,v in calc.items()};previous_benefit={k:v['benefit_accrual']for k,v in calc.items()}
            if preview and preview['financially_funded']:current=preview['accounts'];loans=[{**l,'remaining_months':max(1,l['remaining_months']-1)}for l in loans]
            else:current=None
        state['birth_invoice_estimate']={'amount':invoice,'fee_source':self.fees[b['prefecture_code']],'CV':sc['birth_invoice_cv'],'kind':'FY2024 regional mean transported without inflation; unobserved household variance; normal delivery direct payment approved scenario; other extras explicit'}
        if any(p['role']in ['co_resident_grandparent','unclassified_co_resident']for p in state['persons']):unknown.append('additional_person_income_and_insurance_unidentified')
        funded=all(p['settlement']and p['settlement']['financially_funded']for p in periods)
        state['model_version']=VERSION;state['automatic_accounts']={'accounts':accounts,'loans':loans,'net_worth':net_worth(accounts)if accounts else None,'trace':trace};state['automatic_periods']=periods
        state['automatic_jobs_annual']=jobs;state['automatic_scenario']=sc
        state['maternal_phase_connection']=b['maternal_phase_connection']
        if b['maternal_phase_connection'].get('applied'):
            phase=b['maternal_phase_connection'];state['employment']['mother']['future_path']={'observed_one_year_outcome':phase['joint']['one_year_status'],'source_row':phase['source'],'kind':phase['kind']}
            if phase['quit_before_birth_scenario']:state['employment']['mother']['at_birth_status']='quit_before_birth_estimate'
        if conditions and 'household_income_yen'in conditions:state['household']['fixed_current_normal_job_total']=conditions['household_income_yen']
        state['household']['reference_co_resident_grandparent']=b['family']['co_resident_grandparent']
        state['household']['reference_household_size']=b['housing']['household_size']
        if b['family']['co_resident_grandparent']:unknown.append('grandparent_reference_not_automatically_materialized; income_and_care_unknown')
        state['quality_flags'].update(financially_playable=False,automatic_two_months_funded=funded,automatic_scope_uncertainties=sorted(set(unknown)),newborn_full_joint_externally_validated=False)
        state['provenance']['automatic']='Mortgage/holder counts2024. Job usual income2022 held nominally fixed, monthly conversion and contracts estimated. Rent2023 fixed. Birth invoice FY2024 regional normal-delivery basic fee plus12000 premium, CV unobserved. National CPI quantity-fixed transport; municipal taxes Kashiwa benchmark. No complete newborn joint validation.'
        return state
if __name__=='__main__':
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--pref',default='13');a.add_argument('--seed',default='demo');a.add_argument('--conditions',default='{}');a.add_argument('--scenario',default='{}');a.add_argument('--no-region',action='store_true');v=a.parse_args()
    print(json.dumps(Model().generate(v.pref,json.loads(v.conditions),v.seed,include_region=not v.no_region,scenario=json.loads(v.scenario)),ensure_ascii=False,indent=2))
