"""Fetch actual official originals; no synthetic replacement on failure."""
from pathlib import Path
import urllib.request,json,hashlib,datetime
ROOT=Path(__file__).resolve().parent
JOBS=[('finance_7-111-1.xlsx','000040490402'),('finance_7-81-1.xlsx','000040490397'),('birth_cost_2025.pdf','https://www.mhlw.go.jp/content/12401000/001584788.pdf')]
def main():
    (ROOT/'raw').mkdir(parents=True,exist_ok=True);(ROOT/'data').mkdir(exist_ok=True)
    rows=[]
    for name,sid in JOBS:
        url=sid if sid.startswith('https:')else f'https://www.e-stat.go.jp/stat-search/file-download?statInfId={sid}&fileKind=0';p=ROOT/'raw'/name
        r={'file':name,'url':url,'observation_year':2024,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
        try:
            if not p.exists():
                with urllib.request.urlopen(url,timeout=90) as q:b=q.read()
                if not b.startswith(b'%PDF'if name.endswith('.pdf')else b'PK'):raise ValueError('Not original binary')
                p.write_bytes(b)
            r.update(status='acquired_original',sha256=hashlib.file_digest(p.open('rb'),'sha256').hexdigest(),bytes=p.stat().st_size)
        except Exception as e:r.update(status='not_acquired',error=repr(e))
        rows.append(r);print(json.dumps(r),flush=True)
    (ROOT/'data/sources.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
    assert all(r['status']=='acquired_original'for r in rows)
if __name__=='__main__':main()
