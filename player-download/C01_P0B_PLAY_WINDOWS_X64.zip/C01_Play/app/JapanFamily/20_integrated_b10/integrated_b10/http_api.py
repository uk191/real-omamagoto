"""Local player-facing API. Research snapshots/seeds/latent values have no route."""
import argparse
import json
from http.server import BaseHTTPRequestHandler,HTTPServer

from .coordinator import Simulation,IntegrationError,DecisionRequired,VERSION
from .legacy import a18_engine_class


class Handler(BaseHTTPRequestHandler):
    engine=None
    simulations={}

    def log_message(self,*args):pass

    def reply(self,status,payload):
        data=json.dumps(payload,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)

    def do_GET(self):
        if self.path=='/health':
            return self.reply(200,{'version':VERSION,'scope_months':24,'A_version':'A3.0-0.2',
                'B_version':'B-1.0-preintegration.2','functional_coupling':True,
                'national_external_validity':False,'causal_effects_identified':False})
        self.reply(404,{'error':'not_found'})

    def do_POST(self):
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=6_000_000:raise IntegrationError('Request body outside1..6MB')
            data=json.loads(self.rfile.read(length))
            if not isinstance(data,dict):raise IntegrationError('JSON object required')
            for field in ['research_continue','stop_on_decision','include_region']:
                if field in data and type(data[field]) is not bool:raise IntegrationError(field+' must be a JSON boolean')
            observer=data.pop('observer','mother')
            if self.path=='/initialize':
                sim=Simulation.initialize(**data,engine=self.engine)
                result=sim.player_view(observer);key=sim.identity['run_id']
                if key in self.simulations:return self.reply(409,{'error':'simulation_already_exists'})
                self.simulations[key]=sim
            elif self.path in ['/step','/simulate','/observe']:
                key=data.pop('simulation_id');sim=self.simulations.get(key)
                if sim is None:return self.reply(404,{'error':'simulation_not_found'})
                # Authorize registered observer before advancing any state.
                sim.player_view(observer)
                if self.path=='/observe':
                    if data:raise IntegrationError('Unknown observe fields')
                elif self.path=='/step':sim.step(**data)
                else:sim.run(**data)
                result=sim.player_view(observer)
            else:return self.reply(404,{'error':'not_found'})
            self.reply(200,result)
        except DecisionRequired as e:self.reply(409,{'error':'decision_required','message':str(e)})
        except PermissionError as e:self.reply(403,{'error':'observer_not_registered'})
        except (ValueError,TypeError,KeyError) as e:self.reply(400,{'error':type(e).__name__,'message':str(e)})


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8770);args=parser.parse_args()
    Handler.engine=a18_engine_class()();Handler.simulations={}
    server=HTTPServer(('127.0.0.1',args.port),Handler)
    print(json.dumps({'port':server.server_port}),flush=True);server.serve_forever()


if __name__=='__main__':main()
