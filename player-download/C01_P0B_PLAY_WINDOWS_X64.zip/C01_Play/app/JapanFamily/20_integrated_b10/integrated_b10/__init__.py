"""A1–A3.0-0.2 / B-1.0 integration layer, separate from preserved kernels."""
from .coordinator import Simulation, IntegrationError, UnsupportedBirthScope, VERSION

__all__ = ["Simulation", "IntegrationError", "UnsupportedBirthScope", "VERSION"]
