"""Local research CLI. Saves are internal; printed response is observer-only."""
import argparse,json
from .coordinator import Simulation


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prefecture',default='13');ap.add_argument('--seed',type=int,default=42)
 ap.add_argument('--birth-date',default='2026-10-01');ap.add_argument('--months',type=int,default=24)
 ap.add_argument('--research-continue',action='store_true');ap.add_argument('--observer',default='mother')
 ap.add_argument('--save');ap.add_argument('--resume');ap.add_argument('--actions',help='JSON file, zero-based elapsed-month keys')
 args=ap.parse_args();sim=Simulation.load(args.resume)if args.resume else Simulation.initialize(args.prefecture,seed=args.seed,birth_date=args.birth_date)
 actions=json.load(open(args.actions))if args.actions else None
 sim.run(args.months,actions,stop_on_decision=not args.research_continue,research_continue=args.research_continue)
 if args.save:sim.save(args.save)
 print(json.dumps(sim.player_view(args.observer),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
