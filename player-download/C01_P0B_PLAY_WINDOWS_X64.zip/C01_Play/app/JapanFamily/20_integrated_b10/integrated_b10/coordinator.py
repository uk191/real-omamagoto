"""Single-family orchestration over byte-preserved A and B component kernels.

A actions -> A calendar period -> one identified exposure record -> B period ->
observable projection. No child latent parameter is supplied to A.
"""
import copy
import datetime as dt
import hashlib
import json
import math
from pathlib import Path

from .legacy import PROJECT,a18_engine_class
from child_b10 import Child
from child_b10.engine import VERSION as B_VERSION,PARAMETER_HASH as B_PARAMETER_HASH
from child_b10.player_api import parent_observations
from child_b10.randomness import digest
from child_b10.storage import DYNAMIC

VERSION='B-1.0-integrated.1'
A_VERSION='A3.0-0.2'


class IntegrationError(ValueError):pass
class UnsupportedBirthScope(IntegrationError):pass
class DecisionRequired(IntegrationError):pass


def b_seed(master_seed):
    return int.from_bytes(hashlib.sha256(json.dumps([VERSION,'child_stream',master_seed],ensure_ascii=False,separators=(',',':')).encode()).digest()[:8],'big') & (2**63-1)


def global_id(household_id,local_id):
    return household_id+'/'+local_id


def projection_delta(child):
    s=child.research_snapshot(compact=True)
    return {k:s[k] for k in DYNAMIC}


class Simulation:
    """Trusted research controller. player_view() is the only player projection."""
    def __init__(self,engine):self.engine=engine

    @classmethod
    def initialize(cls,prefecture_code='13',*,seed=0,birth_date='2026-10-01',conditions=None,
                   a_scenario=None,birth_profile=None,initial_family=None,
                   observation_opportunity=.6,include_region=True,engine=None,child_seed=None):
        if not isinstance(seed,(int,str)) or isinstance(seed,bool):raise IntegrationError('Integer/string master seed required')
        if child_seed is not None and (type(child_seed) is not int or child_seed<0):raise IntegrationError('Explicit child seed must be a nonnegative integer')
        actual_b_seed=b_seed(seed) if child_seed is None else child_seed
        birth=dt.date.fromisoformat(birth_date)
        if birth.day!=1:raise UnsupportedBirthScope('Integrated calendar scope requires first-of-month birth; standalone B supports other days, but A period exposure cannot be invented')
        profile=copy.deepcopy(birth_profile or {})
        allowed={'gestation_days','birth_weight_kg','birth_length_cm','evidence_kind','known_by'}
        if set(profile)-allowed:raise IntegrationError('Unknown birth profile fields')
        days=profile.get('gestation_days')
        if days is not None and (type(days) is not int or not 259<=days<=293):
            raise UnsupportedBirthScope('B kernel has no calibrated nonterm birth/growth model; A family not replaced by a term child')
        if (isinstance(observation_opportunity,bool) or not isinstance(observation_opportunity,(int,float))
                or not math.isfinite(observation_opportunity) or not 0<=observation_opportunity<=1):raise IntegrationError('Observation opportunity must be finite0..1')
        if profile and profile.get('evidence_kind') not in ['observed_external','explicit_scenario']:
            raise IntegrationError('Supplied birth profile requires observed_external or explicit_scenario provenance')
        engine=engine or a18_engine_class()()
        a=engine.initialize(prefecture_code,conditions,seed,birth_date,a_scenario,include_region,initial_family)
        household=a['household'];hid=household['household_id'];index_id=household['index_person_id']
        if household['multiplicity']!=1:raise UnsupportedBirthScope('Multiple birth A roster preserved; B multiple-birth physiology is unsupported')
        people={p['person_id']:p for p in a['persons']}
        if len(people)!=len(a['persons']):raise IntegrationError('Duplicate A person IDs')
        if index_id not in people or people[index_id]['date_of_birth']!=birth_date:raise IntegrationError('Index child birth mismatch')
        sex=people[index_id].get('sex')
        if sex not in ['male','female']:raise UnsupportedBirthScope('Unknown recorded sex: do not randomly overwrite A identity to obtain a growth reference')
        caregivers=sorted(a['parents'])
        if not all(p in people and people[p].get('co_resident') and people[p].get('alive') is not False for p in caregivers):raise IntegrationError('Caregiver roster mismatch')
        links={pid:global_id(hid,pid) for pid in people}
        child=Child.generate(seed=actual_b_seed,birth_date=birth_date,child_id=links[index_id],
            caregiver_ids=[links[p] for p in caregivers],sex=sex,gestation_days=days,
            birth_weight_kg=profile.get('birth_weight_kg'),birth_length_cm=profile.get('birth_length_cm'))
        known_by=profile.get('known_by',caregivers)
        if not isinstance(known_by,list) or set(known_by)-set(caregivers):raise IntegrationError('Birth measurement recipients must be A caregivers')
        if profile.get('evidence_kind')=='observed_external':
            for metric in ['birth_weight_kg','birth_length_cm']:
                if metric in profile:
                    child.record_measurement(observer_id=hid+'/birth_record',metric=metric.replace('birth_',''),
                        value=profile[metric],source='explicit_external_birth_measurement',known_by=[links[x] for x in known_by])
        obj=cls(engine);obj.a=a;obj.child=child;obj.records=[];obj.history=[]
        run_id='b10_'+digest([VERSION,seed,prefecture_code,birth_date,conditions,a_scenario,profile,observation_opportunity,include_region,actual_b_seed,digest(a['initial_family'])])[:24]
        obj.identity={'run_id':run_id,'household_id':hid,'index_local_person_id':index_id,'index_global_person_id':links[index_id],
            'person_links':links,'caregiver_local_ids':caregivers,'birth_date':birth_date,
            'delivery_event_id':household['delivery_event_id'],
            'birth_rank_interval':copy.deepcopy(household.get('index_birth_rank_interval')),
            'maternal_cumulative_rank':people[index_id].get('maternal_cumulative_rank'),
            'index_within_delivery':household['index_within_delivery']}
        obj.configuration={'master_seed':seed,'B_seed':actual_b_seed,'B_seed_override':child_seed is not None,'observation_opportunity':observation_opportunity,
            'observation_definition':'fictitious scheduled opportunity, gated by A positive active-care time; not an empirical probability',
            'birth_profile':profile,'birth_missingness':{
                'A_gestation_days':'unknown_not_in_A' if days is None else profile['evidence_kind'],
                'A_birth_weight':'unknown_not_in_A' if 'birth_weight_kg' not in profile else profile['evidence_kind'],
                'A_birth_length':'unknown_not_in_A' if 'birth_length_cm' not in profile else profile['evidence_kind'],
                'low_birth_weight_health_effects':'not_modeled; no clinical risk extrapolation',
                'generated_values':'B term hospital-reference scenario, not observations of this A child'},
            'B_environment_causal_effects':False,'calendar_scope':'first_day_2026_birth;24_calendar_periods',
            'A_unresolved_paths_retained':True}
        obj.chain='0'*64;obj.status='running';obj._birth_state=child.research_snapshot()
        obj.history.append({'id':hid+'/integration/birth','component':'integration','kind':'identity_link',
            'date':birth_date,'people':[links[index_id]]+[links[x] for x in caregivers],
            'evidence':'identity_link_only; birth physiology reference scenario', 'source_ref':'A.initial_family/persons'})
        obj.assert_consistent();return obj

    @property
    def elapsed_months(self):return self.a['elapsed_months']

    def _environment(self,a_after,row):
        hid=self.identity['household_id'];n=a_after['elapsed_months']
        caregivers={}
        for local in self.identity['caregiver_local_ids']:
            schedule=row['time']['parents'].get(local)
            if schedule is None:raise IntegrationError('A time budget lacks registered caregiver')
            caregivers[self.identity['person_links'][local]]={
                'contact_episodes_per_day':None,
                'observation_opportunity':self.configuration['observation_opportunity'] if schedule['active_care']>0 else 0}
        env={'caregivers':caregivers,'context':'nursery_exposure' if row['care']['status']=='enrolled' and row['time']['nursery']>0 else 'home_or_other',
            'provenance':'A actual simulated monthly record; no contact-hours/SES/fee-to-development effect',
            'a3_context':{'environment_id':hid+f'/environment/{n:02d}','source_month':row['month'],
                'source_model':A_VERSION,'household_id':hid,'quality_flags':copy.deepcopy(a_after['quality_flags']),
                'full_record_ref':'integration_month.A_month',
                'exposure_status':'simulated_scenario_not_validated_Japanese_family_environment'}}
        return env

    def _actions(self,actions):
        if actions is None:return []
        if not isinstance(actions,list) or any(not isinstance(x,dict) for x in actions):raise IntegrationError('A actions list required')
        actions=copy.deepcopy(actions)
        inverse={v:k for k,v in self.identity['person_links'].items()}
        for action in actions:
            person=action.get('person')
            if person in inverse:action['person']=inverse[person];person=action['person']
            if person is not None and person not in self.identity['caregiver_local_ids']:raise IntegrationError('Action actor outside this family')
        return actions

    def step(self,actions=None,*,research_continue=False):
        if type(research_continue) is not bool:raise IntegrationError('Explicit boolean research_continue required')
        if self.elapsed_months>=24:raise IntegrationError('Integrated research horizon is24months; no after-age2 validation')
        if self.status=='decision_required' and not actions and not research_continue:
            raise DecisionRequired('Pending A decisions require an action or explicit research continuation')
        self.assert_consistent();actions=self._actions(actions)
        start=self.a['month'];prior_decisions=len(self.a['decisions']);old_b_events=len(self.child._state['experience_ledger'])
        # Both kernels operate on private candidates. Commit only after coupling checks.
        a_next=self.engine.step(self.a,actions,retain_journal=True)
        transactions=copy.deepcopy(a_next['journal'])
        # Capture each period's actual ledger entries, then retain the exact native
        # retain_journal=False checkpoint shape. No transaction is silently lost.
        a_next['journal']=[];a_next['monthly_history']=[a_next['last_month']]
        row=a_next['last_month'];env=self._environment(a_next,row)
        b_next=copy.deepcopy(self.child);b_next.advance_one_month(env,enable_hypothetical_effects=False)
        if a_next['month']!=b_next._state['as_of_date'] or a_next['elapsed_months']!=b_next._state['elapsed_months']:
            raise IntegrationError('A/B period boundary mismatch')
        child_person=next(p for p in a_next['persons'] if p['person_id']==self.identity['index_local_person_id'])
        if child_person['age_months']!=b_next._state['elapsed_months']:raise IntegrationError('A child age does not match B')
        period_id=self.identity['household_id']+f'/period/{a_next["elapsed_months"]:02d}'
        decisions=copy.deepcopy(a_next['decisions'][prior_decisions:])
        events=[]
        for i,event in enumerate(row['events']):
            person=event.get('person');local=[person] if person in self.identity['person_links'] else []
            events.append({'id':period_id+f'/A_event/{i:03d}','component':'A','kind':event['type'],
                'date_interval':[start,a_next['month']],'date_precision':'calendar_period_not_exact_day',
                'people':[self.identity['person_links'][p] for p in local],
                'source_ref':f'A_month.events[{i}]','payload':copy.deepcopy(event)})
        for i,decision in enumerate(decisions):
            person=decision['request'].get('person');people=[self.identity['person_links'][person]] if person in self.identity['person_links'] else []
            events.append({'id':period_id+f'/A_decision/{i:03d}','component':'A_decision','kind':decision['requested_action'],
                'date_interval':[start,a_next['month']],'people':people,
                'source_ref':f'A_decisions[{i}]','payload':copy.deepcopy(decision)})
        for event in b_next._state['experience_ledger'][old_b_events:]:
            events.append({'id':period_id+'/B/'+event['history_id'].rsplit('/',1)[-1],
                'component':'B','kind':event['kind'],'date':event['date'],
                'people':[self.identity['index_global_person_id']]+event['people'],
                'source_ref':event['history_id'],'known_by':event['known_by'],
                'evidence':event['evidence']})
        public={local:parent_observations(b_next,self.identity['person_links'][local],since_date=(dt.date.fromisoformat(start)+dt.timedelta(days=1)).isoformat())
                for local in self.identity['caregiver_local_ids']}
        record={'period_id':period_id,'household_id':self.identity['household_id'],
            'elapsed_months':a_next['elapsed_months'],'start':start,'end_exclusive':a_next['month'],
            'A_month':copy.deepcopy(row),'A_decisions':decisions,'A_transactions':transactions,
            'A_persons_asof':copy.deepcopy(a_next['persons']),
            'B_delta':projection_delta(b_next),'B_parent_observations':public,
            'environment':env,'events':events,
            'research_continued_unresolved_prior':bool(self.a.get('pending_decisions') and research_continue),
            'requested_actions':actions,
            'outstanding_A_decisions':copy.deepcopy(a_next.get('pending_decisions',[]))}
        chain=digest([self.chain,record])
        self.a=a_next;self.child=b_next;self.records.append(record);self.history.extend(events);self.chain=chain
        self.status='decision_required' if a_next.get('pending_decisions') else 'running'
        if self.elapsed_months==24:self.status='horizon_reached_with_pending_decisions' if a_next.get('pending_decisions') else 'horizon_reached'
        self.assert_consistent();return self

    def run(self,months=24,actions_by_month=None,*,stop_on_decision=True,research_continue=False):
        if type(stop_on_decision) is not bool or type(research_continue) is not bool:raise IntegrationError('Explicit boolean run flags required')
        if type(months) is not int or not 0<=months<=24-self.elapsed_months:raise IntegrationError('Invalid integrated month count')
        if not isinstance(actions_by_month or {},dict):raise IntegrationError('Action schedule must be a dictionary')
        for _ in range(months):
            actions=(actions_by_month or {}).get(str(self.elapsed_months),(actions_by_month or {}).get(self.elapsed_months,[]))
            self.step(actions,research_continue=research_continue)
            if stop_on_decision and self.a.get('pending_decisions'):break
        return self

    def assert_consistent(self):
        b=self.child._state;identity=self.identity;a=self.a
        if a['model_version']!=A_VERSION or b['model_version']!=B_VERSION:raise IntegrationError('Component version mismatch')
        if a['elapsed_months']!=b['elapsed_months'] or a['month']!=b['as_of_date']:raise IntegrationError('Calendar mismatch')
        if a['birth_date']!=identity['birth_date'] or b['child_identity']['birth_date']!=identity['birth_date']:raise IntegrationError('Birth date mismatch')
        if a['household']['household_id']!=identity['household_id']:raise IntegrationError('Household changed unexpectedly')
        if b['child_identity']['child_id']!=identity['index_global_person_id']:raise IntegrationError('Index identity mismatch')
        people={p['person_id']:p for p in a['persons']}
        if set(people)!=set(identity['person_links']):raise IntegrationError('Roster addition/removal requires explicit supported migration')
        person=people[identity['index_local_person_id']]
        if person['age_months']!=b['elapsed_months'] or b['age_days']!=(dt.date.fromisoformat(a['month'])-dt.date.fromisoformat(identity['birth_date'])).days:raise IntegrationError('Stored age mismatch')
        if person['sex']!=b['child_identity']['sex_for_growth_reference']:raise IntegrationError('Recorded sex mismatch')
        if person.get('date_of_birth')!=identity['birth_date']:raise IntegrationError('A child birth record changed')
        if set(b['caregiver_relationships'])!={identity['person_links'][x] for x in identity['caregiver_local_ids']}:raise IntegrationError('Caregiver identity mismatch')
        if a['quality_flags']['financially_playable'] or a['quality_flags']['newborn_full_joint_externally_validated']:raise IntegrationError('Unsupported A readiness flag')
        if len(self.records)!=a['elapsed_months']:raise IntegrationError('Missing/duplicated integrated periods')
        if not self.history or self.history[0]['id']!=identity['household_id']+'/integration/birth' or self.history[1:]!=[e for r in self.records for e in r['events']]:raise IntegrationError('Unified history does not match period sources')
        if b['scenario_effects_enabled']:raise IntegrationError('Unidentified B intervention effects must remain off in integration')
        return True

    def player_view(self,observer='mother'):
        inverse={v:k for k,v in self.identity['person_links'].items()}
        local=inverse.get(observer,observer)
        if local not in self.identity['caregiver_local_ids']:raise PermissionError('Observer is not this household caregiver')
        public=parent_observations(self.child,self.identity['person_links'][local])
        return {'simulation_id':self.identity['run_id'],'as_of_date':self.a['month'],
            'elapsed_months':self.elapsed_months,'status':self.status,
            'household':{'household_id':self.identity['household_id'],
                'prefecture_code':self.a['household']['prefecture_code'],'municipality_code':self.a['household']['municipality_code'],
                'persons':[{'person_id':self.identity['person_links'][p['person_id']],
                    'household_person_id':p['person_id'],'role':p['role'],'co_resident':p['co_resident'],
                    'age_months':p.get('age_months')} for p in self.a['persons']],
                'cash':self.a['accounts']['cash'],'care_status':self.a['care']['status']},
            'child_observations':public,
            'pending_decisions':copy.deepcopy(self.a.get('pending_decisions',[]))}

    def research_snapshot(self):
        return copy.deepcopy({'integration_version':VERSION,'component_versions':{'A':A_VERSION,'B':B_VERSION},
            'B_parameter_sha256':B_PARAMETER_HASH,'identity':self.identity,'configuration':self.configuration,
            'A_state':self.a,'B_state':self.child.research_snapshot(),'B_birth_state':self._birth_state,
            'records':self.records,'history':self.history,'history_chain':self.chain,'status':self.status,
            'validity':{'functional_coupling':True,'A_financially_playable':False,
                'Japan_full_joint_external_validity':False,'psychological_external_validity':False,
                'A_environment_to_B_causal_effects_identified':False,'age_over24months_supported':False}})

    def save(self,path):
        payload=self.research_snapshot();envelope={'payload':payload,'payload_sha256':digest(payload)}
        path=Path(path);temporary=path.with_name(path.name+'.writing')
        temporary.write_text(json.dumps(envelope,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False))
        temporary.replace(path)

    @classmethod
    def from_snapshot(cls,payload,*,engine=None):
        if payload['integration_version']!=VERSION or payload['B_parameter_sha256']!=B_PARAMETER_HASH:raise IntegrationError('Original integration and B parameters required')
        if payload['component_versions']!={'A':A_VERSION,'B':B_VERSION}:raise IntegrationError('Component versions do not match')
        obj=cls(engine or a18_engine_class()());s=copy.deepcopy(payload)
        obj.a=s['A_state'];obj.child=Child();obj.child._state=s['B_state'];obj._birth_state=s['B_birth_state']
        obj.identity=s['identity'];obj.configuration=s['configuration'];obj.records=s['records'];obj.history=s['history']
        obj.chain=s['history_chain'];obj.status=s['status'];obj.assert_consistent()
        chain='0'*64
        for record in obj.records:chain=digest([chain,record])
        if chain!=obj.chain:raise IntegrationError('Integrated history chain mismatch')
        return obj

    @classmethod
    def load(cls,path,*,engine=None):
        envelope=json.loads(Path(path).read_text());payload=envelope['payload']
        if digest(payload)!=envelope['payload_sha256']:raise IntegrationError('Snapshot checksum mismatch')
        return cls.from_snapshot(payload,engine=engine)
