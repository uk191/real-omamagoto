"""Load exactly A3.0-0.2; never silently reuse another generic 'engine/common'."""
import importlib
import sys
from functools import lru_cache
from pathlib import Path

PROJECT=Path(__file__).resolve().parents[2]
BROOT=PROJECT/'19_child_b10'
if str(BROOT) not in sys.path:sys.path.insert(0,str(BROOT))


@lru_cache(maxsize=1)
def a18_engine_class():
    root=PROJECT/'18_monthly_v02'
    for name in ['engine','common','rules','realism','cash_rules','time_budget','ledger','environment']:
        existing=sys.modules.get(name)
        if existing is not None and Path(getattr(existing,'__file__','/')).resolve().parent!=root:
            raise RuntimeError('Legacy module namespace already occupied: '+name+'. Run A17/A18 in separate interpreters, as their original HTTP APIs do.')
    sys.path.insert(0,str(root))
    module=importlib.import_module('engine')
    if module.VERSION!='A3.0-0.2':raise RuntimeError('Wrong legacy A version')
    return module.Engine
