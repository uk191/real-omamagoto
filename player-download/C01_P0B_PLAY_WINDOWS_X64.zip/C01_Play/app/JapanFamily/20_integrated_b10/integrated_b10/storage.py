"""Lossless coupled trajectories, with all inherited A tables left untouched.

Research database only. Never expose this connection or decoded payloads through
the player HTTP API. Periods contain complete A transactions and B deltas.
"""
import copy
import json
import sqlite3
from pathlib import Path

from .coordinator import Simulation, VERSION, B_VERSION, B_PARAMETER_HASH, A_VERSION
from child_b10.storage import encode, decode
from child_b10.randomness import digest

SCHEMA=Path(__file__).resolve().parents[1]/'data'/'integration_schema.sql'


def connect(path):
    connection=sqlite3.connect(path)
    connection.execute('PRAGMA foreign_keys=ON')
    return connection


def create_schema(connection):
    connection.executescript(SCHEMA.read_text())


def insert_case(connection,sim,weight):
    if sim.elapsed_months:raise ValueError('Insert birth before advancing')
    s=sim.research_snapshot();identity=s['identity'];case=identity['run_id']
    connection.execute('INSERT INTO integrated_case VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(
        case,identity['household_id'],sim.a['household']['prefecture_code'],identity['birth_date'],
        identity['index_global_person_id'],weight,encode(s['A_state']),encode(s['B_birth_state']),
        encode(identity),encode(s['configuration']),encode(s['history']),None,None,None))
    for p in sim.a['persons']:
        connection.execute('INSERT INTO integrated_person VALUES(?,?,?,?,?,?,?,?)',(
            case,p['person_id'],identity['person_links'][p['person_id']],p['role'],p.get('sex'),
            p.get('date_of_birth'),None if p['co_resident'] is None else int(p['co_resident']),encode(p)))
    return case


def insert_period(connection,sim):
    case=sim.identity['run_id'];record=sim.records[-1];month=sim.elapsed_months
    connection.execute('INSERT INTO integrated_period VALUES(?,?,?,?,?,?,?,?,?,?,?)',(
        case,month,record['period_id'],record['start'],record['end_exclusive'],encode(record),
        digest(record),sim.chain,sim.status,digest(sim.a),digest(sim.child._state)))
    if month in (12,24):
        connection.execute('INSERT INTO integrated_checkpoint VALUES(?,?,?)',(case,month,encode(sim.a)))
    if month==24:
        connection.execute('UPDATE integrated_case SET final_snapshot_sha256=?,final_history_chain=?,final_status=? WHERE case_id=?',
            (digest(sim.research_snapshot()),sim.chain,sim.status,case))


def restore_simulation(connection,case_id,month=24,*,engine=None):
    """Exact restore at 0/12/24; individual period records remain accessible."""
    if month not in (0,12,24):raise ValueError('Stored A checkpoints are at birth,12,24; replay from a checkpoint for other ages')
    row=connection.execute('SELECT initial_A_zlib,B_birth_zlib,identity_zlib,configuration_zlib,birth_history_zlib,final_snapshot_sha256 FROM integrated_case WHERE case_id=?',(case_id,)).fetchone()
    if row is None:raise KeyError(case_id)
    a,b,identity,configuration,history=map(decode,row[:5]);birth=copy.deepcopy(b)
    events=copy.deepcopy(b['experience_ledger']);observations=copy.deepcopy(b['parent_observations'])
    records=[];chain='0'*64;status='running'
    rows=connection.execute('SELECT month,record_zlib,record_sha256,history_chain,status,A_state_sha256,B_state_sha256 FROM integrated_period WHERE case_id=? AND month<=? ORDER BY month',(case_id,month)).fetchall()
    if [r[0] for r in rows]!=list(range(1,month+1)):raise ValueError('Missing integrated periods')
    for _,blob,expected_record,expected_chain,status,_,expected_b in rows:
        record=decode(blob)
        if digest(record)!=expected_record:raise ValueError('Period checksum mismatch')
        chain=digest([chain,record])
        if chain!=expected_chain:raise ValueError('History checksum mismatch')
        delta=copy.deepcopy(record['B_delta']);events.extend(delta.pop('experience_ledger'))
        observations.extend(delta.pop('parent_observations'));b.update(delta)
        b['experience_ledger']=events;b['parent_observations']=observations
        if digest(b)!=expected_b:raise ValueError('B reconstruction checksum mismatch')
        records.append(record);history.extend(record['events'])
    if month:
        checkpoint=connection.execute('SELECT A_state_zlib FROM integrated_checkpoint WHERE case_id=? AND month=?',(case_id,month)).fetchone()
        if checkpoint is None:raise ValueError('A checkpoint missing')
        a=decode(checkpoint[0])
        if digest(a)!=rows[-1][5]:raise ValueError('A checkpoint checksum mismatch')
    payload={'integration_version':VERSION,'component_versions':{'A':A_VERSION,'B':B_VERSION},
        'B_parameter_sha256':B_PARAMETER_HASH,'identity':identity,'configuration':configuration,
        'A_state':a,'B_state':b,'B_birth_state':birth,'records':records,'history':history,
        'history_chain':chain,'status':status}
    sim=Simulation.from_snapshot(payload,engine=engine)
    if month==24 and digest(sim.research_snapshot())!=row[5]:raise ValueError('Final full snapshot checksum mismatch')
    return sim
