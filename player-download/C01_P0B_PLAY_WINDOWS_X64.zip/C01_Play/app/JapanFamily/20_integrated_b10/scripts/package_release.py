#!/usr/bin/env python3
"""Paired self-describing release; preserve all original archives and uploads."""
import hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;REPO=PROJECT.parent
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'scripts'))
from audit_baselines import sha
from integrated_b10.coordinator import digest


def main():
 out=REPO/'artifacts';out.mkdir(exist_ok=True);database=ROOT/'results/coupled_10340/integrated.sqlite'
 assert database.exists();code_files={};data_files={}
 # Reviewable legacy source and documents. Full original data, raw tables,
 # statistical kernels and history remain byte-preserved in the data archive.
 a_map=json.loads((REPO/'provenance/A302_original/extracted_file_sha256.json').read_text())
 for name,expected in a_map.items():
  path=REPO/name
  if path.suffix in ['.py','.md','.sql','.json','.csv','.txt']and path.stat().st_size<=2*1024*1024:
   assert sha(path)==expected;code_files[name]=path
 with zipfile.ZipFile(out/'B1.0_PREINTEGRATION_CODE_AND_REPORTS.zip')as z:b_map=json.loads(z.read('MANIFEST.json'))['files']
 for name,expected in b_map.items():
  path=REPO/name;assert sha(path)==expected;code_files[name]=path
 for path in sorted(ROOT.rglob('*')):
  rel=path.relative_to(ROOT)
  if not path.is_file()or '__pycache__'in rel.parts or 'shards'in rel.parts or path.suffix in ['.sqlite','.npz','.pyc']or '.pending.'in path.name:continue
  code_files[str(path.relative_to(REPO))]=path
 code_files['ASSEMBLE.py']=ROOT/'scripts/assemble_release.py'
 code_files['READ_INTEGRATED_RELEASE.md']=ROOT/'docs/再構築と再検証.md'
 for path in sorted((REPO/'provenance/A302_original').iterdir()):
  if path.is_file():data_files[str(path.relative_to(REPO))]=path
 for path in sorted(out.glob('B1.0_PREINTEGRATION*')):
  if path.is_file():data_files[str(path.relative_to(REPO))]=path
 extra=out/'B1.0_CODE_AND_REPORTS_VERIFICATION.json'
 if extra.exists():data_files[str(extra.relative_to(REPO))]=extra
 data_files[str(database.relative_to(REPO))]=database
 vectors=ROOT/'results/coupled_10340/coupled_vectors.npz';data_files[str(vectors.relative_to(REPO))]=vectors
 cm={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(code_files.items())}
 dm={n:{'bytes':p.stat().st_size,'sha256':sha(p)}for n,p in sorted(data_files.items())}
 pins={'A_original_zip_sha256':sha(REPO/'provenance/A302_original/A302_official_restored.zip'),
  'B_original_zip_sha256':sha(out/'B1.0_PREINTEGRATION.zip'),
  'B_original_code_zip_sha256':sha(out/'B1.0_PREINTEGRATION_CODE_AND_REPORTS.zip'),
  'integrated_database_sha256':sha(database),'code_file_tree_sha256':digest(cm),'data_file_tree_sha256':digest(dm)}
 bundle='B10-INTEGRATED-'+digest(pins)[:24];paths=[]
 for kind,files,mapping in [('CODE_AND_REPORTS',code_files,cm),('DATA',data_files,dm)]:
  path=out/f'B1.0_INTEGRATED_{kind}.zip'
  if path.exists():raise FileExistsError('Never overwrite a saved release pack')
  manifest={'bundle_id':bundle,'kind':kind,'pins':pins,'files':mapping,'scope':'formal software coupling research release; external/clinical/psychological/causal validity not achieved',
   'assembly':'Use both packs; python ASSEMBLE.py --code-pack CODE.zip --data-pack DATA.zip --destination NEW_DIRECTORY',
   'complete_old_assets':'Full original A/B ZIPs and all17 newly uploaded transport/instruction files are in DATA; light pack is a code/document projection, not a replacement for DATA',
   'omitted_redundant_working_data':'per-prefecture generation shards and pilot SQLite are redundant subsets of canonical integrated DB; original assets are all retained'}
  with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True)as z:
   for index,(name,file)in enumerate(sorted(files.items()),1):
    compression=zipfile.ZIP_STORED if file.suffix in ['.zip','.gz','.npz','.png','.pdf','.xlsx']else zipfile.ZIP_DEFLATED
    z.write(file,name,compress_type=compression,compresslevel=1)
    if index%200==0:print('pack',kind,index,len(files),flush=True)
   z.writestr('INTEGRATION_'+('CODE'if kind=='CODE_AND_REPORTS'else'DATA')+'_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
  info={'filename':path.name,'bytes':path.stat().st_size,'sha256':sha(path),'payload_files':len(files)};paths.append(info);path.chmod(0o444);print(json.dumps(info),flush=True)
 report={'bundle_id':bundle,'pins':pins,'archives':paths,'saved_bytes_independent_verification':'B1.0_INTEGRATED_RELEASE_VERIFICATION.json generated after packaging; not self-certified here'}
 (out/'B1.0_INTEGRATED_ARCHIVES.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print('PACKAGING_DONE',bundle,flush=True)

if __name__=='__main__':main()
