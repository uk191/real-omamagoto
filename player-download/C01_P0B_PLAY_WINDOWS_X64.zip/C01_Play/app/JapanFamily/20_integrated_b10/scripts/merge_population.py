#!/usr/bin/env python3
"""Copy the immutable A DB, then add new namespaced cohort tables."""
import argparse,json,shutil,sqlite3,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from integrated_b10.legacy import PROJECT
from integrated_b10.storage import connect,create_schema,decode
sys.path.insert(0,str(ROOT/'scripts'))
from audit_baselines import fingerprint,sha
TABLES=['integrated_case','integrated_person','integrated_period','integrated_checkpoint','integrated_failure']

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=ROOT/'results/coupled_10340');ap.add_argument('--database',type=Path,default=ROOT/'results/coupled_10340/integrated.sqlite');args=ap.parse_args()
 summary=json.loads((args.source/'generation_summary.json').read_text());assert summary['completed']==summary['requested']
 if args.database.exists():raise FileExistsError('Never overwrite an existing release database')
 temp=args.database.with_suffix('.pending.sqlite');assert not temp.exists();shutil.copyfile(PROJECT/'data/region.sqlite',temp)
 db=connect(temp);create_schema(db);started=time.time()
 for report in summary['prefectures']:
  pref=report['prefecture'];path=args.source/'shards'/f'pref_{pref}.sqlite'
  db.execute('ATTACH DATABASE ? AS shard',(str(path),))
  with db:
   for table in TABLES:db.execute(f'INSERT INTO main.{table} SELECT * FROM shard.{table}')
   # Lossless raw A records retained in every generation shard. Preserve unknown
   # residence as SQL NULL, including shards written before this normalization fix.
   for case,local,blob in db.execute('SELECT case_id,local_person_id,initial_person_zlib FROM shard.integrated_person WHERE co_resident=0').fetchall():
    if decode(blob)['co_resident'] is None:db.execute('UPDATE main.integrated_person SET co_resident=NULL WHERE case_id=? AND local_person_id=?',(case,local))
  db.execute('DETACH DATABASE shard');print('merged',pref,flush=True)
 with db:
  db.execute('INSERT INTO integrated_run VALUES(?,?)',('cohort',json.dumps(summary,ensure_ascii=False)))
  for p in sorted((ROOT/'data').glob('*.json')):
   db.execute('INSERT INTO integrated_registry VALUES(?,?)',(p.name,p.read_text()))
 checks={'cases':db.execute('SELECT count(*) FROM integrated_case').fetchone()[0],
  'periods':db.execute('SELECT count(*) FROM integrated_period').fetchone()[0],
  'persons':db.execute('SELECT count(*) FROM integrated_person').fetchone()[0],
  'checkpoints':db.execute('SELECT count(*) FROM integrated_checkpoint').fetchone()[0],
  'unknown_person_residence_retained':db.execute('SELECT count(*) FROM integrated_person WHERE co_resident IS NULL').fetchone()[0],
  'failed':db.execute('SELECT count(*) FROM integrated_failure').fetchone()[0],
  'integrity':db.execute('PRAGMA integrity_check').fetchall(),'foreign_keys':db.execute('PRAGMA foreign_key_check').fetchall()}
 assert checks['cases']==summary['requested'] and checks['periods']==summary['requested']*24 and checks['checkpoints']==summary['requested']*2 and checks['failed']==0
 assert checks['integrity']==[('ok',)] and not checks['foreign_keys'];db.close()
 before=json.loads((ROOT/'results/baseline/A_all_tables_before.json').read_text());after=fingerprint(temp,only_tables=set(before))
 assert {k:after[k] for k in before}==before
 source=sqlite3.connect('file:'+str(PROJECT/'data/region.sqlite')+'?mode=ro',uri=True);merged=sqlite3.connect('file:'+str(temp)+'?mode=ro',uri=True)
 source_objects=source.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').fetchall()
 for obj in source_objects:
  actual=merged.execute('SELECT type,name,tbl_name,sql FROM sqlite_master WHERE type=? AND name=?',obj[:2]).fetchone();assert actual==obj,obj[1]
 source.close();merged.close()
 checks.update({'inherited_A_tables':len(before),'all_inherited_table_rows_identical':True,'all_inherited_SQL_objects_identical':True,'inherited_SQL_objects':len(source_objects),
  'A_source_database_sha256':sha(PROJECT/'data/region.sqlite'),'new_database_sha256':sha(temp),'database_bytes':temp.stat().st_size,
  'seconds':time.time()-started})
 temp.replace(args.database);(args.source/'database_verification.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(checks),flush=True)

if __name__=='__main__':main()
