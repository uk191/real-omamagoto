#!/usr/bin/env python3
"""Read every coupled period; compare definitions without external pass flags."""
import argparse,collections,datetime as dt,hashlib,json,math,os,sqlite3,sys,time
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR','/tmp/b10-integrated-mpl')
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import numpy as np
from integrated_b10 import Simulation,VERSION
from integrated_b10.legacy import PROJECT,a18_engine_class
from integrated_b10.storage import decode,restore_simulation
from child_b10.engine import TRAITS,DOMAINS,PARAMS
from child_b10.japan_reference import reference,from_z
from child_b10.growth import from_z as who_from_z
from child_b10.randomness import digest
FIELDS=['weight_kg','length_cm','head_cm']+[f'trait.{x}'for x in TRAITS]+[f'progress.{x}'for x in DOMAINS]+[f'milestone.{x}'for x in PARAMS['milestones']]+[f'short.{x}'for x in ['distress','fatigue','hunger','arousal','settling','sleep_pressure']]


def vector(b):
 ph=b['physical_health'];dev=b['developmental_state']
 return [ph['weight_kg'],ph['length_cm'],ph['head_circumference_cm']]+[b['latent_state'][x]for x in TRAITS]+[dev['progress'][x]for x in DOMAINS]+[float(x in dev['milestones'])for x in PARAMS['milestones']]+[b['emotion_regulation'][x]for x in ['distress','fatigue','hunger','arousal','settling','sleep_pressure']]


def describe(values,weights):
 order=np.argsort(values);v=values[order];w=weights[order];cum=np.cumsum(w)/np.sum(w);mean=float(np.average(v,weights=w))
 return {'n':len(v),'mean':mean,'sd':float(np.sqrt(np.average((v-mean)**2,weights=w))),
  'quantiles':{f'p{int(q*100):02d}':float(v[min(np.searchsorted(cum,q),len(v)-1)])for q in [.01,.03,.1,.25,.5,.75,.9,.97,.99]}}


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--database',type=Path,default=ROOT/'results/coupled_10340/integrated.sqlite');args=ap.parse_args()
 out=args.database.parent;con=sqlite3.connect('file:'+str(args.database)+'?mode=ro',uri=True);started=time.time()
 cases=con.execute('SELECT case_id,prefecture_code,geographic_birth_weight,B_birth_zlib,identity_zlib FROM integrated_case ORDER BY case_id').fetchall()
 n=len(cases);weights=np.array([r[2]for r in cases]);data=np.empty((n,25,len(FIELDS)));sex=[];weeks=[];metadata=[]
 normalized_people=0;unknown_residence=0
 for case,local,normalized,blob in con.execute('SELECT case_id,local_person_id,co_resident,initial_person_zlib FROM integrated_person'):
  person=decode(blob);assert person['person_id']==local
  expected=None if person['co_resident'] is None else int(person['co_resident'])
  assert normalized==expected;normalized_people+=1;unknown_residence+=expected is None
 counts=collections.Counter();employment={str(m):collections.Counter()for m in [6,12,18,24]};care={str(m):collections.Counter()for m in [6,12,18,24]}
 pause=collections.Counter();growth_constraints=0;public_reports=0;event_count=0;transaction_count=0;seeds=[]
 for i,(case,pref,weight,birth_blob,identity_blob) in enumerate(cases):
  b=decode(birth_blob);identity=decode(identity_blob);data[i,0]=vector(b);sex.append(b['child_identity']['sex_for_growth_reference']);weeks.append(b['birth_conditions']['gestation_days']//7)
  metadata.append({'sex':sex[-1],'week':weeks[-1],'birth_weight':data[i,0,0],'birth_length':data[i,0,1],'birth_head':data[i,0,2]})
  rows=con.execute('SELECT month,record_zlib,record_sha256,history_chain FROM integrated_period WHERE case_id=? ORDER BY month',(case,)).fetchall();assert [r[0]for r in rows]==list(range(1,25));chain='0'*64
  for month,blob,expected,expected_chain in rows:
   r=decode(blob);assert digest(r)==expected;chain=digest([chain,r]);assert chain==expected_chain
   assert r['household_id']==identity['household_id'] and r['period_id']==identity['household_id']+f'/period/{month:02d}'
   b=r['B_delta'];data[i,month]=vector(b);a=r['A_month'];counts[pref]+=1
   public_reports+=sum(len(x['observations'])for x in r['B_parent_observations'].values());event_count+=len(r['events']);transaction_count+=len(r['A_transactions'])
   if r['outstanding_A_decisions']:pause['periods_pending']+=1
   if r['research_continued_unresolved_prior']:pause['explicit_research_continuations']+=1
   assert b['elapsed_months']==month and b['as_of_date']==r['end_exclusive']
   assert a['month']==r['start'];assert not b['scenario_effects_enabled']
   if month in [6,12,18,24]:
    for who,p in a['parents'].items():employment[str(month)][who+'/'+p['employment_measurement']['status']]+=weight
    care[str(month)][a['care']['status']]+=weight
  growth_constraints+=b['physical_health'].get('monotonic_constraint_count',0)
  if (i+1)%1000==0:print('read',i+1,n,flush=True)
 assert len(counts)==47 and set(counts.values())=={5280} if n==10340 else True
 distributions={str(m):{name:describe(data[:,m,k],weights)for k,name in enumerate(FIELDS)}for m in range(25)}
 # Conditional sex-by-gestation moments: same source, not independent validation.
 calibration=[]
 for row in reference()['birth_conditional_moments']:
  if not 37<=row['gestation_week']<=41 or row['metric']=='chest':continue
  values=np.array([x['birth_'+row['metric']]for x in metadata if x['sex']==row['sex']and x['week']==row['gestation_week']]);scale=1000 if row['metric']=='weight'else 1
  target=row['mean']/scale;sd=row['sd']/scale
  calibration.append({'sex':row['sex'],'week':row['gestation_week'],'metric':row['metric'],'generated_n':len(values),'source_n':row['n'],
   'generated_mean':float(np.mean(values))if len(values)else None,'source_mean':target,'generated_sd':float(np.std(values,ddof=1))if len(values)>1 else None,'source_sd':sd,
   'mean_MC_z':float((np.mean(values)-target)/(sd/math.sqrt(len(values))))if len(values)>=30 else None,'cell':row['cell_range'],
   'classification':'same_source_calibrated; unweighted within-cell MC audit, term hospital selection and sex/geography transport unverified'})
 physical=[];sex=np.array(sex)
 for gender in ['male','female']:
  mask=sex==gender
  for m in range(25):
   for k,(metric,table)in enumerate([('weight_kg','weianthro'),('length_cm','lenanthro'),('head_cm','hcanthro')]):
    result=describe(data[mask,m,k],weights[mask]);jp=[from_z(table,gender,m*30.4375,z)for z in [-1.8807936081512509,0,1.8807936081512509]]
    physical.append({'sex':gender,'month':m,'metric':metric,'n':int(mask.sum()),'generated_p03_p50_p97':[result['quantiles'][x]for x in ['p03','p50','p97']],
     'Japanese2023_p03_p50_p97':jp,'WHO_p03_p50_p97':[who_from_z(table,gender,round(m*30.4375),z)for z in [-1.8807936081512509,0,1.8807936081512509]],
     'classification':'Japan2023 same-source marginal; WHO independent international descriptive reference; neither identifies selected term2026 longitudinal distribution'})
 # Independent2010 physical references: actual sex/metric definitions, historical
 # cohort and age-bin selection limitations explicitly retained.
 heldout_physical=[]
 for refrow in json.loads((ROOT/'data/heldout2010_physical.json').read_text())['rows']:
  gender=refrow['sex'];lo,hi=refrow['age_month_interval'];k=['weight_kg','length_cm','head_cm'].index(refrow['metric']);mask=sex==gender
  at_start=describe(data[mask,lo,k],weights[mask]);at_end=describe(data[mask,hi,k],weights[mask])
  heldout_physical.append({**refrow,'generated_at_bin_start_p03_p50_p97':[at_start['quantiles'][x]for x in ['p03','p50','p97']],
   'generated_at_bin_end_p03_p50_p97':[at_end['quantiles'][x]for x in ['p03','p50','p97']],
   'source_p03_p50_p97':[refrow['values'][i]for i in [0,3,6]],
   'external_fit_pass':None,'classification':'independent2010 descriptive comparison; different year, term selection and unidentified within-bin ages; endpoints are comparators, not sampling confidence bounds'})
 (out/'heldout2010_physical_comparisons.json').write_text(json.dumps(heldout_physical,ensure_ascii=False,indent=2)+'\n')
 # Held-out2010 empirical reports, retained raw cells. Generated month bounds,
 # rather than falsely treating half-month bin midpoints as exact observations.
 independent=json.loads((PROJECT/'19_child_b10/results/independent_comparisons.json').read_text());comparisons={}
 for name,report in independent['independent_comparisons'].items():
  points=[];field=FIELDS.index('milestone.'+name)
  for p in report['points']:
   age=p['age_midpoint_months'];lower=int(math.floor(age));upper=int(math.ceil(age))
   if upper>24:continue
   lo=float(np.average(data[:,lower,field],weights=weights));hi=float(np.average(data[:,upper,field],weights=weights))
   points.append({**p,'generated_at_bin_start':lo,'generated_at_bin_end':hi,
    'observed2010_outside_generated_age_bounds':p['observed2010']<lo or p['observed2010']>hi})
  comparisons[name]={'points':points,'classification':'independent2010 sample; age-bin/report/term-selection/cohort definitions differ; no modern external-fit pass',
   'midpoint_curve_RMSE_inherited':report['RMSE'],'number_outside_generated_bounds':sum(x['observed2010_outside_generated_age_bounds']for x in points)}
 loads=np.array([PARAMS['trait_loadings'][x]for x in TRAITS]);target=loads@loads.T;np.fill_diagonal(target,1);emp=np.corrcoef(data[:,0,3:3+len(TRAITS)],rowvar=False)
 persistence={name:float(np.corrcoef(data[:,0,3+k],data[:,24,3+k])[0,1])for k,name in enumerate(TRAITS)}
 # Geographic weighting is descriptive, not repair of A unpaid-employment paths.
 summary={'version':VERSION,'coupled_families':n,'coupled_periods':sum(counts.values()),'stored_child_states_including_birth':n*25,
  'prefecture_period_counts':dict(counts),'birth_sex_counts':dict(collections.Counter(sex.tolist())),
  'normalized_people_checked':normalized_people,'unknown_residence_retained_as_null':unknown_residence,
  'geographic_weight_sum':float(weights.sum()),'effective_n_geographic':float(weights.sum()**2/np.sum(weights**2)),
  'pending_decisions':dict(pause),'parent_observation_reports':public_reports,'unified_events':event_count,'A_transactions':transaction_count,
  'growth_monotonic_constraint_count':growth_constraints,'trait_covariance_max_absolute_error_vs_assumption':float(np.max(np.abs(emp-target))),
  'trait_birth24_persistence':persistence,'trait_retention_assumption':PARAMS['trait_monthly_retention']**24,
  'birth_same_source_calibration':calibration,'employment_weighted_status':{m:dict(x)for m,x in employment.items()},'care_weighted_status':{m:dict(x)for m,x in care.items()},
  'functional_checks':{'all_period_hashes_and_history_chains':True,'all47_have220_complete_trajectories':n==10340 and len(counts)==47 and set(counts.values())=={5280},'no_unverified_B_causal_effects_enabled':True},
  'external_validity_achieved':False,'causal_effects_identified':False,'psychological_scores_validated':False,
  'sampling_scope':'47 geographically weighted actual A families, first-day2026 singleton birth; B term hospital-reference physiology. Rotating calendar is coverage test, not seasonality. Other children retained in A, only index child modeled by B.',
  'interpretation':'Internal/hash/distribution checks verify software. Same-source calibration is not held-out validation.2010/2023 and WHO comparisons have population/measurement/year mismatch; clinical, psychological, household joint and longitudinal validity remain unresolved.',
  'independent_physical_comparison_rows':len(heldout_physical),'independent_milestone_comparison_points':sum(len(x['points'])for x in comparisons.values()),
  'seconds':time.time()-started}
 (out/'statistical_validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
 (out/'distributions_age0_24.json').write_text(json.dumps(distributions,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
 (out/'physical_reference_comparisons.json').write_text(json.dumps(physical,ensure_ascii=False,indent=2)+'\n')
 (out/'heldout2010_comparisons.json').write_text(json.dumps({'source':independent['heldout_source'],'comparisons':comparisons,'external_validity_achieved':False},ensure_ascii=False,indent=2)+'\n')
 np.savez_compressed(out/'coupled_vectors.npz',vectors=data,weights=weights,sex=sex,fields=np.array(FIELDS))
 # Reproduce one complete coupled seed per prefecture and checkpoint replay.
 engine=a18_engine_class()();replays=[]
 for pref in sorted(counts):
  case=con.execute('SELECT case_id FROM integrated_case WHERE prefecture_code=? ORDER BY case_id LIMIT 1',(pref,)).fetchone()[0]
  stored=restore_simulation(con,case,24,engine=engine);middle=restore_simulation(con,case,12,engine=engine)
  middle.run(12,stop_on_decision=False,research_continue=True)
  config=stored.configuration
  fresh=Simulation.initialize(pref,seed=config['master_seed'],birth_date=stored.identity['birth_date'],engine=engine)
  fresh.run(24,stop_on_decision=False,research_continue=True)
  assert stored.research_snapshot()==middle.research_snapshot()==fresh.research_snapshot()
  replays.append({'prefecture':pref,'case_id':case,'master_seed':config['master_seed'],'fresh24_equals_stored24':True,'stored12_plus12_equals_stored24':True,'final_snapshot_sha256':digest(stored.research_snapshot())})
 (out/'replays_47.json').write_text(json.dumps(replays,ensure_ascii=False,indent=2)+'\n');con.close()
 plot(out,distributions,physical,comparisons)
 print('ANALYSIS_DONE',n,sum(counts.values()),round(time.time()-started,1),flush=True)


def plot(out,distributions,physical,comparisons):
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(12,4.6))
 for name,color in [('walking_independently','tab:blue'),('first_contextual_word','tab:orange')]:
  ages=list(range(25));axes[0].plot(ages,[distributions[str(m)]['milestone.'+name]['mean']for m in ages],label='Coupled: '+name,color=color)
  pts=comparisons[name]['points'];axes[0].scatter([p['age_midpoint_months']for p in pts],[p['observed2010']for p in pts],s=12,color=color,marker='x',label='2010 reports: '+name)
 axes[0].set(xlabel='Age (months)',ylabel='Proportion',ylim=(0,1.03),title='Different cohorts/definitions: descriptive comparison')
 axes[0].legend(fontsize=7)
 rows=[r for r in physical if r['sex']=='female'and r['metric']=='weight_kg']
 for key,label in [('generated_p03_p50_p97','Coupled term-reference'),('Japanese2023_p03_p50_p97','Japan2023 marginal'),('WHO_p03_p50_p97','WHO (different population)')]:
  axes[1].plot([r['month']for r in rows],[r[key][1]for r in rows],label=label)
 axes[1].set(xlabel='Age (months)',ylabel='Median weight, female (kg)',title='No national longitudinal external-validity claim');axes[1].legend(fontsize=7)
 fig.tight_layout();fig.savefig(out/'coupled_reference_comparison.png',dpi=170);plt.close(fig)

if __name__=='__main__':main()
