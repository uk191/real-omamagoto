"""Execute inherited test commands in the independently restored writable copy."""
import argparse
import csv
import json
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'results/baseline/legacy_rerun'
COPY=Path('/workspace/scratch/A302_regression_copy/JapanFamily')
JOBS=[
    ('A1_full','10_validation',['validate.py'],'10_validation/summary.json'),
    ('A1_runtime','10_validation',['runtime_validate.py'],'10_validation/runtime_validation.json'),
    ('A2_HTTP','13_family',['check_api.py'],'13_family/validation/api_tests.json'),
    ('A2_108100','13_family',['validate.py','2300'],'13_family/validation/summary.json'),
    ('A25_policy','15_initial_state',['tests.py'],'15_initial_state/validation/policy_accounting_tests.json'),
    ('A25_schema','15_initial_state',['check_schema.py'],'15_initial_state/validation/schema_tests.json'),
    ('A25_HTTP','15_initial_state',['check_model.py'],'15_initial_state/validation/model_api_tests.json'),
    ('A25_103400','15_initial_state',['validate.py','2200'],'15_initial_state/validation/summary.json'),
    ('A25_recovery','16_recovery',['tests.py'],'16_recovery/validation/tests.json'),
    ('A3_v01_core','17_monthly',['tests.py'],'17_monthly/validation/tests.json'),
    ('A3_v01_extra','17_monthly',['tests_extra.py'],'17_monthly/validation/tests_extra.json'),
    ('A3_v02_core','18_monthly_v02',['tests.py'],'18_monthly_v02/validation/tests.json'),
    ('A3_v02_extra','18_monthly_v02',['tests_extra.py'],'18_monthly_v02/validation/tests_extra.json'),
    ('A3_v02_semantics','18_monthly_v02',['tests_v02.py'],'18_monthly_v02/validation/tests_v02.json'),
    ('A3_v01_47_replay','18_monthly_v02',['regression_replay_v01.py'],'18_monthly_v02/validation/regression_replay_v01.json'),
    ('A3_v02_47_replay','18_monthly_v02',['replay_v02.py'],'18_monthly_v02/validation/replay_v02.json'),
]


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--copy',type=Path,default=COPY);ap.add_argument('--output',type=Path,default=OUT);args=ap.parse_args()
    copy_project=args.copy.resolve();output=args.output.resolve()
    if copy_project==ROOT.parent.resolve():raise ValueError('Use a disposable separate A extraction, never the preserved original project')
    assert (copy_project/'release_manifest_v02.json').exists()
    output.mkdir(exist_ok=True,parents=True);rows=[]
    for name,folder,command,resultfile in JOBS:
        start=time.time();log=output/(name+'.log');target=copy_project/resultfile
        old_mtime=target.stat().st_mtime_ns if target.exists() else None
        print('RUN',name,flush=True)
        with log.open('w') as f:
            proc=subprocess.run([sys.executable,*command],cwd=copy_project/folder,stdout=f,stderr=subprocess.STDOUT)
        result=None;fresh=False
        if target.exists():
            fresh=target.stat().st_mtime_ns!=old_mtime;result=json.loads(target.read_text())
            (output/(name+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
        # Some legacy commands intentionally store a differently named file. An exit
        # code still documents that command; never describe a stale JSON as current.
        row={'name':name,'command':command,'cwd':folder,'exit_code':proc.returncode,
            'seconds':time.time()-start,'expected_result':resultfile,'result_file_fresh':fresh,
            'passed':proc.returncode==0 and fresh,'population_scope':'inherited engine regression, not newborn external validation'}
        if fresh and isinstance(result,dict):
            for key in ['tests_fail','generation_failures','internal_violations']:
                value=result.get(key)
                if value and key!='internal_violations':row['passed']=False
                if key=='internal_violations' and isinstance(value,int) and value:row['passed']=False
            if 'passed'in result and 'total'in result:row['tests_passed']=result['passed'];row['tests_total']=result['total'];row['passed'] &= result['passed']==result['total']
        rows.append(row)
        (output/'runner_summary.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
        print('DONE',name,'exit',proc.returncode,'fresh',fresh,'seconds',round(row['seconds'],2),flush=True)
    if any(not r['passed'] for r in rows):sys.exit(1)


if __name__=='__main__':main()
