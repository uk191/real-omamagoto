#!/usr/bin/env python3
"""Independent2010 original XLS percentiles, with original cells, no model fit."""
import hashlib,json,re,sys,unicodedata
from pathlib import Path
import xlrd
ROOT=Path(__file__).resolve().parents[1];B=ROOT.parent/'19_child_b10'
rows=[];sources=json.loads((B/'data/heldout_acquisition.json').read_text())
for metric,sid in [('weight_kg','000012673573'),('length_cm','000012673574'),('head_cm','000012673576')]:
 source=next(r for r in sources if r['id']==sid);path=B/source['file'];assert hashlib.sha256(path.read_bytes()).hexdigest()==source['sha256']
 sheet=xlrd.open_workbook(path).sheet_by_index(0);year=0
 for ri in range(sheet.nrows):
  raw=str(sheet.cell_value(ri,0));label=unicodedata.normalize('NFKC',raw).replace(' ','')
  if label=='出生時':lo=hi=0
  else:
   match=re.fullmatch(r'(?:(\d+)年)?(\d+)[~～〜](\d+)(?:月未満)?',label)
   if not match:continue
   if match[1] is not None:year=int(match[1])
   lo=12*year+int(match[2]);hi=12*year+int(match[3])
  if hi>24:continue
  for sex,startcol in [('male',1),('female',10)]:
   values=[sheet.cell_value(ri,startcol+k)for k in range(7)];assert all(type(x)in [int,float]for x in values)
   rows.append({'metric':metric,'sex':sex,'published_age_label':raw,'age_month_interval':[lo,hi],
    'percentiles':[.03,.1,.25,.5,.75,.9,.97],'values':values,'source_id':sid,'source_file':source['file'],
    'source_sha256':source['sha256'],'cell_range':f'{sheet.name}!R{ri+1}C{startcol+1}:R{ri+1}C{startcol+7}',
    'population':'2010 general/hospital survey published growth reference, not restricted to our term2026 singleton A cohort',
    'role':'independent_sample_historical_descriptive; not used to fit any B parameter'})
out={'sources':[r for r in sources if r['id']in ['000012673573','000012673574','000012673576']],
 'correction_scope':'2024-12 errata retained in B raw/2010_correction2024.*; these tables1/2/4 are not in listed corrected tables',
 'age_handling':'use original bin endpoints; do not fabricate within-bin age weights;30-day cells excluded from calendar-month endpoint comparison','rows':rows}
(ROOT/'data/heldout2010_physical.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print('normalized',len(rows))
