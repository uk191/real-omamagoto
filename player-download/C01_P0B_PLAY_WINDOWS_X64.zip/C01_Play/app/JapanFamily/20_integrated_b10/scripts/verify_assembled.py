#!/usr/bin/env python3
"""Run only from the independently assembled release in a new interpreter."""
import argparse,collections,concurrent.futures,datetime as dt,hashlib,json,math,re,sqlite3,subprocess,sys,time,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;REPO=PROJECT.parent
sys.path.insert(0,str(ROOT))
from integrated_b10 import Simulation,VERSION
from integrated_b10.legacy import a18_engine_class
from integrated_b10.storage import decode,restore_simulation
from child_b10.randomness import digest
sys.path.insert(0,str(ROOT/'scripts'))
from audit_baselines import sha,fingerprint


def suite(root,count,log):
 run=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=root,capture_output=True,text=True)
 log.write_text(run.stdout+'\n'+run.stderr);m=re.search(r'Ran (\d+) tests?',run.stderr)
 assert run.returncode==0 and m and int(m[1])==count,run.stderr
 return {'tests':int(m[1]),'passed':True,'log':str(log)}


def native_http_checks():
 expected=json.loads((PROJECT/'18_monthly_v02/data/release_expectations_v02.json').read_text());checks=[]
 for dirname,version in [('17_monthly','A3.0-0.1'),('18_monthly_v02','A3.0-0.2')]:
  proc=subprocess.Popen([sys.executable,str(PROJECT/dirname/'api.py'),'--port','0'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  try:
   port=json.loads(proc.stdout.readline())['port'];url=f'http://127.0.0.1:{port}'
   with urllib.request.urlopen(url+'/health',timeout=60)as response:assert json.load(response)['model_version']==version
   def post(path,body):
    request=urllib.request.Request(url+path,data=json.dumps(body,ensure_ascii=False).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(request,timeout=120)as response:return json.load(response)
   initial=post('/initialize',{'prefecture_code':'13','seed':'A302-release-check','include_region':False});assert digest(initial)==expected[version]['initial_sha256']
   full=post('/simulate',{'state':initial,'months':24});half=post('/simulate',{'state':initial,'months':12});split=post('/simulate',{'state':half,'months':12})
   assert digest(full)==digest(split)==expected[version]['final24_sha256']
   checks.append({'module':dirname,'version':version,'HTTP_initialize_and24_exact':True,'HTTP_serialized12_plus12_exact':True,'final24_sha256':digest(full)})
  finally:
   proc.terminate();proc.wait(timeout=15);proc.stdout.close();proc.stderr.close()
 return checks


def read_coupled_prefecture(task):
  database,pref=task;con=sqlite3.connect('file:'+database+'?mode=ro',uri=True)
  checked=0;observations=0;transactions=0
  for case,identity_blob,final_chain in con.execute('SELECT case_id,identity_zlib,final_history_chain FROM integrated_case WHERE prefecture_code=? ORDER BY case_id',(pref,)):
   identity=decode(identity_blob);chain='0'*64;rows=con.execute('SELECT month,record_zlib,record_sha256,history_chain FROM integrated_period WHERE case_id=? ORDER BY month',(case,)).fetchall()
   assert [r[0]for r in rows]==list(range(1,25))
   for month,blob,record_sha,expected_chain in rows:
    r=decode(blob);assert digest(r)==record_sha;chain=digest([chain,r]);assert chain==expected_chain
    a=r['A_month'];b=r['B_delta'];assert r['household_id']==identity['household_id'];assert b['elapsed_months']==month and b['as_of_date']==r['end_exclusive']
    assert b['age_days']==(dt.date.fromisoformat(b['as_of_date'])-dt.date.fromisoformat(identity['birth_date'])).days
    assert not b['scenario_effects_enabled'];assert a['ledger']['cash_identity_residual']==a['ledger']['net_worth_identity_residual']==0
    assert set(b['caregiver_relationships'])=={identity['person_links'][x]for x in identity['caregiver_local_ids']}
    assert all(math.isfinite(x)and 0<=x<=1 for x in b['emotion_regulation'].values())
    for local,public in r['B_parent_observations'].items():
     assert set(public)=={'child_id','as_of_date','observations','measurements'};assert public['child_id']==identity['index_global_person_id']
     gid=identity['person_links'][local];assert all(x['observer_id']==gid for x in public['observations'])
     assert public['observations']==[x for x in b['parent_observations']if x['observer_id']==gid]
     observations+=len(public['observations'])
    transactions+=len(r['A_transactions']);checked+=1
   assert chain==final_chain
  con.close();return {'prefecture':pref,'periods':checked,'observations':observations,'transactions':transactions}


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--report',type=Path,required=True);args=ap.parse_args();args.report.parent.mkdir(parents=True,exist_ok=True)
 started=time.time();out={'version':VERSION,'checked_UTC':dt.datetime.now(dt.timezone.utc).isoformat(),
  'fresh_destination':str(REPO),'storage_scope':'saved local ZIPs re-read/CRC/SHA checked, restored into independent directory; no remote durability claim',
  'formal_A_B_software_integration':False,'release_engineering_checks_passed':False,
  'Japan_national_joint_external_validity':False,'psychological_external_validity':False,'clinical_validation':False,'causal_effects_identified':False,
  'financially_playable':False,'age_over24_supported':False}
 try:
  assembly=json.loads((REPO/'ASSEMBLY_VERIFICATION.json').read_text());assert assembly['all_zip_CRCs_passed']and assembly['all_payload_SHA256_match'];out['assembly']=assembly
  # Full old source bytes, including both old databases, checked again after assembly.
  am=json.loads((REPO/'provenance/A302_original/extracted_file_sha256.json').read_text())
  for name,expected in am.items():assert sha(REPO/name)==expected,name
  with zipfile.ZipFile(REPO/'artifacts/B1.0_PREINTEGRATION.zip')as z:bm=json.loads(z.read('MANIFEST.json'))['files']
  for name,expected in bm.items():assert sha(REPO/name)==expected,name
  out['original_A_files_unchanged']=len(am);out['original_B_files_unchanged']=len(bm)
  before=json.loads((ROOT/'results/baseline/A_all_tables_before.json').read_text());db=ROOT/'results/coupled_10340/integrated.sqlite'
  af=fingerprint(PROJECT/'data/region.sqlite',set(before));new_af=fingerprint(db,set(before));assert af==new_af==before
  out['all_inherited_A_tables_row_hashes_unchanged']=len(before)
  source=sqlite3.connect('file:'+str(PROJECT/'data/region.sqlite')+'?mode=ro',uri=True);con=sqlite3.connect('file:'+str(db)+'?mode=ro',uri=True)
  objects=source.execute('SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name').fetchall()
  for obj in objects:assert con.execute('SELECT type,name,tbl_name,sql FROM sqlite_master WHERE type=? AND name=?',obj[:2]).fetchone()==obj
  out['all_inherited_SQL_objects_unchanged']=len(objects);source.close()
  out['databases']=[]
  for name,path in [('original_A',PROJECT/'data/region.sqlite'),('original_B',PROJECT/'19_child_b10/results/population_10000/child_b10.sqlite'),('integrated',db)]:
   c=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);integrity=c.execute('PRAGMA integrity_check').fetchall();fk=c.execute('PRAGMA foreign_key_check').fetchall();c.close()
   assert integrity==[('ok',)]and not fk;out['databases'].append({'name':name,'sha256':sha(path),'integrity_check':integrity,'foreign_key_check':fk})
  counts=dict(con.execute('SELECT prefecture_code,count(*) FROM integrated_case GROUP BY prefecture_code'));assert len(counts)==47 and set(counts.values())=={220}
  n=con.execute('SELECT count(*) FROM integrated_period').fetchone()[0];assert n==248160
  assert con.execute('SELECT count(*) FROM integrated_checkpoint').fetchone()[0]==20680
  assert con.execute('SELECT count(*) FROM integrated_failure').fetchone()[0]==0
  normalized_people=0;unknown_residence=0
  for case,local,gid,household,normalized,blob in con.execute('SELECT p.case_id,p.local_person_id,p.global_person_id,c.household_id,p.co_resident,p.initial_person_zlib FROM integrated_person p JOIN integrated_case c USING(case_id)'):
   person=decode(blob);assert person['person_id']==local and gid==household+'/'+local
   expected=None if person['co_resident'] is None else int(person['co_resident'])
   assert normalized==expected;normalized_people+=1;unknown_residence+=expected is None
  out['normalized_person_rows_checked']=normalized_people;out['unknown_residence_retained_as_null']=unknown_residence
  checked=0;observations=0;transactions=0;period_checks=[]
  with concurrent.futures.ProcessPoolExecutor(max_workers=4)as pool:
   for result in pool.map(read_coupled_prefecture,[(str(db),pref)for pref in sorted(counts)]):
    checked+=result['periods'];observations+=result['observations'];transactions+=result['transactions'];period_checks.append(result)
    print('fresh coupled periods checked',checked,'prefecture',result['prefecture'],flush=True)
  out['fresh_prefecture_readthrough']=period_checks
  assert checked==248160;out['coupled_families']=10340;out['coupled_periods_read_and_hash_checked']=checked;out['prefecture_family_counts']=counts
  out['public_reports_read']=observations;out['A_transactions_read']=transactions
  # Use extracted B code/parameters and original250k records, not previous claims.
  bdb=sqlite3.connect('file:'+str(PROJECT/'19_child_b10/results/population_10000/child_b10.sqlite')+'?mode=ro',uri=True)
  old_read=0
  for child_id,month,age,w,l,h,internal,public_blob in bdb.execute('SELECT * FROM b10_month'):
   b=decode(internal);public=decode(public_blob);assert b['elapsed_months']==month and b['age_days']==age
   assert public['child_id']==child_id and set(public)=={'child_id','as_of_date','observations','measurements'}
   ph=b['physical_health'];assert (ph['weight_kg'],ph['length_cm'],ph['head_circumference_cm'])==(w,l,h);old_read+=1
  assert old_read==250000;out['old_B_states_and_public_payloads_read']=old_read
  from child_b10.storage import restore_child
  from scripts.experiments import routine
  old_replays=[]
  for seed in [1000000,1005000,1009999]:
   ident=bdb.execute('SELECT child_id FROM b10_child WHERE seed=?',(seed,)).fetchone()[0]
   a=restore_child(bdb,ident,12).advance_to(24,routine);b=restore_child(bdb,ident,24)
   assert a.research_snapshot()==b.research_snapshot();old_replays.append({'seed':seed,'stored12_plus12_equals_stored24':True})
  out['old_B_DB_replays']=old_replays;bdb.close()
  out['B_original_unit_suite']=suite(PROJECT/'19_child_b10',31,args.report.with_name('B1.0_INTEGRATED_FRESH_B_TESTS.log'))
  out['integration_unit_and_HTTP_suite']=suite(ROOT,25,args.report.with_name('B1.0_INTEGRATED_FRESH_INTEGRATION_TESTS.log'))
  out['old_A_HTTP_APIs']=native_http_checks()
  a25=json.loads(subprocess.check_output([sys.executable,str(PROJECT/'16_recovery/model.py'),'--pref','13','--seed','A302-release-check','--no-region'],text=True));assert a25['model_version']=='A2.5-0.2r2';out['old_A25_API']=a25['model_version']
  engine=a18_engine_class()();replays=[]
  for pref in sorted(counts):
   case=con.execute('SELECT case_id FROM integrated_case WHERE prefecture_code=? ORDER BY case_id LIMIT 1',(pref,)).fetchone()[0]
   final=restore_simulation(con,case,24,engine=engine);middle=restore_simulation(con,case,12,engine=engine);middle.run(12,stop_on_decision=False,research_continue=True)
   fresh=Simulation.initialize(pref,seed=final.configuration['master_seed'],birth_date=final.identity['birth_date'],engine=engine);fresh.run(24,stop_on_decision=False,research_continue=True)
   assert final.research_snapshot()==middle.research_snapshot()==fresh.research_snapshot()
   replays.append({'prefecture':pref,'case_id':case,'fresh24_equals_stored24':True,'stored12_plus12_equals_stored24':True,'final_sha256':digest(final.research_snapshot())})
  out['fresh_independent_47_replays']=replays;con.close()
  out['formal_A_B_software_integration']=True;out['release_engineering_checks_passed']=True
 except Exception as exc:
  import traceback
  out['error']=repr(exc);out['traceback']=traceback.format_exc();print(out['traceback'],flush=True)
 out['seconds']=time.time()-started;args.report.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(json.dumps(out,ensure_ascii=False),flush=True)
 if not out['release_engineering_checks_passed']:raise SystemExit(1)

if __name__=='__main__':main()
