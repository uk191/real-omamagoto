"""Audit original A/B bytes and databases without executing mutating legacy scripts."""
import hashlib
import json
import re
import sqlite3
import subprocess
import sys
import time
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;REPO=PROJECT.parent
OUT=ROOT/'results/baseline'


def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def fingerprint(path,only_tables=None):
    con=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);out={}
    for (table,) in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
        if only_tables is not None and table not in only_tables:continue
        escaped=table.replace('"','""');h=hashlib.sha256();count=0
        try:rows=con.execute('SELECT * FROM "'+escaped+'" ORDER BY rowid')
        except sqlite3.OperationalError:
            cols=len(con.execute('PRAGMA table_info("'+escaped+'")').fetchall())
            rows=con.execute('SELECT * FROM "'+escaped+'" ORDER BY '+','.join(str(i+1) for i in range(cols)))
        for row in rows:h.update((json.dumps(row,ensure_ascii=False,separators=(',',':'),default=lambda v:v.hex())+'\n').encode());count+=1
        out[table]={'rows':count,'sha256':h.hexdigest()}
        print('fingerprinted',table,count,flush=True)
    con.close();return out


def main():
    OUT.mkdir(exist_ok=True,parents=True)
    a=REPO/'provenance/A302_original/A302_official_restored.zip'
    a_sha=sha(a);assert a_sha=='7dca730f3622bb72a46e6b26c88ea5e4b97155a7674043e8f45bd1b7776f8fff'
    with zipfile.ZipFile(a) as z:assert z.testzip() is None;a_members=len(z.infolist())
    am=json.loads((PROJECT/'release_manifest_v02.json').read_text())
    for name,value in am['files'].items():assert sha(PROJECT/name)==value,name
    bchecks=[]
    for filename,expected in [
        ('B1.0_PREINTEGRATION.zip','b6663c47d73dcc3d279b95e728aab885a78f21968edaadfd2f7ded996626ad86'),
        ('B1.0_PREINTEGRATION_CODE_AND_REPORTS.zip','f5a628f4dc352ca85b69f7c85a9eae9c9151c0e4bbcc4f3be5b6b97ba9015ae2')]:
        p=REPO/'artifacts'/filename;assert sha(p)==expected
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None;manifest=json.loads(z.read('MANIFEST.json'))
        for name,value in manifest['files'].items():assert sha(REPO/name)==value,name
        bchecks.append({'archive':filename,'sha256':expected,'crc':True,'files':len(manifest['files'])})
    af=fingerprint(PROJECT/'data/region.sqlite')
    expected=json.loads((PROJECT/'18_monthly_v02/validation/inherited_tables_before.json').read_text())
    assert len(expected)==55 and {k:af[k] for k in expected}==expected
    (OUT/'A_all_tables_before.json').write_text(json.dumps(af,ensure_ascii=False,indent=2))
    dbs=[]
    for name,path in [('A',PROJECT/'data/region.sqlite'),('B',PROJECT/'19_child_b10/results/population_10000/child_b10.sqlite')]:
        c=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
        integrity=c.execute('PRAGMA integrity_check').fetchall();fk=c.execute('PRAGMA foreign_key_check').fetchall();assert integrity==[('ok',)] and not fk
        tables={r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        counts={}
        for table in ['monthly_v02_household','monthly_v02_state','b10_child','b10_month']:
            if table in tables:counts[table]=c.execute('SELECT count(*) FROM '+table).fetchone()[0]
        dbs.append({'name':name,'sha256':sha(path),'integrity':integrity,'foreign_keys':fk,'counts':counts});c.close()
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],cwd=PROJECT/'19_child_b10',capture_output=True,text=True)
    (OUT/'B_original_31_tests.log').write_text(tests.stdout+tests.stderr)
    assert tests.returncode==0 and re.search(r'Ran 31 tests',tests.stderr)
    replay='''import sqlite3,json
from child_b10.storage import restore_child
from scripts.experiments import routine
c=sqlite3.connect('file:results/population_10000/child_b10.sqlite?mode=ro',uri=True)
out=[]
for seed in [1000000,1005000,1009999]:
 ident=c.execute('SELECT child_id FROM b10_child WHERE seed=?',(seed,)).fetchone()[0]
 a=restore_child(c,ident,12).advance_to(24,routine).research_snapshot()
 b=restore_child(c,ident,24).research_snapshot();assert a==b
 out.append({'seed':seed,'exact':True})
print(json.dumps(out))'''
    b_replay=subprocess.run([sys.executable,'-c',replay],cwd=PROJECT/'19_child_b10',capture_output=True,text=True,check=True)
    result={'A_zip_sha256':a_sha,'A_zip_crc':True,'A_zip_members':a_members,'A_final_manifest_files':len(am['files']),
        'B_archives':bchecks,'B_original_tests':31,'B_original_replays':json.loads(b_replay.stdout),
        'A_original_55_tables_match_prior_release':True,'A_all_tables':len(af),'databases':dbs,
        'notes':'Engineering baseline audit; no new external validity or causal certification'}
    (OUT/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result),flush=True)


if __name__=='__main__':main()
