#!/usr/bin/env python3
"""Build a report from actual stored results; never manufacture a pass field."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from integrated_b10 import VERSION


def main():
 output=ROOT/'results/coupled_10340';generation=json.loads((output/'generation_summary.json').read_text());stats=json.loads((output/'statistical_validation.json').read_text());database=json.loads((output/'database_verification.json').read_text());replays=json.loads((output/'replays_47.json').read_text())
 old=json.loads((ROOT/'results/baseline/legacy_rerun/runner_summary.json').read_text());assert all(x['passed']for x in old)
 assert generation['completed']==10340 and generation['periods']==248160 and len(replays)==47
 assert database['all_inherited_table_rows_identical']and database['all_inherited_SQL_objects_identical']
 assert 'Ran 25 tests' in (ROOT/'results/integration_tests.log').read_text() and (ROOT/'results/integration_tests.log').read_text().rstrip().endswith('OK')
 unpaid=stats['employment_weighted_status']['18'].get('mother/job_attached_zero_work_unpaid',0)
 examples=json.loads((ROOT/'results/examples/comparison_summary.json').read_text())
 maxz=max(abs(x['mean_MC_z'])for x in stats['birth_same_source_calibration']if x['mean_MC_z']is not None)
 status={'version':VERSION,'formal_A_B_software_integration':True,'supported_scope_24months_execution_verified':True,
  'preserved_A_original_files':1259,'preserved_B_original_files':137,'preserved_A_tables':64,
  'new_coupled_families':10340,'new_coupled_periods':248160,'new_child_states_including_birth':258500,
  'old_B_standalone_children_preserved':10000,'old_B_standalone_states_preserved':250000,
  'first_day_2026_singleton_term_reference_only':True,'nonterm_multiple_partial_month_supported':False,
  'scientific_research_complete':False,'Japan_national_external_validity':False,'psychological_validation':False,
  'clinical_validation':False,'causal_effects_identified':False,'financially_playable':False,'age_over24_supported':False,
  'post_save_verification':'Authoritative separate artifact B1.0_INTEGRATED_RELEASE_VERIFICATION.json; generated only after saving and independently extracting both packs',
  'historical_B_status':'19_child_b10 is preserved unchanged; its missing-A integration blocker is superseded by20_child_b10, not retroactively edited'}
 (ROOT/'DELIVERABLE_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
 report=f'''# A-1〜A3.0-0.2 × B-1.0 正式接続構築報告

版：`{VERSION}`。対象：出生〜24か月の研究用接続。今回の添付17ファイルと正式指示書に基づく。原A内の古い開発命令は過去資料として扱い、今回の指示と混同していない。

## 到達点

**元の47県家庭生成APIが生成した同一家庭・同一出生児をBへ結合し、10,340家庭を24か月連続進行して保存した。** 単に2つのプログラムを同梱したものではない。人物・出生・地域・月齢・家計・時間・保育・行動・意思決定・内部状態・親観測・出来事を同一期間に接続する独立モジュールを追加した。

これは正式なソフトウェア接続研究版であり、子どもモデル全領域の研究完成や、日本の家庭・心理・医学・介入の外部妥当性は達成していない。`financially_playable=false`を維持する。支持範囲は2026年各月1日生まれ、単胎、B在胎37〜41週の病院参照シナリオ。早産・多胎・出生月途中は明示的に未対応。2歳以降への実用解禁はしない。

## 原資産の復元・監査・保全

実添付の`A302_restore.py`を監査して実行し、全15片のSHA256、元ZIP467674325バイト、SHA256 `7dca730f3622bb72a46e6b26c88ea5e4b97155a7674043e8f45bd1b7776f8fff`、ZIP内部1259項目のCRCを確認した。toolsと単独指示書の内容一致を含め、添付17ファイルすべてを照合・保全した。元ZIPは読み取り専用。

Aの完全指示書、地域・家庭・初期状態・A17/A18コード、全国検証、出典/変数台帳、外部妥当性判定を監査した。A最終manifest1258ファイルと元ZIPの全1259ファイルhashを確認。元Aの64テーブルの全行hashを保存し、元の55テーブルの以前のhashとも一致。新統合DB内でも旧64テーブルの行と全SQLオブジェクトを照合して一致した。

既存Bは実在する構築報告・2個のZIP・リリース検証・DBを確認し、原ZIPのCRCとSHA、137ファイルの一致、SQLite、31検査、保存12月からの3seed再開を再実行した。原Bの1万人・25万状態・原表・コード・検証結果は変更していない。旧報告の「A取得不能」はその時点の記録として保持し、今回の接続報告で解消を記す。科学的な未完了は引き続き残る。

## 接続と情報分離

`A18 -> A2.5-0.2r2 -> A2 -> A1`を実行し、Aで生成したindex出生児のID・性別・DOBをBへ渡す。各養育者は家庭IDで名前空間化。出生順位の点/区間、分娩ID、同胞・同居人、居住地域を保存する。兄弟のある家庭や単親も動作するが、Bの発達対象はindex児のみ。

Aに在胎週数・出生体格の観測値がない事実はunknownのまま記録し、Bの生成値は正期産病院参照scenarioとする。外部測定の入力は出典とknown_byを要求する。低体重から疾患や障害を診断しない。早産・多胎に正期産児を代入しない。

各月はA候補を一度更新→実際の時間・保育・出来事・行動/判断・元帳を採取→同期間のB候補を一度更新→暦とIDを検査→一括commitの順。失敗時は両状態を維持する。A候補の最終状態は元エンジンretain_journal=Falseと一致し、捨てずに保存した元帳記入は結合月記録に残す。

Aのactive_careは架空の観測機会0.6の正時間ゲートのみ。時間を接触回数・愛着に換算しない。保育は文脈・経験記録へ接続する。文脈記憶の機械則は未校正のB仮定として残る。身体・気質・発達・情動への未識別介入係数はOFF。所得・学歴から先天的能力や人格を決めない。

親向け`player_view`/HTTPには、見たと仮定した行動・知らされた測定・家庭の既知情報・判断待ちだけを返す。内部値・seed・発達目標・内部履歴は返さない。研究snapshot/SQLiteは別。HTTPはローカル試作で本番認証は未実装。

## 実行結果

|検証|今回の実行結果|解釈|
|---|---|---|
|旧Aの再検証|{len(old)}検証プロセス全通過|A1、A2 HTTP/108100生成、旧A2.5 HTTP/103400生成、recovery21検査、A17/A18各単体・47県リプレイ等。使い捨ての別コピーで実行|
|旧A正式ZIPの別展開|元のリリース検証を再実行して通過|A17/A18 HTTP初期化、24月、JSONで12+12、A2.5 API等が元期待hashと一致|
|B元試作|31検査、DB整合性/FK、3seedの保存再開一致|実測心理分布の妥当性とは別|
|新統合境界/API/保存|25検査通過|47県実生成、A経路不変、乱数独立、単親・兄弟、非対応拒否、判断待ち、観測分離、改変拒否、HTTP等|
|予備試行|94家庭・2256期間完走|全47県の実接続を先に検査|
|本試行|{generation['completed']:,}家庭・{generation['periods']:,}期間、失敗0|各県220家庭、24月。出生含む{stats['stored_child_states_including_birth']:,}子ども状態|
|本試行の内部検査|全期間hash・履歴鎖・暦・人物・身体/短期状態の範囲・前提能力・会計残差0・週168h/子84h整合|プログラム整合性。モデルの現実適合ではない|
|保存再開と再生成|全47県1家庭ずつ、保存12+12＝保存24＝同seed出生から24|全研究状態・全履歴の完全一致。全10,340家庭の再生成を二重実行したという意味ではない|
|旧新SQLite|integrity_check=ok、FK違反0|旧A64テーブルとSQL定義は不変|
|保存後検査|別添リリース証明を参照|保存後の2パックを別ディレクトリへ復元して再検査。本文自身を証明にしない|

本試行は{generation['seconds']:.1f}秒、3worker。Aの2025年都道府県別日本人出生数を地域重みに使用（有効標本数{stats['effective_n_geographic']:.1f}）。この重みは在胎・健康・家庭の全国同時分布を識別しない。誕生月は12か月を循環して暦を検査しており、出生季節性を再現した標本ではない。A家計の10月参照アンカーも残す。

A元帳{stats['A_transactions']:,}記入、親別観測{stats['parent_observation_reports']:,}件、統一出来事{stats['unified_events']:,}件を保存。判断待ちのある{stats['pending_decisions'].get('periods_pending',0):,}期間を含み、研究継続を{stats['pending_decisions'].get('explicit_research_continuations',0):,}期間で明示。通常モードは判断待ちで停止する。24月研究完走は家計問題を解決したことではない。

## 不明値の保存で見つかった問題と修正

追加schema照合で、一部A人物の同居状況nullを正規化列だけでfalseに変換していたことを発見した。元A人物blob・全軌跡・親向け投影は不明値を保持しており、欠落はない。SQL列と親投影schemaを三値に修正し、元blobから結合DBを再構築した。修正対象317行、全{stats['normalized_people_checked']:,}人物を再照合して不明値{stats['unknown_residence_retained_as_null']}行をNULLで保持することを確認。回帰検査を25件に拡張した。さらに、同一家族の子ども等のglobal IDが親用の行動主体へ変換される経路を塞ぎ、local IDと同じ養育者検査を適用した。不正指定時にA/B両状態が変わらないことを既存の行動検査に追加した。通常の保存軌跡にはこの不正指定はなく、旧A/B核と抽選結果は変更していない。候補DBのhashと修正記録は`results/pre_release_schema_correction.json`。

## 分布と独立資料

全0〜24月の身体・13気質代理・10成熟時計・12節目・6短期状態について平均、SD、1/3/10/25/50/75/90/97/99分位を保存。出生性別×在胎週×身体の条件付きモーメントは同一2023年出典での校正検査で、評価可能セルの最大絶対MC標準化誤差は{maxz:.3f}。気質の仮定共分散との最大差は{stats['trait_covariance_max_absolute_error_vs_assumption']:.5f}。いずれも実測の相関や全国輸送の認証ではない。

独立した2010年原XLSの身体3指標・男女・出生/年齢階級144行をセル座標・出典hash付きで抽出し、生成分位との比較を保存。発達7項目の独立2010年親回答原表とも、年齢階級の始端/終端における生成通過率を比較した。2010年資料の2024年正誤は該当表1/2/4/11を訂正対象としておらず、正誤原文を保全する。WHOの身体分位も別の国際参照として併記する。

2023年と2010年の調査年、病院/一般集団、正期産選択、尺度・親回答と潜在獲得、階級内月齢の分布を整合できていない。2010年と2023年の初語等に差があり、比較結果から現代の外部妥当性を合格としない。2026年出生児の2028年までの実測経路を2026年時点で検証する資料はない。心理・関係・医学の独立した適合集団/測定モデルも未取得・未識別である。

Bの縦断身体ランクと単調制約は未校正。今回は延べ{stats['growth_monotonic_constraint_count']:,}回の身長/頭囲保持補正を記録した。修正頻度・周辺分布への影響を隠さず保存する。13気質代理は尺度得点ではなく5項目は保存のみ。睡眠、感染、受容言語等の精密な日本確率モデルを完成させたとはしない。

## 個体差と環境比較

同じA初期家庭・同じA24月経路で、B seed901/902/903を変えた3児を進行し、A状態・家計/就業/保育は完全一致、B気質・発達時期・行動には差が出る。Bの乱数はAへ干渉しない。

同じA初期家庭・同じB seed904で、保育available/unavailableのAシナリオを比較。Bの初期特性・身体・気質・発達は一致。Aの保育・時間を介して文脈経験が変わる。この保育対比較では両親のactive_careがともに正なので、親の子ども観測は同じ{examples['same_child_different_A_scenarios']['observations']['available']}件となった。別途1か月の診断用境界例で、Aへの親族支援要求→84時間の親族カバー→両親active_care=0→B観測機会0という実行経路を記録した。この84時間支援は典型的な日本家庭のシナリオではなく、観測ゼロも架空の機会ゲートによる（現実に親が観察不能になるとの主張ではない）。養育が無効だという科学的結論ではなく、未識別の因果係数を実装していないことの検査である。単親、複数兄弟、判断待ち家庭も24月の全研究履歴を圧縮JSONで保存した。

代表児24月CSVと全履歴、比較要約は`results/examples`。どの月のA行動・保育・時間・B文脈/観測を通じて差が出たかをsource_refから追跡できる。

## Aの重大な制約を維持

旧報告の母18月「雇用先あり・実働ゼロ・無給」45.4%は未解決。今回の異なるseed/循環出生月標本でも出生地重みで**{unpaid*100:.2f}%**を生成した。比率が近いことは妥当性の支持ではなく、未検証経路を保全した診断値。所得・資産・支出の同時分布、保育選考、税精算、自治体制度も未完成。これらからBへの心理・医学的因果効果は設定していない。

## 保存と未完了

2パックは共通bundle_idと原A/B・新DBのSHA256で対応づける。DATAに元A/B完全ZIPと全旧資産、今回添付17ファイル、新結合DB・全履歴を保持する。CODEは新接続コード/資料/検証とレビュー用旧コードを含む。組立スクリプトが元A1259・元B137ファイルを復元して照合し、新接続層を追加する。別作業場所の保存後検査は外部`B1.0_INTEGRATED_RELEASE_VERIFICATION.json`に記録する。

未取得・未実装・未識別事項は`data/backlog.json`、未接続因果関係は`data/causal_connections.json`。詳細な医学心理変数・出典台帳は旧Bを変更せず参照する。早産/多胎/月途中出生、病気・感覚・支援、気質測定、愛着、観測誤差、身体縦断、親の自動応答、2〜20歳、本番認証は今後の工程。再構築・中断再開・独立検証は`docs/再構築と再検証.md`。
'''
 (ROOT/'docs/正式統合構築報告.md').write_text(report)
 print('REPORT_WRITTEN',VERSION,flush=True)

if __name__=='__main__':main()
