#!/usr/bin/env python3
"""47 genuine A generators, each linked to one B child, 24 actual periods.

Per-prefecture immutable shards support restart. A failures are retained, never
replaced or resampled. Geographic weights are 2025 Japanese-livebirth weights;
this is not an identified national joint birth/health/household distribution.
"""
import argparse,concurrent.futures,collections,datetime as dt,hashlib,json,math,os,shutil,sqlite3,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from integrated_b10 import Simulation,VERSION
from integrated_b10.legacy import PROJECT,a18_engine_class
from integrated_b10.storage import connect,create_schema,insert_case,insert_period,encode,decode
from child_b10.randomness import digest
from child_b10.engine import PARAMS,DOMAINS

ENGINE=None

def worker_init():
 global ENGINE
 ENGINE=a18_engine_class()()


def process_pref(task):
 pref,count,weight,out=task;path=Path(out)/f'pref_{pref}.sqlite';summary=path.with_suffix('.json')
 if path.exists() and summary.exists():
  saved=json.loads(summary.read_text())
  if saved['requested']==count and saved['version']==VERSION:return saved
  raise ValueError('Existing shard belongs to another configuration')
 if path.exists():path.unlink() # incomplete own shard; no source data touched
 db=connect(path);create_schema(db);started=time.time();complete=0;failed=[];person_count=0
 for i in range(count):
  seed=31000000+int(pref)*10000+i;birth=f'2026-{(i+int(pref)-1)%12+1:02d}-01'
  try:
   sim=Simulation.initialize(pref,seed=seed,birth_date=birth,include_region=True,engine=ENGINE)
   with db:
    insert_case(db,sim,weight/count);person_count+=len(sim.a['persons'])
    previous=sim.child.research_snapshot()
    for month in range(1,25):
     sim.step(research_continue=True);sim.assert_consistent();row=sim.records[-1]['A_month']
     assert row['ledger']['cash_identity_residual']==row['ledger']['net_worth_identity_residual']==0
     assert all(abs(p['total']-168)<1e-8 for p in row['time']['parents'].values())
     assert abs(sum(row['time'][x] for x in ['nursery','relative','parent_care','uncovered'])-84)<1e-8
     assert all(p['active_care']>=0 for p in row['time']['parents'].values())
     assert not sim.child._state['physical_health']['diagnoses']
     assert sim.a['initial_family']['household']['municipality_code'] is not None
     b=sim.child._state;ph=b['physical_health'];dev=b['developmental_state']
     assert all(math.isfinite(x) and 0<=x<=1 for x in b['emotion_regulation'].values())
     assert all(math.isfinite(ph[k]) and ph[k]>0 for k in ['weight_kg','length_cm','head_circumference_cm'])
     assert all(dev['progress'][k]>=previous['developmental_state']['progress'][k] for k in DOMAINS)
     assert all(ph[k]>=previous['physical_health'][k] for k in ['length_cm','head_circumference_cm'])
     assert all(all(pre in dev['milestones'] for pre in PARAMS['milestones'][name][2]) for name in dev['milestones'])
     assert b['age_days']==(dt.date.fromisoformat(b['as_of_date'])-dt.date.fromisoformat(birth)).days
     previous={'physical_health':dict(ph),'developmental_state':{'progress':dict(dev['progress'])}}
     insert_period(db,sim)
    events=sim.child._state['experience_ledger']
    assert [e['date']for e in events]==sorted(e['date']for e in events)
    assert len({e['history_id']for e in events})==len(events)
   complete+=1
  except Exception as exc:
   detail={'seed':seed,'birth_date':birth,'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
   failed.append(detail)
   with db:db.execute('INSERT INTO integrated_failure VALUES(?,?,?,?)',(f'{pref}/{i}',pref,str(seed),json.dumps(detail)))
  if (i+1)%25==0:print(json.dumps({'prefecture':pref,'attempted':i+1,'completed':complete,'seconds':round(time.time()-started,1)}),flush=True)
 assert not db.execute('PRAGMA foreign_key_check').fetchall()
 summary_value={'prefecture':pref,'requested':count,'completed':complete,'periods':complete*24,'persons':person_count,
  'failed':failed,'version':VERSION,'seconds':time.time()-started,'all_ids_dates_ages_account_and_time_checks':not failed}
 with db:db.execute('INSERT INTO integrated_run VALUES(?,?)',('cohort',json.dumps(summary_value)))
 db.close();summary.write_text(json.dumps(summary_value,ensure_ascii=False,indent=2)+'\n')
 return summary_value


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--per-prefecture',type=int,default=220);ap.add_argument('--workers',type=int,default=3)
 ap.add_argument('--output',type=Path,default=ROOT/'results'/'coupled_10340');ap.add_argument('--prefectures',default=','.join(f'{x:02d}'for x in range(1,48)))
 args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True);shards=args.output/'shards';shards.mkdir(exist_ok=True)
 engine=a18_engine_class()();counts={p:sum(x['weight']for x in rows if x['sex']=='all')for p,rows in engine.generator.base.g['birth_pref'].items()}
 total=sum(counts.values());weights={p:x/total for p,x in counts.items()};prefs=args.prefectures.split(',')
 results=[];started=time.time()
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=worker_init) as pool:
  futures={pool.submit(process_pref,(p,args.per_prefecture,weights[p],str(shards))):p for p in prefs}
  for future in concurrent.futures.as_completed(futures):
   result=future.result();results.append(result);print('COMPLETED_PREFECTURE',json.dumps(result),flush=True)
 report={'version':VERSION,'source_generator':'actual A18.Engine -> A2.5-0.2r2 -> A2 -> A1, include_region=True',
  'requested':len(prefs)*args.per_prefecture,'completed':sum(x['completed']for x in results),'periods':sum(x['periods']for x in results),
  'prefectures':sorted(results,key=lambda x:x['prefecture']),'seconds':time.time()-started,'geographic_weights':weights,
  'sampling_scope':'first-day births2026; term37..41 physiology reference; singleton; A livebirth geography; no biological national-joint claim',
  'research_continuation':'explicit at every step; pending A decisions retained; no B intervention effects enabled',
  'external_validity':False,'causal_effects_identified':False}
 (args.output/'generation_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print('GENERATION_DONE',report['completed'],report['periods'],round(report['seconds'],1),flush=True)
 if report['completed']!=report['requested']:raise SystemExit('Incomplete cohort: see retained failures; no resampling')

if __name__=='__main__':main()
