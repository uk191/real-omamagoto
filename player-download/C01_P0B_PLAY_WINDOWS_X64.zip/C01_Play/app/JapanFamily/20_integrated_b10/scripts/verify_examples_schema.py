#!/usr/bin/env python3
"""Validate complete real example histories and observer projections."""
import gzip,json,sys
from pathlib import Path
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from integrated_b10 import Simulation
from integrated_b10.legacy import a18_engine_class


def main():
 wrapper=Draft202012Validator(json.loads((ROOT/'data/integrated_snapshot.schema.json').read_text()))
 public=Draft202012Validator(json.loads((ROOT/'data/player_response.schema.json').read_text()))
 component=Draft202012Validator(json.loads((ROOT.parent/'19_child_b10/data/internal_state.schema.json').read_text()))
 engine=a18_engine_class()();checks=[]
 for p in sorted((ROOT/'results/examples').rglob('*.json.gz')):
  with gzip.open(p,'rt')as f:s=json.load(f)
  wrapper.validate(s);component.validate(s['B_state']);sim=Simulation.from_snapshot(s,engine=engine)
  for observer in sim.identity['caregiver_local_ids']:public.validate(sim.player_view(observer))
  checks.append({'example':p.name,'research_wrapper_schema':True,'B_component_schema':True,'all_registered_observers_schema':True,'coupled_consistency':True})
 assert len(checks)==10
 (ROOT/'results/schema_validation.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');print('10 retained examples and observer projections match schemas',flush=True)

if __name__=='__main__':main()
