#!/usr/bin/env python3
"""Verify paired packs, restore exact source archives and overlay identical code.

Stdlib only; refuses a nonempty destination and differing source overwrites.
"""
import argparse,hashlib,json,shutil,stat,zipfile
from pathlib import Path,PurePosixPath


def sha(path):
 with Path(path).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()


def checked_name(name):
 p=PurePosixPath(name)
 if p.is_absolute()or '..'in p.parts or '\\'in name:raise ValueError('Unsafe ZIP member: '+name)
 return p


def extract(zip_path,destination,skip=()):
 with zipfile.ZipFile(zip_path)as z:
  if z.testzip()is not None:raise ValueError('ZIP CRC failure: '+str(zip_path))
  for info in z.infolist():
   rel=checked_name(info.filename)
   if stat.S_ISLNK(info.external_attr>>16):raise ValueError('Symlink member refused')
   if info.is_dir()or info.filename in skip:continue
   target=destination/str(rel);target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():
    with z.open(info)as src:expected=hashlib.file_digest(src,'sha256').hexdigest()
    if sha(target)!=expected:raise ValueError('Differing source overwrite refused: '+str(rel))
   else:
    with z.open(info)as src,target.open('wb')as out:shutil.copyfileobj(src,out,8*1024*1024)


def check_files(destination,mapping):
 for name,value in mapping.items():
  checked_name(name);expected=value['sha256']if isinstance(value,dict)else value
  if sha(destination/name)!=expected:raise ValueError('SHA256 mismatch: '+name)
 return len(mapping)


def assemble(code_pack,data_pack,destination):
 destination=Path(destination)
 if destination.exists()and any(destination.iterdir()):raise FileExistsError('A new/empty destination is required')
 destination.mkdir(parents=True,exist_ok=True)
 with zipfile.ZipFile(code_pack)as z:code=json.loads(z.read('INTEGRATION_CODE_MANIFEST.json'))
 with zipfile.ZipFile(data_pack)as z:data=json.loads(z.read('INTEGRATION_DATA_MANIFEST.json'))
 if code['bundle_id']!=data['bundle_id']or code['pins']!=data['pins']:raise ValueError('Mismatched release packs')
 print('extracting verified data pack',flush=True);extract(data_pack,destination)
 data_count=check_files(destination,data['files']);print('data payload SHA256 checked',data_count,flush=True)
 original_a=destination/'provenance/A302_original/A302_official_restored.zip'
 original_b=destination/'artifacts/B1.0_PREINTEGRATION.zip'
 if sha(original_a)!=code['pins']['A_original_zip_sha256']or sha(original_b)!=code['pins']['B_original_zip_sha256']:raise ValueError('Original source ZIP hash mismatch')
 print('restoring exact A and B source archives',flush=True);extract(original_a,destination);extract(original_b,destination,skip=('MANIFEST.json',))
 a_manifest=json.loads((destination/'provenance/A302_original/extracted_file_sha256.json').read_text())
 a_count=check_files(destination,a_manifest)
 with zipfile.ZipFile(original_b)as z:b_manifest=json.loads(z.read('MANIFEST.json'))
 b_count=check_files(destination,b_manifest['files'])
 print('overlaying identical preserved source and new adapter',flush=True);extract(code_pack,destination)
 code_count=check_files(destination,code['files'])
 db=destination/'JapanFamily/20_integrated_b10/results/coupled_10340/integrated.sqlite'
 if sha(db)!=code['pins']['integrated_database_sha256']:raise ValueError('Integrated DB hash mismatch')
 for name in set(a_manifest)|set(b_manifest['files']): (destination/name).chmod(0o444)
 for name in data['files']:
  if name.startswith('provenance/')or name.startswith('artifacts/B1.0_PREINTEGRATION'): (destination/name).chmod(0o444)
 db.chmod(0o444)
 report={'bundle_id':code['bundle_id'],'code_pack_sha256':sha(code_pack),'data_pack_sha256':sha(data_pack),
  'code_payload_files_checked':code_count,'data_payload_files_checked':data_count,
  'A_original_files_checked':a_count,'B_original_files_checked':b_count,
  'all_zip_CRCs_passed':True,'all_payload_SHA256_match':True,'originals_overwritten_with_differing_bytes':False,'original_source_files_and_archives_readonly':True,
  'destination':str(destination.resolve()),'scientific_external_validity':False}
 (destination/'ASSEMBLY_VERIFICATION.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False),flush=True);return report


def main():
 ap=argparse.ArgumentParser();ap.add_argument('--code-pack',type=Path,required=True);ap.add_argument('--data-pack',type=Path,required=True);ap.add_argument('--destination',type=Path,required=True);args=ap.parse_args()
 assemble(args.code_pack.resolve(),args.data_pack.resolve(),args.destination.resolve())

if __name__=='__main__':main()
