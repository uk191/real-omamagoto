#!/usr/bin/env python3
"""Actual coupled comparisons; retained trajectories explain every difference."""
import csv,gzip,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from integrated_b10 import Simulation
from integrated_b10.legacy import a18_engine_class
from child_b10.randomness import digest


def save(sim,path):
 with gzip.open(path,'wt',encoding='utf-8')as f:json.dump(sim.research_snapshot(),f,ensure_ascii=False,separators=(',',':'))


def main():
 out=ROOT/'results/examples';out.mkdir(exist_ok=True,parents=True);engine=a18_engine_class()();report={}
 common={'prefecture_code':'13','seed':'example-fixed-family','birth_date':'2026-10-01','engine':engine,
  'include_region':True,'conditions':{'mother_employed':True,'father_employed':True,'birth_rank':1}}
 children=[]
 for seed in [901,902,903]:
  s=Simulation.initialize(**common,child_seed=seed);s.run(24,stop_on_decision=False,research_continue=True)
  save(s,out/f'same_family_child_{seed}.json.gz');children.append(s)
 assert all(s.a==children[0].a for s in children)
 report['different_children_same_A']={'A24_states_identical':True,'A_months_identical':all([r['A_month']for r in s.records]==[r['A_month']for r in children[0].records]for s in children),
  'B_initial_dispositions':{str(s.configuration['B_seed']):s.child._state['initial_dispositions']for s in children},
  'milestones':{str(s.configuration['B_seed']):s.child._state['developmental_state']['milestones']for s in children},
  'mechanism':'only separate B random stream changes; no A state or contact-time response recalibration'}
 scenarios={}
 for access in ['available','unavailable']:
  s=Simulation.initialize(**common,child_seed=904,a_scenario={'return_plan_mode':'declared_month','return_month':2,'return_spread_months':0,'care_access_scenario':access})
  s.run(24,stop_on_decision=False,research_continue=True);scenarios[access]=s;save(s,out/f'same_child_care_{access}.json.gz')
 a,b=scenarios.values();report['same_child_different_A_scenarios']={
  'B_initial_dispositions_equal':a.child._state['initial_dispositions']==b.child._state['initial_dispositions'],
  'B_physical_equal':a.child._state['physical_health']==b.child._state['physical_health'],
  'B_latent_equal':a.child._state['latent_state']==b.child._state['latent_state'],
  'B_development_equal':a.child._state['developmental_state']==b.child._state['developmental_state'],
  'B_parent_observations_equal':a.child._state['parent_observations']==b.child._state['parent_observations'],
  'B_context_experience_equal':a.child._state['experience_memory']==b.child._state['experience_memory'],
  'A_enrolled_periods':{k:sum(r['A_month']['care']['status']=='enrolled'for r in s.records)for k,s in scenarios.items()},
  'observations':{k:len(s.child._state['parent_observations'])for k,s in scenarios.items()},
  'experience_memory':{k:s.child._state['experience_memory']for k,s in scenarios.items()},
  'causal_interpretation':False,
  'mechanism':'A care-access scenario -> A care/time -> observed opportunities and context labels -> assumed context memory; B biological/latent/developmental environment-effect coefficients OFF'}
 assert all(report['same_child_different_A_scenarios'][k]for k in ['B_initial_dispositions_equal','B_physical_equal','B_latent_equal','B_development_equal'])
 # Deliberate observation boundary, not typical Japanese relative care.
 gate_config={'relative_available_probability':1,'relative_hours':84}
 normal=Simulation.initialize(**common,child_seed=905,a_scenario=gate_config)
 gated=Simulation.initialize(**common,child_seed=905,a_scenario=gate_config)
 normal.step(research_continue=True)
 gated.step([{'type':'request_relative_support','id':'observation-boundary'}],research_continue=True)
 assert all(x['active_care']==0 for x in gated.records[0]['A_month']['time']['parents'].values())
 assert not gated.child._state['parent_observations'] and normal.child._state['parent_observations']
 assert normal.child._state['developmental_state']==gated.child._state['developmental_state']
 gate_out=out/'observation_gate';gate_out.mkdir(exist_ok=True)
 save(normal,gate_out/'parent_care_1month.json.gz');save(gated,gate_out/'relative_coverage_1month.json.gz')
 report['actual_A_action_to_B_observation_boundary']={
  'diagnostic_not_typical_family_scenario':True,'months':1,'A_action':gated.records[0]['requested_actions'],
  'A_decision':gated.records[0]['A_decisions'],'A_time':gated.records[0]['A_month']['time'],
  'baseline_parent_reports':len(normal.child._state['parent_observations']),
  'after_relative_coverage_parent_reports':len(gated.child._state['parent_observations']),
  'development_equal':True,'effect':'requested84h relative awake coverage -> actual A parent active care0 -> B opportunity0; no attachment or developmental effect'}
 report['representatives']=[]
 cases=[('single_parent','01',{'partner_present':False,'legal_status':'nonmarital'},{}),
  ('siblings','27',{'mother_age':32,'father_age':34,'birth_rank':3},{}),
  ('decision_pause','47',{'mother_employed':False,'father_employed':False},{'initial_cash_override':0,'auto_actions':False})]
 for name,pref,conditions,scenario in cases:
  s=Simulation.initialize(pref,seed='example-'+name,conditions=conditions,a_scenario=scenario,engine=engine)
  s.run(24,stop_on_decision=False,research_continue=True);save(s,out/f'{name}.json.gz')
  report['representatives'].append({'name':name,'prefecture':pref,'persons':len(s.a['persons']),
    'months':s.elapsed_months,'pending_periods':sum(bool(r['outstanding_A_decisions'])for r in s.records),
    'research_continuation_periods':sum(r['research_continued_unresolved_prior']for r in s.records),
    'final_snapshot_sha256':digest(s.research_snapshot())})
 reference=children[0]
 with (out/'representative_24months.csv').open('w',newline='')as f:
  writer=csv.writer(f);writer.writerow(['elapsed_months','as_of_date','household_id','child_id','cash_JPY','care_status','weight_kg_latent','length_cm_latent','new_milestones','mother_observations','A_events','A_decisions','pending_A_decisions'])
  for r in reference.records:
   ph=r['B_delta']['physical_health'];events=[e['kind']for e in r['events']if e['component']=='B']
   writer.writerow([r['elapsed_months'],r['end_exclusive'],r['household_id'],reference.identity['index_global_person_id'],r['A_month']['accounts']['cash'],r['A_month']['care']['status'],ph['weight_kg'],ph['length_cm'],','.join(events),len(r['B_parent_observations']['mother']['observations']),len(r['A_month']['events']),len(r['A_decisions']),len(r['outstanding_A_decisions'])])
 report['interpretation']='Functional paired research scenarios, not measured Japanese individual traits or identified interventions. All full A/B research histories retained; player API remains separate.'
 (out/'comparison_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False),flush=True)

if __name__=='__main__':main()
