import copy
import json
import subprocess
import sys
import tempfile
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from integrated_b10 import Simulation,IntegrationError,UnsupportedBirthScope
from integrated_b10.coordinator import DecisionRequired,b_seed
from integrated_b10.legacy import a18_engine_class
from child_b10.randomness import digest


class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.engine=a18_engine_class()()

    def start(self,seed='integration-test',**kwargs):
        return Simulation.initialize(seed=seed,engine=self.engine,include_region=kwargs.pop('include_region',False),**kwargs)

    def complete(self,s,months=24,actions=None):
        return s.run(months,actions,stop_on_decision=False,research_continue=True)

    def test_47_prefectures_real_generator_and_regions(self):
        for pref in range(1,48):
            sim=self.start(seed=f'47check/{pref}',prefecture_code=f'{pref:02d}',
                           birth_date=f'2026-{1+(pref-1)%12:02d}-01',include_region=True)
            self.assertEqual(sim.a['household']['prefecture_code'],f'{pref:02d}')
            self.assertIsNotNone(sim.a['region_context'])
            self.assertEqual(sim.a['initial_family']['birth_date'],sim.identity['birth_date'])
            sim.step(research_continue=True);self.assertTrue(sim.assert_consistent())

    def test_native_A_path_unchanged_and_rng_independent(self):
        actions={'0':[{'type':'set_spending','value':.8,'id':'budget-0'}],
                 '6':[{'type':'request_relative_support','id':'relative-6'}]}
        sim=self.start(seed='unchanged-A');native=copy.deepcopy(sim.a)
        for month in range(24):
            for _ in range(3):sim.player_view()
            native=self.engine.step(native,actions.get(str(month),[]),retain_journal=False)
            sim.step(actions.get(str(month),[]),research_continue=True)
        self.assertEqual(sim.a,native)
        self.assertNotEqual(sim.configuration['B_seed'],sim.configuration['master_seed'])

    def test_24_step_vs_run(self):
        a=self.start();b=self.start()
        for _ in range(24):a.step(research_continue=True)
        self.complete(b)
        self.assertEqual(a.research_snapshot(),b.research_snapshot())

    def test_12_save_restore_12_exact(self):
        actions={'0':[{'type':'set_spending','value':.8,'id':'budget-start'}],
                 '14':[{'type':'set_spending','value':1.1,'id':'budget-later'}]}
        full=self.complete(self.start(),actions=actions)
        half=self.complete(self.start(),12,actions)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'state.json';half.save(p);restored=Simulation.load(p,engine=self.engine)
        self.complete(restored,12,actions)
        self.assertEqual(full.research_snapshot(),restored.research_snapshot())

    def test_save_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'s';self.start().save(p);value=json.loads(p.read_text())
            value['payload']['B_state']['latent_state']['reactivity']=999;p.write_text(json.dumps(value))
            with self.assertRaises(IntegrationError):Simulation.load(p,engine=self.engine)

    def test_history_chain_edit_rejected(self):
        sim=self.complete(self.start(),2);s=sim.research_snapshot()
        s['records'][0]['environment']['context']='edited'
        with self.assertRaises(IntegrationError):Simulation.from_snapshot(s,engine=self.engine)
        s=sim.research_snapshot()
        index=next(p for p in s['A_state']['persons']if p['person_id']==s['identity']['index_local_person_id']);index['age_months']=999
        with self.assertRaises(IntegrationError):Simulation.from_snapshot(s,engine=self.engine)
        s=sim.research_snapshot();s['history'][-1]['kind']='edited'
        with self.assertRaises(IntegrationError):Simulation.from_snapshot(s,engine=self.engine)

    def test_actor_mapping_and_atomic_bad_action(self):
        sim=self.start();before=digest(sim.research_snapshot())
        with self.assertRaises(IntegrationError):sim.step([{'type':'quit','person':'another_family/mother'}])
        self.assertEqual(before,digest(sim.research_snapshot()))
        with self.assertRaises(IntegrationError):sim.step([{'type':'set_spending','person':sim.identity['index_global_person_id'],'value':.8}])
        self.assertEqual(before,digest(sim.research_snapshot()))
        with self.assertRaises(ValueError):sim.step([{'type':'quit','person':'mother','latent_state':999}])
        self.assertEqual(before,digest(sim.research_snapshot()))
        sim.step([{'type':'set_spending','person':sim.identity['person_links']['mother'],'value':.8}],research_continue=True)
        self.assertEqual(sim.records[0]['requested_actions'][0]['person'],'mother')

    def test_single_parent(self):
        sim=self.complete(self.start(seed='single',conditions={'partner_present':False,'legal_status':'nonmarital'}))
        self.assertEqual(sim.identity['caregiver_local_ids'],['mother'])
        with self.assertRaises(PermissionError):sim.player_view('father')
        self.assertTrue(sim.player_view('mother')['child_observations']['observations'])

    def test_siblings_roster_preserved(self):
        sim=self.start(seed='siblings',conditions={'mother_age':32,'father_age':34,'birth_rank':3})
        original=copy.deepcopy(sim.a['persons']);self.complete(sim)
        self.assertGreaterEqual(len(original),5)
        self.assertEqual({p['person_id'] for p in original},set(sim.identity['person_links']))
        self.assertEqual(sim.identity['birth_rank_interval'],[3,3])

    def test_term_missing_birth_fields_are_scenarios(self):
        sim=self.start()
        self.assertEqual(sim.configuration['birth_missingness']['A_gestation_days'],'unknown_not_in_A')
        self.assertIn('scenario',sim.configuration['birth_missingness']['generated_values'])
        self.assertEqual(sim.child._state['physical_health']['diagnoses'],[])

    def test_nonterm_and_partial_month_explicitly_unsupported(self):
        with self.assertRaises(UnsupportedBirthScope):self.start(birth_profile={'gestation_days':240,'evidence_kind':'observed_external'})
        with self.assertRaises(UnsupportedBirthScope):self.start(birth_date='2026-10-17')
        with self.assertRaises(IntegrationError):self.start(birth_profile={'gestation_days':280})

    def test_multiple_birth_unsupported_without_overwriting_A(self):
        family=self.engine.generator.generate('13',seed='twins',birth_date='2026-10-01',
            initialization={'multiplicity':2,'index_within_delivery':1},include_region=False)
        before=digest(family)
        with self.assertRaises(UnsupportedBirthScope):self.start(seed='twins',initial_family=family)
        self.assertEqual(before,digest(family))

    def test_missing_recorded_sex_not_randomly_imputed(self):
        sim=self.start();family=copy.deepcopy(sim.a['initial_family'])
        person=next(p for p in family['persons'] if p['person_id']=='index_child');person.pop('sex')
        with self.assertRaises(UnsupportedBirthScope):self.start(initial_family=family)

    def test_external_birth_measurement_only_informed_observer(self):
        sim=self.start(birth_profile={'gestation_days':280,'birth_weight_kg':2.2,
            'evidence_kind':'observed_external','known_by':['mother']})
        self.assertEqual(sim.player_view('mother')['child_observations']['measurements'][0]['value'],2.2)
        self.assertEqual(sim.player_view('father')['child_observations']['measurements'],[])
        self.assertEqual(sim.child._state['physical_health']['diagnoses'],[])

    def test_decision_pause_and_explicit_research_continuation(self):
        with self.assertRaises(IntegrationError):self.start().step(research_continue='false')
        sim=self.start(seed='pause',conditions={'mother_employed':False,'father_employed':False},
            a_scenario={'initial_cash_override':0,'auto_actions':False})
        sim.run(24);self.assertEqual(sim.status,'decision_required')
        self.assertGreater(sim.elapsed_months,0);self.assertLess(sim.elapsed_months,24)
        self.assertTrue(sim.records[-1]['outstanding_A_decisions'])
        self.assertTrue(all(not r['outstanding_A_decisions'] for r in sim.records[:-1]))
        with self.assertRaises(DecisionRequired):sim.step()
        sim.step(research_continue=True);self.assertTrue(sim.records[-1]['research_continued_unresolved_prior'])

    def test_separate_child_stream_same_family(self):
        a=self.complete(self.start(seed='shared-family',child_seed=101))
        b=self.complete(self.start(seed='shared-family',child_seed=102))
        self.assertEqual(a.a,b.a)
        self.assertNotEqual(a.child._state['initial_dispositions'],b.child._state['initial_dispositions'])
        self.assertNotEqual(a.identity['run_id'],b.identity['run_id'])

    def test_no_unverified_environment_effects(self):
        kw={'seed':'care-contrast','conditions':{'mother_employed':True,'father_employed':True}}
        common={'return_plan_mode':'declared_month','return_month':2,'return_spread_months':0}
        a=self.complete(self.start(**kw,a_scenario={**common,'care_access_scenario':'available'}))
        b=self.complete(self.start(**kw,a_scenario={**common,'care_access_scenario':'unavailable'}))
        self.assertEqual(a.child._state['latent_state'],b.child._state['latent_state'])
        self.assertEqual(a.child._state['physical_health'],b.child._state['physical_health'])
        self.assertEqual(a.child._state['developmental_state'],b.child._state['developmental_state'])
        self.assertEqual(a.child._state['emotion_regulation'],b.child._state['emotion_regulation'])
        self.assertEqual(a.child._state['caregiver_relationships'],b.child._state['caregiver_relationships'])
        self.assertNotEqual(a.child._state['experience_memory'],b.child._state['experience_memory'])
        self.assertTrue(any(r['A_month']['care']['status']=='enrolled' for r in a.records))
        self.assertFalse(any(r['A_month']['care']['status']=='enrolled' for r in b.records))

    def test_period_ages_ids_and_transactions(self):
        sim=self.complete(self.start(birth_date='2026-01-01'))
        ids=[r['id'] for r in sim.history];self.assertEqual(len(ids),len(set(ids)))
        for i,record in enumerate(sim.records,1):
            self.assertEqual(record['elapsed_months'],i);self.assertEqual(record['B_delta']['elapsed_months'],i)
            child=next(p for p in record['A_persons_asof'] if p['person_id']=='index_child')
            self.assertEqual(child['age_months'],i);self.assertTrue(record['A_transactions'])
            self.assertEqual(record['A_month']['ledger']['cash_identity_residual'],0)
            for event in record['events']:self.assertTrue(set(event['people'])<=set(sim.identity['person_links'].values()))

    def test_player_projection_has_no_internal_truth(self):
        unobserved=self.complete(self.start(observation_opportunity=0),1)
        self.assertEqual(unobserved.player_view()['child_observations']['observations'],[])
        kw={'seed':'actual-A-observation-gate','a_scenario':{'relative_available_probability':1,'relative_hours':84}}
        baseline=self.complete(self.start(**kw),1);gated=self.start(**kw)
        gated.step([{'type':'request_relative_support'}],research_continue=True)
        self.assertTrue(all(p['active_care']==0 for p in gated.records[0]['A_month']['time']['parents'].values()))
        self.assertTrue(baseline.player_view()['child_observations']['observations'])
        self.assertEqual(gated.player_view()['child_observations']['observations'],[])
        self.assertEqual(baseline.child._state['developmental_state'],gated.child._state['developmental_state'])

        sim=self.complete(self.start(),3);before=digest(sim.research_snapshot());view=sim.player_view()
        text=json.dumps(view)
        for key in ['latent_state','developmental_state','growth_z','initial_dispositions','B_seed','master_seed','familiarity','transition_parameters']:
            self.assertNotIn(key,text)
        view['household']['cash']=0;self.assertEqual(before,digest(sim.research_snapshot()))

    def test_scope_limit_atomic(self):
        sim=self.complete(self.start());before=digest(sim.research_snapshot())
        with self.assertRaises(IntegrationError):sim.step(research_continue=True)
        self.assertEqual(before,digest(sim.research_snapshot()))


class HTTPTests(unittest.TestCase):
    def test_player_only_HTTP(self):
        root=Path(__file__).resolve().parents[1]
        process=subprocess.Popen([sys.executable,'-m','integrated_b10.http_api','--port','0'],cwd=root,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        try:
            port=json.loads(process.stdout.readline())['port'];url=f'http://127.0.0.1:{port}'
            def call(path,body=None):
                request=urllib.request.Request(url+path,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json'})
                try:
                    with urllib.request.urlopen(request,timeout=60) as response:return response.status,json.load(response)
                except urllib.error.HTTPError as e:return e.code,json.load(e)
            self.assertEqual(call('/health')[0],200)
            status,result=call('/initialize',{'seed':'http-integration','include_region':False});self.assertEqual(status,200)
            sid=result['simulation_id'];self.assertEqual(call('/initialize',{'seed':'http-integration','include_region':False})[0],409)
            self.assertEqual(call('/step',{'simulation_id':sid,'observer':'stranger'})[0],403)
            self.assertEqual(call('/step',{'simulation_id':sid,'research_continue':'false'})[0],400)
            status,result=call('/simulate',{'simulation_id':sid,'months':24,'stop_on_decision':False,'research_continue':True})
            self.assertEqual(status,200);self.assertEqual(result['elapsed_months'],24)
            self.assertNotIn('B_state',result);self.assertNotIn('seed',json.dumps(result))
            self.assertEqual(call('/research',{'simulation_id':sid})[0],404)
            self.assertEqual(call('/save',{'simulation_id':sid})[0],404)
        finally:
            process.terminate();process.wait(timeout=15)
            process.stdout.close();process.stderr.close()


if __name__=='__main__':unittest.main()
