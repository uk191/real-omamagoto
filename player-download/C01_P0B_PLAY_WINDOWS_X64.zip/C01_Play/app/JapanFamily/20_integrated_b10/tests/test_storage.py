import sqlite3
import unittest
from integrated_b10 import Simulation
from integrated_b10.legacy import a18_engine_class
from integrated_b10.storage import connect,create_schema,insert_case,insert_period,restore_simulation


class CoupledStorageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine=a18_engine_class()();cls.db=connect(':memory:');create_schema(cls.db)
        cls.sim=Simulation.initialize(seed='coupled-storage',include_region=True,engine=cls.engine)
        cls.birth=cls.sim.research_snapshot();insert_case(cls.db,cls.sim,1)
        for _ in range(24):
            cls.sim.step(research_continue=True);insert_period(cls.db,cls.sim)
        cls.case=cls.sim.identity['run_id'];cls.db.commit()

    @classmethod
    def tearDownClass(cls):cls.db.close()

    def test_lossless_birth_12_24_and_resume(self):
        self.assertEqual(restore_simulation(self.db,self.case,0,engine=self.engine).research_snapshot(),self.birth)
        final=restore_simulation(self.db,self.case,24,engine=self.engine)
        self.assertEqual(final.research_snapshot(),self.sim.research_snapshot())
        middle=restore_simulation(self.db,self.case,12,engine=self.engine)
        middle.run(12,stop_on_decision=False,research_continue=True)
        self.assertEqual(middle.research_snapshot(),final.research_snapshot())

    def test_unknown_residence_not_converted_to_nonresident(self):
        sim=Simulation.initialize(seed='storage-unknown-residence',include_region=False,engine=self.engine,
            conditions={'partner_present':False,'legal_status':'nonmarital'})
        con=connect(':memory:');create_schema(con);insert_case(con,sim,1)
        from integrated_b10.storage import decode
        for normalized,blob in con.execute('SELECT co_resident,initial_person_zlib FROM integrated_person'):
            original=decode(blob)['co_resident']
            self.assertEqual(normalized,None if original is None else int(original))
        self.assertTrue(any(p['co_resident'] is None for p in sim.a['persons']))
        con.close()

    def test_missing_period_rejected(self):
        con=connect(':memory:');self.db.backup(con)
        con.execute('PRAGMA foreign_keys=OFF');con.execute('DELETE FROM integrated_period WHERE month=8')
        with self.assertRaises(ValueError):restore_simulation(con,self.case,12,engine=self.engine)
        con.close()

    def test_period_hash_edit_rejected(self):
        con=connect(':memory:');self.db.backup(con)
        con.execute("UPDATE integrated_period SET record_sha256='changed' WHERE month=1")
        with self.assertRaises(ValueError):restore_simulation(con,self.case,12,engine=self.engine)
        con.close()
