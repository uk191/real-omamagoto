# B-1.0 正式接続研究版

この工程は、原A-1〜A3.0-0.2とB1.0 PREINTEGRATIONを保全し、**実際の47県家庭生成器が生成した同一の出生児・家庭を24か月進行する接続層**を追加する。版は`B-1.0-integrated.1`。正式な接続とはソフトウェア統合の達成を指し、日本の家庭・子どもの全同時分布、心理尺度、医学、養育の因果効果の認証を意味しない。

元AとBのコード・原表・DB・検査はそれぞれ元の場所に保持する。新規コードはこのディレクトリ内のみ。新統合DBは旧A DBのコピーへ`integrated_*`テーブルを追加した別ファイルで、旧64テーブルは不変。元Bの1万人・25万状態DBも別資産として保持する。

## 実行

Python3.12（実行コアは標準ライブラリのみ）。このディレクトリを作業場所にする。統計分析・原表抽出・schema照合には`requirements-analysis.txt`のパッケージが必要。旧Aの一部検査には既存の依存パッケージを用いる。

```bash
python -m integrated_b10.cli --prefecture 13 --seed 42 --months 24 --research-continue --save /tmp/coupled.json > /tmp/parent_observations.json
python -m unittest discover -s tests -v
python -m integrated_b10.http_api --port 8088
```

`--research-continue`を省くとAの判断待ちで停止する。これは親へ判断を求める通常動作。大量研究試行は未解決判断を明示して継続し、実行した事実を毎月記録する。家計の不足が解決したことにはしない。

研究用Python例：

```python
from integrated_b10 import Simulation
s = Simulation.initialize('01', seed=42, birth_date='2026-10-01')
s.run(12, stop_on_decision=False, research_continue=True)
s.save('/tmp/research_checkpoint.json')
s = Simulation.load('/tmp/research_checkpoint.json')
s.run(12, stop_on_decision=False, research_continue=True)
parent_payload = s.player_view('mother')
```

`research_snapshot()`、保存JSON、SQLiteは内部研究データ。プレイヤーには`player_view()`またはHTTPの観測投影のみを渡す。ローカルHTTP試作に本番認証はない。A17/A18は汎用モジュール名が重なるため別プロセスで実行する。

## 対象範囲

2026年の各月1日生まれ、単胎、Bの在胎37〜41週参照シナリオ、出生〜24か月。単親・兄弟のあるA家庭を含むが、B個体モデルはindex出生児のみ。早産・過期産・多胎・月途中出生は明示的な未対応エラー。Aの出生児を別の児へ置き換えない。低出生体重の外部測定値を記録できるが、疾患リスクや医学的効果を外挿しない。

Aに在胎週数・出生体格の実測値がない場合、欠測の事実と、Bが生成する正期産病院参照シナリオを両方保存する。所得・学歴・親の在宅時間から先天的能力や愛着を決めない。Aの保育と時間は経験の文脈・観察機会へ接続するだけで、発達の未検証介入係数はOFF。

詳細は[接続仕様](docs/接続仕様.md)、[検証・再構築](docs/再構築と再検証.md)、[構築報告](docs/正式統合構築報告.md)、[未完了事項](data/backlog.json)を参照。
