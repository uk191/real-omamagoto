"""Population/conditional calibration diagnostics are separate from internal invariants.
No unobserved newborn financial joint is declared externally validated.
"""
import json,csv,gzip,collections,math,statistics,time,hashlib,sqlite3,sys
from pathlib import Path
from family import FamilyModel,Dist,rng,ConditionSupportError,VERSION,age5
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'validation'
def write(name,rows):
    rows=list(rows)
    if not rows:
        (OUT/name).unlink(missing_ok=True)
        return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with(OUT/name).open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def tv(actual,expected):
    aa=sum(actual.values());ee=sum(expected.values());keys=set(actual)|set(expected)
    return sum(abs(actual.get(k,0)/aa-expected.get(k,0)/ee)for k in keys)/2 if aa and ee else None
def moments(vals):
    finite=[v for v in vals if v is not None]
    if not finite:return {'n':len(vals),'missing_fraction':1}
    ss=sorted(finite);q=lambda p:ss[min(len(ss)-1,int(p*(len(ss)-1)))]
    return {'n':len(vals),'finite_n':len(finite),'missing_fraction':1-len(finite)/len(vals),'mean_finite':statistics.mean(finite),'variance_finite':statistics.pvariance(finite),'p10_finite':q(.1),'p25_finite':q(.25),'p50_finite':q(.5),'p75_finite':q(.75),'p90_finite':q(.9),'interpretation':'finite-bin game points only; tails and lowest negative asset band have no point; true mean/variance not identified'}
def main(n_per_pref=2300):
    m=FamilyModel();tests=[]
    def test(id,ok,detail,type='internal'):
        tests.append({'test_id':id,'status':'PASS'if ok else'FAIL','validation_type':type,'detail':detail});print(id,tests[-1]['status'],detail,flush=True)
    acquisitions=[json.loads(x)for x in(ROOT/'data/acquisition.jsonl').read_text().splitlines()];rawbad=[]
    for x in acquisitions:
        if x.get('status')=='downloaded'and hashlib.sha256((ROOT/'raw'/x['file']).read_bytes()).hexdigest()!=x['sha256']:rawbad.append(x['id'])
    test('raw_checksum',not rawbad,rawbad,'source_audit')
    c=sqlite3.connect(ROOT.parent/'data/region.sqlite');test('sqlite_integrity',c.execute('PRAGMA integrity_check').fetchone()[0]=='ok','full updated DB');test('sqlite_fk',not c.execute('PRAGMA foreign_key_check').fetchall(),'inherited FK relationships')
    # Prefecture and municipality childbirth totals: wards are aggregated once to their parent city.
    reconcile=[];pref_births={}
    for p in range(1,48):
        pref=f'{p:02d}';total=sum(x['weight']or 0 for x in m.g['birth_pref'][pref]if x['sex']=='all');municipal=sum(x['weight']or 0 for x in m.g['birth_municipal'][(pref,'総 数','all')]);pref_births[pref]=total;reconcile.append({'pref':pref,'birth_pref_2025':total,'municipal_disjoint_total_2025':municipal,'difference':municipal-total})
    write('birth_geography_reconciliation.csv',reconcile);test('birth_geography_47',all(x['difference']==0 for x in reconcile),{'max_difference':max(abs(x['difference'])for x in reconcile)},'source_audit')
    sexok=True
    for pref in pref_births:
        cc=collections.Counter()
        for x in m.g['birth_pref'][pref]:cc[(x['mother_label'],x['rank'],x['sex'])]+=x['weight']or 0
        sexok&=all(v==cc[(a,r,'male')]+cc[(a,r,'female')]for(a,r,s),v in cc.items()if s=='all')
    test('birth_sex_partition',sexok,'all=male+female in each prefecture/age/parity cell','source_audit')
    N=n_per_pref*47;failures=[];bad=collections.Counter();stats=[];cross=collections.Counter();municipal_counts=collections.defaultdict(collections.Counter);birth_counts=collections.defaultdict(collections.Counter);incomevals=[];rentvals=[];dispos=[];assets=[];sizes=[];nuclear_first_large=0;first=0;dispo_gt_gross=0;compare_finite=0;missing=collections.Counter();fallback=collections.Counter()
    csvpath=OUT/'generated_households_lite.csv.gz';start=time.monotonic()
    fields=['pref','seed','mother_age','father_age','parity_category','birth_rank','legal','partner_present','mother_employed','father_employed','mother_education','father_education','mother_occupation','father_occupation','gross_lo','gross_hi','gross_point','tenure','household_size','rent_lo','rent_hi','rent_point','disposable_lo','disposable_hi','disposable_point','net_assets_lo','net_assets_hi','net_assets_point','mortgage_any_property','municipality','attempts','co_grandparent','family_source_geo']
    with gzip.open(csvpath,'wt',encoding='utf-8',newline='')as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for p in range(1,48):
            pref=f'{p:02d}';t0=time.monotonic();p_income=[];p_rent=[];p_emp=collections.Counter();p_ten=collections.Counter();p_legal=collections.Counter();p_gp=collections.Counter()
            for i in range(n_per_pref):
                seed=f'audit/{pref}/{i}'
                try:o=m.generate(pref,seed=seed,include_region=False)
                except Exception as e:failures.append({'pref':pref,'seed':seed,'error':type(e).__name__+': '+str(e)});continue
                mo,fa=o['mother'],o['father'];ch=o['child'];hh=o['household_income'];h=o['housing'];fin=o['finances'];di=fin['disposable_income_OECD'];ai=fin['net_total_assets'];rr=h['monthly_rent']
                row={'pref':pref,'seed':seed,'mother_age':mo['age'],'father_age':fa['age']if fa else None,'parity_category':ch['birth_rank_category'],'birth_rank':ch['birth_rank'],'legal':o['legal_birth_status'],'partner_present':o['partner_present'],'mother_employed':mo['employed'],'father_employed':fa['employed']if fa else None,'mother_education':mo['education_coarse'],'father_education':fa['education_coarse']if fa else None,'mother_occupation':mo['occupation_code'],'father_occupation':fa['occupation_code']if fa else None,'gross_lo':hh['interval'][0],'gross_hi':hh['interval'][1],'gross_point':hh['value'],'tenure':h['tenure'],'household_size':h['household_size'],'rent_lo':rr['interval'][0],'rent_hi':rr['interval'][1],'rent_point':rr['value'],'disposable_lo':di['interval'][0],'disposable_hi':di['interval'][1],'disposable_point':di['value'],'net_assets_lo':ai['interval'][0],'net_assets_hi':ai['interval'][1],'net_assets_point':ai['value'],'mortgage_any_property':fin['mortgage_present_any_property'],'municipality':o['municipality_code'],'attempts':o['conditioning']['attempts'],'co_grandparent':o['family']['co_resident_grandparent'],'family_source_geo':o['source_trace'].get('regional_family_geo')};writer.writerow(row)
                if ch['age_years']!=0:bad['child_not_zero']+=1
                if o['municipality_code'][:2]!=pref:bad['geo_pref']+=1
                knownw=[x['main_job_income']['value']for x in[mo,fa]if x and x['main_job_income']['value']is not None]
                if hh['value']is not None and sum(knownw)>hh['value']+1:bad['parent_income_gt_household']+=1
                if h['tenure']=='owner'and rr['value']!=0:bad['owner_rent']+=1
                if h['household_size']is not None and h['household_size']<(3 if fa else 2):bad['household_members']+=1
                if not mo['employed']and mo['occupation_code']is not None:bad['unemployed_job']+=1
                incomevals.append(hh['value']);p_income.append(hh['value']);rentvals.append(rr['value']if h['tenure']!='owner'else None);p_rent.append(rr['value']if h['tenure']!='owner'else None);dispos.append(di['value']);assets.append(ai['value']);sizes.append(h['household_size']);p_emp[(mo['employed'],fa['employed']if fa else None)]+=1;p_ten[h['tenure']]+=1;p_legal[o['legal_birth_status']]+=1;p_gp[o['family']['co_resident_grandparent']]+=1
                maternal_label=next((x['mother_label']for x in m.g['birth_pref'][pref]if x['source']==o['source_trace']['birth_pref']),None)
                birth_counts[pref][(maternal_label,ch['birth_rank_category'])]+=1;municipal_counts[pref][o['municipality_code']]+=1;cross[(pref,mo['education_coarse'],fa['education_coarse']if fa else None,h['tenure'],str(hh['interval']),mo['employed'],fa['employed']if fa else None)]+=1
                if ch['birth_rank_category']==1:
                    first+=1
                    if h['household_size']is not None and h['household_size']>=4:nuclear_first_large+=1
                if di['value']is not None and hh['value']is not None:compare_finite+=1;dispo_gt_gross+=di['value']>hh['value']
                for key,val in[('gross',hh['value']),('rent',rr['value']),('net_assets',ai['value']),('disposable',di['value']),('household_size',h['household_size'])]:missing[key]+=val is None
                for key in['size_national_backoff','rent_national_backoff','age_backoff']:fallback[key]+=bool(h.get(key))
            stats.append({'pref':pref,'draws':sum(p_ten.values()),'seconds':time.monotonic()-t0,'gross':moments(p_income),'renters_rent':moments(p_rent),'employment_counts':str(dict(p_emp)),'tenure_counts':str(dict(p_ten)),'legal_counts':str(dict(p_legal)),'grandparent_proxy_counts':str(dict(p_gp))})
            print('pref',pref,'draws',sum(p_ten.values()),'elapsed',round(time.monotonic()-start,1),flush=True)
    test('108100_generation',not failures and sum(x['draws']for x in stats)==N,{'requested':N,'failed':len(failures)},'execution')
    test('internal_invariants',not bad,dict(bad),'internal')
    write('generation_failures.csv',failures);write('prefecture_summary.csv',stats);write('attribute_combinations.csv',[{'pref':x[0],'mother_education':x[1],'father_education':x[2],'tenure':x[3],'gross_interval':x[4],'mother_employed':x[5],'father_employed':x[6],'count':n}for x,n in cross.items()])
    diagnostics=[];maxz=0
    for p in pref_births:
        expected=collections.Counter()
        for x in m.g['birth_pref'][p]:
            if x['sex']=='all':expected[(x['mother_label'],x['rank'])]+=x['weight']or 0
        actual=birth_counts[p];total=sum(expected.values());nn=sum(actual.values());zmax=0
        for key,w in expected.items():
            prob=w/total;expected_n=nn*prob
            if expected_n>=5 and 0<prob<1:zmax=max(zmax,abs(actual[key]-expected_n)/math.sqrt(nn*prob*(1-prob)))
        maxz=max(maxz,zmax);mexpected=collections.Counter()
        for x in m.g['birth_municipal'][(p,'総 数','all')]:mexpected[x['code']]+=x['weight']or 0
        diagnostics.append({'pref':p,'birth_age_rank_TV':tv(actual,expected),'max_abs_z_expected5plus':zmax,'municipality_TV':tv(municipal_counts[p],mexpected),'validation_type':'calibration_to_observed_2025_birth_counts; not 2026 heldout'})
    write('birth_distribution_validation.csv',diagnostics);test('birth_age_parity_calibration',maxz<7,{'max_abs_z':maxz,'threshold':7},'calibration_to_training_observations')
    # Source conditional distributions: draw complete finance and housing-rent kernels independently.
    kc=[]
    for name,rows,key in[('finance',[x for x in m.k['finance']if x['family']=='014'],lambda x:(x['di'],x['asset'],x['mortgage'])),('rent_13_private_500to700',[x for x in m.k['rents']if x['geo']=='13000'and x['tenure']=='23'and x['income_interval']==[5000000,7000000]],lambda x:x['rent']),('couple_education_25to34',[x for x in m.k['couple_pairs']if x['age_interval']==[25,35]],lambda x:(x['fe'],x['me']))]:
        d=Dist(rows);ac=collections.Counter();ex=collections.Counter();rr=rng(20261014,name)
        for x in rows:ex[key(x)]+=x['weight']
        for _ in range(50000):ac[key(d.draw(rr))]+=1
        kc.append({'kernel':name,'draws':50000,'TV':tv(ac,ex),'validation_type':'implementation_calibration; not birth-family external fit'})
    write('conditional_kernel_validation.csv',kc);test('conditional_kernel_calibration',all(x['TV']<.08 for x in kc),kc,'implementation_calibration')
    cases=[('12',{}),('13',{'mother_age':32,'father_age':35,'birth_rank':2}),('13',{'household_income_yen':6000000,'mother_education':'4','father_education':'4'}),('47',{'partner_present':False,'household_income_yen':2500000}),('22',{'municipality_code':'22130','mother_occupation':'03'}),('01',{'household_income_yen':30000000,'father_education':'4'}),('13',{'mother_age':55}),('13',{'mother_age':14}),('13',{'father_age':75}),('07',{'municipality_code':'07546'}),('13',{'tenure':'private_rental'}),('40',{'mother_employed':False}),('32',{}),('37',{}),('27',{}),('14',{}),('45',{}),('47',{'municipality_code':'47382'}),('01',{'municipality_code':'01692'}),('12',{'municipality_code':'12217'})]
    examples=[];ct=[]
    for i,(p,h)in enumerate(cases):
        try:
            a=m.generate(p,h,f'example/{i}',include_region=True);b=m.generate(p,h,f'example/{i}',include_region=True)
            respected=m.matches(a,h)
            for who in ['mother','father']:
                if who+'_age'in h:respected&=a[who]is not None and a[who]['age']==h[who+'_age']
            if 'birth_rank'in h:respected&=a['child']['birth_rank']==h['birth_rank']
            if 'household_income_yen'in h:respected&=a['household_income']['value']==h['household_income_yen']
            if 'partner_present'in h:respected&=a['partner_present']is h['partner_present']
            if 'municipality_code'in h:respected&=a['municipality_code']==h['municipality_code']
            if 'legal_status'in h:respected&=a['legal_birth_status']==h['legal_status']
            ct.append({'case':i,'status':'PASS'if a==b and respected else'FAIL','condition':json.dumps(h,ensure_ascii=False),'fixed_conditions_respected':respected,'same_seed_reproduces':a==b,'note':'all requested fields checked; unidentified conditions stay unresolved'});examples.append(a)
        except Exception as e:ct.append({'case':i,'status':'UNRESOLVED','condition':json.dumps(h,ensure_ascii=False),'note':str(e)})
    (OUT/'examples.json').write_text(json.dumps(examples,ensure_ascii=False,indent=2));write('condition_tests.csv',ct);test('seed_reproducibility',all(x['status']!='FAIL'for x in ct),{'examples':len(examples),'unresolved':sum(x['status']=='UNRESOLVED'for x in ct)},'internal')
    invalid=[('99',{}),('12',{'mother_age':-1}),('12',{'birth_rank':0}),('12',{'unknown':3}),('12',{'partner_present':False,'father_employed':True}),('12',{'municipality_code':'13101'})];rejected=0
    for p,h in invalid:
        try:m.generate(p,h,include_region=False,max_attempts=10)
        except(ValueError,ConditionSupportError):rejected+=1
    test('invalid_conditions_rejected',rejected==len(invalid),rejected,'internal')
    summary={'model_version':VERSION,'requested_households':N,'generated_households':N-len(failures),'generation_failures':len(failures),'seconds':time.monotonic()-start,'internal_violations':dict(bad),'birth_max_abs_z':maxz,'gross_finite_points':moments(incomevals),'rent_finite_points':moments(rentvals),'disposable_finite_points':moments(dispos),'net_assets_finite_points':moments(assets),'household_sizes':moments(sizes),'null_points':dict(missing),'fallback_counts':dict(fallback),'first_birth_household_size4plus_proxy_fraction':nuclear_first_large/first if first else None,'disposable_gt_gross_reference_fraction':dispo_gt_gross/compare_finite if compare_finite else None,'financial_joint_not_validated':True,'full_newborn_joint_not_validated':True,'birth2026_not_observed':True,'generation_csv_sha256':hashlib.sha256(csvpath.read_bytes()).hexdigest(),'examples':len(examples),'tests_pass':sum(x['status']=='PASS'for x in tests),'tests_fail':sum(x['status']=='FAIL'for x in tests)}
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));write('tests.csv',tests);c.close();print(json.dumps(summary,ensure_ascii=False),flush=True)
if __name__=='__main__':main(int(sys.argv[1])if len(sys.argv)>1 else 2300)
