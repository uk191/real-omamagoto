# A-1.5 / A-2 家庭生成API（A2-0.4）

47都道府県で、基準児を0歳として出生家庭の参考属性を確率生成する研究実装です。2025年の出生構造、2022年の就業・通常収入、2023年の住宅・家賃、2024年の可処分所得・純資産の原表を接続しています。**2026年にこれら全てを観測したデータではありません。家庭の完全な同時分布・出生当日の家計・育休・兄弟年齢は未完成です。**

生成のみならPython標準ライブラリで動きます。検証環境はPython 3.12.14。原表の再変換にはルートの `requirements_A2.txt` を使います。SQLite DBと `data/kernels.json.gz` は同梱済みです。DBを他の場所へ移す場合は `FamilyModel(db=..., cache=...)` を使用します。

## Python

プロジェクトのルート `JapanFamily` から実行します。

```python
import sys
sys.path.insert(0, "13_family")
from family import FamilyModel

model = FamilyModel()
household = model.generate(
    "13",  # 都道府県01〜47
    conditions={"mother_age": 32, "father_age": 35,
                "household_income_yen": 6_000_000},
    seed="example-1", year=2026, include_region=True,
)
batch = model.generate_batch("12", 1000, seed="batch-1",
                             include_region=False)
```

```bash
python 13_family/family.py --pref 13 --seed 42 --conditions '{"mother_age":32,"father_age":35,"household_income_yen":6000000}'
python 13_family/api.py --port 8765
```

HTTPは `127.0.0.1:8765` に限定します。`GET /health`、`POST /generate`、`POST /generate-batch`。生成リクエストはJSONオブジェクトです。

```json
{"prefecture_code":"13","year":2026,"seed":"demo",
 "include_region":true,
 "conditions":{"mother_age":32,"father_age":35,
               "mother_education":"4","household_income_yen":6000000}}
```

一括生成は同じ構造に `"n":100` を加えます（1〜1000）。全県の検証はHTTPの上限に依存せず、Python APIで行っています。入力の形式・県・年が不正なら400。公表原表の条件付き支持が確認できない、又は試行上限に達した場合は422です。条件を勝手に書き換えません。422は現実に不可能との判定ではありません。

## 固定条件

| 条件名 | 値・意味 |
|---|---|
| `mother_age`, `father_age` | 整数の満年齢。原表でその各歳が観測できる範囲。合併・開放階級内の正確な年齢は未識別として422 |
| `birth_rank` | 1〜9の整数。10子以上は原表でまとめられるため、正確な10・11等への固定は未識別。無条件生成では10+区間を保持 |
| `legal_status` | `marital` / `nonmarital`。出生の婚内区分。パートナー同居とは別 |
| `partner_present` | 真偽値。未指定では婚内true（仮定）、非婚内NULL。非婚内=単親とは確定しない |
| `mother_education`, `father_education` | `"1"` 小中、`"2"` 高校、`"3"` 専門・短大・高専、`"4"` 大学・大学院、`"unknown"` 在学・不詳の集約 |
| `mother_occupation`, `father_occupation` | 職業大分類 `"01"`〜`"12"`。原表のラベルを出力にも保持 |
| `mother_employed`, `father_employed` | 真偽値。参考年の有業状態。出生当日の実働・育休状態ではない |
| `household_income_yen` | 非負整数。2022年通常税込世帯収入の原表階級を条件化し、点値はユーザー指定。正確な金額の人口密度を観測した意味ではない |
| `mother_income_yen`, `father_income_yen` | 非負整数。2022参考年の主仕事税込年間収入・収益を原表階級に条件化し、指定点を保持。総個人所得・出生月の現金収入とは別 |
| `tenure` | `owner`、`public_rental`、`UR_or_public_corporation`、`private_rental`、`employer_housing` |
| `municipality_code` | 5桁行政コード。政令市は市のコード、東京は23特別区それぞれ。浜松市は `22130` |

母子の年齢差、学歴や職業の因果効果を推定したモデルではありません。入力条件を固定すると、その条件に合う観測階級・推定接合の中で他属性を再抽選します。希少な条件の支持が観測できないとき、確率を捏造して通しません。

## 出力の読み方

金額は `{value, interval, kind}`。上端・下端が開く階級は点値NULLを保持します。有限階級内の点は原表の個票ではなく、階級内一様抽選又は親所得合計を世帯所得以下に収める配分の**ゲーム上の仮定**です。未知の残高・税・兄弟年齢はNULLです。持ち家の家賃0は住宅ローン返済0を意味しません。

`finances.net_total_assets` は純金融資産と住宅宅地評価額の合計です。現金・預貯金ではありません。最下位階級に負値が含まれるため、下限と点値を未確定として保持します。`mortgage_present_any_property` は現住居以外の物件も含む負債の有無です。借家世帯でもあり得ます。

所得・家賃・資産の異年・異定義接合は `reference_year`、`source_trace`、`assumptions` で示します。`quality.financially_playable` と `quality.newborn_full_joint_externally_validated` はfalseです。総所得と可処分所得の差で税負担を計算しないでください。

年齢0の基準児は出生児単位です。複産では同じ出産家庭に出生児数分の重みが掛かります。年間の重複しない出産世帯単位へ直す機能は未実装です。出生順位は母が過去に生んだ出生児の累積順位であり、現在同居する兄弟の人数ではありません。

## 再実行

```bash
pip install -r requirements_A2.txt
# 同梱原表を使いA2統計核とDBの追加表を再構築
python run_family_pipeline.py
# A1回帰、108100家庭生成、外部比較、HTTP・リリース検証、統合報告再生成
python run_family_pipeline.py --validate
# A1を原表から再構築した後、A2を追加（時間が掛かります）
python run_family_pipeline.py --rebuild-a1 --validate
# 公開URLを再取得する場合（データ改訂時は新モデル版として管理）
python run_family_pipeline.py --refresh --validate
```

元の `run_pipeline.py` はA1再構築のため維持しています。それだけを実行するとDBはA1版に戻るため、A2を使う場合は統合入口 `run_family_pipeline.py` を実行します。追加表は別DBで構築して整合性検査後に置換します。取得済み原表だけでオフライン再変換できます。

同じseedと、同梱された同じモデル版・統計核で再現します。乱数の成分系列をSHA256で分け、Pythonの実行時hashには依存しません。モデル版、コード、原表、統計核はリリースのSHA256台帳に固定しています。原表を更新した再構築は同じ統計モデル版として扱わないでください。

`validation/` に最終108100試行の圧縮CSV、11項目の検証表、県別分散・分位点、複合属性、別年・別対象比較、17生成事例と3未識別条件、HTTP検証ケースを保存しています。A1の22回帰項目と235キャッシュ比較はルートの `10_validation/`。主な未完成項目と634候補全体の継続優先度は `data/backlog.csv` です。

`release_checks.py` は別プロセスのseed再現、台帳保持、全観測行のSHAを確認します。受領時の原DBがある場合は原DBから再計算し、配布ZIP単体では保存済みの原DB全行指紋 `data/A1_observation_baseline.json` と比較します。原634候補の全列比較用CSVも同梱しています。リリース検査の成功は、出生家庭の完全な外部適合を意味しません。
