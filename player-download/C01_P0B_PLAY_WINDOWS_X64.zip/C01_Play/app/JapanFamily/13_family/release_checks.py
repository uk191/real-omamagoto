"""Independent release checks, preserving the original catalogue and observation rows."""
import csv,json,gzip,sqlite3,hashlib,subprocess,sys,ast,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent;P=ROOT.parent;OUT=ROOT/'validation'
def readcsv(path):return list(csv.DictReader(path.open(encoding='utf-8-sig')))
def fingerprint(path):
    c=sqlite3.connect(path);h=hashlib.sha256();n=0
    for row in c.execute('SELECT * FROM observation ORDER BY rowid'):
        h.update(repr(row).encode('utf-8'));h.update(b'\n');n+=1
    c.close();return {'rows':n,'canonical_observation_sha256':h.hexdigest()}
def main():
    summary=json.loads((OUT/'summary.json').read_text());tests=[]
    def check(name,ok,detail):tests.append({'test':name,'pass':bool(ok),'detail':detail});print(name,bool(ok),flush=True)
    original=readcsv(ROOT/'data/A1_candidate_baseline.csv');current=readcsv(P/'04_variables.csv');byid={x['variable_id']:x for x in current}
    check('original634_all_fields_preserved',len(original)==len(current)==634 and all(all(byid[x['variable_id']].get(k)==v for k,v in x.items())for x in original),'Original columns and IDs unchanged; A2 fields added separately')
    expanded=readcsv(ROOT/'data/expanded_variable_catalogue.csv');ids=[x['variable_id']for x in expanded]
    check('expanded690_unique_ids',len(expanded)==690 and len(ids)==len(set(ids)),len(expanded))
    sample=collections.Counter();canonical=hashlib.sha256();bounds_bad=0
    with gzip.open(OUT/'generated_households_lite.csv.gz','rt',encoding='utf-8',newline='')as f:
        for row in csv.DictReader(f):
            sample[row['pref']]+=1;canonical.update(json.dumps(row,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode());canonical.update(b'\n')
            for field in ['gross','rent','disposable','net_assets']:
                point=row[field+'_point'];lo=row[field+'_lo'];hi=row[field+'_hi']
                if not point:continue
                val=float(point)
                if lo and val<float(lo):bounds_bad+=1
                if hi and float(hi)!=float(lo or 'nan')and val>=float(hi):bounds_bad+=1
    check('108100_csv_47x2300',sum(sample.values())==108100 and len(sample)==47 and set(sample.values())=={2300},dict(sample))
    check('finite_points_inside_published_intervals',bounds_bad==0,bounds_bad)
    check('summary_matches_sample_and_no_failures',summary['generated_households']==sum(sample.values())and summary['generation_failures']==0 and summary['tests_fail']==0,summary['tests_pass'])
    check('csv_compressed_checksum',hashlib.sha256((OUT/'generated_households_lite.csv.gz').read_bytes()).hexdigest()==summary['generation_csv_sha256'],'Archive checksum recorded alongside model/seed')
    original_db=P.parent/'inputs/region_original.sqlite'
    baseline=fingerprint(original_db) if original_db.exists() else json.loads((ROOT/'data/A1_observation_baseline.json').read_text())
    updated=fingerprint(P/'data/region.sqlite');check('all_A1_observations_unchanged',baseline==updated,{'original':baseline,'updated':updated,'baseline_mode':'original_DB_recomputed' if original_db.exists() else 'frozen_original_fingerprint'})
    c=sqlite3.connect(P/'data/region.sqlite');check('final_DB_integrity',c.execute('PRAGMA integrity_check').fetchall()==[('ok',)],'full integrated database');check('final_DB_foreign_keys',not c.execute('PRAGMA foreign_key_check').fetchall(),'No orphans');c.close()
    hashes=[]
    for _ in range(2):
        result=subprocess.run([sys.executable,str(ROOT/'family.py'),'--pref','13','--seed','release-reload','--no-region'],check=True,capture_output=True,text=True)
        hashes.append(hashlib.sha256(result.stdout.encode()).hexdigest())
    check('independent_process_seed_reproducibility',hashes[0]==hashes[1],hashes)
    moments=[]
    for row in readcsv(OUT/'prefecture_summary.csv'):
        for variable in ['gross','renters_rent']:moments.append({'pref':row['pref'],'variable':variable,**ast.literal_eval(row[variable])})
    keys=list(dict.fromkeys(k for r in moments for k in r))
    with(OUT/'prefecture_moments.csv').open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(moments)
    report={'model_version':summary['model_version'],'tests':tests,'all_pass':all(x['pass']for x in tests),'generated_payload_sha256':canonical.hexdigest(),'note':'Release/internal tests, not proof of an externally verified newborn financial joint'}
    (OUT/'release_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));assert report['all_pass']
if __name__=='__main__':main()
