"""Install a complete kernel snapshot atomically; verify before replacing the database.
Never rebuild inherited A1 tables. Optional --base accepts an audited original DB.
"""
import sqlite3,json,gzip,shutil,sys,os
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def install(base=None):
    destination=ROOT.parent/'data/region.sqlite';source=Path(base)if base else destination
    temporary=destination.with_suffix('.building.sqlite')
    shutil.copyfile(source,temporary)
    with gzip.open(ROOT/'data/kernels.json.gz','rt')as f:k=json.load(f)
    c=sqlite3.connect(temporary)
    if c.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('Base database failed integrity check')
    c.executescript('CREATE TABLE IF NOT EXISTS family_stat_cell(kernel TEXT,cell_index INTEGER,dimensions_json TEXT,weight REAL,kind TEXT,source_locator_json TEXT,PRIMARY KEY(kernel,cell_index));CREATE TABLE IF NOT EXISTS family_model_manifest(model_version TEXT PRIMARY KEY,manifest_json TEXT);CREATE TABLE IF NOT EXISTS family_generation(run_id TEXT PRIMARY KEY,model_version TEXT,seed TEXT,pref_code TEXT,constraints_json TEXT,household_json TEXT);')
    c.execute('DELETE FROM family_stat_cell')
    for name,rows in k.items():
        if name=='audit'or not isinstance(rows,list):continue
        for start in range(0,len(rows),2000):
            part=rows[start:start+2000]
            c.executemany('INSERT INTO family_stat_cell VALUES(?,?,?,?,?,?)',[(name,start+i,json.dumps({x:y for x,y in row.items()if x not in('weight','source')},ensure_ascii=False),row.get('weight'),'administrative_crosswalk'if name=='region_family_mapping'else('processed_observed'if row.get('source',{}).get('method')else'observed'),json.dumps(row.get('source'),ensure_ascii=False))for i,row in enumerate(part)])
        print(name,len(rows),flush=True)
    c.execute('INSERT OR REPLACE INTO family_model_manifest VALUES(?,?)',(k['version'],json.dumps({'basis_years':{'birth':2025,'work':2022,'housing':2023,'finance':2024},'unobserved_joint':'assumptions; not validated newborn microdistribution'},ensure_ascii=False)))
    c.commit()
    checks=c.execute('PRAGMA integrity_check').fetchall()
    if checks!=[('ok',)]:raise RuntimeError(str(checks[:10]))
    print('verified_cells',c.execute('SELECT count(*) FROM family_stat_cell').fetchone()[0],flush=True);c.close()
    with temporary.open('rb')as f:os.fsync(f.fileno())
    temporary.replace(destination)
if __name__=='__main__':install(sys.argv[1]if len(sys.argv)>1 else None)
