from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import json,threading,argparse
from family import FamilyModel,ConditionSupportError,VERSION
local=threading.local()
def model():
    if not hasattr(local,'model'):local.model=FamilyModel()
    return local.model
class Handler(BaseHTTPRequestHandler):
    def reply(self,status,data):
        b=json.dumps(data,ensure_ascii=False).encode();self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):self.reply(200 if self.path=='/health'else 404,{'version':VERSION,'status':'research_generator','fully_calibrated':False})
    def do_POST(self):
        if self.path not in('/generate','/generate-batch'):return self.reply(404,{'error':'unknown_route'})
        try:
            size=int(self.headers.get('Content-Length',0))
            if size>100000:return self.reply(413,{'error':'request_too_large'})
            q=json.loads(self.rfile.read(size))
            if not isinstance(q,dict):raise ValueError('JSON object required')
            if q.get('year',2026)!=2026:raise ValueError('requested year 2026 only')
            m=model();args={'conditions':q.get('conditions',{}),'seed':q.get('seed',0),'include_region':q.get('include_region',True)}
            if self.path=='/generate':o=m.generate(q['prefecture_code'],year=q.get('year',2026),**args)
            else:
                n=int(q.get('n',1))
                if not 1<=n<=1000:raise ValueError('n=1..1000')
                o=m.generate_batch(q['prefecture_code'],n,**args)
            self.reply(200,o)
        except ConditionSupportError as e:self.reply(422,{'error':'unresolved_conditional_support','message':str(e),'conditions_overridden':False})
        except(ValueError,KeyError,TypeError)as e:self.reply(400,{'error':'invalid_request','message':str(e)})
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);a=p.parse_args();ThreadingHTTPServer(('127.0.0.1',a.port),Handler).serve_forever()
