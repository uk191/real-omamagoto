import json,csv,collections
from pathlib import Path
from family import FamilyModel
from validate import tv,write
ROOT=Path(__file__).resolve().parent
def main():
    m=FamilyModel();out=[]
    for p in range(1,48):
        pref=f'{p:02d}';birth=collections.Counter()
        for x in m.g['birth_municipal'][(pref,'総 数','all')]:birth[x['code']]+=x['weight']or 0
        for frame in['child_under18','child_under6','resident']:
            d=m.region.distribution(pref,frame);old={x['code']:x['weight']for x in d['rows']}
            out.append({'pref':pref,'A1_frame':frame,'A1_reference_year':2025 if frame=='resident'else 2020,'birth_reference_year':2025,'municipality_share_TV':tv(old,birth),'positive_birth_municipalities':sum(v>0 for v in birth.values()),'positive_A1_frame_municipalities':len(old),'birth_positive_A1_absent':';'.join(co for co,w in birth.items()if w>0 and co not in old),'interpretation':'different sampling units and years; household stocks do not identify birth-event household probabilities'})
    write('A1_stock_vs_birth_region.csv',out);print('comparisons',len(out))
if __name__=='__main__':main()
