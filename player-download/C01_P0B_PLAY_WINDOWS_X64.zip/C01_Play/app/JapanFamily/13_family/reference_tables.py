"""Rebuild separately scoped reference summaries; never turn their means into raw families."""
import json
from tables import ROOT,cells,code
from catalogue import csvwrite
def main():
    for name in ['finance_3-32-1','finance_7-91','finance_7-101-1']:
        rows=[]
        for d,v,s,m,u in cells(name):
            if code(d.get('地域_2024',''))!='00000':continue
            if name=='finance_3-32-1'and code(d.get('所得構成',''))!='0':continue
            rows.append({'dimensions':d,'value':v,'source':s,'measure':m,'unit':u})
        (ROOT/'data'/(name+'_reference_cells.json')).write_text(json.dumps(rows,ensure_ascii=False));print(name,len(rows),flush=True)
    budget=[]
    for d,v,s,m,u in cells('finance_1-10'):
        if code(d.get('世帯類型',''))!='11211'or code(d.get('世帯区分',''))!='0':continue
        budget.append({'family':d['世帯類型'],'survey_year':2024,'budget_item':d['収支項目分類'],'measure':m,'value':v,'unit':u,'source_cell':json.dumps(s,ensure_ascii=False),'individual_generation':'not_implemented; conditional means are not household-level joint distributions'})
    csvwrite(ROOT/'data/young_child_budget_reference.csv',budget)
if __name__=='__main__':main()
