"""Exercise actual HTTP routes in one network namespace, including input rejection."""
import threading,json,urllib.request,urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer
from api import Handler
def main():
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler);threading.Thread(target=server.serve_forever,daemon=True).start();url=f'http://127.0.0.1:{server.server_port}';out=Path(__file__).resolve().parent/'validation';tests=[]
    def call(route,q):
        req=urllib.request.Request(url+route,data=json.dumps(q).encode()if q is not None else None,headers={'Content-Type':'application/json'})
        try:
            with urllib.request.urlopen(req)as r:return r.status,json.load(r)
        except urllib.error.HTTPError as e:return e.code,json.load(e)
    cases=[('/health',None,200),('/generate',{'prefecture_code':'13','seed':'personal-income','include_region':False,'conditions':{'mother_income_yen':1600000,'father_income_yen':3500000,'household_income_yen':6000000}},200),('/generate',{'prefecture_code':'12','conditions':{'partner_present':False,'father_age':35}},400),('/generate',[],400),('/generate-batch',{'prefecture_code':'12','n':1,'year':2030},400),('/generate',{'prefecture_code':'13','conditions':{'mother_age':55}},422),('/generate',{'prefecture_code':'13','seed':'api','include_region':True,'conditions':{'mother_age':32,'father_age':35,'household_income_yen':6000000}},200),('/generate-batch',{'prefecture_code':'47','n':3,'seed':'api','include_region':False},200),('/generate',{'prefecture_code':'99'},400),('/generate-batch',{'prefecture_code':'12','n':1001},400)]
    for route,q,expected in cases:
        status,data=call(route,q);ok=status==expected
        if q and q.get('seed')=='api':(out/('api_batch.json'if isinstance(data,list)else'api_example.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
        if route=='/generate'and status==200 and q.get('seed')=='api':ok&=data['household_income']['value']==6000000 and data['mother']['age']==32 and data['father']['age']==35
        if q and q.get('seed')=='personal-income':
            ok&=data['mother']['main_job_income']['value']==1600000 and data['father']['main_job_income']['value']==3500000 and data['household_income']['value']==6000000
            (out/'api_parent_income_example.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
        tests.append({'route':route,'request':q,'status':status,'expected':expected,'pass':ok})
    server.shutdown();(out/'api_tests.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2));print(tests);assert all(x['pass']for x in tests)
if __name__=='__main__':main()
