"""Full-output diagnostics against separate-year/domain observations.
Distances are findings, never evidence of a verified newborn full joint.
"""
import csv,json,gzip,collections,math
from pathlib import Path
from family import FamilyModel,age_match
from validate import tv,write
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'validation'
def weighted_quantile(values,p):
    z=sorted((v,w)for v,w in values if v is not None);total=sum(w for v,w in z);s=0
    for v,w in z:
        s+=w
        if s>=p*total:return v
def essband(i):
    lo,hi=i
    if lo is None:return'unknown'
    if lo<10000000:return f'{int(lo)//1000000+1:02d}'
    if lo<12500000:return'11'
    if lo<15000000:return'12'
    if lo<20000000:return'13'
    return'14'
def main():
    m=FamilyModel();pref_tot={p:sum(x['weight']or 0 for x in rows if x['sex']=='all')for p,rows in m.g['birth_pref'].items()};rawrows=list(csv.DictReader(gzip.open(OUT/'generated_households_lite.csv.gz','rt')));ns=collections.Counter(x['pref']for x in rawrows)
    actual=collections.defaultdict(collections.Counter);proxy=collections.Counter();mother=collections.Counter();father=collections.Counter();dispo=[];asset=[];earner=[];proxycount=0
    for x in rawrows:
        p=x['pref'];w=pref_tot[p]/ns[p];a=int(x['mother_age'])if x['mother_age']else None
        if a is not None:mother[a]+=w
        if x['father_age']:father[int(x['father_age'])]+=w
        for key,values in [('disposable_point',dispo),('net_assets_point',asset)]:values.append((float(x[key])if x[key]else None,w))
        if x['family_source_geo']:
            ag='1'if a is not None and a<30 else(str((a-30)//10+2)if a is not None and a<70 else'seven'if a is not None else'0')
            ag='6'if ag=='seven'else ag
            emp='1'if x['mother_employed']==x['father_employed']=='True'else('2'if x['father_employed']=='True'else('3'if x['mother_employed']=='True'else'4'))
            inc=essband([float(x['gross_lo'])if x['gross_lo']else None,float(x['gross_hi'])if x['gross_hi']else None]);gp=x['co_grandparent']=='True';actual[(x['family_source_geo'],ag)][(gp,inc,emp)]+=1
        if x['parity_category']=='1'and x['partner_present']=='True'and x['co_grandparent']=='False'and x['household_size']=='3':
            inc=essband([float(x['gross_lo'])if x['gross_lo']else None,float(x['gross_hi'])if x['gross_hi']else None]);proxy[inc]+=w;proxycount+=1
    conditional=[]
    for(g,a),counts in actual.items():
        expected=collections.Counter()
        for x in m.g['family_regional'][g]:
            if x['a']==a:expected[(x['grandparent'],x['income'],x['employment'])]+=x['weight']
        conditional.append({'ESS_geo':g,'mother_age_category':a,'draws':sum(counts.values()),'full_generated_income_employment_grandparent_TV':tv(counts,expected),'status':'DIAGNOSTIC; national finer age distribution + newborn ages + feasible wage selection differ from coarse-age stock; not equality assertion'})
    write('full_output_conditional_fit.csv',conditional)
    reference=json.loads((ROOT/'data/finance_3-32-1_reference_cells.json').read_text());incomeexpected=collections.Counter();rawmean=None
    for x in reference:
        d=x['dimensions']
        if not d.get('世帯類型','').startswith('11211_')or x['measure']!='世帯数分布':continue
        ic=d['年間収入階級'];co=ic.split('_')[0]
        if co=='00'or co.startswith('R'):continue
        label=ic.split('_')[1];num=label.split('~')[0].split('万')[0]
        if not num.isdigit():continue
        incomeexpected[essband([0 if co=='01'else int(num)*10000,None])]+=x['value']or 0
    youngdiag={'reference_table':'finance_3-32-1','reference_year':2024,'reference_domain':'couple + one unmarried child age <=2, current resident child; not birth rank1','generated_proxy_domain':'rank1, partner present, no co-grandparent, size3; resident kinship not independently identified','generated_proxy_unweighted_n':proxycount,'gross_income_broad_category_TV':tv(proxy,incomeexpected),'interpretation':'separate source/year approximate-domain comparison. 2022 nominal gross vs2024: price correction not applied. Not an external PASS; mismatch cannot identify a unique correction.'}
    (OUT/'young_child_income_external.json').write_text(json.dumps(youngdiag,ensure_ascii=False,indent=2))
    qrefs=[]
    for name,values,classification in [('finance_7-91',dispo,'所得構成'),('finance_7-101-1',asset,'資産・負債の種類')]:
        rs=json.loads((ROOT/'data'/(name+'_reference_cells.json')).read_text())
        target='1_'if name=='finance_7-91'else'4_'
        measures={'第1・十分位数':.1,'第1・四分位数':.25,'中位数':.5,'第3・四分位数':.75,'第9・十分位数':.9}
        for x in rs:
            d=x['dimensions'];measure=x['measure']
            if not d.get('世帯類型','').startswith('014_')or not d.get('住宅ローン残高の有無','').startswith('0_')or not d.get(classification,'').startswith(target)or measure not in measures:continue
            raw=x['value'];yen=raw*1000 if raw is not None and x['unit']=='千円'else raw
            qrefs.append({'source_table':name,'reference_year':2024,'measure':measure,'actual_reference_yen':yen,'generated_weighted_finite_point_quantile':weighted_quantile(values,measures[measure]),'source_cell':json.dumps(x['source'],ensure_ascii=False),'interpretation':'014 contains children of broader ages; generated newborn proxy + regional transport. Generated quantile conditional on finite bins; negative/open assets omitted. Not exact-domain validation; no tax identity inferred.'})
    write('external_quantile_comparison.csv',qrefs)
    old=collections.Counter();new=collections.Counter()
    for name,counter in [('birth_father_2024',old),('birth_father',new)]:
        for x in m.k[name]:
            s=x['mother_label'];co=s.replace('歳','')
            if co.isdigit():counter[int(co)]+=x['weight']or 0
    bdiag={'mother_age_TV_marital_2024_vs2025_observed':tv(old,new),'generated_weighted_mother_vs2024_marital_approx_TV':tv(mother,old),'generated_weighted_mother_vs2025_marital_approx_TV':tv(mother,new),'note':'2024 and2025 are different years, not a 2026 heldout. Generated mothers include nonmarital births; exact/open ages differ; approximate-domain distances only.'}
    (OUT/'birth_separate_year_diagnostics.json').write_text(json.dumps(bdiag,ensure_ascii=False,indent=2))
    result={'national_moments_weighted_by_2025_birth_counts':True,'equal_47_validation_sample_not_national_population_mix':True,'young_child_income_external':youngdiag,'birth_separate_year':bdiag,'conditional_cells':len(conditional),'conditional_cells_n100plus':sum(x['draws']>=100 for x in conditional),'median_conditional_TV_n100plus':sorted(x['full_generated_income_employment_grandparent_TV']for x in conditional if x['draws']>=100 and x['full_generated_income_employment_grandparent_TV']is not None)[sum(x['draws']>=100 and x['full_generated_income_employment_grandparent_TV']is not None for x in conditional)//2],'complete_newborn_external_validation':'NOT ESTABLISHED'}
    bounds=[]
    for field in ['gross','disposable','net_assets','rent']:
        lo=[];hi=[]
        for row in rawrows:
            if field=='rent'and row['tenure']=='owner':continue
            w=pref_tot[row['pref']]/ns[row['pref']];l=row[field+'_lo'];h=row[field+'_hi'];lo.append((float(l)if l else-math.inf,w));hi.append((float(h)if h else math.inf,w))
        for quantile in[.1,.25,.5,.75,.9]:
            l=weighted_quantile(lo,quantile);h=weighted_quantile(hi,quantile)
            bounds.append({'variable':field,'quantile':quantile,'generated_bin_quantile_lower_bound':l if math.isfinite(l)else'unbounded_below','generated_bin_quantile_upper_bound':h if math.isfinite(h)else'unbounded_above','interpretation':'bin/category bounds including open and unknown bins, nationwide reweighted; simulation quantiles not actual2026 observations'})
    write('national_generated_quantile_bounds.csv',bounds)
    (OUT/'external_diagnostics_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(result)
if __name__=='__main__':main()
