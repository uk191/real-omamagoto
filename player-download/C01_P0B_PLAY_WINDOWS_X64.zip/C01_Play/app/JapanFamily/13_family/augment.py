"""Observed ESS regional household association; municipality match audited by name.
Major-city categories are not municipality codes; never truncate or reinterpret them.
"""
import json,gzip,sqlite3,collections
from tables import ROOT,cells,code,label,interval
def augment(k,c):
    geo=collections.defaultdict(list)
    for co,name,pref,typ in c.execute("SELECT code,name,pref_code,geo_type FROM geo_unit WHERE geo_version='census2025-10-01'"):
        if typ in('city','designated_city','town_or_village','special_ward'):geo[(pref,name)].append(co)
    totals={};rows=[];mapping={};audit=[]
    for d,v,s,m,u in cells('ess_r_140'):
        g=code(d['地域区分']);a=code(d['妻の年齢']);f=code(d['世帯の家族類型・6歳未満の子供の有無']);e=code(d['夫と妻の就業状態']);i=code(d['世帯所得'])
        if f not in('31','41')or e=='0':continue
        if g not in mapping:
            name=label(d['地域区分']);matches=geo.get((g[:2],name),[])
            mapping[g]={'survey_code':g,'name':name,'pref':g[:2],'municipality_codes':matches if len(matches)==1 else([f'131{z:02d}'for z in range(1,24)]if name=='特別区部'else[]),'level':'national'if g=='00'else('prefecture'if len(g)==2 else('tokyo_special_ward_cluster'if name=='特別区部'else'major_city')),'method':'exact_prefecture_and_name; unique 2025 authority match; Tokyo23 group shared'}
        key=(g,a,f,e)
        if i=='00':totals[key]=(v,interval(d['妻の年齢']),s);continue
        rows.append({'geo':g,'a':a,'age_interval':interval(d['妻の年齢']),'grandparent':f=='41','employment':e,'income':i,'income_interval':interval(d['世帯所得'],10000),'weight':v or 0,'source':s})
    grouped=collections.Counter()
    for x in rows:grouped[(x['geo'],x['a'],'41'if x['grandparent']else'31',x['employment'])]+=x['weight']
    for(g,a,f,e),(v,ai,s)in totals.items():
        gap=(v or 0)-grouped[(g,a,f,e)]
        audit.append({'geo':g,'age_code':a,'family':f,'employment':e,'total':v,'known_sum':grouped[(g,a,f,e)],'residual':gap})
        if gap>0:rows.append({'geo':g,'a':a,'age_interval':ai,'grandparent':f=='41','employment':e,'income':'unknown','income_interval':[None,None],'weight':gap,'source':s|{'method':'total minus known-income cells; contains source rounding'}})
    k['family_regional']=rows;k['region_family_mapping']=list(mapping.values());k['audit']+=audit
    return k
if __name__=='__main__':
    with gzip.open(ROOT/'data/kernels.json.gz','rt')as f:k=json.load(f)
    c=sqlite3.connect(ROOT.parent/'data/region.sqlite');k=augment(k,c);c.close();k['version']='A2-0.4'
    p=ROOT/'data/kernels.json.gz';tmp=p.with_suffix('.tmp')
    with gzip.open(tmp,'wt',encoding='utf-8')as f:json.dump(k,f,ensure_ascii=False,separators=(',',':'))
    tmp.replace(p);(ROOT/'data/kernel_inventory.json').write_text(json.dumps({a:len(b)for a,b in k.items()if isinstance(b,list)},indent=2))
    from install_kernels import install
    install()
