"""Reproducible observed conditional kernels from official tables; no synthetic raw observations."""
import sqlite3,json,csv,re,collections,gzip,math
from pathlib import Path
from tables import ROOT,norm,code,label,number,interval,cells
PROJECT=ROOT.parent
def main():
    k={'version':'A2-0.4','audit':[]};c=sqlite3.connect(PROJECT/'data/region.sqlite')
    geo={r[0]:r[1:]for r in c.execute("SELECT code,geo_type,parent_geo_id FROM geo_unit WHERE geo_version='census2025-10-01'")}
    bp=[];bm=[]
    for p in range(1,48):
        pref=f'{p:02d}';rows=list(csv.reader((ROOT/'raw'/f'vital25_geo_4_{pref}.csv').read_text(encoding='cp932').splitlines()));active=False;name=''
        assert f'({p:02d}'in norm(rows[1][0])or f'{p:02d}'in norm(rows[1][0]),'Wrong prefecture table'
        for i,row in enumerate(rows,1):
            if len(row)==1:active=norm(row[0]).replace(' ','')=='総数';continue
            if not active or len(row)<20:continue
            if row[0]:name=norm(row[0])
            if not name.startswith(pref+' '):continue
            m=norm(row[1]);
            if m.replace(' ','')=='総数':continue
            for sex,off in [('all',2),('male',8),('female',14)]:
                for rank in range(1,6):bp.append({'pref':pref,'mother_label':m,'rank':rank,'sex':sex,'weight':number(row[off+rank],True),'source':{'table_id':f'vital25_geo_4_{pref}','row':i,'column':off+rank+1}})
        rows=list(csv.reader((ROOT/'raw'/f'vital25_geo_5-2_{pref}.csv').read_text(encoding='cp932').splitlines()));heads=rows[2];co=''
        for i,row in enumerate(rows[3:],4):
            if len(row)<3:continue
            if row[0]:co=norm(row[0])[:5]
            if co not in geo or geo[co][0]not in('city','town_or_village','administrative_ward','designated_city','special_ward'):continue
            auth=geo[co][1].split(':')[-1]if geo[co][0]=='administrative_ward'else co
            sex={'総数':'all','男':'male','女':'female'}.get(norm(row[1]).replace(' ',''))
            if not sex:continue
            for j in range(2,len(row)):bm.append({'pref':pref,'code':auth,'mother_age5':norm(heads[j]),'sex':sex,'weight':number(row[j],True),'source':{'table_id':f'vital25_geo_5-2_{pref}','row':i,'column':j+1,'original_geo_code':co}})
    k['birth_pref']=bp;k['birth_municipal']=bm
    bn=[];bl=[];tail=[];birth2024=[]
    for year in[2024,2025]:
        rr=list(csv.reader((ROOT/'raw'/f'vital{year}_8.csv').read_text(encoding='cp932').splitlines()));heads=rr[4];rank=''
        for i,row in enumerate(rr[5:],6):
            if len(row)==1:rank=norm(row[0]);continue
            if len(row)<3 or rank.replace(' ','')=='総数'or norm(row[0])=='母の年齢(総数)':continue
            for j in range(2,len(row)):
                x={'mother_label':norm(row[0]),'rank':int(re.search(r'\d+',rank)[0]),'father_label':norm(heads[j]),'weight':number(row[j],True),'source':{'table_id':f'vital{year}_8','row':i,'column':j+1}}
                (bn if year==2025 else birth2024).append(x)
        rr=list(csv.reader((ROOT/'raw'/f'vital{year}_7.csv').read_text(encoding='cp932').splitlines()));heads=rr[4];legal='';sex=''
        for i,row in enumerate(rr[5:],6):
            if len(row)==1:legal=norm(row[0]).replace(' ','');continue
            if len(row)<3:continue
            if row[0]:sex=norm(row[0]).replace(' ','')
            rank=norm(row[1]);mt=re.search(r'第(\d+)',rank)
            if sex!='総数'or not mt:continue
            r=int(mt[1])
            for j in range(3,len(row)):
                v=number(row[j],True);loc={'table_id':f'vital{year}_7','row':i,'column':j+1};m=norm(heads[j])
                if year==2025 and legal in('嫡出子','嫡出でない子'):bl.append({'mother_label':m,'rank':r,'rank_open':'以上'in rank,'legal_status':'marital'if legal=='嫡出子'else'nonmarital','weight':v,'source':loc})
                if year==2025 and legal=='総数'and r>=5:tail.append({'mother_label':m,'rank':r,'rank_open':'以上'in rank,'weight':v,'source':loc})
    k.update(birth_father=bn,birth_legal=bl,birth_tail=tail,birth_father_2024=birth2024)
    base=[];totals={}
    for d,v,s,m,u in cells('ess_239'):
        a=code(d['妻の年齢']);f=code(d['世帯の家族類型・6歳未満の子供の有無']);inc=code(d['世帯所得']);emp=code(d['夫と妻の就業状態'])
        if f not in('31','41')or emp=='0':continue
        if inc=='00':totals[(a,f,emp)]=(v,interval(d['妻の年齢']),s);continue
        base.append({'a':a,'age_interval':interval(d['妻の年齢']),'grandparent':f=='41','income':inc,'income_interval':interval(d['世帯所得'],10000),'employment':emp,'weight':v or 0,'source':s})
    for(a,f,e),(v,ai,s)in totals.items():
        known=sum(x['weight']for x in base if x['a']==a and x['grandparent']==(f=='41')and x['employment']==e);gap=(v or 0)-known
        k['audit'].append({'table':'ess_239','a':a,'family':f,'employment':e,'total':v,'known_sum':known,'gap':gap})
        if gap>0:base.append({'a':a,'age_interval':ai,'grandparent':f=='41','income':'unknown','income_interval':[None,None],'employment':e,'weight':gap,'source':s|{'method':'total minus known-income cells; includes rounding'}})
    k['family_base']=base
    single=[]
    for d,v,s,m,u in cells('ess_257-1'):
        a=code(d['母親の年齢']);emp=code(d['母親の就業状態・仕事の主従・求職活動の有無']);inc=code(d['世帯所得'])
        if emp not in('1','2')or inc=='00':continue
        single.append({'a':a,'age_interval':interval(d['母親の年齢']),'employment':'1'if emp=='1'else'0','income':inc,'income_interval':interval(d['世帯所得'],10000),'weight':v or 0,'source':s})
    k['single_base']=single;pairs=[];pt={}
    for d,v,s,m,u in cells('ess_248'):
        fe,fi,a,me,mi,st=[code(d[x])for x in['夫の教育','夫の所得','妻の年齢','妻の教育','妻の所得','妻の従業上の地位・雇用形態']]
        if st!='0'or a=='0':continue
        if fe==fi==me==mi=='0':pt[a]=(v,interval(d['妻の年齢']),s)
        if any(x=='0'for x in[fe,fi,me,mi]):continue
        pairs.append({'a':a,'fe':fe,'me':me,'father_income_interval':interval(d['夫の所得'],10000),'mother_income_interval':interval(d['妻の所得'],10000),'age_interval':interval(d['妻の年齢']),'weight':v or 0,'source':s})
    for a,(v,ai,s)in pt.items():
        gap=(v or 0)-sum(x['weight']for x in pairs if x['a']==a)
        if gap>0:pairs.append({'a':a,'fe':None,'me':None,'father_income_interval':[None,None],'mother_income_interval':[None,None],'age_interval':ai,'weight':gap,'source':s|{'method':'unknown joint-component residual; independent individual backoff'},'missing_pair':True})
    k['couple_pairs']=pairs
    ed=[]
    for t,parent in[('ess_261','father'),('ess_262','mother')]:
        total=None
        for d,v,s,m,u in cells(t):
            key='夫の教育'if parent=='father'else'妻の教育';e=code(d[key]);care=code(d['夫の育児の有無・頻度']if parent=='father'else d['妻の育児の有無・頻度'])
            if code(d['妻の就業状態・仕事の主従'])!='0'or code(d['妻の従業上の地位・雇用形態'])!='0'or care!='0'or code(d['世帯の家族類型'])!='0':continue
            if e=='0':total=(v,s);continue
            if e in('91','92','93'):continue
            co='1'if e=='1'else('2'if e=='2'else('4'if e in('8','9')else'3'))
            ed.append({'parent':parent,'coarse':co,'label':label(d[key]),'weight':v or 0,'source':s})
        if total:
            gap=(total[0]or 0)-sum(x['weight']for x in ed if x['parent']==parent)
            if gap>0:ed.append({'parent':parent,'coarse':'unknown','label':None,'weight':gap,'source':total[1]|{'method':'unresolved education residual'}})
    k['education_reference']=ed;jobs=[]
    for d,v,s,m,u in cells('ess_n_43'):
        sx=code(d['男女']);a=code(d['年齢']);e=code(d['教育']);inc=code(d['所得(主な仕事からの年間収入・収益)']);oc=code(d['職業'])
        if sx=='0'or a=='0'or e in('0','1','191','192','193')or inc=='00'or oc=='00':continue
        co='1'if e=='11'else('2'if e=='12'else('4'if e in('18','19')else('3'if e in('13','14','15','16','17')else'unknown')))
        jobs.append({'sex':sx,'age_interval':interval(d['年齢']),'coarse':co,'education':label(d['教育']),'income_interval':interval(d['所得(主な仕事からの年間収入・収益)'],10000),'occupation':oc,'occupation_label':label(d['職業']),'weight':v or 0,'source':s})
    k['jobs']=jobs;ind=[]
    for d,v,s,m,u in cells('ess_n_41'):
        sx=code(d['男女']);a=code(d['年齢']);e=code(d['教育']);inc=code(d['所得(主な仕事からの年間収入・収益)']);st=code(d['従業上の地位・雇用形態・起業の有無']);i=code(d['産業'])
        if sx=='0'or a=='00'or e!='0'or inc=='00'or st not in('0','1','2','22','23')or len(i)!=2 or i=='00':continue
        ind.append({'sex':sx,'age_interval':interval(d['年齢']),'income_interval':interval(d['所得(主な仕事からの年間収入・収益)'],10000),'status':st,'industry':i,'label':label(d['産業']),'weight':v or 0,'source':s})
    k['industry']=ind;ri=[]
    for d,v,s,m,u in cells('ess_r_35'):
        g=code(d['地域区分']);sx=code(d['男女']);i=code(d['産業']);o=code(d['職業'])
        if sx=='0'or g not in['00']+[f'{p:02d}'for p in range(1,48)]or len(i)!=2 or i=='00'or o=='00':continue
        ri.append({'pref':g,'sex':sx,'industry':i,'occupation':o,'weight':v or 0,'source':s})
    k['regional_industry']=ri;hours=[]
    for d,v,s,m,u in cells('ess_n_35'):
        sx=code(d['男女']);o=code(d['職業']);ic=code(d['所得(主な仕事からの年間収入・収益)']);hh=d['年間就業日数・就業の規則性・週間就業時間'];hc=code(hh)
        if sx=='0'or len(o)!=2 or o=='00'or ic=='00':continue
        if hc not in('16','17')and not(re.fullmatch(r'15\d\d',hc)and 1505<=int(hc)<=1518)and not(re.fullmatch(r'2\d\d',hc)and 201<=int(hc)<=214):continue
        hours.append({'sex':sx,'occupation':o,'income_interval':interval(d['所得(主な仕事からの年間収入・収益)'],10000),'hours_interval':interval(label(hh).split('(')[0])if hc not in('16','17')else[None,None],'schedule':label(hh),'weight':v or 0,'source':s})
    k['hours']=hours;geos=['00000']+[f'{p:02d}000'for p in range(1,48)];housing=[]
    for d,v,s,m,u in cells('housing_40-1'):
        g=code(d['地域区分']);i=code(d['世帯の年間収入階級']);t=code(d['住宅の所有の関係']);n=code(d['世帯人員'])
        if g not in geos or i=='00'or t not in('1','21','22','23','24')or n=='0':continue
        housing.append({'geo':g,'income_interval':interval(d['世帯の年間収入階級'],10000),'tenure':t,'size':n,'weight':v or 0,'source':s})
    k['housing']=housing;hf=[]
    for d,v,s,m,u in cells('housing_54'):
        f=code(d['家族類型']);t=code(d['住宅の所有の関係']);b=code(d['住宅の建て方']);a=code(d['家計を主に支える者の年齢']);i=code(d['世帯の年間収入階級'])
        if f not in('1121','1131','12')or t not in('1','21','22','23','24')or b not in('1','2','3','4')or code(d['建物の階数'])!='00'or a=='00'or i=='0':continue
        hf.append({'family':f,'tenure':t,'building':b,'age_interval':interval(d['家計を主に支える者の年齢']),'income_interval':interval(d['世帯の年間収入階級'],10000),'weight':v or 0,'source':s})
    k['housing_family']=hf;rents=[]
    for d,v,s,m,u in cells('housing_126'):
        if m!='借家(専用住宅)数':continue
        g=code(d['地域区分']);i=code(d['世帯の年間収入階級']);t={'1':'21','2':'22','3':'23','4':'24'}.get(code(d['住宅の所有の関係']));rent=code(d['住宅の1か月当たり家賃'])
        if g not in geos or i=='00'or t is None or code(d['家計を主に支える者の従業上の地位'])!='0'or rent=='00':continue
        rents.append({'geo':g,'tenure':t,'income_interval':interval(d['世帯の年間収入階級'],10000),'rent':rent,'rent_interval':interval(d['住宅の1か月当たり家賃']),'weight':v or 0,'source':s})
    k['rents']=rents;fin=[]
    for d,v,s,m,u in cells('finance_7-61-1'):
        if m!='世帯数分布'or'世帯類型'not in d:continue
        f=code(d['世帯類型']);mt=code(d['住宅ローン残高の有無']);di=code(d['年間可処分所得階級']);a=code(d['資産額階級'])
        if f not in('012','014')or mt not in('1','2')or not re.fullmatch(r'\d{2}',di)or di=='00'or not re.fullmatch(r'\d{2}',a)or a=='00':continue
        ii=interval(d['年間可処分所得階級'],10000);ai=interval(d['資産額階級'],10000)
        if di=='01':ii[0]=None
        if a=='01':ai[0]=None
        fin.append({'family':f,'mortgage':mt,'disposable_interval':ii,'asset_interval':ai,'di':di,'asset':a,'weight':v or 0,'source':s})
    k['finance']=fin;fr=[]
    for d,v,s,m,u in cells('finance_7-62-1'):
        if m!='世帯数分布':continue
        g=code(d['地域_2024']);a=code(d['世帯主の年齢階級']);di=code(d['年間可処分所得階級']);asset=code(d['資産額階級'])
        if g not in geos or a=='00'or not re.fullmatch(r'\d{2}',di)or di=='00'or not re.fullmatch(r'\d{2}',asset)or asset=='00':continue
        fr.append({'geo':g,'age_interval':interval(d['世帯主の年齢階級']),'di':di,'asset':asset,'weight':v or 0,'source':s})
    k['finance_region']=fr
    from augment import augment
    k=augment(k,c)
    c.close()
    out=ROOT/'data/kernels.json.gz';tmp=out.with_suffix('.tmp')
    with gzip.open(tmp,'wt',encoding='utf-8')as f:json.dump(k,f,ensure_ascii=False,separators=(',',':'))
    tmp.replace(out);(ROOT/'data/kernel_inventory.json').write_text(json.dumps({x:len(y)for x,y in k.items()if isinstance(y,list)},indent=2))
    from install_kernels import install
    install()
if __name__=='__main__':main()
