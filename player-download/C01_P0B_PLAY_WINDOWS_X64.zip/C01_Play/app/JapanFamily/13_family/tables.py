"""Classification-preserving Excel extraction. Subtotals remain explicit, never microrecords."""
from pathlib import Path
import json,re,unicodedata,math,openpyxl
ROOT=Path(__file__).resolve().parent
def norm(x):return unicodedata.normalize('NFKC',str(x if x is not None else'')).strip()
def code(x):return norm(x).split('_',1)[0]
def label(x):return norm(x).split('_',1)[-1]
def number(x,count=False):
    if x is None or norm(x)=='':return None
    if count and norm(x)=='-':return 0.
    try:return float(norm(x).replace(',',''))
    except ValueError:return None
def interval(s,unit=1):
    s=label(s).replace(',','');a=[float(x)for x in re.findall(r'\d+(?:\.\d+)?',s)]
    if '不詳'in s or not a:return [None,None]
    if s=='0円':return [0,0]
    if '未満'in s and len(a)==1:return [0,a[0]*unit]
    if '以上'in s:return [a[0]*unit,None]
    if len(a)>1:
        age='円'not in s and unit==1
        high=a[1]+(1 if '未満'not in s and(age or('万円'in s and int(a[1])%10==9))else 0)
        return [a[0]*unit,high*unit]
    return [a[0]*unit,a[0]*unit]
def cells(table):
    path=ROOT/'raw'/(table+'.xlsx');w=openpyxl.load_workbook(path,read_only=True,data_only=True)
    for sh in w:
        rows=list(sh.values);hi=next((i for i,r in enumerate(rows[:25])if any(norm(x)in('地域区分','地域_2024','階層レベル','地域識別コード')for x in r)and not any(norm(x)in('事項名','項目名')for x in r)),None)
        if hi is None:continue
        hdr=rows[hi];first=next((j for j,x in enumerate(hdr)if x is not None and str(x).strip()==''),None)
        if first is None:first=next(j for j in range(1,len(hdr))if all(x is None for x in hdr[j:]))
        locate=lambda text:next((i for i in range(hi)if text in[ norm(x)for x in rows[i]]),None)
        ar,ir,mr,ur=map(locate,['事項名','項目名','表章項目','表章単位'])
        dims=[(j,norm(x))for j,x in enumerate(hdr[:first])if norm(x)not in('','階層レベル','地域識別コード','表章項目','表章単位')]
        for rownum,r in enumerate(rows[hi+1:],hi+2):
            if not any(x is not None for x in r):continue
            ds={k:norm(r[j])for j,k in dims}
            if not ds or any(v==''for v in ds.values()):continue
            measure=norm(r[hdr.index('表章項目')])if'表章項目'in hdr else None
            for j in range(first,len(r)):
                if r[j]is None:continue
                d=dict(ds)
                if ar is not None and ir is not None and rows[ar][j]is not None:d[norm(rows[ar][j])]=norm(rows[ir][j])
                m=measure or(norm(rows[mr][j])if mr is not None else'');u=norm(rows[ur][j])if ur is not None else(norm(r[hdr.index('表章単位')])if'表章単位'in hdr else'')
                iscount=m in('世帯数','主世帯数','借家(専用住宅)数','世帯数分布','世帯員数分布','人口')
                yield d,number(r[j],iscount),{'table_id':table,'sheet':sh.title,'row':rownum,'column':j+1,'raw_value':str(r[j])},m,u
    w.close()
