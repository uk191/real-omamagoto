"""Official public-file retrieval; immutable raw bytes + hash + timestamps. No API credentials."""
from pathlib import Path
import urllib.request,hashlib,json,datetime,concurrent.futures,sys
ROOT=Path(__file__).resolve().parent
def manifest():
    rows=[]
    def add(id,infid,year,title,kind=0):rows.append({'id':id,'file':id+('.csv'if kind==1 else'.xlsx'),'url':f'https://www.e-stat.go.jp/stat-search/file-download?statInfId={infid}&fileKind={kind}','year':year,'title':title,'publisher':'厚生労働省'if id.startswith('vital')else'総務省統計局'})
    for year,nos in [(2025,{'5':'000040503680','7':'000040503682','8':'000040503683','10':'000040503685','17':'000040503692','4-3':'000040503642','4-21':'000040503657','4-29':'000040503666','4-33':'000040503670','4-37':'000040503674'}),(2024,{'5':'000040320419','7':'000040320421','8':'000040320422','10':'000040320424','17':'000040320431','4-3':'000040320378','4-21':'000040320396','4-29':'000040320405','4-33':'000040320409','4-37':'000040320413'})]:
        for no,i in nos.items():add(f'vital{year}_{no}',i,year,'人口動態統計 '+str(year)+' 出生表 '+no,1)
    for p in range(1,48):
        for no,base,title in [('4',40503996,'出生順位・母の各歳・性'),('5-2',40504112,'市区町村・母の5歳階級・性')]:add(f'vital25_geo_{no}_{p:02d}',f'{base+p:012d}',2025,f'保管都道府県出生 {no} {p:02d} {title}',1)
    add('ess_r_140','000040077672',2022,'就業構造基本調査 地域140 妻年齢・6歳未満子・所得・夫婦就業')
    ess={'239':40077525,'240-2':40077527,'244':40077531,'248':40077535,'250-2':40077538,'257-1':40077545,'257-2':40077546,'258-1':40077548,'261':40077553,'262':40077554,'263':40077555,'269':40077561,'270':40077562,'n_35':40077294,'n_41':40077302,'n_43':40077304}
    for no,i in ess.items():add('ess_'+no,f'{i:012d}',2022,'就業構造基本調査 全国表 '+no)
    for no,i in {'n_26':40077284,'r_35':40077616,'r_24':40077605,'r_25':40077606}.items():
        if no in ('r_24','r_25'):continue  # exact regional income files retained as next acquisition, not guessed
        add('ess_'+no,f'{i:012d}',2022,'就業構造基本調査 '+no)
    for no,i in {'38-1':40077910,'40-1':40209911,'40-2':40209912,'43-4':40209921,'48-1':40209929,'48-2':40209930,'54':40209938,'126':40210070}.items():
        if no=='38-1':continue
        add('housing_'+no,f'{i:012d}',2023,'住宅・土地統計調査 表'+no)
    finance={'3-1':4049,'7-61-1':40490390,'7-62-1':40490391,'7-91':40490400,'7-101-1':40490401}
    for no,i in finance.items():
        if no=='3-1':continue
        add('finance_'+no,f'{i:012d}',2024,'全国家計構造調査 表'+no)
    for id,url in [('finance_search_js','https://www.stat.go.jp/data/zenkokukakei/2024/tblsearch/js/kakei-search.js'),('finance_glossary','https://www.stat.go.jp/data/zenkokukakei/2024/pdf/yougo2024.pdf'),('finance_notes','https://www.stat.go.jp/data/zenkokukakei/2024/pdf/riyou2024.pdf'),('ess_glossary','https://www.stat.go.jp/data/shugyou/2022/pdf/yougo.pdf'),('ipss17_overview','https://www.ipss.go.jp/ps-doukou/j/doukou17/JNFS17gaiyo.pdf'),('ipss17_data','https://www.ipss.go.jp/ps-doukou/j/db_17/db_17GaiyoBaseData.html'),('research_joint','https://www.jasss.org/20/4/16.html')]:rows.append({'id':id,'file':id+('.pdf'if url.endswith('pdf')else('.js'if url.endswith('js')else'.html')),'url':url,'title':id,'year':None,'publisher':'official or primary research'})
    for no in ['9-3','9-5','9-11','10-7']:rows.append({'id':'ipss17_'+no,'file':'ipss17_'+no+'.csv','url':'https://www.ipss.go.jp/ps-doukou/j/db_17/17GaiyoBaseData/JNFS17gaiyoFigure'+no+'.csv','year':2025,'title':'第17回出生動向基本調査 図表'+no,'publisher':'国立社会保障・人口問題研究所'})
    return rows
def fetch(item):
    path=ROOT/'raw'/item['file'];row=dict(item);row['retrieved_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        with urllib.request.urlopen(urllib.request.Request(item['url'],headers={'User-Agent':'JapanFamilyResearch/0.3 public-statistics'}),timeout=50)as r:b=r.read();row.update(http_status=r.status,content_type=r.headers.get('Content-Type'))
        if path.exists()and hashlib.sha256(path.read_bytes()).digest()!=hashlib.sha256(b).digest():
            revision=ROOT/'raw/revisions';revision.mkdir(exist_ok=True);rp=revision/(item['id']+'_'+hashlib.sha256(b).hexdigest()[:16]+path.suffix);rp.write_bytes(b)
            row.update(status='revision_detected_requires_new_model_version',revision_file=str(rp.relative_to(ROOT)),revision_sha256=hashlib.sha256(b).hexdigest(),error='Existing frozen raw file preserved; adopt revision under a new model version')
            print(row['id'],row['status'],flush=True);return row
        path.write_bytes(b);row.update(status='downloaded',bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    except Exception as e:row.update(status='failed',error=str(e))
    print(row['id'],row['status'],row.get('bytes',row.get('error')),flush=True);return row
def acquire(items):
    with concurrent.futures.ThreadPoolExecutor(max_workers=6)as ex:rs=list(ex.map(fetch,items))
    with(ROOT/'data/acquisition.jsonl').open('a')as f:
        for row in rs:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    return rs
if __name__=='__main__':
    items=json.loads(Path(sys.argv[1]).read_text())if len(sys.argv)>1 else manifest();(ROOT/'data/acquisition_manifest.json').write_text(json.dumps(items,ensure_ascii=False,indent=2));results=acquire(items)
    if any(x['status']!='downloaded'for x in results):raise SystemExit('Acquisition incomplete or official revision detected; preserved previous snapshot')
