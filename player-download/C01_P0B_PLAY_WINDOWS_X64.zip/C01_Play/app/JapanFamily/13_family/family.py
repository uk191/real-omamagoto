"""A2-0.4 seeded newborn-family research generator. Aggregate observations are not microdata."""
import json,gzip,random,hashlib,bisect,collections,math,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent;VERSION='A2-0.4'
sys.path.insert(0,str(PROJECT/'08_sampler'))
from region import RegionModel
class ConditionSupportError(ValueError):pass
def rng(seed,part):return random.Random(int.from_bytes(hashlib.sha256(f'{VERSION}:{seed}:{part}'.encode()).digest()[:16],'big'))
def exact_age(s):
    mt=re.search(r'\d+',s)
    return int(mt[0])if mt and not any(x in s for x in['以上','以下'])else None
def observed_age_interval(s):
    a=exact_age(s)
    if a is not None:return[a,a]
    mt=re.search(r'\d+',s)
    return [None,int(mt[0])]if mt and'以下'in s else([int(mt[0]),None]if mt and'以上'in s else[None,None])
def age5(s):
    a=exact_age(s)
    return '14歳以下'if'以下'in s else('50歳以上'if'以上'in s or(a is not None and a>=50)else(f'{a//5*5}~{a//5*5+4}歳'if a is not None else'不 詳'))
def contains(i,x):return(i[0]is None or x>=i[0])and(i[1]is None or x<i[1]or i[0]==i[1]==x)
def age_match(i,a):return a is not None and i!=[None,None]and contains(i,a)
def overlaps(a,b):
    if a==[None,None]or b==[None,None]:return True
    lo=max(a[0]if a[0]is not None else-math.inf,b[0]if b[0]is not None else-math.inf);hi=min(a[1]if a[1]is not None else math.inf,b[1]if b[1]is not None else math.inf)
    return hi>lo or hi==lo==a[0]==a[1]==b[0]==b[1]
def amount(i,r,fixed=None):
    if fixed is not None:return {'value':fixed,'interval':i,'kind':'user_fixed_within_accepted_observed_bin'}
    lo,hi=i
    return {'value':None if lo is None or hi is None else(lo if lo==hi else round(r.uniform(lo,hi-1))),'interval':i,'kind':'open_interval_no_point'if lo is None or hi is None else'game_assumption_uniform_within_finite_published_bin'}
class Dist:
    def __init__(self,rows,weights=None):
        self.rows=[];self.cdf=[];self.total=0
        for x,w in zip(rows,weights if weights is not None else[x['weight']for x in rows]):
            if w is None or w<=0:continue
            self.rows.append(x);self.total+=w;self.cdf.append(self.total)
        if not self.rows:raise ConditionSupportError('No positive published conditional support; this is not proof of impossibility')
    def draw(self,r):return self.rows[min(len(self.rows)-1,bisect.bisect_right(self.cdf,r.random()*self.total))]
class FamilyModel:
    def __init__(self,cache=None,db=None):
        with gzip.open(cache or ROOT/'data/kernels.json.gz','rt',encoding='utf-8')as f:self.k=json.load(f)
        assert self.k['version']==VERSION
        self.cache={};self.region=RegionModel(db or PROJECT/'data/region.sqlite');self.g={}
        def grouped(name,key):
            g=collections.defaultdict(list)
            for x in self.k[name]:g[key(x)].append(x)
            self.g[name]=g
        for n,key in [('birth_pref',lambda x:x['pref']),('birth_legal',lambda x:(x['mother_label'],min(x['rank'],5))),('birth_father',lambda x:(x['mother_label'],min(x['rank'],4))),('birth_tail',lambda x:x['mother_label']),('birth_municipal',lambda x:(x['pref'],x['mother_age5'],x['sex'])),('jobs',lambda x:x['sex']),('industry',lambda x:(x['sex'],tuple(x['age_interval']),tuple(x['income_interval']))),('regional_industry',lambda x:(x['pref'],x['sex'],x['occupation'])),('hours',lambda x:(x['sex'],x['occupation'])),('housing',lambda x:x['geo']),('rents',lambda x:(x['geo'],x['tenure'])),('finance_region',lambda x:x['geo'])]:grouped(n,key)
        grouped('family_regional',lambda x:x['geo'])
        self.family_geo={}
        for x in self.k['region_family_mapping']:
            for co in x['municipality_codes']:self.family_geo[co]=x['survey_code']
        self.industry_marg=collections.defaultdict(collections.Counter)
        for x in self.k['industry']:
            if x['status']=='0':self.industry_marg[x['sex']][x['industry']]+=x['weight']
    def memo(self,key,fn):
        if key not in self.cache:self.cache[key]=fn()
        return self.cache[key]
    def national_birth(self,m,rank,hc):
        key=('nat',m,rank,hc.get('father_age'),hc.get('legal_status'),hc.get('birth_rank'))
        def build():
            lc=collections.Counter();ls={}
            for x in self.g['birth_legal'].get((m,min(rank,5)),[]):
                if hc.get('birth_rank',0)>=5 and x['rank']!=hc['birth_rank']:continue
                lc[x['legal_status']]+=x['weight']or 0;ls[x['legal_status']]=x['source']
            fs=self.g['birth_father'].get((m,min(rank,4)),[]);ft=sum(x['weight']or 0 for x in fs);rows=[]
            if lc.get('marital')and ft:
                for x in fs:
                    row={'legal':'marital','father_label':x['father_label'],'weight':lc['marital']*(x['weight']or 0)/ft,'source':x['source'],'legal_source':ls['marital']}
                    rows.append(row)
            if lc.get('nonmarital'):rows.append({'legal':'nonmarital','father_label':'unknown','weight':lc['nonmarital'],'source':ls['nonmarital'],'legal_source':ls['nonmarital']})
            out=[]
            for x in rows:
                if hc.get('legal_status')and hc['legal_status']!=x['legal']:continue
                if 'father_age'in hc:
                    f=x['father_label'];a=hc['father_age']
                    if not(f==f'{a}歳'or('以上'in f and a>=int(re.search(r'\d+',f)[0]))):continue
                out.append(x)
            return Dist(out)if any(x['weight']for x in out)else None
        return self.memo(key,build)
    def birth_dist(self,p,h):
        key=('birth',p,json.dumps({x:y for x,y in h.items()if x in['mother_age','father_age','birth_rank','legal_status','municipality_code']},sort_keys=True))
        def build():
            rows=[];weights=[]
            for x in self.g['birth_pref'][p]:
                if x['sex']!='all'or not x['weight']:continue
                m=x['mother_label'];rank=x['rank']
                if 'mother_age'in h:
                    a=h['mother_age'];mt=re.search(r'\d+',m)
                    if not(m==f'{a}歳'or(mt and'以上'in m and a>=int(mt[0]))or(mt and'以下'in m and a<=int(mt[0]))):continue
                if 'birth_rank'in h and min(h['birth_rank'],5)!=rank:continue
                nd=self.national_birth(m,rank,h);base=self.national_birth(m,rank,{})
                if nd is None or base is None:continue
                likelihood=nd.total/base.total
                if h.get('municipality_code'):
                    ms=self.g['birth_municipal'].get((p,age5(m),'all'),[]);total=sum(z['weight']or 0 for z in ms);local=sum(z['weight']or 0 for z in ms if z['code']==h['municipality_code'])
                    if not total or not local:continue
                    likelihood*=local/total
                rows.append(x);weights.append(x['weight']*likelihood)
            return Dist(rows,weights)
        return self.memo(key,build)
    def base(self,a,partner,p,municipality):
        rg=self.family_geo.get(municipality,p)
        key=('base',a//5 if a is not None else None,partner,rg)
        def build():
            name='family_base'if partner else'single_base';rs=[x for x in self.k[name]if age_match(x['age_interval'],a)];fb=False
            if not any(x['weight']for x in rs):rs=[x for x in self.k[name]if x['a']in('0','00')];fb=True
            if partner:
                def shares(g):
                    z=[x for x in self.g['family_regional'][g]if age_match(x['age_interval'],a)]
                    if not any(x['weight']for x in z):z=[x for x in self.g['family_regional'][g]if x['a']=='0']
                    cc=collections.Counter()
                    for x in z:cc[(x['grandparent'],x['income'],x['employment'])]+=x['weight']
                    total=sum(cc.values());return {key:value/total for key,value in cc.items()}if total else{}
                lp,np=shares(rg),shares('00');weights=[x['weight']*(lp.get((x['grandparent'],x['income'],x['employment']),0)/np[(x['grandparent'],x['income'],x['employment'])]if np.get((x['grandparent'],x['income'],x['employment']))else 1)for x in rs]
                if sum(weights)>0:return Dist(rs,weights),fb
            return Dist(rs),fb
        return self.memo(key,build)
    def pair(self,a,hh,r):
        def build():
            rs=[x for x in self.k['couple_pairs']if age_match(x['age_interval'],a)and(hh[1]is None or(x['father_income_interval'][0]or 0)+(x['mother_income_interval'][0]or 0)<hh[1])]
            return Dist(rs)if any(x['weight']for x in rs)else None
        d=self.memo(('pair',(a-5)//10 if a is not None else None,tuple(hh)),build);return d.draw(r)if d else None
    def parent(self,who,sex,a,employed,hh,r,coarse=None,inc=None):
        if employed:
            def build():
                rs=[x for x in self.g['jobs'][sex]if age_match(x['age_interval'],a)and(coarse is None or x['coarse']==coarse)and(inc is None or overlaps(x['income_interval'],inc))and(hh[1]is None or x['income_interval'][0]<hh[1])];fb=False
                if not any(x['weight']for x in rs):rs=[x for x in self.g['jobs'][sex]if(coarse is None or x['coarse']==coarse)and(inc is None or overlaps(x['income_interval'],inc))and(hh[1]is None or x['income_interval'][0]<hh[1])];fb=True
                return Dist(rs),fb
            d,fb=self.memo(('parent',sex,(a-5)//10 if a is not None else None,coarse,tuple(inc or[None,None]),tuple(hh)),build);x=d.draw(r)
            return {'age':a,'employed':True,'education_coarse':x['coarse'],'education':x['education'],'occupation_code':x['occupation'],'occupation':x['occupation_label'],'main_job_income':amount(x['income_interval'],r),'reference_year':2022,'source':x['source'],'age_backoff':fb}
        rs=[x for x in self.k['education_reference']if x['parent']==who];x=Dist(rs).draw(r)
        return {'age':a,'employed':False,'education_coarse':x['coarse'],'education':x['label'],'occupation_code':None,'occupation':None,'main_job_income':{'value':0,'interval':[0,0],'kind':'game_assumption_stable_reference_nonemployment_not_prior_year_income'},'reference_year':2022,'source':x['source'],'age_backoff':True}
    def work(self,p,sex,parent,r):
        if not parent['employed']:return {'industry':None,'employment_type':None,'actual_hours_at_birth':None,'reference_hours':None}
        a=parent['age'];inc=parent['main_job_income']['interval'];oc=parent['occupation_code'];ai=(a//5*5,a//5*5+5)if a is not None else(None,None)
        def build():
            rs=self.g['industry'].get((sex,ai,tuple(inc)),[])
            if not rs:rs=[x for x in self.k['industry']if x['sex']==sex and overlaps(x['income_interval'],inc)]
            grouped=collections.defaultdict(dict)
            for x in rs:grouped[(x['industry'],tuple(x['age_interval']),tuple(x['income_interval']))][x['status']]=x
            seed=[]
            for vs in grouped.values():
                if '0'not in vs:continue
                get=lambda st:vs.get(st,{'weight':0})['weight'];total,selfemp,emp,regular,nonreg=map(get,['0','1','2','22','23'])
                for st,w in[('self_employed',selfemp),('regular',regular),('nonregular',nonreg),('employee_other',max(0,emp-regular-nonreg)),('other_or_unknown',max(0,total-selfemp-emp))]:seed.append(vs['0']|{'status':st,'weight':w})
            ri=self.g['regional_industry'].get((p,sex,oc),[]);rc=collections.Counter()
            for x in ri:rc[x['industry']]+=x['weight']
            nr=self.industry_marg[sex];rt=sum(rc.values());nt=sum(nr.values())
            weights=[x['weight']*(rc.get(x['industry'],0)/rt)/(nr.get(x['industry'],0)/nt)if rt and nr.get(x['industry'])else x['weight']for x in seed]
            return Dist(seed,weights if sum(weights)>0 else None)if any(z['weight']for z in seed)else None
        d=self.memo(('work',p,sex,oc,ai,tuple(inc)),build)
        if d is None:return {'industry':None,'industry_code':None,'employment_type':None,'reference_year':2022,'reference_hours':None,'actual_hours_at_birth':None,'kind':'missing_published_industry_support_for_age_income; retained_parent_attributes'}
        x=d.draw(r);hrs=[z for z in self.g['hours'].get((sex,oc),[])if overlaps(z['income_interval'],inc)];y=Dist(hrs).draw(r)if any(z['weight']for z in hrs)else None
        return {'industry':x['label'],'industry_code':x['industry'],'employment_type':x['status'],'reference_year':2022,'reference_hours':amount(y['hours_interval'],r)if y else None,'schedule':y['schedule']if y else None,'actual_hours_at_birth':None,'source':x['source'],'hours_source':y['source']if y else None,'kind':'estimate_regional_occupation_industry_transport; occupation_industry_age_income_full_joint_unobserved'}
    def housing(self,p,a,fam,hh,r):
        def build():
            rs=[x for x in self.k['housing_family']if x['family']==fam and age_match(x['age_interval'],a)and overlaps(x['income_interval'],hh)];fb=False
            if not any(x['weight']for x in rs):rs=[x for x in self.k['housing_family']if x['family']==fam and overlaps(x['income_interval'],hh)];fb=True
            def shares(g):
                cc=collections.Counter()
                for x in self.g['housing'][g]:
                    if overlaps(x['income_interval'],hh):cc[x['tenure']]+=x['weight']
                total=sum(cc.values());return {k:v/total for k,v in cc.items()}if total else{}
            lp,np=shares(p+'000'),shares('00000');w=[x['weight']*lp.get(x['tenure'],0)/np[x['tenure']]if np.get(x['tenure'])else 0 for x in rs]
            return Dist(rs,w),fb
        d,fb=self.memo(('house',p,a//5 if a is not None else None,fam,tuple(hh)),build);x=d.draw(r);t=x['tenure'];nmin=2 if fam=='1131'else(4 if fam=='12'else 3)
        def sizedist():
            rs=[y for y in self.g['housing'][p+'000']if y['tenure']==t and int(y['size'])>=nmin and overlaps(y['income_interval'],hh)];fallback=False
            if not any(y['weight']for y in rs):rs=[y for y in self.g['housing']['00000']if y['tenure']==t and int(y['size'])>=nmin and overlaps(y['income_interval'],hh)];fallback=True
            return (Dist(rs)if any(y['weight']for y in rs)else None),fallback
        sd,sfb=self.memo(('size',p,t,nmin,tuple(hh)),sizedist);sz=sd.draw(r)if sd else None
        rent={'value':0,'interval':[0,0],'kind':'owner_no_rent_excludes_mortgage'};rsource=None;rfb=False
        if t!='1':
            def rd():
                rs=[y for y in self.g['rents'][(p+'000',t)]if overlaps(y['income_interval'],hh)];fallback=False
                if not any(y['weight']for y in rs):rs=[y for y in self.g['rents'][('00000',t)]if overlaps(y['income_interval'],hh)];fallback=True
                return (Dist(rs)if any(y['weight']for y in rs)else None),fallback
            dd,rfb=self.memo(('rent',p,t,tuple(hh)),rd)
            if dd:y=dd.draw(r);rent=amount(y['rent_interval'],r);rsource=y['source']
            else:rent={'value':None,'interval':[None,None],'kind':'missing'}
        n=int(sz['size'])if sz else nmin
        return {'tenure_code':t,'tenure':{'1':'owner','21':'public_rental','22':'UR_or_public_corporation','23':'private_rental','24':'employer_housing'}[t],'building_code':x['building'],'household_size':n if n<7 and sz else None,'household_size_interval':[n,None if n==7 or sz is None else n],'monthly_rent':rent,'rent_reference_year':2023,'floor_area_m2':None,'house_price_yen':None,'current_home_mortgage_balance':None,'source':x['source'],'size_source':sz['source']if sz else None,'rent_source':rsource,'age_backoff':fb,'size_national_backoff':sfb,'rent_national_backoff':rfb,'kind':'estimate_national_family_income_age_tenure_reweighted_to_prefecture','parity_size_joint':'unobserved; kinship of additional household members unresolved'}
    def finance(self,p,a,partner,r):
        fam='014'if partner else'012'
        def build():
            rs=[x for x in self.k['finance']if x['family']==fam]
            def counts(g):
                cc=collections.Counter()
                for x in self.g['finance_region'][g]:
                    if age_match(x['age_interval'],a):cc[(x['di'],x['asset'])]+=x['weight']
                tt=sum(cc.values());return {k:v/tt for k,v in cc.items()}if tt else{}
            lp,np=counts(p+'000'),counts('00000');w=[x['weight']*(lp[(x['di'],x['asset'])]/np[(x['di'],x['asset'])]if(x['di'],x['asset'])in lp and np.get((x['di'],x['asset']))else 1)for x in rs]
            return Dist(rs,w)
        ab=0 if a is not None and a<35 else((a-5)//10 if a is not None else None);x=self.memo(('finance',p,ab,fam),build).draw(r)
        return {'disposable_income_OECD':amount(x['disposable_interval'],r),'net_total_assets':amount(x['asset_interval'],r),'mortgage_present_any_property':x['mortgage']=='1','cash_savings_yen':None,'financial_debt_yen':None,'taxes_yen':None,'social_insurance_yen':None,'source':x['source'],'reference_year':2024,'kind':'estimate_observed_disposable_net_asset_mortgage_joint_with_region_age_transport','gross_disposable_link':'conditional independence approximation; no observed gross/disposable/asset full joint; not valid tax burden calculation'}
    def municipality(self,p,m,r,fixed=None):
        def build():
            rs=self.g['birth_municipal'].get((p,age5(m),'all'),[]);fb=False
            if not sum(x['weight']or 0 for x in rs):rs=self.g['birth_municipal'].get((p,'総 数','all'),[]);fb=True
            cc=collections.Counter();sources=collections.defaultdict(list)
            for x in rs:cc[x['code']]+=x['weight']or 0;sources[x['code']].append(x['source'])
            return Dist([{'code':co,'weight':w,'source':sources[co]}for co,w in sorted(cc.items())]),fb
        d,fb=self.memo(('municipality',p,age5(m)),build)
        if fixed:
            rs=[x for x in d.rows if x['code']==fixed]
            if not rs:raise ConditionSupportError('No positive municipality/mother-age birth count')
            return rs[0],fb
        return d.draw(r),fb
    def matches(self,o,h):
        for who in['mother','father']:
            p=o[who]
            income_key=who+'_income_yen'
            if income_key in h and(p is None or p['main_job_income']['value']!=h[income_key]):return False
            for field,attr in[('education','education_coarse'),('occupation','occupation_code'),('employed','employed')]:
                key=who+'_'+field
                if key in h and(p is None or p.get(attr)!=h[key]):return False
        if 'household_income_yen'in h and(o['household_income']['interval']==[None,None]or not contains(o['household_income']['interval'],h['household_income_yen'])):return False
        if 'tenure'in h and o['housing']['tenure']!=h['tenure']:return False
        return True
    def generate(self,pref_code,conditions=None,seed=0,year=2026,include_region=True,max_attempts=10000):
        p=str(pref_code).zfill(2);h=dict(conditions or{});allowed={'mother_age','father_age','birth_rank','legal_status','partner_present','household_income_yen','mother_income_yen','father_income_yen','mother_education','father_education','mother_occupation','father_occupation','mother_employed','father_employed','tenure','municipality_code'}
        if set(h)-allowed:raise ValueError('Unknown conditions '+str(sorted(set(h)-allowed)))
        if p not in self.g['birth_pref']or year!=2026:raise ValueError('Prefecture 01..47, requested year 2026 only')
        for key in['mother_age','father_age','birth_rank','household_income_yen','mother_income_yen','father_income_yen']:
            if key in h and(not isinstance(h[key],int)or isinstance(h[key],bool)or h[key]<0):raise ValueError(key+' must be nonnegative integer')
        if 'household_income_yen'in h and sum(h.get(x+'_income_yen',0)for x in ['mother','father'])>h['household_income_yen']:raise ValueError('Fixed known parent incomes exceed fixed household income under the model allocation assumption')
        if h.get('birth_rank')==0:raise ValueError('birth_rank >=1')
        if h.get('legal_status')not in(None,'marital','nonmarital'):raise ValueError('Invalid legal_status')
        for key in['partner_present','mother_employed','father_employed']:
            if key in h and not isinstance(h[key],bool):raise ValueError(key+' must be boolean')
        if h.get('partner_present')is False and any(x.startswith('father_')for x in h):raise ValueError('Absent co-resident partner cannot receive father household attributes; nonresident biological-father attributes are not implemented')
        for key in['mother_education','father_education']:
            if key in h and h[key]not in('1','2','3','4','unknown'):raise ValueError('Education coarse codes 1/2/3/4/unknown')
        for key in['mother_occupation','father_occupation']:
            if key in h:h[key]=str(h[key]).zfill(2)
        if 'municipality_code'in h:h['municipality_code']=str(h['municipality_code']).zfill(5)
        if 'mother_age'in h and not any(x['mother_label']==f"{h['mother_age']}歳"for x in self.g['birth_pref'][p]):raise ConditionSupportError('Exact maternal age is not separately observed in the published combined/open age band; no age-specific likelihood is identified. This is not proof of impossibility.')
        if 'father_age'in h and not any(x['father_label']==f"{h['father_age']}歳"for x in self.k['birth_father']):raise ConditionSupportError('Exact paternal age is not separately observed in the published combined/open age band; no age-specific likelihood is identified. This is not proof of impossibility.')
        if h.get('birth_rank',0)>=10:raise ConditionSupportError('Exact parity within 10+ is unidentified; unconditioned draws retain a 10+ interval, with no unsupported point probability.')
        bd=self.birth_dist(p,h);endog=any(x in h for x in['household_income_yen','mother_income_yen','father_income_yen','mother_education','father_education','mother_occupation','father_occupation','mother_employed','father_employed','tenure']);first=bd.draw(rng(seed,'0:birth'))
        birth_proposal=0
        for attempt in range(max_attempts):
            b=bd.draw(rng(seed,f'{birth_proposal}:birth'))if endog else first;m=b['mother_label'];a=h.get('mother_age',exact_age(m));rank=b['rank'];nt=self.national_birth(m,rank,h).draw(rng(seed,f'{birth_proposal if endog else 0}:national'));fa=h.get('father_age',exact_age(nt['father_label']))
            partner=h.get('partner_present',True if nt['legal']=='marital'else None);present=partner is True;mu,mfb=self.municipality(p,m,rng(seed,f'{birth_proposal if endog else 0}:municipality'),h.get('municipality_code'));ds,fb=self.base(a,present,p,mu['code']);f=ds.draw(rng(seed,f'{attempt}:base'));hh=f['income_interval'];r=rng(seed,f'{attempt}:parents')
            me=f['employment']in('1','3')if present else f['employment']=='1';fe=f['employment']in('1','2')if present else False;pair=self.pair(a,hh,r)if me and fe else None
            mother=self.parent('mother','2',a,me,hh,r,pair['me']if pair else None,pair['mother_income_interval']if pair and not pair.get('missing_pair')else None)
            father=self.parent('father','1',fa,fe,hh,r,pair['fe']if pair else None,pair['father_income_interval']if pair and not pair.get('missing_pair')else None)if present else None
            low=sum(z['main_job_income']['interval'][0]or 0 for z in[mother,father]if z)
            if hh[1]is not None and low>=hh[1]:continue
            fixed_parent_income={};unsupported=False
            for who,z in [('mother',mother),('father',father)]:
                key=who+'_income_yen'
                if key not in h:continue
                if z is None or not contains(z['main_job_income']['interval'],h[key]):unsupported=True;break
                fixed_parent_income[who]=h[key]
            if unsupported:
                birth_proposal+=1
                continue
            low=sum(fixed_parent_income.get(who,z['main_job_income']['interval'][0]or 0)for who,z in [('mother',mother),('father',father)]if z)
            if hh[1]is not None and low>=hh[1]:
                birth_proposal+=1
                continue
            if 'household_income_yen'in h and( hh==[None,None]or not contains(hh,h['household_income_yen'])or low>h['household_income_yen']):
                birth_proposal+=1
                continue
            inc=amount(hh,r,h.get('household_income_yen'))
            if inc['value']is not None and inc['value']<low:inc=amount([low,hh[1]],r);inc['interval']=hh;inc['kind']='game_assumption_feasible_income_bin'
            inc.update(reference_year=2022,currency='JPY',price_basis='nominal 2022 reference; not a 2026 observation')
            if inc['value']is not None:
                remaining=inc['value']
                for who,z,other in[('mother',mother,father),('father',father,None)]:
                    if not z:continue
                    if who in fixed_parent_income:
                        z['main_job_income']['value']=fixed_parent_income[who];z['main_job_income']['kind']='user_fixed_within_accepted_observed_bin';remaining-=fixed_parent_income[who];continue
                    if not z['employed']:continue
                    lo,hi=z['main_job_income']['interval'];otherlow=fixed_parent_income.get('father',(other['main_job_income']['interval'][0]or 0))if other else 0;up=min(hi-1 if hi is not None else math.inf,remaining-otherlow)
                    if hi is not None and up>=lo:z['main_job_income']['value']=round(r.uniform(lo,max(lo,up)));remaining-=z['main_job_income']['value'];z['main_job_income']['kind']='game_assumption_feasible_allocation_in_observed_bin'
                    else:z['main_job_income']['value']=None
            for who,z in [('mother',mother),('father',father)]:
                if z and who in fixed_parent_income:z['main_job_income']['value']=fixed_parent_income[who];z['main_job_income']['kind']='user_fixed_within_accepted_observed_bin'
            mother['age_interval']=observed_age_interval(m);mother['source_age_category']=m
            if father:father['age_interval']=observed_age_interval(nt['father_label']);father['source_age_category']=nt['father_label']
            if '以下'in m and mother['age_interval'][1]<15:
                mother.update(employed=None,education_coarse='unknown',education=None,occupation_code=None,occupation=None,main_job_income={'value':None,'interval':[None,None],'kind':'not_identified_below_ESS_survey_age15'},source=None,age_backoff=True)
            earner=father if father and(father['main_job_income']['value']or father['main_job_income']['interval'][0]or 0)>(mother['main_job_income']['value']or 0)else mother;fam='1131'if not present else('12'if f['grandparent']else'1121');house=self.housing(p,earner['age'],fam,hh,rng(seed,f'{attempt}:housing'))
            out={'model_version':VERSION,'seed':seed,'requested_year':year,'prefecture_code':p,'sampling_unit':'index liveborn child; multiple births weight delivery households more heavily','birth_population':'Japanese live births with 2025 geography 01..47; geography foreign15 excluded; foreign-national birth model not integrated','birth_reference_year':2025,'child':{'age_years':0,'birth_rank_category':rank,'birth_rank':rank if rank<5 else None,'birth_rank_interval':[rank,rank]if rank<5 else[5,None]},'legal_birth_status':nt['legal'],'partner_present':partner,'mother':mother,'father':father,'household_income':inc,'housing':house,'family':{'co_resident_grandparent':f.get('grandparent')if present else None,'grandparent_count':None,'historical_previous_live_births_interval':[rank-1,rank-1]if rank<5 else[4,None],'resident_sibling_ages':None,'resident_sibling_count':None,'household_size':house['household_size'],'household_size_interval':house['household_size_interval'],'additional_member_kinship':'unresolved; household size is transported from housing survey, not inferred from parity'},'source_trace':{'birth_pref':b['source'],'birth_national':nt['source'],'birth_legal':nt['legal_source'],'family_base':f['source'],'couple_pair':pair['source']if pair else None},'quality':{'family_age_backoff':fb,'newborn_full_joint_externally_validated':False,'financially_playable':False}}
            if not self.matches(out,h):
                birth_proposal+=1
                continue
            if rank==5:
                tails=[x|{'rank_open':x['rank']>=10}for x in self.g['birth_legal'].get((m,5),[])if x['legal_status']==nt['legal']and('birth_rank'not in h or x['rank']==h['birth_rank'])];tx=Dist(tails).draw(rng(seed,f'{attempt}:tail'))if any(x['weight']for x in tails)else None
                n=h.get('birth_rank',tx['rank']if tx and not tx['rank_open']else None);out['child'].update(birth_rank=n,birth_rank_interval=[n,n]if n else[10,None]);out['family']['historical_previous_live_births_interval']=[n-1,n-1]if n else[9,None]
                out['source_trace']['birth_tail']=tx['source']if tx else None
            # Sex is observed jointly with prefecture/maternal age/parity; no invented fixed ratio.
            male=sum(x['weight']or 0 for x in self.g['birth_pref'][p]if x['mother_label']==m and x['rank']==rank and x['sex']=='male');total=b['weight'];out['child']['sex']='male'if rng(seed,f'{attempt}:child_sex').random()*total<male else'female'
            mother['work_context']=self.work(p,'2',mother,rng(seed,f'{attempt}:mother_work'))
            if father:father['work_context']=self.work(p,'1',father,rng(seed,f'{attempt}:father_work'))
            out['finances']=self.finance(p,earner['age'],present,rng(seed,f'{attempt}:finance'));out['source_trace']['regional_family_geo']=self.family_geo.get(mu['code'],p)if present else None;out['municipality_code']=mu['code'];out['source_trace']['municipality']=mu['source'];out['quality']['municipality_age_backoff']=mfb
            out['conditioning']={'conditions':h,'method':'normalize feasible family proposals within each birth/municipality, then reject on user conditions; user points fixed within accepted bins','attempts':attempt+1,'birth_proposals':birth_proposal+1};out['assumptions']=['2026 birth scenario freezes observed 2025 birth structure','under6 and cross-sectional household distributions transported to newborn families','ESS2022 major-city household income/employment association used where observed; other municipalities use prefecture proxy; newborn transport unvalidated','marital co-residence default true; nonmarital co-residence unresolved','gross vs disposable/NET assets relation not identified','open bins retain null point values; finite-bin points are game assumptions']
            out['missing_features']=['foreign_birth_integration','household_unique_delivery_sampling','resident_sibling_survival_and_ages','current_parental_leave_and_return','cash_savings_debt_joint','tax_social_insurance_engine','house_prices_floor_area','municipality_birth_income_joint','grandparent_distance_health_and_current_help']
            if include_region:
                ctx=self.region.make_region_context(p,{'municipality_code':mu['code'],'sampling_frame':'resident'},year,seed);zd=self.region.zone_distribution(mu['code'],'child_under6')
                if zd['complete']and zd['total']>0:
                    j=bisect.bisect_left(zd['cdf'],rng(seed,'zone').random());z=dict(zd['rows'][j]);ctx['living_environment']={'status':'sampled_statistical_living_environment','statistical_area_ref':z['geo_id'],'basis_year':2020,'weight_frame':'child_under6','kind':'estimate_transport_to_newborns','source_datasets':[z['pop_dataset_id'],z['family_dataset_id'],z['housing_dataset_id']]}
                else:ctx['living_environment']={'status':'municipality_only_no_reconciled_under6_support','birth_existence_not_denied':True}
                ctx['sampling']={'frame':'2025_birth_conditional_mother_age','municipality_basis_year':2025,'zone_basis_year':2020};out['region_context']=ctx
            return out
        raise ConditionSupportError(f'No accepted draw in {max_attempts} trials; rare/unidentified support remains unresolved, no conditions overwritten')
    def generate_batch(self,pref_code,n,seed=0,conditions=None,include_region=False):return [self.generate(pref_code,conditions,f'{seed}/{i}',include_region=include_region)for i in range(n)]
if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--pref',default='12');ap.add_argument('--seed',default='42');ap.add_argument('--conditions',default='{}');ap.add_argument('--no-region',action='store_true');a=ap.parse_args();print(json.dumps(FamilyModel().generate(a.pref,json.loads(a.conditions),a.seed,include_region=not a.no_region),ensure_ascii=False,indent=2))
