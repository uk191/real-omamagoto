"""Append provenance without replacing A1 identities; preserve all 634 candidates.
Statuses distinguish implemented proxies, acquired summaries, and unresolved items.
"""
import csv,json,gzip,sqlite3,collections,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent;P=ROOT.parent
def csvwrite(path,rows):
    rows=list(rows);keys=list(dict.fromkeys(k for r in rows for k in r))
    with path.open('w',encoding='utf-8-sig',newline='')as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
def build():
    with gzip.open(ROOT/'data/kernels.json.gz','rt')as f:k=json.load(f)
    c=sqlite3.connect(P/'data/region.sqlite');acq={}
    for line in(ROOT/'data/acquisition.jsonl').read_text().splitlines():
        x=json.loads(line);acq[x['id']]=x
    uses=collections.defaultdict(set)
    for name,rows in k.items():
        if name=='audit'or not isinstance(rows,list):continue
        for row in rows:
            if row.get('source',{}).get('table_id'):uses[row['source']['table_id']].add(name)
    families={'vital':('A2_VITAL','厚生労働省','人口動態統計 確定数','https://www.mhlw.go.jp/toukei/list/81-1a.html','Japanese live births in Japan; index child not unique delivery'),'ess':('A2_ESS22','総務省統計局','2022年就業構造基本調査','https://www.stat.go.jp/data/shugyou/2022/index2.html','Survey population varies by table; under6 married household stocks or employed persons; not newborn cohort'),'housing':('A2_HLS23','総務省統計局','2023年住宅・土地統計調査','https://www.stat.go.jp/data/jyutaku/2023/index.html','Main households; rent distribution limited rented dedicated housing'),'finance':('A2_FIN24','総務省統計局','2024年全国家計構造調査','https://www.stat.go.jp/data/zenkokukakei/2024/index.html','General household survey; each family/age/tenure domain differs; NET assets not savings'),'ipss17':('A2_IPSS25','国立社会保障・人口問題研究所','第17回出生動向基本調査','https://www.ipss.go.jp/ps-doukou/j/doukou17/doukou17.asp','2025 survey; historical first-birth transitions and cumulative support; not current-at-birth state')}
    for sid,pub,title,url,pop in families.values():c.execute('INSERT OR REPLACE INTO source_catalog VALUES(?,?,?,?,?,?,?,?,?,?)',(sid,pub,title,url,None,'2026-10-13','See official source terms; redistribution review pending','public official files','downloaded','Table-specific observational years retained. '+pop))
    c.execute('INSERT OR REPLACE INTO source_catalog VALUES(?,?,?,?,?,?,?,?,?,?)',('A2_REFERENCE','primary publishers','Definitions and methodological research','https://www.jasss.org/20/4/16.html',None,'2026-10-13','Source-specific terms','public document','downloaded','Not Japanese empirical probability data'))
    srcrows=[]
    for id,x in acq.items():
        family=next((v for key,v in families.items()if id.startswith(key)),None);sid=family[0]if family else'A2_REFERENCE';status='converted_model_kernel'if uses[id]else('converted_reference_only'if(ROOT/'data'/(id+'_reference_cells.json')).exists()or id=='finance_1-10'else'acquired_not_implemented')
        c.execute('INSERT OR REPLACE INTO artifact VALUES(?,?,?,?,?,?,?,?,?,?,?)',('A2:'+id,sid,x['url'],'13_family/raw/'+x['file'],x['retrieved_at'],x.get('sha256'),x.get('bytes'),x['status'],x.get('http_status'),x.get('error'),x.get('content_type')))
        c.execute('INSERT OR REPLACE INTO dataset_catalog VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',('A2:'+id,sid,'A2:'+id,id,str(x.get('year')),None,family[4]if family else'see source document','Published aggregate tabulation; source row/column retained','observation-specific; A1 geo crosswalk where needed',json.dumps(sorted(uses[id])),'No claim these are 2026 observations; no microdata; sparse cells and rounding; no newborn full joint',status))
        srcrows.append(x|{'source_id':sid,'conversion_status':status,'model_kernels':';'.join(sorted(uses[id])),'model_population':family[4]if family else'see document','license_review':'official terms recorded; comprehensive game redistribution permission not established'})
    csvwrite(ROOT/'data/sources_A2.csv',srcrows)
    oldsrc=list(csv.DictReader((P/'03_sources.csv').open(encoding='utf-8-sig')));oldsrc=[x for x in oldsrc if not x['artifact_id'].startswith('A2:')]
    csvwrite(P/'03_sources.csv',oldsrc+[{'artifact_id':'A2:'+x['id'],'source_id':x['source_id'],'url':x['url'],'local_path':'13_family/raw/'+x['file'],'accessed_at':x['retrieved_at'],'sha256':x.get('sha256'),'bytes':x.get('bytes'),'status':x['status'],'http_status':x.get('http_status'),'error':x.get('error'),'content_type':x.get('content_type'),'title':x['title'],'publisher':x['publisher'],'survey_years':x.get('year'),'conversion_status':x['conversion_status'],'model_use':x['model_kernels'],'notes':x['model_population'],'license_review_status':x['license_review']}for x in srcrows])
    mapping={
      'POP_017':('implemented_reference','birth_pref;birth_municipal','2025年日本人出生。出生率ではなく出生児数。2026は構造固定シナリオ。'),
      'POP_031':('implemented_reference','birth_pref','県×母の各歳×出生順位×性。母の年齢端階級は区間。'),
      'POP_036':('partial_proxy','birth_father;birth_legal','婚内出生の全国父母各歳同時分布を県へ移送。非婚内父年齢未識別。'),
      'POP_037':('partial_proxy','family_base;family_regional','6歳未満子の夫婦と親同居世帯の断面。出生日の祖父母人数・支援ではない。'),
      'POP_039':('partial_proxy','family_base;family_regional','6歳未満子世帯の夫婦就業×所得×年齢。出生時状態への移送未検証。'),
      'POP_029':('partial_proxy','housing','所得×所有関係×人数の住宅調査断面。出生順位との同時分布なし。'),
      'LAB_003':('partial_proxy','industry','2022年有業者の性×年齢×主仕事所得×産業×正規雇用。出生日雇用契約ではない。'),
      'LAB_004':('partial_proxy','industry','非正規雇用分類。母親新生児コホートではない。'),
      'LAB_005':('partial_proxy','hours','週間時間階級から計算可能。時短制度利用率や出生時実働とは異なる。'),
      'LAB_006':('partial_proxy','industry;regional_industry','県×性×職業×産業。有業者分布を家庭へ移送。'),
      'LAB_007':('partial_proxy','jobs','職業×学歴×年齢×性×主仕事年間所得。'),
      'LAB_021':('partial_proxy','hours','実際の週労働時間階級・年間就業規則性。階級内点値は仮定、平均の点識別はない。'),
      'LAB_025':('acquired_not_implemented','ipss17_9-5','妊娠前から児1歳時の第1子就業継続・育休経路。出生当日の育休率ではない。'),
      'LAB_026':('acquired_not_implemented','ipss17_9-5','児1歳時継続情報。復職月のハザードは未取得。'),
      'LAB_027':('acquired_not_implemented','ipss17_9-3;ipss17_9-5','妊娠前就業・第1子出生後の歴史的経路。地域同時分布なし。'),
      'LAB_028':('partial_proxy','family_regional','6歳未満子ありの妻就業状態を使用。出生当日実働ではない。'),
      'LAB_029':('partial_proxy','family_regional','6歳未満子ありの夫就業状態を使用。'),
      'LAB_033':('partial_proxy','industry','産業・主仕事収益階級別自営業状態。'),
      'WAG_017':('partial_proxy','jobs','主な仕事からの年間収入・収益のみ。総個人税前所得・月給・副業とは区別。'),
      'WAG_019':('partial_proxy','family_base;family_regional','2022世帯所得階級。原表に従う世帯全体の所得。個人主仕事収益合計とは同義でない。'),
      'WAG_020':('partial_proxy','finance','2024年間可処分所得(OECD新基準)。2022総所得との世帯別結合は未検証。'),
      'WAG_021':('acquired_reference_only','finance_7-91','実際の第1十分位数。世帯類型などの条件ごとの断面、2026新生児家庭ではない。'),
      'WAG_022':('acquired_reference_only','finance_7-91','実際の中位数。分布を全国平均一点から生成しない。'),
      'WAG_023':('acquired_reference_only','finance_7-91','実際の第9十分位数。定義は年間可処分所得。'),
      'WAG_024':('partial_proxy','family_base;family_regional','親2人の有業組み合わせを実装。他の同居有業者は未モデル化。'),
      'WAG_025':('partial_proxy','family_base;family_regional','6歳未満子あり世帯の所得同時分布。'),
      'WAG_026':('partial_proxy','single_base;ess_r_153','母子世帯断面を単親の代理。非婚内出生=単親とは確定しない。'),
      'WAG_027':('acquired_not_implemented','ess_270;ess_r_152','副業有無の原表取得。個人所得に加算する処理未実装。'),
      'HOU_001':('partial_proxy','housing;housing_family','所得・人数・地域×所有関係と年齢家族類型全国表の接合。出生家庭完全同時分布なし。'),
      'HOU_004':('partial_proxy','housing_family','家族類型×主稼得者年齢×所得×所有×建て方。県補正推定。'),
      'HOU_005':('partial_proxy','housing_family','同上、共同住宅。'),
      'HOU_006':('acquired_reference_only','finance_3-19','床面積階級別の所得等集計。実世帯の面積抽選未実装。既存A1床面積参照を維持。'),
      'HOU_016':('partial_proxy','rents','2023年県×世帯所得×借家種別×月額家賃階級。専用住宅の借家に限定。'),
      'HOU_024':('acquired_not_implemented','finance_1-10','支出項目の原表取得。世帯別住宅ローン返済生成未実装。'),
      'FIN_020':('acquired_reference_only','finance_7-101-1','金融資産残高と純金融資産・純資産総額の四分位/十分位は区別。家庭の現金生成には未使用。'),
      'FIN_021':('acquired_reference_only','finance_7-101-1','預貯金分位点。総資産=預貯金と誤認しない。'),
      'FIN_022':('acquired_reference_only','finance_7-101-1','株式、有価証券別分位点。世帯同時残高未実装。'),
      'FIN_023':('acquired_reference_only','finance_7-101-1','住宅宅地資産の分位点。純資産総額生成と住居購入価格は異なる。'),
      'FIN_026':('acquired_reference_only','finance_7-101-1;finance','負債分位点と住宅ローン残高有無。元本残高の生成は未実装。'),
      'FIN_028':('acquired_reference_only','finance_7-101-1','住宅土地以外の負債及び月賦年賦の分位点。世帯残高の生成なし。')}
    budget_ids={'FIN_001':'210101','FIN_002':'210102','FIN_003':'210103','FIN_004':'21010703','FIN_005':'21010701','FIN_007':'210106','FIN_009':'210110015009','FIN_010':'210108','FIN_012':'210109','FIN_013':'210105','FIN_014':'210104','FIN_017':'2101'}
    for vid,item in budget_ids.items():mapping[vid]=('acquired_reference_only','finance_1-10:'+item,'2024年の夫婦+2歳以下の未婚子1人世帯の月間項目平均を抽出。地域分布・家庭別支出同時生成ではない。NULL項目はゼロにしない。')
    original=list(csv.DictReader((P/'04_variables.csv').open(encoding='utf-8-sig')));assert len(original)==634
    for x in original:
        vid=x['variable_id'];x.update(A2_status='inherited_A1_only'if x['acquisition_status']!='not_acquired_or_individually_verified'else'not_acquired_or_individually_verified',A2_reference='',A2_scope_note='',A2_priority='P0'if vid.startswith(('POP_','LAB_','WAG_','FIN_','HOU_'))else('P1'if vid.startswith(('EDU_','MED_','CST_','PRI_'))else'P2'),A2_next_action='原表の該当セル・定義・年次・粒度の対応確認を継続。未取得をゼロで補完しない。')
        if vid in mapping:
            status,ref,note=mapping[vid];x.update(A2_status=status,A2_reference=ref,A2_scope_note=note,A2_next_action='新生児コホートへの適用と未識別の接合を検証。取得済みと出生時生成への完全実装を区別。')
    csvwrite(P/'04_variables.csv',original)
    native=[]
    kernel_defs={
      'birth_pref':('出生児の県・母年齢・順位・性','件',2025,'観測','日本国内の日本人出生児'),
      'birth_municipal':('出生児の市区町村・母5歳階級・性','件',2025,'観測/行政親区集約','日本人出生、政令区を市へ非重複集約'),
      'birth_father':('婚内出生の父母年齢・順位','件',2025,'全国観測/県へ移送推定','婚内出生、4子以上父年齢階級を5子以上にも代理使用'),
      'birth_legal':('母年齢・順位・婚内非婚内','件',2025,'全国観測/県へ移送推定','婚内・非婚内出生。パートナー同居は別概念'),
      'birth_tail':('5子以上の詳細出生順位','件',2025,'全国観測/県へ移送推定','10子以上は開放階級'),
      'birth_father_2024':('父母年齢・順位の別年比較','件',2024,'検証参照','2025訓練とは別年だが2026を検証しない'),
      'family_base':('母年齢×祖父母同居×夫婦有業×世帯所得','世帯',2022,'観測断面/新生児へ移送推定','6歳未満子の夫婦世帯'),
      'family_regional':('地域×母年齢×祖父母同居×夫婦有業×所得','世帯',2022,'観測断面/5歳母年齢へ比率補正推定','県・主要都市の6歳未満子の夫婦世帯'),
      'single_base':('母子世帯の母年齢・有業・所得','世帯',2022,'代理推定','母子世帯。年齢不詳/疎セル全国へ後退'),
      'couple_pairs':('夫婦の学歴・個人主仕事所得ペア','世帯',2022,'観測断面/移送推定','共に有業の夫婦。新生児限定ではない'),
      'education_reference':('非就業親の学歴の代理','世帯',2022,'観測断面/条件不足の代理推定','6歳未満子あり親の教育。年齢別非就業親教育の同時分布不足'),
      'jobs':('性×年齢×学歴×職業×主仕事所得','人',2022,'観測断面/移送推定','全有業者。給与月額と年収収益を区別'),
      'industry':('性×年齢×主仕事所得×産業×雇用状態','人',2022,'観測断面/移送推定','階層小計差分で排他的雇用形態作成、丸め差あり'),
      'regional_industry':('県×性×職業×産業','人',2022,'観測断面/比率補正推定','完全な職業産業年齢所得同時分布は未識別'),
      'hours':('性×職業×主仕事所得×時間・就業規則性','人',2022,'観測断面/移送推定','出生時実働はNULL、有限階級内点値は仮定'),
      'housing':('県×所得×住宅所有×世帯人数','世帯',2023,'観測断面/移送推定','主世帯。最低既知人数で条件化、兄弟人数への変換禁止'),
      'housing_family':('家族×主稼得者年齢×所得×所有×建て方','世帯',2023,'観測断面/県比率補正推定','全国原表を県所有関係で補正'),
      'rents':('県×所得×借家種別×家賃','世帯/月円',2023,'観測断面/移送推定','借家専用住宅、区間生成、平均起点ではない'),
      'finance':('家族×可処分所得×純資産総額×住宅ローン有無','世帯/年円/円',2024,'観測断面/移送推定','大人1又は2+子供世帯、負債控除後NET資産'),
      'finance_region':('県×世帯主年齢×可処分所得×純資産','世帯',2024,'観測断面/比率補正推定','生成主稼得者年齢を世帯主年齢の代理に使用'),
      'region_family_mapping':('就業構造地域分類と行政コードの対応','分類',2022,'行政クロスウォーク','2025行政市名一致、東京23区は特別区部集団')}
    for name,(label,unit,year,kind,pop)in kernel_defs.items():
        vid='A2_'+name.upper();status='implemented_reference'if name.endswith('_2024')else'implemented_with_scope_limits';src='A2_VITAL'if name.startswith('birth')else('A2_HLS23'if name.startswith(('housing','rents'))else('A2_FIN24'if name.startswith('finance')else'A2_ESS22'))
        native.append({'variable_id':vid,'label':label,'definition':pop,'unit':unit,'observed_year':year,'requested_year':2026,'measurement_kind':kind,'status':status,'source_id':src,'implemented_reference':'family_stat_cell:'+name,'uncertainty':'出生時家庭の完全同時分布は未検証。観測断面と接合推定は別。','missing_policy':'NULL/unknown; finite bins keep bounds; no arbitrary tail points'})
        c.execute('INSERT OR REPLACE INTO variable_catalog VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(vid,label,name,pop,unit,'published cells','table-defined domain',pop,kind,'source-dependent','survey year',kind,status,src,None,'13_family/data/sources_A2.csv','newborn transport and stitched joint unvalidated','research generator'))
    fields=[
      ('CHILD_AGE','child.age_years','出生した基準児の満年齢','年','birth_pref','observed_birth_scenario','常に0'),
      ('CHILD_SEX','child.sex','県×母年齢×出生順位別の出生児性','カテゴリー','birth_pref','observed_joint_transport','5子以上詳細順位と性の県同時分布は未取得'),
      ('BIRTH_RANK','child.birth_rank','母の累積出生順位。10以上は区間','順位','birth_legal','observed_joint_transport','同居生存兄弟数ではない'),
      ('MOTHER_AGE','mother.age','母の満年齢','歳','birth_pref','observed_joint_transport','合併・開放年齢階級の点はNULL。細粒度入力は未識別として返す'),
      ('FATHER_AGE','father.age','同居パートナーとして扱う父年齢','歳','birth_father','national_conditional_transport','非婚内父年齢・パートナーとの同一性は未識別'),
      ('MOTHER_EDUCATION','mother.education','母の最終卒業教育又は在学不詳','カテゴリー','couple_pairs;jobs;education_reference','proxy_joint_transport','非就業者の年齢別教育同時分布不足'),
      ('FATHER_EDUCATION','father.education','父の最終卒業教育又は在学不詳','カテゴリー','couple_pairs;jobs;education_reference','proxy_joint_transport','配偶学歴相関は共に有業の夫婦に限定して直接観測'),
      ('MOTHER_JOB','mother.occupation_code','母の2022参考職業大分類','カテゴリー','jobs','proxy_joint_transport','出生日実職業確定ではない'),
      ('FATHER_JOB','father.occupation_code','父の2022参考職業大分類','カテゴリー','jobs','proxy_joint_transport','非就業者はNULL'),
      ('MOTHER_INCOME','mother.main_job_income','母の主仕事の税込年間収入・収益','年円','jobs;couple_pairs','proxy_joint_transport','新規就業の年換算推計を含む。家庭の2026現金収入ではない'),
      ('FATHER_INCOME','father.main_job_income','父の主仕事の税込年間収入・収益','年円','jobs;couple_pairs','proxy_joint_transport','有限区間内の整合的点配分はゲーム仮定'),
      ('PARTNER','partner_present','同居パートナーの有無','bool/NULL','birth_legal;family_base','assumption','婚内は既定true、非婚内は既定NULL。非婚内=単親ではない'),
      ('LEGAL_STATUS','legal_birth_status','婚内/非婚内の出生区分','カテゴリー','birth_legal','national_conditional_transport','出生区分と同居状態を分ける'),
      ('HOUSEHOLD_GROSS','household_income','ESSの親族世帯員の通常収入合計','年円','family_base;family_regional','observed_bins_transport','対象期間2021年10月〜2022年9月、現物・臨時所得等の定義は原表参照'),
      ('RENT','housing.monthly_rent','借家専用住宅の月額家賃','月円','rents','observed_bins_transport','2023基準。持ち家rent0にローンや修繕費は含まない'),
      ('SIZE','family.household_size','同居世帯人員の代理','人','housing','proxy_joint_transport','7人以上は開放。追加人数の続柄未識別'),
      ('TENURE','housing.tenure','所有・公営・UR公社・民営・給与住宅','カテゴリー','housing;housing_family','proxy_joint_transport','県所得別住宅所有比率で全国家族年齢同時表を補正'),
      ('GRANDPARENT_CO','family.co_resident_grandparent','夫婦・子供と親の同居類型','bool/NULL','family_base;family_regional','proxy_joint_transport','健康距離人数援助頻度を意味しない'),
      ('DISPOSABLE','finances.disposable_income_OECD','2024年間可処分所得OECD新基準','年円','finance','reference_joint_transport','総所得との異年接合未検証。税額を差額で計算しない'),
      ('NET_ASSETS','finances.net_total_assets','純金融資産+住宅宅地評価額のNET資産','円','finance','reference_joint_transport','現金ではない。最下位の負値開放帯と上位開放帯は点NULL'),
      ('MORTGAGE_ANY','finances.mortgage_present_any_property','住宅土地ローン残高の有無','bool','finance','reference_joint_transport','現住居以外の物件の負債もある。借家ならfalseと確定しない'),
      ('MUNICIPALITY','municipality_code','2025母年齢別出生数で選ぶ行政市区町村','5桁文字列','birth_municipal','observed_conditional_transport','2022地域家庭統計は主要都市・県。残余自治体内の所得差は未識別'),
      ('ANONYMOUS_AREA','region_context.living_environment','2020非重複小地域を基にした匿名生活圏','地域参照','A1_SMALLAREA','estimate_transport','2020年6歳未満子の重み。出生家庭の町丁目住所ではない')]
    schemas=[]
    for id,path,label,unit,ref,kind,note in fields:
        schemas.append({'json_path':path,'definition':label,'unit':unit,'reference':ref,'measurement_kind':kind,'uncertainty':note,'missing_policy':'NULL/interval; never invented mean or automatic zero'})
        native.append({'variable_id':'A2_FIELD_'+id,'label':label,'definition':note,'unit':unit,'observed_year':'2025'if ref.startswith('birth')else('2023'if ref.startswith(('rents','housing'))else('2024'if ref=='finance'else'2022 or source-specific')),'requested_year':2026,'measurement_kind':kind,'status':'implemented_with_scope_limits','source_id':ref,'implemented_reference':path,'uncertainty':note,'missing_policy':'NULL/interval; reference years retained'})
        c.execute('INSERT OR REPLACE INTO variable_catalog VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('A2_FIELD_'+id,label,path,note,unit,None,None,'source-defined reference populations',kind,'source-dependent','reference year',kind,'implemented_with_scope_limits',None,None,ref,note,'generated output field'))
    (ROOT/'data/output_schema.json').write_text(json.dumps(schemas,ensure_ascii=False,indent=2))
    gaps=[('CURRENT_LEAVE','出生当日の育児休業','ipss17_9-5','児1歳時就業遷移は取得したが出生時の条件付き発生と継続月数未実装'),('SIBLING_AGES','同居兄弟数・年齢','vital2025_7;ess_r_152','母の累積出生順位は生存同居兄弟数ではない'),('CASH','現金預貯金残高','finance_7-101-1','分位点取得、所得住宅家族と結合する残高同時分布未取得'),('DEBT','金融負債残高','finance_7-101-1','負債区分の分位点取得、生成未実装'),('TAX','税社会保険負担','finance_3-32-1','集計控除推計は個人別法制度エンジンではない'),('HOUSE_PRICE','住宅取得価格','未取得','住宅資産評価額と購入価格は異なる'),('FLOOR_AREA','住戸面積','finance_3-19','原表取得、世帯生成との接合未実装'),('GRANDPARENT_HELP','出生日の祖父母育児援助','ipss17_9-11','第一子3歳までの累積援助は現在支援フラグではない'),('FOREIGN_BIRTH','外国籍を含む全出生家庭','vital2025_4-33','補助原表取得、出生家族属性モデル統合未実装'),('DELIVERY_WEIGHT','同一出産世帯単位の抽選','vital2025_10','複産原表取得、現版は出生児単位'),('REGION_COST','地域物価生活費保育通勤','A1原表;finance_1-10','A1地域参照を維持、家庭別生活費同時生成未実装'),('INCOME_2026','2026名目所得・家賃補正','未モデル化','2026年間実績は未観測。元年価格で保持し、勝手な倍率補正をしない')]
    for id,label,src,note in gaps:native.append({'variable_id':'A2_'+id,'label':label,'definition':note,'unit':'未確定/原表依存','observed_year':'source-specific','requested_year':2026,'measurement_kind':'未実装','status':'acquired_not_implemented'if src!='未取得'else'not_acquired','source_id':src,'implemented_reference':'NULL','uncertainty':note,'missing_policy':'NULL; not zero'})
    csvwrite(ROOT/'data/variables_A2.csv',native);csvwrite(ROOT/'data/expanded_variable_catalogue.csv',[{**x,'catalogue_namespace':'original_634'}for x in original]+[{**x,'catalogue_namespace':'A2_native'}for x in native]);csvwrite(ROOT/'data/backlog.csv',[{k:x[k]for k in['variable_id','変数候補','acquisition_status','A2_status','A2_reference','A2_scope_note','A2_priority','A2_next_action']}for x in original if x['A2_status']!='implemented_reference']+[{'variable_id':x['variable_id'],'変数候補':x['label'],'A2_status':x['status'],'A2_scope_note':x['definition'],'A2_priority':'P0','A2_next_action':'該当同時分布・アクセス可否・代替モデルを調査し、NULLを根拠ある実装へ更新'}for x in native if x['measurement_kind']=='未実装'])
    for x in native:
        if x['measurement_kind']!='未実装':continue
        c.execute('INSERT OR REPLACE INTO variable_catalog VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(x['variable_id'],x['label'],x['variable_id'],x['definition'],x['unit'],None,None,'Unidentified newborn household condition','unimplemented','unresolved','unresolved','unimplemented',x['status'],None,None,x['source_id'],x['uncertainty'],'pending research and implementation'))
    coverage={'original_candidate_count':len(original),'original_A1_mapped':sum(x['acquisition_status']!='not_acquired_or_individually_verified'for x in original),'original_A1_unmapped':548,'A2_original_candidate_status':dict(collections.Counter(x['A2_status']for x in original)),'A2_added_variable_count':len(native),'total_expanded':len(original)+len(native),'raw_acquisitions':len(acq),'raw_downloaded':sum(x['status']=='downloaded'for x in acq.values()),'raw_failed':sum(x['status']!='downloaded'for x in acq.values()),'model_cell_count':c.execute('SELECT count(*) FROM family_stat_cell').fetchone()[0],'A1_observations_preserved':c.execute('SELECT count(*) FROM observation').fetchone()[0],'remaining_all634_individual_source_review_complete':False}
    (ROOT/'data/coverage_summary.json').write_text(json.dumps(coverage,ensure_ascii=False,indent=2));c.commit();c.close();print(coverage)
if __name__=='__main__':build()
