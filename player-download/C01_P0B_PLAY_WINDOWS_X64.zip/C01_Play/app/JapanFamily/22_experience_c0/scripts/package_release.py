"""Three content-addressed packs; no copy of inherited multi-GB research history."""
import hashlib,json,platform,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;REPO=PROJECT.parent;OUT=REPO/'artifacts'
COMPONENTS=['08_sampler','13_family','15_initial_state','16_recovery','18_monthly_v02','19_child_b10','20_integrated_b10','21_child_b11']
def sha(path):
 with path.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def inherited():
 files=[]
 for name in COMPONENTS:
  base=PROJECT/name
  files.extend(p for p in base.rglob('*.py') if not any(x in p.parts for x in ['results','__pycache__']))
  # Compiled parameters, schemas and evidence ledgers; do not republish raw full papers.
  files.extend(p for p in (base/'data').glob('*') if p.is_file() and p.suffix in ['.json','.csv','.gz'])
  files.extend(p for p in base.glob('*.md'))
  files.extend(p for p in (base/'docs').glob('*.md'))
 files.append(PROJECT/'data/future_prefecture_reference_2026_2046.csv')
 return sorted(set(files))
def listing(files):return {str(p.relative_to(REPO)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(set(files))}
def main():
 OUT.mkdir(exist_ok=True)
 source=inherited();(ROOT/'data/inherited_runtime_manifest.json').write_text(json.dumps({'scope':'unchanged executable subset and compiled statistical kernels; original research assets remain separately pinned','files':listing(source)},ensure_ascii=False,indent=2))
 code=[];data=[]
 for p in ROOT.rglob('*'):
  if not p.is_file()or '__pycache__'in p.parts or 'runtime'in p.relative_to(ROOT).parts or p.suffix=='.pyc':continue
  if p.name=='runtime_region.sqlite':continue
  if p.name in ['C0_RELEASE_VERIFICATION.json','server.log','independent_browser.log','independent_tests.log','packaging.log','release_verification.log']:continue
  if p.name in ['research_checkpoint.json.gz','player_history.json.gz']:data.append(p)
  else:code.append(p)
 code.extend(source)
 manifests={'CODE':listing(code),'RUNTIME_DATA':listing([ROOT/'data/runtime_region.sqlite']),'EXPERIENCE_DATA':listing(data)}
 bundle='C0-'+hashlib.sha256(json.dumps(manifests,sort_keys=True).encode()).hexdigest()[:32]
 artifacts=[]
 for kind,files in manifests.items():
  name={'CODE':'C0_CODE_AND_REPORTS.zip','RUNTIME_DATA':'C0_RUNTIME_DATA.zip','EXPERIENCE_DATA':'C0_EXPERIENCE_DATA.zip'}[kind]
  manifest={'bundle_id':bundle,'version':'C-0.1-experience','kind':kind,'files':files,'all_tree_sha256':hashlib.sha256(json.dumps(manifests,sort_keys=True).encode()).hexdigest(),
            'other_pack_trees':{k:hashlib.sha256(json.dumps(v,sort_keys=True).encode()).hexdigest()for k,v in manifests.items() if k!=kind},
            'python':platform.python_version(),'scientific_external_validity':False,'actual_user_test':False}
  path=OUT/name
  with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True)as z:
   for file in files:z.write(REPO/file,file)
   z.writestr('C0_'+kind+'_MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2))
  artifacts.append({'filename':name,'bytes':path.stat().st_size,'sha256':sha(path),'payload_files':len(files)})
  print('SAVED',name,path.stat().st_size,flush=True)
 meta={'bundle_id':bundle,'archives':artifacts,'legacy_preservation_pins':json.loads((ROOT/'data/baseline_pins.json').read_text()),
       'strategy':'Unchanged original assets retained in workspace and original releases. Only runtime row projection and new C0 paths redistributed; no inherited full histories copied.'}
 (OUT/'C0_ARCHIVES.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));(OUT/'C0_SHA256SUMS.txt').write_text(''.join(r['sha256']+'  '+r['filename']+'\n'for r in artifacts))
 print('BUNDLE',bundle,flush=True)
if __name__=='__main__':main()
