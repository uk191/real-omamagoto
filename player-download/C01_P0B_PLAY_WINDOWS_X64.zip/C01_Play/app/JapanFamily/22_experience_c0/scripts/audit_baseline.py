import hashlib,json,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent;REPO=PROJECT.parent

def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def collect():
 pins=json.loads((PROJECT/'21_child_b11/data/baseline_pins.json').read_text())
 for p in sorted((PROJECT/'21_child_b11/child_b11').glob('*.py')):pins.append({'path':str(p.relative_to(REPO)),'sha256':sha(p)})
 p=PROJECT/'21_child_b11/data/parameters.json';pins.append({'path':str(p.relative_to(REPO)),'sha256':sha(p)})
 archives=json.loads((REPO/'artifacts/B1.1_ARCHIVES.json').read_text())['archives']
 for entry in archives:
  p=REPO/'artifacts'/entry['filename'];assert sha(p)==entry['sha256'];pins.append({'path':str(p.relative_to(REPO)),'sha256':entry['sha256']})
 for row in pins:assert sha(REPO/row['path'])==row['sha256'],row['path']
 return pins
if __name__=='__main__':
 pins=collect();(ROOT/'data/baseline_pins.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2));print('PRESERVED_PINS',len(pins))
