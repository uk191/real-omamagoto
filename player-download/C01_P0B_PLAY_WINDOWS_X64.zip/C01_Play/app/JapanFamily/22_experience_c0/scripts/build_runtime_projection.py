"""Lossless SQL row projection needed by unchanged A1/A2 execution, not a new sampler."""
import hashlib,json,sqlite3,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];PROJECT=ROOT.parent
SRC=PROJECT/'data/region.sqlite';DST=ROOT/'data/runtime_region.sqlite'
TABLES={'source_catalog':None,'artifact':None,'dataset_catalog':None,'variable_catalog':None,
        'geo_unit':None,'functional_area':None,'area_membership':None,
        'smallarea_record':None,'observation':"source_id IN ('CENSUS25','CFA26','CPI25')"}

def sha(path):
    with path.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def fingerprint(db,table,where=None):
    h=hashlib.sha256();n=0
    query='SELECT * FROM "'+table+'"'+(' WHERE '+where if where else '')+' ORDER BY rowid'
    for row in db.execute(query):h.update((json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n').encode());n+=1
    return {'rows':n,'sha256':h.hexdigest()}
def main():
    if DST.exists():raise SystemExit('Projection already exists; preserve and verify it rather than overwrite')
    src=sqlite3.connect('file:'+str(SRC)+'?mode=ro',uri=True);db=sqlite3.connect(DST);db.execute('PRAGMA foreign_keys=OFF');db.execute('ATTACH DATABASE ? AS original',(str(SRC),));result=[]
    for table,where in TABLES.items():
        sql=src.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone()[0];db.execute(sql)
        db.execute('INSERT INTO main."'+table+'" SELECT * FROM original."'+table+'"'+(' WHERE '+where if where else '')+' ORDER BY rowid')
        expected=fingerprint(src,table,where);actual=fingerprint(db,table);assert actual==expected,table
        result.append({'table':table,'selection':where or 'all rows','original_selected':expected,'projection':actual});print(table,expected['rows'],flush=True)
    for sql, in src.execute("SELECT sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL AND tbl_name IN ("+','.join('?'for _ in TABLES)+')',tuple(TABLES)):db.execute(sql)
    db.commit();assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';fk=db.execute('PRAGMA foreign_key_check').fetchall();assert not fk,fk[:3];db.close();src.close()
    manifest={'source':str(SRC.relative_to(PROJECT.parent)),'source_sha256':sha(SRC),'projection_sha256':sha(DST),'projection_bytes':DST.stat().st_size,'tables':result,'unrelated_old_tables_not_copied':True,'scope':'runtime query projection only, not replacement for full research/provenance DB','foreign_keys':True}
    (ROOT/'data/runtime_projection_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));DST.chmod(0o444);print('PROJECTION',DST.stat().st_size,flush=True)
if __name__=='__main__':main()
