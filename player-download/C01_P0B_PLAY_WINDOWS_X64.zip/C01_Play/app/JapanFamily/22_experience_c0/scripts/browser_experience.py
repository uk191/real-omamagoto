"""Real browser clicks, network whitelist inspection, save/reload, 24-month finish."""
import argparse
import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:8780');args=parser.parse_args()
    screenshots=ROOT/'results/screenshots';screenshots.mkdir(parents=True,exist_ok=True)
    errors=[];responses=[];commands=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1)
        page.on('pageerror',lambda e:errors.append(str(e)))
        def capture(response):
            if '/api/' in response.url and response.status==200:
                data=response.json(); serialized=json.dumps(data,ensure_ascii=False)
                for key in ['latent_state','initial_dispositions','probabilities','transition_parameters','growth_z','sleep_rank','A_forecast']:
                    assert key not in serialized,key
                responses.append({'path':response.url.split('?')[0].replace(args.url,''),'sha256':hashlib.sha256(serialized.encode()).hexdigest()})
        page.on('response',capture)
        def click_command(selector):
            with page.expect_response(lambda r:r.url.endswith('/api/command') and r.request.method=='POST') as reply:page.click(selector)
            result=reply.value.json();assert reply.value.status==200,result
            expect(page.locator('body')).to_have_attribute('aria-busy','false')
            commands.append({'selector':selector,'age_months':result['view']['age_months'],'revision':result['view']['revision']})
            return result
        def shot(name):
            expect(page.locator('#notice')).not_to_be_visible(timeout=8000)
            page.screenshot(path=str(screenshots/name),full_page=True)
        page.goto(args.url);page.locator('.start-details > summary').click()
        page.fill('[name=seed]','C0-browser-full');page.fill('[name=child_name]','あお')
        page.fill('[name=mother_age]','32');page.fill('[name=father_age]','35')
        page.select_option('[name=mother_employed]','true');page.select_option('[name=father_employed]','true')
        page.click('#start-button');expect(page.locator('#game')).to_be_visible()
        click_command('[data-observe="observe"]')
        page.select_option('#action-kind','apply_child_allowance');queued=click_command('#queue-action')
        assert queued['view']['date']=='2026-10-01' and len(queued['view']['queued_requests'])==1
        pause_count=0;saved_view=None
        for month in range(1,25):
            if month==4:
                page.select_option('#action-kind','apply_childcare');click_command('#queue-action')
            if month==7:
                page.select_option('#action-kind','request_relative_support');click_command('#queue-action')
            if month==13:
                page.select_option('#action-kind','set_spending');page.select_option('#action-value','0.9');click_command('#queue-action')
            if page.locator('#review-label').is_visible():
                pause_count+=1
                if pause_count==1:shot('05_decision_pause_desktop.png')
                page.check('#reviewed')
            data=click_command('#advance');expect(page.locator('#age-months')).to_have_text(str(month))
            if month==12:
                shot('06_child_month12_desktop.png');page.click('[data-tab=life]');shot('07_household_month12_desktop.png');page.click('[data-tab=child]')
                saved=click_command('#save');saved_view=saved['view']
                page.reload();expect(page.locator('#age-months')).to_have_text('12')
                sid=page.evaluate('localStorage.getItem("c0.session")')
                assert page.request.get(args.url+'/api/session',params={'sid':sid}).json()['view']==saved_view
                page.click('#open-saves');expect(page.locator('#saves-dialog')).to_be_visible();shot('08_saved_record_dialog.png')
                page.locator('[data-load]').first.click();expect(page.locator('#saves-dialog')).not_to_be_visible()
                expect(page.locator('#age-months')).to_have_text('12')
            if month==18:
                page.select_option('#observer','father');expect(page.locator('#child-caption')).to_contain_text('父')
                page.select_option('#observer','mother');expect(page.locator('#child-caption')).to_contain_text('母')
        assert data['view']['finished']
        shot('09_child_month24_desktop.png');page.click('#advance');expect(page.locator('#tab-album')).to_be_visible()
        expect(page.locator('.album-item')).to_have_count(24);page.locator('.album-item').last.locator('summary').click();shot('10_album_month24_desktop.png')
        page.click('[data-tab=child]');page.set_viewport_size({'width':390,'height':844});shot('11_child_month24_mobile.png')
        assert not page.evaluate('document.documentElement.scrollWidth>window.innerWidth')
        for path in ['/runtime/saves/','/c0/game.py','/../21_child_b11/data/parameters.json','/api/internal','/data/runtime_region.sqlite']:
            assert page.request.get(args.url+path).status==404,path
        assert page.request.post(args.url+'/api/start',data={'seed':'evil'}).status==403
        assert page.request.post(args.url+'/api/start',headers={'X-C0-Client':'browser-v1','Origin':'https://invalid.example'},data={'seed':'evil'}).status==403
        assert not errors,errors
        result={'kind':'developer scenario inspection; not actual user testing','browser':browser.version,'finished_months':24,'saved_reloaded_month':12,
                'pause_reviews':pause_count,'commands':commands,'public_response_checks':responses,'page_errors':errors,
                'no_horizontal_overflow_390px':True,'private_routes_blocked':True,'csrf_checks':True,'screenshots':sorted(p.name for p in screenshots.glob('*.png'))}
        (ROOT/'results/browser_experience.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));browser.close()
        print('BROWSER_EXPERIENCE_PASS',24,len(commands),len(responses))
if __name__=='__main__':main()
