"""Ten selected native families + decision/child comparisons; developer inspection."""
import copy,gzip,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from c0.bridge import make_engine,digest
from c0.game import Game

CASES=[
 {'key':'tokyo_dual','label':'東京都・共働きの参照家庭','pref':'13','conditions':{'mother_employed':True,'father_employed':True,'mother_age':32,'father_age':35,'birth_rank':1},'criterion':'employee_mother'},
 {'key':'chiba_leave','label':'千葉県・育休を希望する家庭','pref':'12','conditions':{'mother_employed':True,'father_employed':True,'birth_rank':1},'criterion':'employee_mother'},
 {'key':'single_mother','label':'北海道・母と子の参照家庭','pref':'01','conditions':{'partner_present':False,'legal_status':'nonmarital','mother_employed':True,'birth_rank':1}},
 {'key':'low_reference_income','label':'沖縄県・通常世帯年収200万円の参照条件','pref':'47','conditions':{'household_income_yen':2000000,'mother_employed':False,'father_employed':True}},
 {'key':'higher_reference_income','label':'神奈川県・通常世帯年収1500万円の参照条件','pref':'14','conditions':{'household_income_yen':15000000,'mother_employed':True,'father_employed':True}},
 {'key':'support_available','label':'大阪府・親族等の支援が得られる想定','pref':'27','conditions':{'mother_employed':True,'father_employed':True},'scenario':{'relative_available_probability':1.,'relative_hours':24}},
 {'key':'support_unavailable','label':'熊本県・親族等の支援が得られない想定','pref':'43','conditions':{'mother_employed':True,'father_employed':True},'scenario':{'relative_available_probability':0.}},
 {'key':'regional_household','label':'長野県の参照家庭','pref':'20','conditions':{'mother_employed':True,'father_employed':True}},
 {'key':'one_usual_earner','label':'秋田県・母は通常無業の参照条件','pref':'05','conditions':{'mother_employed':False,'father_employed':True}},
 {'key':'grandparent_reference','label':'山梨県・同居祖父母の統計参照フラグがある家庭','pref':'19','conditions':{'mother_age':33,'father_age':35},'criterion':'grandparent_reference'},
]

def selected(engine,case):
 attempts=[]
 for i in range(100):
  seed='C0-experience/'+case['key']+'/'+str(i)
  try:g=Game.start(engine,prefecture_code=case['pref'],conditions=case.get('conditions'),seed=seed,research_scenario=case.get('scenario'))
  except ValueError as e:
   attempts.append({'seed':seed,'accepted':False,'generation_error':str(e)});continue
  criterion=case.get('criterion');ok=True
  if criterion=='employee_mother':ok=g.core.a['parents']['mother']['employee_contract']
  if criterion=='grandparent_reference':ok=bool(g.core.a['household']['reference_co_resident_grandparent'])
  attempts.append({'seed':seed,'accepted':ok,'selection_criterion':criterion})
  if ok:return g,attempts
 raise ValueError('Representative selection not supported: '+case['key'])

def record(game,folder,label):
 folder.mkdir(parents=True,exist_ok=True);game.save(folder/'research_checkpoint.json.gz')
 rows=[{'turn':r['turn'],'start':r['start'],'end':r['end'],'age_months':r['age_months'],
        'child':r['views']['mother']['child'],'household':r['views']['mother']['household'],
        'decisions':r['decisions'],'pauses':r['pauses']}for r in game.turns]
 with gzip.open(folder/'player_history.json.gz','wt',encoding='utf-8')as f:json.dump(rows,f,ensure_ascii=False,separators=(',',':'))
 lines=['# '+label,'開発者による実シミュレーションのシナリオ検査。実ユーザーテストではありません。']
 for r in rows:
  lines.extend([f'\n## {r["end"]}（{r["age_months"]}か月）','\n'.join(c['text']for c in r['child']['cards']),
                '\n'.join(x['text']for x in r['decisions']),
                '仕事：'+' / '.join(p['name']+' '+p['status']for p in r['household']['parents']),
                '保育：'+r['household']['care']['status'],
                '確認事項：'+' / '.join(p['text']for p in r['pauses'])])
 (folder/'player_history.md').write_text('\n\n'.join(lines))
 return rows

def play(g,policy='standard'):
 while not g.finished:
  n=g.core.a['elapsed_months']
  if n==0:
   g.request('apply_child_allowance')
   if policy in ['early_return','late_return']:
    g.request('take_leave',person='mother');g.request('request_return',person='mother',value=6 if policy=='early_return' else 12)
   if policy=='relative_support':g.request('request_relative_support')
   if policy=='budget_low':g.request('set_spending',value=.8)
   if policy=='budget_high':g.request('set_spending',value=1.1)
  if policy=='standard':
   if n==3:g.request('apply_childcare')
   if n==6:g.request('request_relative_support')
   if n==9 and g.core.a['parents']['mother'].get('contract_active'):g.request('request_hours',person='mother',value=.75)
   if n==12:g.request('set_spending',value=.9)
  if (policy=='early_return'and n==3)or(policy=='late_return'and n==9):g.request('apply_childcare')
  if n in [0,3,6,9,12,18,21]:g.observe({0:'observe',3:'shared_play',6:'offer_comfort',9:'observe',12:'shared_play',18:'offer_comfort',21:'observe'}[n])
  # Explicit developer acknowledgement of unresolved issues, recorded per turn.
  g.advance(reviewed=True)
 return g

def biology(g):return {k:g.core.child._state[k]for k in ['physical_health','latent_state','developmental_state','emotion_regulation','sleep']}

def main():
 engine=make_engine();out=ROOT/'results/scenarios';out.mkdir(exist_ok=True);summaries=[];starts={};started=time.time()
 for case in CASES:
  g,selection=selected(engine,case);starts[case['key']]=g.clone();play(g);rows=record(g,out/case['key'],case['label']);assert len(rows)==24 and g.core.elapsed_months==24
  summary={'case':case,'selection':selection,'household_id':g.core.identity['household_id'],'seed':g.config['seed'],'turns':len(g.turns),'player_months':24,
           'pending_periods':sum(bool(r['pauses'])for r in g.turns),'cash_shortage_periods':sum(any(p['kind']=='cash_shortage'for p in r['pauses'])for r in g.turns),
           'observations':sum(r['views']['mother']['child']['report_count']for r in g.turns),
           'caregiver_ids':g.core.identity['caregiver_local_ids'],'grandparent_reference_flag':g.core.a['household']['reference_co_resident_grandparent'],
           'actual_grandparent_individual_support_model':False,'final_core_sha256':digest(g.core.payload())};summaries.append(summary);print('CASE',case['key'],summary['pending_periods'],flush=True)
 # Three native decision comparisons. No invented child causal effects.
 comparisons=[]
 for casekey,policies in [('tokyo_dual',['early_return','late_return']),('support_available',['relative_support','no_relative_support']),('low_reference_income',['budget_low','budget_high'])]:
  branches={p:play(starts[casekey].clone(),p)for p in policies}
  for p,g in branches.items():record(g,out/'comparisons'/casekey/p,casekey+' / '+p)
  a,b=branches.values();Aeq=a.core.a==b.core.a;Beq=biology(a)==biology(b)
  pair={'case':casekey,'policies':policies,'same_initial_family':True,'same_initial_child':True,'A_final_equal':Aeq,'B_biology_equal':Beq,
        'B_parent_observations_equal':a.core.child._state['parent_observations']==b.core.child._state['parent_observations'],
        'native_model_changes':{p:{'cash_yen':g.core.a['accounts'].get('cash',0),'consumption_total':sum(r['A_month']['consumption']for r in g.core.a_periods),
                                  'mother_weekly_work_by_period':[r['A_month']['time']['parents']['mother']['work']for r in g.core.a_periods],
                                  'relative_hours_by_period':[r['A_month']['time']['relative']for r in g.core.a_periods],
                                  'care_status_by_period':[r['A_month']['care']['status']for r in g.core.a_periods]}for p,g in branches.items()},
        'empirical_causal_effect':False,'effects_policy':'B hypothetical treatment effects disabled; finance/time effects are native A scenario results'};comparisons.append(pair)
 assert all(r['B_biology_equal']for r in comparisons)
 # Same family, different random children, shared household policy.
 children=[]
 for seed in [3301,3302,3303]:
  g=Game.start(engine,prefecture_code='13',seed='C0-child-comparison',child_seed=seed,conditions={'mother_employed':True,'father_employed':True});play(g);record(g,out/'children'/str(seed),'同じ家庭・異なる子ども '+str(seed));children.append(g)
 assert all(g.core.a==children[0].core.a for g in children)
 childcomp={'same_A_household_and_policy':True,'children':3,'different_internal_final_states':len({digest(biology(g))for g in children}),
            'different_observed_histories':len({digest(g.core.child._state['parent_observations'])for g in children}),
            'observations_by_signal':{str(g.config['child_seed']):{k:sum(r['behaviors'].get(k,False)for r in g.core.child.player_view(g.core.identity['person_links']['mother'])['observations'])for k in ['orients_to_unfamiliar_object','difficulty_settling','explores_available_space','takes_independent_steps','uses_contextual_word']}for g in children},
            'not_only_random_wording':True,'external_behavior_validity':False}
 (out/'summary.json').write_text(json.dumps({'families':summaries,'unique_households':len({r['household_id']for r in summaries}),'decision_comparisons':comparisons,'child_comparison':childcomp,'seconds':time.time()-started,'actual_user_test':False},ensure_ascii=False,indent=2));print('EXPERIENCE_DONE',len(summaries),flush=True)
if __name__=='__main__':main()
