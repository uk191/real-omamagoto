#!/usr/bin/env bash
set -euo pipefail
C0_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
C0_PORT="${C0_PORT:-8780}"
export C0_PORT
if python - <<'PY'
import json,os,sys,urllib.request
try:
 data=json.load(urllib.request.urlopen('http://127.0.0.1:'+os.environ['C0_PORT']+'/api/health',timeout=1))
 sys.exit(0 if data.get('version')=='C-0.1-experience' else 1)
except OSError:sys.exit(1)
PY
then
  echo "C-0 is already ready on port $C0_PORT"
  exit 0
fi
mkdir -p "$C0_ROOT/runtime"
nohup python "$C0_ROOT/server.py" --port "$C0_PORT" > "$C0_ROOT/runtime/server.log" 2>&1 &
C0_SERVER_PID=$!
echo "$C0_SERVER_PID" > "$C0_ROOT/runtime/server-$C0_PORT.pid"
for C0_ATTEMPT in $(seq 1 100); do
  if ! kill -0 "$C0_SERVER_PID" 2>/dev/null; then
    echo "C-0 startup failed; inspect $C0_ROOT/runtime/server.log" >&2
    exit 1
  fi
  if python - <<'PY'
import json,os,sys,urllib.request
try:
 data=json.load(urllib.request.urlopen('http://127.0.0.1:'+os.environ['C0_PORT']+'/api/health',timeout=.5))
 sys.exit(0 if data.get('ok') else 1)
except OSError:sys.exit(1)
PY
  then
    echo "C-0 ready on port $C0_PORT; PID $C0_SERVER_PID"
    exit 0
  fi
  sleep .1
done
echo "C-0 startup timed out; inspect $C0_ROOT/runtime/server.log" >&2
exit 1
