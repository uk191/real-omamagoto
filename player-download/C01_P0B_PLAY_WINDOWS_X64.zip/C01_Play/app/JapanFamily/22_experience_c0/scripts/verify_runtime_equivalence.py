"""Exact full-state comparison using both DB backends; requires preserved original."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from c0.bridge import make_engine,digest
from c0.game import Game
native=make_engine();portable=make_engine(ROOT/'data/runtime_region.sqlite');rows=[]
for p in range(1,48):
 code=f'{p:02d}';seed='C0-runtime-equivalence/'+code
 a=Game.start(native,prefecture_code=code,seed=seed);b=Game.start(portable,prefecture_code=code,seed=seed)
 assert a.snapshot()==b.snapshot(),(code,'birth')
 for month in range(24):
  a.advance(reviewed=True);b.advance(reviewed=True)
  assert a.snapshot()==b.snapshot(),(code,month+1)
 rows.append({'prefecture':code,'seed':seed,'checked_birth_and_periods':25,'native_full_DB_equals_projection_birth_through24months':True,'sha256':digest(a.snapshot())})
 print('RUNTIME_MATCH',code,flush=True)
(ROOT/'results/runtime_equivalence_47.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
