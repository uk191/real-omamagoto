import json,time,urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
for attempt in range(100):
 try:
  assert json.load(urllib.request.urlopen('http://127.0.0.1:8780/api/health',timeout=.5))['ok'];break
 except OSError:time.sleep(.1)
else:raise RuntimeError('C0 server not ready')
with sync_playwright()as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':1440,'height':1050},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto('http://127.0.0.1:8780');page.screenshot(path=str(ROOT/'results/screenshots/01_start_desktop.png'),full_page=True)
 page.locator('.start-details > summary').click();page.fill('[name=seed]','C0-browser-smoke');page.fill('[name=child_name]','はる');page.click('#start-button');page.wait_for_selector('#game:not([hidden])');page.click('[data-observe="observe"]');page.wait_for_timeout(350);page.click('#advance');expect(page.locator('#age-months')).to_have_text('1');expect(page.locator('#notice')).not_to_be_visible(timeout=8000);page.screenshot(path=str(ROOT/'results/screenshots/02_child_month1_desktop.png'),full_page=True)
 page.click('[data-tab=life]');page.screenshot(path=str(ROOT/'results/screenshots/03_household_month1_desktop.png'),full_page=True)
 page.click('[data-tab=child]');page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(ROOT/'results/screenshots/04_child_mobile.png'),full_page=True)
 assert not page.evaluate('document.documentElement.scrollWidth>window.innerWidth')
 (ROOT/'results/browser_smoke.json').write_text(json.dumps({'page_errors':errors,'screenshots':4,'browser':b.version,'kind':'developer browser scenario inspection, not user test'},ensure_ascii=False,indent=2));b.close()
 assert not errors,errors
