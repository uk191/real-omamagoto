"""Independently inspect saved ZIP bytes and execute a clean extracted application."""
import argparse,gzip,hashlib,json,os,shutil,socket,sqlite3,subprocess,sys,tempfile,time,urllib.request,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];REPO=ROOT.parent.parent;ART=REPO/'artifacts'
def sha(path):
 with path.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--keep',type=Path);args=parser.parse_args()
 meta=json.loads((ART/'C0_ARCHIVES.json').read_text());dest=args.keep or Path(tempfile.mkdtemp(prefix='c0_saved_release_',dir='/tmp'));dest.mkdir(parents=True,exist_ok=True)
 result={'bundle_id':meta['bundle_id'],'kind':'independent saved ZIP execution in separate directory, same host','archives':[],'scientific_external_validity':False,'actual_user_test':False}
 for item in meta['archives']:
  path=ART/item['filename'];assert sha(path)==item['sha256'];assert path.stat().st_size==item['bytes']
  with zipfile.ZipFile(path)as z:
   assert z.testzip()is None
   manifest=json.loads(z.read(next(n for n in z.namelist()if n.startswith('C0_')and n.endswith('_MANIFEST.json'))));assert manifest['bundle_id']==meta['bundle_id']
   for name in z.namelist():assert not name.startswith('/')and '..'not in Path(name).parts
   z.extractall(dest)
   for name,v in manifest['files'].items():assert sha(dest/name)==v['sha256'],name
  result['archives'].append({**item,'crc':True,'file_sha256':True})
 extracted=dest/'JapanFamily/22_experience_c0';assert not(dest/'JapanFamily/data/region.sqlite').exists()
 m=json.loads((extracted/'data/runtime_projection_manifest.json').read_text());dbpath=extracted/'data/runtime_region.sqlite';assert sha(dbpath)==m['projection_sha256']
 db=sqlite3.connect('file:'+str(dbpath)+'?mode=ro',uri=True);assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not db.execute('PRAGMA foreign_key_check').fetchall()
 sys.path.insert(0,str(extracted/'scripts'));from build_runtime_projection import fingerprint
 for row in m['tables']:assert fingerprint(db,row['table'])==row['projection']
 db.close();result['runtime_sqlite']={'integrity':'ok','foreign_key_violations':0,'selected_table_fingerprints':len(m['tables']),'sha256':sha(dbpath)}
 env=os.environ.copy();env.pop('PYTHONPATH',None)
 testlog=ROOT/'results/independent_tests.log'
 with testlog.open('w')as f:
  subprocess.run([sys.executable,'-m','unittest','discover','-s',str(extracted/'tests'),'-v'],cwd=dest,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 # Clean subprocess: it cannot accidentally reuse imported source-workspace modules.
 checkcode='''import gzip,json,sys
from pathlib import Path
root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from c0.bridge import make_engine,digest
from c0.game import Game
engine=make_engine();results=[]
for path in sorted((root/'results/scenarios').rglob('research_checkpoint.json.gz')):
 target=Game.load(path,engine);c=target.config
 g=Game.start(engine,prefecture_code=c['prefecture_code'],seed=c['seed'],birth_date=c['birth_date'],conditions=c['conditions'],child_name=c['child_name'],child_seed=c['child_seed'],research_scenario=c['research_scenario'])
 for cmd in target.commands:
  if cmd['type']=='request':
   a=cmd['action'];g.request(a['type'],person=a.get('person'),value=a.get('value'))
  elif cmd['type']=='cancel':g.cancel(cmd['request_id'])
  elif cmd['type']=='child_action':g.observe(cmd['kind'],cmd['observer'])
  elif cmd['type']=='advance':g.advance(reviewed=cmd['reviewed'],observer=cmd['observer'])
 assert g.snapshot()==target.snapshot(),str(path)
 assert g.finished and g.core.elapsed_months==24
 results.append({'path':str(path.relative_to(root)),'complete_saved_state_equal':True,'sha256':digest(g.snapshot())})
rows=json.loads((root/'results/runtime_equivalence_47.json').read_text())
for row in rows:
 g=Game.start(engine,prefecture_code=row['prefecture'],seed=row['seed'])
 for i in range(24):g.advance(reviewed=True)
 assert digest(g.snapshot())==row['sha256'],row['prefecture']
print(json.dumps({'replayed_checkpoints':results,'runtime_47_final_hashes_match':True,'runtime_only_no_original_db':True}))
'''
 cp=subprocess.run([sys.executable,'-c',checkcode,str(extracted)],cwd=dest,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
 result['replay']=json.loads(cp.stdout);assert len(result['replay']['replayed_checkpoints'])==19
 result['new_tests']=13
 with socket.socket()as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
 log=ROOT/'results/independent_browser.log'
 with log.open('w')as f:
  process=subprocess.Popen([sys.executable,str(extracted/'server.py'),'--port',str(port),'--save-dir',str(dest/'private_saves')],cwd=dest,env=env,stdout=f,stderr=f)
  try:
   ready=False
   for i in range(100):
    if process.poll()is not None:raise RuntimeError('Extracted server exited')
    try:
     ready=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=.5))['ok']
     if ready:break
    except OSError:time.sleep(.1)
   assert ready
   subprocess.run([sys.executable,str(extracted/'scripts/browser_experience.py'),'--url',f'http://127.0.0.1:{port}'],cwd=dest,env=env,stdout=f,stderr=f,check=True)
   browser=json.loads((extracted/'results/browser_experience.json').read_text());assert browser['finished_months']==24 and not browser['page_errors']
   result['fresh_browser']={'finished_months':24,'saved_reloaded_month':12,'page_errors':[],'private_routes_blocked':True,'browser':browser['browser']}
  finally:process.terminate();process.wait(timeout=10)
 # Check immutability of all previous pinned assets, including three large DBs.
 checked=0
 for row in meta['legacy_preservation_pins']:assert sha(REPO/row['path'])==row['sha256'],row['path'];checked+=1
 result['preserved_legacy_pins']=checked
 result['legacy_regression']={'B11_tests':18,'B10_integration_tests':25,'logs':'results/legacy_*_tests.log'}
 result['passed']=True
 (ART/'C0_RELEASE_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));(ROOT/'C0_RELEASE_VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 print('INDEPENDENT_RELEASE_PASS',meta['bundle_id'],len(result['replay']['replayed_checkpoints']),checked,flush=True)
 if not args.keep:shutil.rmtree(dest)
if __name__=='__main__':main()
