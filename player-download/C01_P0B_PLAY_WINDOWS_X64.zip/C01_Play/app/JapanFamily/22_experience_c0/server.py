#!/usr/bin/env python3
"""Single-user local HTTP application. Research state and saves never served."""
import argparse
import json
import re
import secrets
import sys
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from c0 import VERSION
from c0.bridge import make_engine
from c0.game import Game, ReviewRequired
from c0.catalogue import PREFECTURES


class Application:
    def __init__(self, engine, save_dir):
        self.engine = engine
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        self.sessions = {}

    def create(self, payload):
        allowed = {'prefecture_code', 'seed', 'birth_date', 'conditions', 'child_name'}
        if set(payload) - allowed:
            raise ValueError('開始時に指定できない項目が含まれています。')
        pref = payload.get('prefecture_code', '13')
        if pref not in [f'{i:02d}' for i in range(1, 48)]:
            raise ValueError('都道府県を選んでください。')
        seed = payload.get('seed') or secrets.token_hex(8)
        if not isinstance(seed, (int, str)) or isinstance(seed, bool) or len(str(seed)) > 80:
            raise ValueError('記録コードは80文字以内にしてください。')
        conditions = payload.get('conditions') or {}
        if not isinstance(conditions, dict) or set(conditions) - {
                'mother_age', 'father_age', 'mother_employed', 'father_employed',
                'household_income_yen', 'partner_present', 'legal_status', 'birth_rank',
                'mother_education', 'father_education', 'municipality_code'}:
            raise ValueError('この開始画面に対応していない条件です。')
        game = Game.start(self.engine, prefecture_code=pref, seed=seed,
                          birth_date=payload.get('birth_date', '2026-10-01'), conditions=conditions,
                          child_name=payload.get('child_name', '子ども'))
        sid = secrets.token_hex(16)
        self.sessions[sid] = game
        return sid, game

    def session(self, sid):
        if not isinstance(sid, str) or not re.fullmatch('[0-9a-f]{32}', sid) or sid not in self.sessions:
            raise LookupError('記録が見つかりません。保存した記録から再開するか、新しく始めてください。')
        return self.sessions[sid]

    def save(self, sid):
        game = self.session(sid)
        slot = secrets.token_hex(16)
        path = self.save_dir / (slot + '.json.gz')
        h = game.save(path)
        meta = {'slot': slot, 'child_name': game.config['child_name'],
                'date': game.core.child._state['as_of_date'], 'age_months': game.core.elapsed_months,
                'version': VERSION, 'payload_sha256': h}
        (self.save_dir / (slot + '.meta.json')).write_text(json.dumps(meta, ensure_ascii=False))
        return meta

    def load(self, slot):
        if not isinstance(slot, str) or not re.fullmatch('[0-9a-f]{32}', slot):
            raise ValueError('保存記録を選んでください。')
        game = Game.load(self.save_dir / (slot + '.json.gz'), self.engine)
        sid = secrets.token_hex(16)
        self.sessions[sid] = game
        return sid, game


class Handler(BaseHTTPRequestHandler):
    server_version = 'C0-local'

    def log_message(self, fmt, *args):
        # Do not log session capabilities or private state.
        sys.stderr.write('%s %s\n' % (self.command, self.path.split('?')[0]))

    @property
    def app(self):
        return self.server.application

    def send(self, status, body, content_type='application/json; charset=utf-8'):
        data = json.dumps(body, ensure_ascii=False, allow_nan=False).encode() if not isinstance(body, bytes) else body
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        url = urllib.parse.urlsplit(self.path)
        query = urllib.parse.parse_qs(url.query)
        try:
            if url.path == '/api/health':
                return self.send(200, {'ok': True, 'version': VERSION, 'engine': 'native A3.0-0.2 + B-1.1'})
            if url.path == '/api/catalogue':
                return self.send(200, {'prefectures': [{'code': f'{i:02d}', 'name': n} for i, n in enumerate(PREFECTURES, 1)]})
            if url.path == '/api/saves':
                saves = [json.loads(p.read_text()) for p in sorted(self.app.save_dir.glob('*.meta.json'), key=lambda p: p.stat().st_mtime, reverse=True)]
                return self.send(200, {'saves': saves})
            if url.path == '/api/session':
                game = self.app.session(query.get('sid', [''])[0])
                return self.send(200, {'view': game.view(query.get('observer', ['mother'])[0])})
            static = {'/': ('index.html', 'text/html; charset=utf-8'),
                      '/app.js': ('app.js', 'text/javascript; charset=utf-8'),
                      '/style.css': ('style.css', 'text/css; charset=utf-8')}
            if url.path in static:
                name, mime = static[url.path]
                return self.send(200, (ROOT / 'web' / name).read_bytes(), mime)
            return self.send(404, {'error': 'このページはありません。'})
        except LookupError as e:
            return self.send(404, {'error': str(e)})
        except PermissionError:
            return self.send(403, {'error': 'この観察者の記録は表示できません。'})
        except Exception:
            traceback.print_exc()
            return self.send(500, {'error': '記録を読み込めませんでした。サーバーのログを確認してください。'})

    def do_POST(self):
        try:
            origin = self.headers.get('Origin')
            if (origin and urllib.parse.urlsplit(origin).netloc != self.headers.get('Host')) or self.headers.get('X-C0-Client') != 'browser-v1':
                return self.send(403, {'error': 'この画面から操作してください。'})
            if self.headers.get_content_type() != 'application/json':
                return self.send(415, {'error': 'JSON形式で送信してください。'})
            length = int(self.headers.get('Content-Length', 0))
            if not 0 < length <= 32768:
                return self.send(413, {'error': '送信データが大きすぎます。'})
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError('操作内容はオブジェクトで指定してください。')
            path = urllib.parse.urlsplit(self.path).path
            if path == '/api/start':
                sid, game = self.app.create(body)
                return self.send(200, {'sid': sid, 'view': game.view()})
            if path == '/api/load':
                if set(body) != {'slot'}:
                    raise ValueError('保存記録だけを指定してください。')
                sid, game = self.app.load(body['slot'])
                return self.send(200, {'sid': sid, 'view': game.view()})
            if path != '/api/command':
                return self.send(404, {'error': 'この操作はありません。'})
            if set(body) - {'sid', 'revision', 'command', 'observer', 'kind', 'person', 'value', 'request_id', 'reviewed', 'count'}:
                raise ValueError('指定できない操作項目があります。')
            game = self.app.session(body.get('sid'))
            game.check_revision(body.get('revision'))
            observer = body.get('observer', 'mother')
            if observer not in game.core.identity['caregiver_local_ids']:
                raise PermissionError()
            command = body.get('command')
            if command == 'request':
                game.request(body.get('kind'), person=body.get('person'), value=body.get('value'))
            elif command == 'cancel':
                game.cancel(body.get('request_id'))
            elif command == 'observe':
                game.observe(body.get('kind'), observer)
            elif command == 'advance':
                done = game.advance_many(body.get('count', 1), reviewed=body.get('reviewed', False), observer=observer)
                return self.send(200, {'view': game.view(observer), 'periods_advanced': done})
            elif command == 'save':
                return self.send(200, {'view': game.view(observer), 'saved': self.app.save(body['sid'])})
            else:
                raise ValueError('この操作は選べません。')
            return self.send(200, {'view': game.view(observer)})
        except ReviewRequired as e:
            return self.send(409, {'error': str(e), 'needs_review': True})
        except (ValueError, TypeError, KeyError) as e:
            return self.send(422, {'error': '条件を確認してください。' + str(e)[:220]})
        except LookupError as e:
            return self.send(404, {'error': str(e)})
        except PermissionError:
            return self.send(403, {'error': 'この家庭の養育者の操作だけが可能です。'})
        except Exception:
            traceback.print_exc()
            return self.send(500, {'error': '操作を完了できませんでした。条件とサーバーログを確認してください。'})


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', default='127.0.0.1')
    p.add_argument('--port', type=int, default=8780)
    p.add_argument('--save-dir', type=Path, default=ROOT / 'runtime/saves')
    p.add_argument('--runtime-db', type=Path)
    args = p.parse_args()
    app = Application(make_engine(args.runtime_db), args.save_dir)
    server = HTTPServer((args.host, args.port), Handler)
    server.application = app
    print(json.dumps({'ready': True, 'port': server.server_port, 'version': VERSION}), flush=True)
    server.serve_forever()

if __name__ == '__main__':
    main()
