# C-0「まいにちの、あいだ。」

2026年の日本で、実際のA3.0-0.2 / B-1.1を使って出生から24か月を進める、ローカルの体験実証版です。科学的外部妥当性やゲームとしての完成を宣言する版ではありません。

## 起動

既存ワークスペースではリポジトリのルートで実行します。

```sh
python JapanFamily/22_experience_c0/server.py --port 8780
```

ポート8780をブラウザで開きます。初期画面で都道府県・出生日・親の条件を選び、「暮らしを始める」を押してください。子どもの個性を選ぶ操作はありません。子どもの記録を読み、希望を登録してから次の期へ進めます。確認事項が出たら内容を読み、確認欄にチェックして進めます。最大3期の進行は重要事項・初めて観察された姿で止まります。24か月でアルバムを振り返ります。

Python 3.12とnumpy/scipyが必要です。UIにはビルド作業・外部API・課金キーは不要です。新しい環境では必要に応じて `python -m pip install -r JapanFamily/22_experience_c0/requirements.txt` を実行してください。再現性確認には同じPython・依存版を使います。ブラウザ検査はPlaywrightとChromiumが別途必要です。

## 軽量配布を新しい場所で使う

`C0_CODE_AND_REPORTS.zip` と `C0_RUNTIME_DATA.zip` を**同じ空のフォルダ**に展開し、そのフォルダで上記コマンドを実行します。元の5GB超の統合DBは不要です。実行用DBは元DBの必要行を無変更で選択した派生物で、正式原本の代替ではありません。47都道府県で出生＋24期の全状態一致を検査しています。

全19経路の研究用チェックポイントと構造化履歴は `C0_EXPERIENCE_DATA.zip` に分離しています。軽量コードパックにも10家庭・比較の日本語記録、画面、集計、根拠対応表を収録しています。旧原資料・DB・全履歴は元のB1.0/B1.1パックを保持し、`data/baseline_pins.json` と `data/inherited_runtime_manifest.json` で対応させます。

## 保存と再開

「ここまでを保存する」でサーバー側の `runtime/saves` に保存します。「保存した記録」から再開できます。サーバーを止めると未保存セッションは消えます。「新しく始める」は現在の家庭を保存してから別の家庭を開始します。保存内容は内部状態を含む研究用ファイルで、ブラウザには配信しません。保存ファイルを編集・他用途へ公開しないでください。

単一利用者のローカル実行を想定しています。認証・マルチユーザー分離・公開サービス運用は対象外です。保存スロットは同じローカル実行環境の利用者間で共有されます。既定のループバック待受を用いてください。

## 検証・再構築

```sh
python -m unittest discover -s JapanFamily/22_experience_c0/tests -v
python JapanFamily/22_experience_c0/scripts/scenarios.py
python JapanFamily/22_experience_c0/scripts/browser_experience.py
python JapanFamily/22_experience_c0/scripts/package_release.py
python JapanFamily/22_experience_c0/scripts/verify_release.py
```

ブラウザ検査は先にサーバーを起動します。Chromiumは `/usr/bin/chromium` を使います。ネットワーク制限のある環境でPlaywrightのブラウザを再取得する必要はありません。

元DBから実行用DBを作る場合のみ `scripts/build_runtime_projection.py`、元DBとの比較は `scripts/verify_runtime_equivalence.py` を実行します。既存の実行用DBは上書きしません。元DBを変更する移行・インストール処理はありません。

上記の全リリース再検査には、リポジトリの `artifacts` に3つの保存済みZIPと `C0_ARCHIVES.json`、旧資産の保全確認には元のA/B成果物も必要です。軽量パックだけで行える検査はC0テスト・シナリオ再実行・ブラウザ検査です。保存後の結果 `C0_RELEASE_VERIFICATION.json` と `C0_SHA256SUMS.txt` は循環参照を避けてZIP外に保存しています。

## 体験の限界

親の選択は仕事・保育・家計の希望と実現に影響します。子どもへの関わりは観察の機会を増やしますが、能力・愛着への未識別の長期効果は計算しません。比較した3家庭では環境の選択を変えても子どもの発達・観察履歴は同一でした。一方、同じ家庭で異なる子どもを生成すると観察履歴が変わります。気質と行動の係数は未校正で、性格診断として表示しません。

単胎・在胎37〜41週・2026年出生・24か月までが参照範囲です。月途中出生の実月齢は扱いますが、A側の最終月途中の会計は未精算と表示します。早産・多胎・臨床診断、2歳以降は対応済みとしません。

詳しくは `C0_BUILD_REPORT.md`、`docs/model_to_display.md`、`docs/experience_findings.md` を参照してください。これは開発者によるシナリオ検査で、実ユーザーテストは実施していません。
