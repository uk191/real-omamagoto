import copy
import gzip
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from c0.bridge import make_engine, Simulation, ConfiguredEngine, digest
from c0.game import Game, ReviewRequired
from server import Application


class ExperienceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.engine = make_engine()

    def new(self, **kwargs):
        return Game.start(self.engine, seed='C0-regression', **kwargs)

    def test_views_do_not_consume_randomness(self):
        a = self.new(); b = a.clone(); before = a.snapshot()
        for i in range(30):
            a.view('mother'); a.view('father')
        self.assertEqual(before, a.snapshot())
        a.advance(reviewed=True); b.advance(reviewed=True)
        self.assertEqual(a.snapshot(), b.snapshot())

    def test_native_first_day_engine_unchanged(self):
        a = self.new()
        b = Simulation.initialize('13', seed='C0-regression', birth_date='2026-10-01', engine=ConfiguredEngine(self.engine, {'auto_actions':False}))
        # C0 explicit administrative policy, not a scientific kernel modification.
        b.engine = self.engine
        self.assertEqual(a.core.a, b.a)
        for i in range(24):
            a.advance(reviewed=True); b.step(research_continue=True)
        self.assertEqual(a.core.a, b.a)
        self.assertEqual(a.core.child.research_snapshot(), b.child.research_snapshot())
        self.assertEqual(a.core.exposures, b.exposures)

    def test_midmonth_exact_horizon_and_no_forecast(self):
        a = self.new(birth_date='2026-01-31')
        while not a.finished:
            if len(a.turns) == 24: a.request('request_relative_support')
            a.advance(reviewed=True)
        self.assertEqual(len(a.turns), 25)
        self.assertEqual(a.core.child._state['as_of_date'], '2028-01-31')
        self.assertEqual(len(a.core.a_periods), 24)
        self.assertTrue(a.view()['household']['partial_month_unsettled'])
        self.assertNotIn('forecast', json.dumps(a.view()))
        self.assertEqual(a.view()['decisions'][0]['outcome'], 'deferred')
        self.assertEqual(a.view()['decisions'][0]['evidence'], 'unsettled_final_calendar_period')
        for row in a.core.exposures:
            self.assertGreaterEqual(row['start_inclusive'], '2026-01-31')
        with self.assertRaises(ValueError): a.advance(reviewed=True)

    def test_save_resume_and_tamper(self):
        a = self.new()
        for i in range(12): a.advance(reviewed=True)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'save.gz'; before = a.snapshot(); a.save(p)
            self.assertEqual(before, a.snapshot()); b = Game.load(p, self.engine)
            for i in range(12): a.advance(reviewed=True); b.advance(reviewed=True)
            self.assertEqual(a.snapshot(), b.snapshot())
            with gzip.open(p, 'rt') as f: env = json.load(f)
            env['payload']['revision'] += 1
            with gzip.open(p, 'wt') as f: json.dump(env, f)
            with self.assertRaises(ValueError): Game.load(p, self.engine)

    def test_request_is_not_outcome_and_cancel_is_pure(self):
        a = self.new(); before = a.core.payload()
        a.request('apply_childcare'); self.assertEqual(before, a.core.payload())
        with self.assertRaises(ValueError): a.request('apply_childcare')
        a.cancel(a.queue[0]['id']); self.assertEqual(before, a.core.payload())
        a.request('request_relative_support'); a.advance(reviewed=True)
        self.assertTrue(a.turns[-1]['decisions'])
        self.assertFalse(a.queue)

    def test_causally_unidentified_child_effect_is_off(self):
        a = self.new(); b = a.clone()
        a.observe('shared_play'); a.observe('offer_comfort')
        self.assertNotEqual(a.view()['child']['total_reports'], b.view()['child']['total_reports'])
        for i in range(24): a.advance(reviewed=True); b.advance(reviewed=True)
        for key in ['physical_health','latent_state','developmental_state','emotion_regulation','sleep']:
            self.assertEqual(a.core.child._state[key], b.core.child._state[key], key)
        self.assertEqual(a.core.a, b.core.a)

    def test_review_gate_is_atomic(self):
        a = self.new(); a.core.a['pending_decisions'] = [{'type':'care_work_conflict'}]
        before = a.snapshot()
        with self.assertRaises(ReviewRequired): a.advance()
        self.assertEqual(before, a.snapshot())
        a.advance(reviewed=True)

    def test_bad_actor_bad_action_and_revision(self):
        a = self.new(); before = a.snapshot()
        for call in [lambda:a.observe('observe','stranger'), lambda:a.request('request_hours',person='mother',value=float('nan')),
                     lambda:a.request('request_return',person='mother',value=-1), lambda:a.request('IQ_boost'),
                     lambda:a.request('accept_job_offer',person='mother',value='not-an-offer')]:
            with self.assertRaises(ValueError): call()
        with self.assertRaises(PermissionError): a.view('stranger')
        self.assertEqual(before, a.snapshot())
        a.request('apply_child_allowance')
        with self.assertRaises(ValueError): a.check_revision(0)

    def test_same_child_action_bounded_and_reproducible(self):
        a = self.new(); b = a.clone()
        a.observe('observe'); b.observe('observe')
        self.assertEqual(a.snapshot(), b.snapshot())
        before = a.snapshot()
        with self.assertRaises(ValueError): a.observe('observe')
        self.assertEqual(before, a.snapshot())

    def test_parent_whitelist_and_fact_hashes(self):
        a = self.new(); a.observe('observe'); a.advance(reviewed=True)
        s = json.dumps(a.view())
        for key in ['latent_state','initial_dispositions','transition_parameters','probabilities','growth_z','sleep_rank','A_forecast']:
            self.assertNotIn(key, s)
        public = a.core.child.player_view(a.core.identity['person_links']['mother'])
        for c in a.view()['child']['cards']:
            refs = [public['observations'][r['observation_index']] for r in c['sources']]
            self.assertEqual(c['value_sha256'], digest(refs))
            self.assertEqual(c['present'], sum(r['behaviors'][c['signal']] for r in refs))

    def test_no_action_growth_and_null_care_fee(self):
        a = self.new(); length = a.core.child._state['physical_health']['length_cm']
        for i in range(24): a.advance(reviewed=True)
        self.assertGreater(a.core.child._state['physical_health']['length_cm'], length)
        self.assertEqual(a.view()['age_months'], 24)
        self.assertIsInstance(a.view()['household']['budget']['care_charge_yen'], (int,float))

    def test_multi_turn_stop(self):
        a = self.new(); a.core.a['pending_decisions'] = [{'type':'care_work_conflict'}]
        with self.assertRaises(ReviewRequired): a.advance_many(3)
        with self.assertRaises(ValueError): a.advance_many(25)
        n = a.advance_many(3,reviewed=True)
        self.assertLessEqual(n,3)
        if a.turns[-1]['pauses']: self.assertEqual(n,len(a.turns))

    def test_application_slots_private_and_no_research_override(self):
        with tempfile.TemporaryDirectory() as tmp:
            app = Application(self.engine,tmp)
            with self.assertRaises(ValueError): app.create({'child_seed':123})
            sid,a = app.create({'seed':'C0-private-test','child_name':'<script>記録</script>'})
            a.advance(reviewed=True); meta = app.save(sid); sid2,b = app.load(meta['slot'])
            self.assertEqual(a.snapshot(),b.snapshot())
            self.assertNotEqual(sid,sid2)
            self.assertEqual((Path(tmp)/(meta['slot']+'.json.gz')).stat().st_mode & 0o777,0o600)
            with self.assertRaises(LookupError): app.session('../data')
            with self.assertRaises(ValueError): app.load('../data')

if __name__ == '__main__': unittest.main()
