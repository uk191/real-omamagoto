# 内部モデルとプレイヤー表示の対応

| 表示・操作 | 実際の入力・出力 | 表現・制限 | 根拠区分 |
|---|---|---|---|
| 地域・親の属性で開始 | A18.Engine.initialize → A2.5 → A2 FamilyModel → A1 RegionModel、B11.Simulation.initialize | 条件を指定できない母集団・組合せは生成拒否。seed記録。家族ID・子ID・出生イベントをBと共有 | 継承統計＋輸送・結合の仮定 |
| 年齢・現在日 | B.child.as_of_date / age_days / elapsed_months | 暦月と満月齢を区別、月途中出生は25回の区切り。24か月の誕生日で終了 | 日付恒等式 |
| 10種類の様子カード | B.child.player_view(養育者ID).observations[].behaviors | 観察できた標本の肯定数／総数。観察がない時間や内面は推定して表示しない | 未校正の行動・測定モデル |
| 足・ことばの初めての記録 | 同一観察者の過去の全報告との比較 | 初獲得でなく「記録に初めて」。診断、将来予測をしない | 観測上の事実 |
| 関わりの3操作 | B.child.act(observe/shared_play/offer_comfort,scenario_effects=False) | 観察報告を追加。1操作・観察者・期につき1回。能力、愛着を加点しない | 観察機会の仮定 |
| 親の仕事 | 完了済みA.parents.employment_measurement / actual_weekly_hours | 希望の勤務時間、通常時所得、実働、実際の当期給与を別表示 | 未検証の就業経路を含む |
| 保育・身近な支援 | A.care.status/application/relative_confirmed | 申込み≠入園。not_admittedは入園に至らず。祖父母個人の支援とは断定しない | Aの制度参照＋選考仮定 |
| 家計 | 完了済みA.accounts / A.last_month ledger | 現金・不足・消費等。当期途中の予測値を表示しない。初期残高は生成上の設定 | 所得・支出・資産同時分布は未適合 |
| 生活時間 | A.last_month.time | 週参照配分と表示。実測生活日誌や接触の質ではない | 時間配分の仮定 |
| 希望と結果 | C0.queue → A18.Engine.step(actions) → A_decisions | 登録中は未処理、取消可。受理・条件確認・実際の利用を区別。各決定に元レコードのハッシュ | ネイティブAの実行結果、実証因果ではない |
| 停止 | A.pending_decisions / 新しい観察 / job_offer | 未解決確認は解決したことを意味しない。最大3期でも重要な条件を跨いで自動進行しない | 明示的な体験進行規則 |
| アルバム | C0.turns[].views[observer] | 保存した各期の観察を定型整形。後の知識で過去を書き換えない | 実行履歴 |

各カードには `source_ref`、元観察インデックス・日付・SHA256、元値列の `value_sha256`、`evidence` を付けます。日本語は `catalogue.py` と `projection.py` の定型変換です。生成AIによる自由な設定や因果の補完は使っていません。子どもの呼び名はHTMLエスケープします。

開発者はローカルPythonの `Game.snapshot()` で状態・乱数・研究履歴を検査します。HTTPは `Game.view()` のホワイトリストだけを返します。内部真実・forecast・潜在気質・発達確率・未来の節目・精密な睡眠時間・臨床診断を返すHTTP APIは設けていません。保管した研究チェックポイントは静的配信対象外です。

この分離は単一利用者の製品表現上の分離です。配布コードを編集できる開発者に対する秘密保護ではありません。
