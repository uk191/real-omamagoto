# 3家庭の選択前後・翌期の実記録

研究用の内部説明を含む検査資料。ゲーム内では子どもの潜在状態は表示しません。各記述は保存履歴から定型生成しています。実証的な介入効果ではありません。

## tokyo_dual

開始時の家庭・子ども・seedは固定。比較方針：early_return, late_return

### early_return

**2026-11-01・1か月**

親から見えた様子：記録した4場面のうち、0場面で泣いていた。 / 記録した4場面のうち、2場面で落ち着く様子があった。 / 記録した1場面のうち、0場面で物へ注意を向けた。

実際の希望処理：児童手当の手続きをする：申請・相談を提出した。 / 育児休業を希望する：現在の条件が続く。 / 復職の希望時期を伝える：希望時期を登録した。

結果：父 育児休業中 / 母 産後休業中。家庭で過ごす。現金2,342,615円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 1。観察値SHA：72306d130bf7c980887c06034f52f84fd2d4c107a3ee79817814c8a092baca81, 295bab456e5ad762cd562a1a730f62dae6620add3745f8b3ce132e3db7d0f93d, 865cbe562d54160030fa2bfc3e22065e1307e33dcd52f818341c6a377362a535

**2026-12-01・2か月**

親から見えた様子：記録した2場面のうち、2場面で泣いていた。 / 記録した4場面のうち、2場面で落ち着く様子があった。 / 記録した1場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 育児休業中 / 母 産後休業中。家庭で過ごす。現金1,921,409円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 2。観察値SHA：d4c81a846be524230702f232556c6e6a41212be83b13bfb71a468025202be162, 3ff000b1ce740939294731d11c6e57333276107a3b65925137acecc05c8af5ff, 9a1b4cc2af15baffb0e5af127e14f06bdc10a0406bf18c6aaaed365e157fbe09

**2027-02-01・4か月**

親から見えた様子：記録した5場面のうち、1場面で泣いていた。 / 記録した3場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：保育の利用を申し込む：申請・相談を提出した。

結果：父 働いている / 母 育児休業中。保育の申請を審査待ち。現金1,169,516円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 4。観察値SHA：0fe0808a6e58d85c787e54a233c2c86c34ee3d57ab96ace4a01e85ed626171c6, ea8130d73cd4762cb712205f07330561a1ffd63de468777997cc2f60e333b12d, 8e61d8580aafd12c7b8dd452591db2ef9062bf8d001fe6f07e5968631bce1a17

**2027-05-01・7か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した2場面のうち、1場面で落ち着く様子があった。 / 記録した3場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。保育を利用中。現金2,225,808円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 7。観察値SHA：0b5a31c4de79caf89b9f1780f35bf94fd538e5f04fad08dfb14f33e27abd6157, a8fe232a26e4723bb418cbe03776b27b264246667fe61fbeb64473521783a4e3, 076412009e573a64f3d9626bc3d025b35bd7b395c39411c484814a31c5e05640

**2027-08-01・10か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した5場面のうち、3場面で落ち着く様子があった。 / 記録した4場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。保育を利用中。現金2,709,462円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 10。観察値SHA：b168841792cda825d9beacd712570eef69dbb94145849a7c2bb18d27bdc9581c, 4da9f8c9a9b6e584d79677a365dfa4ae2dfbd797f4f45f6365c0aa358f1fc00e, a60f3496c87bf9fddb11f49f4f49c41cd338ed56f8b6d351346569e30e42b053

**2027-11-01・13か月**

親から見えた様子：記録した4場面のうち、1場面で泣いていた。 / 記録した2場面のうち、2場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。保育を利用中。現金2,828,086円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 13。観察値SHA：4e0a0c11d9a1e79f3e1245a3e6dff36e8a73e8c8478a475e5a853fb2184a156d, aa680bfed12cdf04309318f4a511aefe1689c0727030d5f39778f9c0b916d3ae, 31b36e62ccb12f2a140a90ee7aa8c37aa3975546602278139964c2f9fc64afd0

**2028-10-01・24か月**

親から見えた様子：記録した1場面のうち、0場面で泣いていた。 / 記録した2場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。保育を利用中。現金3,138,791円。

追跡：results/scenarios/comparisons/tokyo_dual/early_return/player_history.json.gz / turn 24。観察値SHA：65ed3775881d4df4a1997eb1b3efbbd6a01454d212ea012dee9039565251c9ca, 99ebd09b02c0056124deae3008d008ee9ddfb58ce10633b9f8f7879b37276d50, e3c2306d10678054909609b8e9eb8be75c5a9165580d16f03314f63912892c52

翌期への持越しは同経路の次期記録に保存。Aの予定・保育・時間・残高がネイティブ計算を通じて持ち越される。Bの未識別効果は停止しているため、比較方針間で子どもの生物学的状態・観察は同一。これは実証的効果ゼロの証明ではなく未実装である。

### late_return

**2026-11-01・1か月**

親から見えた様子：記録した4場面のうち、0場面で泣いていた。 / 記録した4場面のうち、2場面で落ち着く様子があった。 / 記録した1場面のうち、0場面で物へ注意を向けた。

実際の希望処理：児童手当の手続きをする：申請・相談を提出した。 / 育児休業を希望する：現在の条件が続く。 / 復職の希望時期を伝える：希望時期を登録した。

結果：父 育児休業中 / 母 産後休業中。家庭で過ごす。現金2,342,615円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 1。観察値SHA：72306d130bf7c980887c06034f52f84fd2d4c107a3ee79817814c8a092baca81, 295bab456e5ad762cd562a1a730f62dae6620add3745f8b3ce132e3db7d0f93d, 865cbe562d54160030fa2bfc3e22065e1307e33dcd52f818341c6a377362a535

**2026-12-01・2か月**

親から見えた様子：記録した2場面のうち、2場面で泣いていた。 / 記録した4場面のうち、2場面で落ち着く様子があった。 / 記録した1場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 育児休業中 / 母 産後休業中。家庭で過ごす。現金1,921,409円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 2。観察値SHA：d4c81a846be524230702f232556c6e6a41212be83b13bfb71a468025202be162, 3ff000b1ce740939294731d11c6e57333276107a3b65925137acecc05c8af5ff, 9a1b4cc2af15baffb0e5af127e14f06bdc10a0406bf18c6aaaed365e157fbe09

**2027-02-01・4か月**

親から見えた様子：記録した5場面のうち、1場面で泣いていた。 / 記録した3場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 育児休業中。家庭で過ごす。現金1,169,516円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 4。観察値SHA：0fe0808a6e58d85c787e54a233c2c86c34ee3d57ab96ace4a01e85ed626171c6, ea8130d73cd4762cb712205f07330561a1ffd63de468777997cc2f60e333b12d, 8e61d8580aafd12c7b8dd452591db2ef9062bf8d001fe6f07e5968631bce1a17

**2027-05-01・7か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した2場面のうち、1場面で落ち着く様子があった。 / 記録した3場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 育児休業中。家庭で過ごす。現金2,266,874円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 7。観察値SHA：0b5a31c4de79caf89b9f1780f35bf94fd538e5f04fad08dfb14f33e27abd6157, a8fe232a26e4723bb418cbe03776b27b264246667fe61fbeb64473521783a4e3, 076412009e573a64f3d9626bc3d025b35bd7b395c39411c484814a31c5e05640

**2027-08-01・10か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した5場面のうち、3場面で落ち着く様子があった。 / 記録した4場面のうち、2場面で物へ注意を向けた。

実際の希望処理：保育の利用を申し込む：申請・相談を提出した。

結果：父 働いている / 母 育児休業中。保育の申請を審査待ち。現金2,148,564円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 10。観察値SHA：b168841792cda825d9beacd712570eef69dbb94145849a7c2bb18d27bdc9581c, 4da9f8c9a9b6e584d79677a365dfa4ae2dfbd797f4f45f6365c0aa358f1fc00e, a60f3496c87bf9fddb11f49f4f49c41cd338ed56f8b6d351346569e30e42b053

**2027-11-01・13か月**

親から見えた様子：記録した4場面のうち、1場面で泣いていた。 / 記録した2場面のうち、2場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 雇用先との関係は継続・実働と賃金は0。保育の申請は今回の調整では入園に至らず。現金2,333,410円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 13。観察値SHA：4e0a0c11d9a1e79f3e1245a3e6dff36e8a73e8c8478a475e5a853fb2184a156d, aa680bfed12cdf04309318f4a511aefe1689c0727030d5f39778f9c0b916d3ae, 31b36e62ccb12f2a140a90ee7aa8c37aa3975546602278139964c2f9fc64afd0

**2028-10-01・24か月**

親から見えた様子：記録した1場面のうち、0場面で泣いていた。 / 記録した2場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。保育を利用中。現金1,530,100円。

追跡：results/scenarios/comparisons/tokyo_dual/late_return/player_history.json.gz / turn 24。観察値SHA：65ed3775881d4df4a1997eb1b3efbbd6a01454d212ea012dee9039565251c9ca, 99ebd09b02c0056124deae3008d008ee9ddfb58ce10633b9f8f7879b37276d50, e3c2306d10678054909609b8e9eb8be75c5a9165580d16f03314f63912892c52

翌期への持越しは同経路の次期記録に保存。Aの予定・保育・時間・残高がネイティブ計算を通じて持ち越される。Bの未識別効果は停止しているため、比較方針間で子どもの生物学的状態・観察は同一。これは実証的効果ゼロの証明ではなく未実装である。

## support_available

開始時の家庭・子ども・seedは固定。比較方針：relative_support, no_relative_support

### relative_support

**2026-11-01・1か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した3場面のうち、2場面で落ち着く様子があった。 / 記録した4場面のうち、1場面で物へ注意を向けた。

実際の希望処理：児童手当の手続きをする：申請・相談を提出した。 / 身近な人に支援を相談する：支援を得られる条件だった。

結果：父 働いている / 母 産後休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 1。観察値SHA：9c5950ce4aa1849728f6eed56a897834dc5f3c7aa7529a48447089d24e7df17e, 182b139ed9728936490d85e1eb122206158902e3e726c0159d29c8218be8c96b, 316f5a5e9a39ca4b2df8085137d0f4634a0b5c40c271a9e6c206359a58818539

**2026-12-01・2か月**

親から見えた様子：記録した1場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。 / 記録した3場面のうち、0場面で声の方を見た。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 産後休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 2。観察値SHA：e69dce7e64f4017e7ac24539aa1c0d4e914f655cca0b1de77c54d3f406b6623f, 5657bee6cb2f8283e6631258c02c6ab819bc6ffadf144069440e116c84fa5785, 5657bee6cb2f8283e6631258c02c6ab819bc6ffadf144069440e116c84fa5785

**2027-02-01・4か月**

親から見えた様子：記録した5場面のうち、3場面で泣いていた。 / 記録した1場面のうち、1場面で落ち着く様子があった。 / 記録した4場面のうち、3場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 育児休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 4。観察値SHA：c4f61a90e7681aaef9a74f8fa4be5d2096231e2288bba1879a41138545abafe1, fdb7b58dbd6d3f407aa90029f3abd7d493f626be6d2ffedcd676f8fbcfd29679, b1b7253bca8e9cc63734e0b418226685f06a1076111a261535814bd6d2f4f4e2

**2027-05-01・7か月**

親から見えた様子：記録した4場面のうち、1場面で泣いていた。 / 記録した4場面のうち、2場面で落ち着く様子があった。 / 記録した4場面のうち、3場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 育児休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 7。観察値SHA：4b59dc87e96576331dd26825508d4fa672d3ac57100383fb9f72837e02178f81, 4b59dc87e96576331dd26825508d4fa672d3ac57100383fb9f72837e02178f81, 4b59dc87e96576331dd26825508d4fa672d3ac57100383fb9f72837e02178f81

**2027-08-01・10か月**

親から見えた様子：記録した3場面のうち、1場面で泣いていた。 / 記録した5場面のうち、3場面で落ち着く様子があった。 / 記録した4場面のうち、4場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 10。観察値SHA：bf39e6932683758fa66d70abd45f68ede4ab173061040099d1a6911bc3f8bbb6, f117d2f6adb8c0e7a2bc4f8f0b4795b94a89abdc1f527d60afd19fb8e5f1768f, 5be348ee59e8cf919cc33eff7812908ab875c8039248adc8a1d3276d3fcb5f3a

**2027-11-01・13か月**

親から見えた様子：記録した2場面のうち、2場面で泣いていた。 / 記録した5場面のうち、4場面で落ち着く様子があった。 / 記録した4場面のうち、3場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。家庭で過ごす。現金146,912円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 13。観察値SHA：3e56210ef8afd946f09c0d065e02761cc3fd0d857f54b4e4e5bb3006124d99e0, 46ede81d55d7bc15a95409c058b9235b74d5c625ad48d2d542ae1cae69a45061, 32321cd25a222abeb4b6fd3d5e21e61dcbb5b5b82a7c3b5dbe022f4f12261fbe

**2028-10-01・24か月**

親から見えた様子：記録した3場面のうち、1場面で泣いていた。 / 記録した1場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 働いている。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/relative_support/player_history.json.gz / turn 24。観察値SHA：d6f2383d278cd8b3ab213884c2fc51be09de1dd00baee7991a1e414f0ebf8ff4, 3aeb87b3aaa2a38e3bdb26dde00e0f312fbc7e0768bbef94d1433d7087aaf37a, fcc6599dff6921ca7ebaf2b61c734c0e68dfaf5fe7ff36d3a34a2231d4df2ce4

翌期への持越しは同経路の次期記録に保存。Aの予定・保育・時間・残高がネイティブ計算を通じて持ち越される。Bの未識別効果は停止しているため、比較方針間で子どもの生物学的状態・観察は同一。これは実証的効果ゼロの証明ではなく未実装である。

### no_relative_support

**2026-11-01・1か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した3場面のうち、2場面で落ち着く様子があった。 / 記録した4場面のうち、1場面で物へ注意を向けた。

実際の希望処理：児童手当の手続きをする：申請・相談を提出した。

結果：父 働いている / 母 産後休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 1。観察値SHA：9c5950ce4aa1849728f6eed56a897834dc5f3c7aa7529a48447089d24e7df17e, 182b139ed9728936490d85e1eb122206158902e3e726c0159d29c8218be8c96b, 316f5a5e9a39ca4b2df8085137d0f4634a0b5c40c271a9e6c206359a58818539

**2026-12-01・2か月**

親から見えた様子：記録した1場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。 / 記録した3場面のうち、0場面で声の方を見た。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 産後休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 2。観察値SHA：e69dce7e64f4017e7ac24539aa1c0d4e914f655cca0b1de77c54d3f406b6623f, 5657bee6cb2f8283e6631258c02c6ab819bc6ffadf144069440e116c84fa5785, 5657bee6cb2f8283e6631258c02c6ab819bc6ffadf144069440e116c84fa5785

**2027-02-01・4か月**

親から見えた様子：記録した5場面のうち、3場面で泣いていた。 / 記録した1場面のうち、1場面で落ち着く様子があった。 / 記録した4場面のうち、3場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 育児休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 4。観察値SHA：c4f61a90e7681aaef9a74f8fa4be5d2096231e2288bba1879a41138545abafe1, fdb7b58dbd6d3f407aa90029f3abd7d493f626be6d2ffedcd676f8fbcfd29679, b1b7253bca8e9cc63734e0b418226685f06a1076111a261535814bd6d2f4f4e2

**2027-05-01・7か月**

親から見えた様子：記録した4場面のうち、1場面で泣いていた。 / 記録した4場面のうち、2場面で落ち着く様子があった。 / 記録した4場面のうち、3場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 育児休業中。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 7。観察値SHA：4b59dc87e96576331dd26825508d4fa672d3ac57100383fb9f72837e02178f81, 4b59dc87e96576331dd26825508d4fa672d3ac57100383fb9f72837e02178f81, 4b59dc87e96576331dd26825508d4fa672d3ac57100383fb9f72837e02178f81

**2027-08-01・10か月**

親から見えた様子：記録した3場面のうち、1場面で泣いていた。 / 記録した5場面のうち、3場面で落ち着く様子があった。 / 記録した4場面のうち、4場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 雇用先との関係は継続・実働と賃金は0。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 10。観察値SHA：bf39e6932683758fa66d70abd45f68ede4ab173061040099d1a6911bc3f8bbb6, f117d2f6adb8c0e7a2bc4f8f0b4795b94a89abdc1f527d60afd19fb8e5f1768f, 5be348ee59e8cf919cc33eff7812908ab875c8039248adc8a1d3276d3fcb5f3a

**2027-11-01・13か月**

親から見えた様子：記録した2場面のうち、2場面で泣いていた。 / 記録した5場面のうち、4場面で落ち着く様子があった。 / 記録した4場面のうち、3場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 雇用先との関係は継続・実働と賃金は0。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 13。観察値SHA：3e56210ef8afd946f09c0d065e02761cc3fd0d857f54b4e4e5bb3006124d99e0, 46ede81d55d7bc15a95409c058b9235b74d5c625ad48d2d542ae1cae69a45061, 32321cd25a222abeb4b6fd3d5e21e61dcbb5b5b82a7c3b5dbe022f4f12261fbe

**2028-10-01・24か月**

親から見えた様子：記録した3場面のうち、1場面で泣いていた。 / 記録した1場面のうち、0場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 雇用先との関係は継続・実働と賃金は0。家庭で過ごす。現金0円。

追跡：results/scenarios/comparisons/support_available/no_relative_support/player_history.json.gz / turn 24。観察値SHA：d6f2383d278cd8b3ab213884c2fc51be09de1dd00baee7991a1e414f0ebf8ff4, 3aeb87b3aaa2a38e3bdb26dde00e0f312fbc7e0768bbef94d1433d7087aaf37a, fcc6599dff6921ca7ebaf2b61c734c0e68dfaf5fe7ff36d3a34a2231d4df2ce4

翌期への持越しは同経路の次期記録に保存。Aの予定・保育・時間・残高がネイティブ計算を通じて持ち越される。Bの未識別効果は停止しているため、比較方針間で子どもの生物学的状態・観察は同一。これは実証的効果ゼロの証明ではなく未実装である。

## low_reference_income

開始時の家庭・子ども・seedは固定。比較方針：budget_low, budget_high

### budget_low

**2026-11-01・1か月**

親から見えた様子：記録した3場面のうち、1場面で泣いていた。 / 記録した3場面のうち、2場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。

実際の希望処理：児童手当の手続きをする：申請・相談を提出した。 / 調整できる生活費を見直す：受け付けられた。

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,927,297円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 1。観察値SHA：0f052c7e56b9e57e73e35f37811f1e2034fb598f00f8223e8992e8450f35f640, 20320640a44debdc108f6c1b87d161f70356a57917c70b5161564d1ebfbe952b, 20320640a44debdc108f6c1b87d161f70356a57917c70b5161564d1ebfbe952b

**2026-12-01・2か月**

親から見えた様子：記録した2場面のうち、1場面で泣いていた。 / 記録した1場面のうち、1場面で落ち着く様子があった。 / 記録した3場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,929,907円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 2。観察値SHA：0eb1c60070356236f318f99eab4b7e64abb1fac261cccff1bb4db9643a643346, 889c60faf8079f53c35124256afa69490c4849ba109c89cc83853f1bd9f03047, 0faf2b7677cb808357e438c7d0a1e568a533d8d29173e8d804413d09b3af0219

**2027-02-01・4か月**

親から見えた様子：記録した3場面のうち、2場面で泣いていた。 / 記録した4場面のうち、3場面で落ち着く様子があった。 / 記録した3場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,986,283円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 4。観察値SHA：ea2ae08ce83b21e89f9888f9a85a97d5b9751082b62d78496eb7cdb0a371fb54, 39b8d2f316f9df86723f0991118bdf30f3b8b84fab14fc9ac437e81d88696fa2, ca5b1982f74a5d56e71823fa396d9c64d8d449d53e6b8d58353dfbefab53ea90

**2027-05-01・7か月**

親から見えた様子：記録した5場面のうち、3場面で泣いていた。 / 記録した4場面のうち、3場面で落ち着く様子があった。 / 記録した4場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金2,052,832円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 7。観察値SHA：2c1c7db7bab28340ccf77d6c6b456a4f6fb7ba2afd68ead4a9358dd22b24d137, 5a9d2abb13921527917a9cb80b7a0af70ed319f7a98d6fdfabb99932be1eeffe, 65b5c75571f545a5f279c7b4ff8c01adad776bee991a1f8c14fd209477edc850

**2027-08-01・10か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した2場面のうち、1場面で落ち着く様子があった。 / 記録した4場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金2,087,772円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 10。観察値SHA：dc159db90e4d167c4ebd0d349015cf178bd57339f8fbcb55d59a82d5d48bbd62, f457842adfe0beb7cec551ac6d80defe026869e67f3b8bd9579929314e0dccd9, bbc2c018281a871590d0e66de21cc923ee0f9e04d1ee720edbcd5d231ae76876

**2027-11-01・13か月**

親から見えた様子：記録した2場面のうち、1場面で泣いていた。 / 記録した5場面のうち、4場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金2,151,076円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 13。観察値SHA：fe973e023f4e5678b359441b6e6e169cd6c4233027b4cf97edb2ec00de0feeb9, 8411635d8a691df87cc068988aeb27bc384fe591ca3cbf1687138460c77817d5, dda1c730fd243d359ca39b8a877dc83254b74e5a6ba8411656e84eb976ec6777

**2028-10-01・24か月**

親から見えた様子：記録した1場面のうち、1場面で泣いていた。 / 記録した1場面のうち、1場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金2,299,518円。

追跡：results/scenarios/comparisons/low_reference_income/budget_low/player_history.json.gz / turn 24。観察値SHA：ff6c9f06731a6895eb67548d5a58417bbef9c5199f371ad628632b98150f0f8c, 533eb786a21fa8dbeb8460b38371244cd3c8cc76bb31b470006e7ff14b60ca97, 2151e2bc279066b8f1bb2e00dd2a1dd542b88d22ef520c7e3b487aaa477888c8

翌期への持越しは同経路の次期記録に保存。Aの予定・保育・時間・残高がネイティブ計算を通じて持ち越される。Bの未識別効果は停止しているため、比較方針間で子どもの生物学的状態・観察は同一。これは実証的効果ゼロの証明ではなく未実装である。

### budget_high

**2026-11-01・1か月**

親から見えた様子：記録した3場面のうち、1場面で泣いていた。 / 記録した3場面のうち、2場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。

実際の希望処理：児童手当の手続きをする：申請・相談を提出した。 / 調整できる生活費を見直す：受け付けられた。

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,916,411円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 1。観察値SHA：0f052c7e56b9e57e73e35f37811f1e2034fb598f00f8223e8992e8450f35f640, 20320640a44debdc108f6c1b87d161f70356a57917c70b5161564d1ebfbe952b, 20320640a44debdc108f6c1b87d161f70356a57917c70b5161564d1ebfbe952b

**2026-12-01・2か月**

親から見えた様子：記録した2場面のうち、1場面で泣いていた。 / 記録した1場面のうち、1場面で落ち着く様子があった。 / 記録した3場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,908,113円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 2。観察値SHA：0eb1c60070356236f318f99eab4b7e64abb1fac261cccff1bb4db9643a643346, 889c60faf8079f53c35124256afa69490c4849ba109c89cc83853f1bd9f03047, 0faf2b7677cb808357e438c7d0a1e568a533d8d29173e8d804413d09b3af0219

**2027-02-01・4か月**

親から見えた様子：記録した3場面のうち、2場面で泣いていた。 / 記録した4場面のうち、3場面で落ち着く様子があった。 / 記録した3場面のうち、0場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,942,608円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 4。観察値SHA：ea2ae08ce83b21e89f9888f9a85a97d5b9751082b62d78496eb7cdb0a371fb54, 39b8d2f316f9df86723f0991118bdf30f3b8b84fab14fc9ac437e81d88696fa2, ca5b1982f74a5d56e71823fa396d9c64d8d449d53e6b8d58353dfbefab53ea90

**2027-05-01・7か月**

親から見えた様子：記録した5場面のうち、3場面で泣いていた。 / 記録した4場面のうち、3場面で落ち着く様子があった。 / 記録した4場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,976,190円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 7。観察値SHA：2c1c7db7bab28340ccf77d6c6b456a4f6fb7ba2afd68ead4a9358dd22b24d137, 5a9d2abb13921527917a9cb80b7a0af70ed319f7a98d6fdfabb99932be1eeffe, 65b5c75571f545a5f279c7b4ff8c01adad776bee991a1f8c14fd209477edc850

**2027-08-01・10か月**

親から見えた様子：記録した4場面のうち、2場面で泣いていた。 / 記録した2場面のうち、1場面で落ち着く様子があった。 / 記録した4場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金1,977,988円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 10。観察値SHA：dc159db90e4d167c4ebd0d349015cf178bd57339f8fbcb55d59a82d5d48bbd62, f457842adfe0beb7cec551ac6d80defe026869e67f3b8bd9579929314e0dccd9, bbc2c018281a871590d0e66de21cc923ee0f9e04d1ee720edbcd5d231ae76876

**2027-11-01・13か月**

親から見えた様子：記録した2場面のうち、1場面で泣いていた。 / 記録した5場面のうち、4場面で落ち着く様子があった。 / 記録した3場面のうち、1場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金2,007,971円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 13。観察値SHA：fe973e023f4e5678b359441b6e6e169cd6c4233027b4cf97edb2ec00de0feeb9, 8411635d8a691df87cc068988aeb27bc384fe591ca3cbf1687138460c77817d5, dda1c730fd243d359ca39b8a877dc83254b74e5a6ba8411656e84eb976ec6777

**2028-10-01・24か月**

親から見えた様子：記録した1場面のうち、1場面で泣いていた。 / 記録した1場面のうち、1場面で落ち着く様子があった。 / 記録した3場面のうち、2場面で物へ注意を向けた。

実際の希望処理：今期に追加の希望処理はなし

結果：父 働いている / 母 現在は仕事をしていない。家庭で過ごす。現金2,032,747円。

追跡：results/scenarios/comparisons/low_reference_income/budget_high/player_history.json.gz / turn 24。観察値SHA：ff6c9f06731a6895eb67548d5a58417bbef9c5199f371ad628632b98150f0f8c, 533eb786a21fa8dbeb8460b38371244cd3c8cc76bb31b470006e7ff14b60ca97, 2151e2bc279066b8f1bb2e00dd2a1dd542b88d22ef520c7e3b487aaa477888c8

翌期への持越しは同経路の次期記録に保存。Aの予定・保育・時間・残高がネイティブ計算を通じて持ち越される。Bの未識別効果は停止しているため、比較方針間で子どもの生物学的状態・観察は同一。これは実証的効果ゼロの証明ではなく未実装である。
