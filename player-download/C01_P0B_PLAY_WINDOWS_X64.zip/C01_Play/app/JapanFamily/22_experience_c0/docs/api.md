# 層・API・保存の設計

`web/`（表示）→ `server.py`（HTTP・セッション）→ `c0/game.py`（希望・観察・区切り）→ `B11.Simulation.advance_to_date` → 既存A18/B11（科学モデル）。`projection.py` は観測と完了した家庭情報だけを日本語へ変換します。表示・GET・保存は科学モデルの乱数を消費しません。

| API | 用途 |
|---|---|
| GET /api/health, /api/catalogue | 起動確認、47都道府県 |
| POST /api/start | prefecture_code, seed, birth_date, conditions, child_name。研究用child_seedや効果係数は指定不可 |
| GET /api/session?sid=…&observer=mother | 観測表示のみ。母のいない家庭は対象外。父は存在するときだけ |
| POST /api/command | sid,revision,command=request/cancel/observe/advance/save。操作種別・人物・値を検査 |
| GET /api/saves / POST /api/load | このサーバーの保存スロット一覧／再開 |

変更APIはJSONと `X-C0-Client: browser-v1`、同一Originを要求します。同じrevisionの重複操作を拒否します。セッションIDは推測困難な32桁の能力トークンです。レスポンスはno-store、静的配信はHTML/JS/CSSの3パスのみです。単一利用者用であり公開サービスの認証機構ではありません。

内部保存はgzip JSON `{payload,sha256}`。payloadは版、開始条件、B11の全payload、希望キュー、期別の養育者ごとの観測、コマンド列、観察のオフセット、revisionを含みます。ファイルモード0600、同一ディレクトリの一時ファイルから置換し、版と内容SHAを確認してB11の正規ロードを呼びます。ハッシュは破損検知であり署名ではありません。

C0ではAの `auto_actions=False` を明示指定します。申請等をプレイヤーが選べるようにする管理方針で、元のA/Bコードや分布係数の変更ではありません。初期の予定・給付資格・仕事の状態までゼロからプレイヤーが作る訳ではありません。通常発達・生活は明示介入がなくても進みます。

月途中出生では、B11の日付APIで次の暦月境界まで進め、最後だけ24か月の誕生日まで進めます。Aの途中月forecastは内部に限り、完了したA会計だけを表示します。A最終期を日割りしたと偽らず、最終途中月は未精算と表示します。保留した希望はAの当該期間開始時に受け渡されます。

最終途中月で出した希望は、親が登録した事実だけを表示し、結果を `deferred`（この期間では未確定）とします。内部forecastの承認・給与・保育を完了した結果として公開しません。

既存DBがある場合は元DBを使います。ない場合のみ `bridge.make_engine` がRegionModel構築時に派生DBを注入します。SQLとサンプラーは元実装そのままです。注入後は元factoryに戻します。サーバーは1スレッドでSQLiteと初期化を扱い、元コードのグローバル名前衝突を避けます。
