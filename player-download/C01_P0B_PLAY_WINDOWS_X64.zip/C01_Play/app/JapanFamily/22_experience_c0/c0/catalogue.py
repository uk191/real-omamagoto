"""Player commands are requests to native A, never direct outcome assignment."""
PREFECTURES = '北海道 青森県 岩手県 宮城県 秋田県 山形県 福島県 茨城県 栃木県 群馬県 埼玉県 千葉県 東京都 神奈川県 新潟県 富山県 石川県 福井県 山梨県 長野県 岐阜県 静岡県 愛知県 三重県 滋賀県 京都府 大阪府 兵庫県 奈良県 和歌山県 鳥取県 島根県 岡山県 広島県 山口県 徳島県 香川県 愛媛県 高知県 福岡県 佐賀県 長崎県 熊本県 大分県 宮崎県 鹿児島県 沖縄県'.split()
PARENT = {'mother': '母', 'father': '父'}
SIGNALS = {
    'crying': ('泣く様子', '泣いていた'),
    'settles_after_comfort': ('慰めた場面', '落ち着く様子があった'),
    'orients_to_unfamiliar_object': ('見慣れない物への反応', '物へ注意を向けた'),
    'looks_toward_voice': ('声への反応', '声の方を見た'),
    'difficulty_settling': ('寝つく場面', '落ち着きにくい様子があった'),
    'takes_independent_steps': ('足を運ぶ姿', 'ひとりで足を運んだ'),
    'uses_contextual_word': ('ことばの記録', '場面に合うことばがあった'),
    'sustains_object_attention': ('物への注意', '物へ注意を向け続けた'),
    'withdraws_from_intense_stimulus': ('強い刺激への反応', '刺激から身を引いた'),
    'explores_available_space': ('周囲への関心', '周囲を探索する様子があった'),
}
EMPLOYMENT = {
    'working': '働いている', 'outside_labour_force': '現在は仕事をしていない',
    'job_search': '仕事を探している', 'unemployed': '仕事を探している',
    'job_attached_zero_work_unpaid': '雇用先との関係は継続・実働と賃金は0',
    'maternity': '産後休業の期間', 'parental_leave': '育児休業中',
    'paid_leave': '有給の休業', 'maternity_leave': '産後休業中',
    'nonemployed': '現在は仕事をしていない', 'unpaid_care_interruption': '育児のため実働を休止',
}
CARE = {'home': '家庭で過ごす', 'pending': '保育の申請を審査待ち',
        'enrolled': '保育を利用中', 'waiting': '保育の調整待ち',
        'needs_eligibility_review': '保育の利用条件を再確認', 'rejected': '今回の申請は利用に至らず',
        'not_admitted': '保育の申請は今回の調整では入園に至らず'}
OUTCOME = {'accepted': '受け付けられた', 'submitted': '申請・相談を提出した',
           'scheduled': '希望時期を登録した', 'accepted_conditional': '条件付きで受け付けられた',
           'needs_evidence': '確認資料が必要', 'needs_eligibility_evidence': '利用条件の確認が必要',
           'needs_decision': 'さらに判断が必要', 'needs_data': '現在のモデルでは条件を確認できない',
           'rejected': '今回は受け付けられなかった', 'denied': '希望は認められなかった',
           'unavailable': '今回は支援を得られなかった', 'available': '支援を得られる条件だった',
           'unchanged': '現在の条件が続く', 'pending': '返答待ち',
           'unidentified_or_ineligible': '資格を確認できない'}
ACTIONS = {
 'apply_child_allowance': ('児童手当の手続きをする', '申請と承認、実際の入金は別に進みます。', 'procedures'),
 'apply_childcare': ('保育の利用を申し込む', '就業などの利用条件と、保育の受入れ条件を確認します。入園は確約されません。', 'care'),
 'request_relative_support': ('身近な人に支援を相談する', '親族等の支援を得られるか確認します。祖父母個人の能力・予定を再現したものではありません。', 'care'),
 'end_relative_support': ('支援の利用を終える', '親族等へ依頼している保育枠を終了します。', 'care'),
 'take_leave': ('育児休業を希望する', '雇用契約や時期の条件があり、給付の資格とは別に扱います。', 'work'),
 'request_return': ('復職の希望時期を伝える', '希望は登録できますが、産後休業や保育、雇用先の条件で実働が変わります。', 'work'),
 'request_hours': ('勤務時間の調整を相談する', '希望が認められるかは雇用先の応答を経ます。実働が希望通りになる保証はありません。', 'work'),
 'extend_leave': ('育児休業の延長を相談する', '時期と必要資料の確認があります。保育の結果だけで自動的に延長は成立しません。', 'work'),
 'job_search': ('仕事を探し始める', '求人の提案と、採用・受諾は別です。仕事が必ず見つかる操作ではありません。', 'work'),
 'accept_job_offer': ('届いた仕事の提案を受ける', '現在届いている提案だけを受諾できます。', 'work'),
 'reject_job_offer': ('届いた仕事の提案を見送る', '提案を見送ります。', 'work'),
 'quit': ('今の仕事を辞める希望を出す', '以後の契約・給与に関わる選択です。', 'work'),
 'set_spending': ('調整できる生活費を見直す', '家賃等の保護された費目はそのまま。子どもの能力や愛着の加点にはつながりません。', 'budget'),
 'set_liquidity_policy': ('支払いに使う資産の方針を選ぶ', '預金・有価証券等を現金へ振り替える方針です。収入が増えたことにはしません。', 'budget'),
}
CHILD_ACTIONS = {'observe': ('少しそばで見てみる', 'この場面で気づいた様子を記録します。'),
                 'shared_play': ('一緒に過ごす場面を記録', '一緒に過ごした場面の反応を観察します。'),
                 'offer_comfort': ('なだめる場面を記録', 'その場面で見られた反応を記録します。')}
PAUSES = {
 'cash_shortage': ('支払いを確認したい', '期限の来た支払いに不足が出ています。支出・資産の方針を確認できます。'),
 'care_work_conflict': ('仕事と保育の時間を相談したい', '希望する就業時間と、利用できる保育枠が両立していません。'),
 'leave_plan_exceeds_evidenced_entitlement': ('休業の扱いを確認したい', '希望の休業期間を支える条件が確認できていません。無給のまま雇用関係が続く扱いは未検証です。'),
 'care_eligibility_review': ('保育の利用条件を確認したい', '利用条件や手続きについて、あらためて確認が必要です。'),
 'job_offer_proposed': ('仕事の提案が届いた', '受けるか、見送るかを選べます。'),
 'within_city_rental_offer': ('住居の提案が届いた', '転居の費用や契約には未実装の部分があります。'),
}
