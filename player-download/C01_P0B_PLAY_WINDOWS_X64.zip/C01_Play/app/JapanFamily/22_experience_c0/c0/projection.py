"""Pure whitelisted facts -> Japanese text. No free-form generative narrative."""
import datetime as dt
from .bridge import digest
from .catalogue import PARENT, SIGNALS, EMPLOYMENT, CARE, ACTIONS, OUTCOME, PAUSES


def fact(key, text, source, value, evidence='simulated_household_assumption'):
    return {'id': key, 'text': text, 'source_ref': source,
            'value_sha256': digest(value), 'evidence': evidence}


def child_record(core, observer, offset=0):
    global_id = core.identity['person_links'][observer]
    public = core.child.player_view(global_id)
    before, reports = public['observations'][:offset], public['observations'][offset:]
    cards, notices = [], []
    for key, (title, phrase) in SIGNALS.items():
        indexed = [(i + offset, r) for i, r in enumerate(reports) if key in r['behaviors']]
        if not indexed:
            continue
        positive = sum(r['behaviors'][key] for i, r in indexed)
        text = f'記録した{len(indexed)}場面のうち、{positive}場面で{phrase}。'
        item = fact('child/' + key, text, 'B.player_view.observations',
                    [r for i, r in indexed], 'uncalibrated_behavior_and_observation')
        item.update(signal=key, title=title, present=positive, sampled=len(indexed),
                    sources=[{'observation_index': i, 'date': r['date'],
                              'sha256': digest(r), 'source': r['source']} for i, r in indexed])
        cards.append(item)
        if (key in ['takes_independent_steps', 'uses_contextual_word'] and positive
                and not any(r['behaviors'].get(key) for r in before)):
            notices.append(f'{title}が、{PARENT[observer]}の記録に初めて残りました。')
    return {'child_id': public['child_id'], 'observer': observer, 'cards': cards,
            'notices': notices, 'observations': reports, 'measurements': public['measurements'],
            'report_count': len(reports), 'total_reports': len(public['observations']),
            'sampling_note': '記録できた場面の様子です。観察のなかった時間や、子どもの内面まではわかりません。'}


def household_record(core):
    a = core.a
    row = a.get('last_month')
    region = a.get('region_context') or {}
    parents = []
    for who, p in a['parents'].items():
        measurement = p.get('employment_measurement') or {}
        status = measurement.get('status', p['state'])
        hours = p.get('actual_weekly_hours')
        parents.append({'id': who, 'name': PARENT[who],
                        'status': EMPLOYMENT.get(status, '仕事・休業の状況を確認中'),
                        'status_code': status, 'weekly_hours': hours,
                        'normal_annual_reference': p['normal_annual'],
                        'requested_return_month': p['return_month'] if p['leave_requested'] else None,
                        'contract_active': bool(p.get('contract_active')),
                        'job_offer': ({'id': p['job_offer']['id'],
                                       'normal_annual': p['job_offer']['normal_annual'],
                                       'normal_weekly_hours': p['job_offer']['normal_weekly_hours']}
                                      if p.get('job_offer') else None),
                        'source_ref': f'A.completed.parents.{who}',
                        'evidence': 'unverified_employment_path' if status == 'job_attached_zero_work_unpaid' else 'simulated_household_assumption'})
    people = [{'id': x['person_id'], 'role': x['role'], 'age_years': x.get('age_years')}
              for x in a['persons'] if x.get('co_resident') is True]
    budget = {'cash_yen': a['accounts'].get('cash', 0), 'period': None,
              'consumption_yen': None, 'rent_yen': None, 'care_charge_yen': None,
              'wages_gross_yen': None, 'unpaid_due_yen': None,
              'spending_factor': a['spending_factor'], 'source_ref': 'A.completed.accounts',
              'evidence': 'unvalidated_cashflow_and_joint_distribution'}
    time = None
    if row:
        budget.update(period={'start': row['month'], 'end_exclusive': a['month']},
                      consumption_yen=row['consumption'], rent_yen=row['rent'],
                      care_charge_yen=(row['care_fee'] or {}).get('cash_charge', 0),
                      wages_gross_yen=row['actual_earned_gross'],
                      unpaid_due_yen=row['ledger']['unpaid_due'] + row['ledger']['unpaid_principal_due'])
        time = {'parents': {who: {k: v[k] for k in ['work', 'commute', 'active_care', 'rest']}
                            for who, v in row['time']['parents'].items()},
                'nursery': row['time']['nursery'], 'relative': row['time']['relative'],
                'kind': 'weekly_reference_allocation_not_measured_time',
                'source_ref': 'A.completed.time'}
    return {'household_id': a['household']['household_id'],
            'prefecture_code': a['household']['prefecture_code'],
            'municipality': region.get('municipality_name', '地域名未取得'),
            'family_size': len(people), 'people': people, 'parents': parents,
            'care': {'status': CARE.get(a['care']['status'], '保育の条件を調整中'),
                     'status_code': a['care']['status'],
                     'relative_requested': a['care']['relative_requested'],
                     'relative_confirmed': a['care']['relative_confirmed'],
                     'application_submitted': a['care']['application'] is not None},
            'budget': budget, 'time': time,
            'accounting_through': a['month'],
            'partial_month_unsettled': core.child._state['as_of_date'] != a['month']}


def decision_records(periods):
    records = []
    for period in periods:
        for d in period['A_decisions']:
            kind = d['requested_action']
            if kind not in ACTIONS:
                continue
            records.append(fact('decision/' + d['action_id'],
                                f'{ACTIONS[kind][0]}：{OUTCOME.get(d["outcome"], "条件を確認中")}。',
                                'A.completed.A_decisions/' + d['action_id'], d,
                                'native_action_feasibility_scenario') | {
                                    'kind': kind, 'outcome': d['outcome'],
                                    'request_id': d['request'].get('id'),
                                    'person': d['request'].get('person'),
                                    'requested_value': d['request'].get('value')})
    return records


def pauses(core):
    out = []
    for i, item in enumerate(core.a.get('pending_decisions', [])):
        title, text = PAUSES.get(item['type'], ('家族で確認したいこと', '生活の条件について、あらためて確認が必要です。'))
        out.append(fact(f'pause/{i}', text, f'A.pending_decisions/{i}', item,
                        'unverified_household_path') | {
                            'title': title, 'kind': item['type'],
                            'amount_yen': item.get('amount')})
    return out
