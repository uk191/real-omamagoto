"""Decision / turn layer. Calls native calendar API; does not replace A or B."""
import copy
import datetime as dt
import gzip
import json
import math
import os
import tempfile
from pathlib import Path
from . import VERSION
from .bridge import Simulation, ConfiguredEngine, B_VERSION, PARAMETER_HASH, anniversary, digest
from .catalogue import ACTIONS, CHILD_ACTIONS, PARENT
from .projection import child_record, household_record, decision_records, pauses, fact


class ReviewRequired(ValueError):
    pass


class Game:
    @classmethod
    def start(cls, engine, *, prefecture_code='13', seed=0, birth_date='2026-10-01',
              conditions=None, child_name='子ども', child_seed=None, research_scenario=None):
        if not isinstance(child_name, str) or not 1 <= len(child_name.strip()) <= 24:
            raise ValueError('呼び名は1〜24文字で入力してください。')
        scenario = {'auto_actions': False, **(research_scenario or {})}
        obj = cls()
        obj.core = Simulation.initialize(prefecture_code, seed=seed, birth_date=birth_date,
                                        conditions=conditions, child_seed=child_seed,
                                        engine=ConfiguredEngine(engine, scenario))
        # The engine's step already carries all configuration in A state.
        obj.core.engine = engine
        obj.config = {'prefecture_code': prefecture_code, 'seed': seed,
                      'birth_date': birth_date, 'conditions': copy.deepcopy(conditions or {}),
                      'child_name': child_name.strip(), 'child_seed': child_seed,
                      'research_scenario': scenario}
        obj.queue = []
        obj.turns = []
        obj.commands = []
        obj.report_offsets = {p: 0 for p in obj.core.identity['caregiver_local_ids']}
        obj.child_actions_this_turn = []
        obj.revision = 0
        return obj

    def clone(self):
        obj = copy.copy(self)
        obj.core = self.core.clone()
        for key in ['queue', 'commands', 'turns', 'report_offsets', 'child_actions_this_turn']:
            setattr(obj, key, copy.deepcopy(getattr(self, key)))
        return obj

    @property
    def finished(self):
        b = dt.date.fromisoformat(self.config['birth_date'])
        return self.core.child._state['as_of_date'] == anniversary(b, 24).isoformat()

    def check_revision(self, revision):
        if type(revision) is not int or revision != self.revision:
            raise ValueError('表示の更新が必要です。同じ操作を重ねず、最新の記録を読み直してください。')

    def request(self, kind, *, person=None, value=None):
        if self.finished:
            raise ValueError('24か月の体験を終えています。')
        if kind not in ACTIONS:
            raise ValueError('この体験版では選べない操作です。')
        cgs = self.core.identity['caregiver_local_ids']
        if person is not None and person not in cgs:
            raise ValueError('この家庭の養育者を指定してください。')
        if kind in ['take_leave', 'request_return', 'request_hours', 'extend_leave', 'job_search',
                    'accept_job_offer', 'reject_job_offer', 'quit'] and person not in cgs:
            raise ValueError('希望を出す養育者を選んでください。')
        n = self.core.a['elapsed_months']
        if kind == 'request_return' and (type(value) is not int or not n <= value <= 24):
            raise ValueError('復職の希望は、今期以降・24か月までで指定してください。')
        if kind == 'request_hours' and (type(value) not in [int, float] or not math.isfinite(value) or not 0 < value <= 1):
            raise ValueError('勤務時間の希望割合を選んでください。')
        if kind == 'set_spending' and (type(value) not in [int, float] or not math.isfinite(value) or not .5 <= value <= 1.5):
            raise ValueError('生活費の調整は0.5〜1.5の範囲で選んでください。')
        if kind == 'set_liquidity_policy' and value not in ['cash_only', 'use_term', 'use_securities']:
            raise ValueError('支払いの方針を選んでください。')
        if kind == 'extend_leave' and value not in [18, 24]:
            raise ValueError('延長の相談時期を選んでください。')
        if kind in ['accept_job_offer', 'reject_job_offer']:
            offer = self.core.a['parents'][person].get('job_offer')
            if not offer or value != offer['id']:
                raise ValueError('現在届いている仕事の提案だけを選べます。')
        if kind in ['apply_childcare', 'apply_child_allowance', 'request_relative_support', 'end_relative_support',
                    'take_leave', 'job_search', 'quit'] and value is not None:
            raise ValueError('この希望には値を指定できません。')
        if len(self.queue) >= 8 or any(a['type'] == kind and a.get('person') == person for a in self.queue):
            raise ValueError('同じ希望は今期に1回だけ登録できます。変更するときは取り消してください。')
        action = {'type': kind, 'id': f'c0-{len(self.commands):04d}'}
        if person is not None:
            action['person'] = person
        if value is not None:
            action['value'] = value
        self.queue.append(action)
        self.commands.append({'type': 'request', 'date': self.core.child._state['as_of_date'],
                              'action': copy.deepcopy(action)})
        self.revision += 1
        return self

    def cancel(self, request_id):
        matching = [x for x in self.queue if x['id'] == request_id]
        if not matching:
            raise ValueError('取り消す希望が見つかりません。')
        self.queue = [x for x in self.queue if x['id'] != request_id]
        self.commands.append({'type': 'cancel', 'request_id': request_id})
        self.revision += 1

    def observe(self, kind, observer='mother'):
        if self.finished:
            raise ValueError('24か月の体験を終えています。')
        if kind not in CHILD_ACTIONS or observer not in self.core.identity['caregiver_local_ids']:
            raise ValueError('この家庭で選べる観察を指定してください。')
        key = observer + '/' + kind
        if key in self.child_actions_this_turn:
            raise ValueError('この期間はすでに記録しました。次の期間にも様子を見てみましょう。')
        obj = self.clone()
        obj.core.child.act(kind, caregiver_id=obj.core.identity['person_links'][observer], scenario_effects=False)
        obj.child_actions_this_turn.append(key)
        obj.commands.append({'type': 'child_action', 'kind': kind, 'observer': observer,
                             'date': obj.core.child._state['as_of_date']})
        obj.revision += 1
        self.__dict__.update(obj.__dict__)
        return self

    def advance(self, *, reviewed=False, observer='mother'):
        if type(reviewed) is not bool:
            raise ValueError('確認は真偽値で指定してください。')
        if observer not in self.core.identity['caregiver_local_ids']:
            raise ValueError('この家庭の養育者を指定してください。')
        if self.finished:
            raise ValueError('24か月の体験を終えています。')
        if self.core.a.get('pending_decisions') and not reviewed:
            raise ReviewRequired('家族で確認したいことがあります。内容を確認してから進めてください。')
        obj = self.clone()
        start = obj.core.child._state['as_of_date']
        old_periods = len(obj.core.a_periods)
        next_boundary = dt.date.fromisoformat(obj.core.a['month'])
        next_boundary = next_boundary.replace(year=next_boundary.year + (next_boundary.month == 12),
                                              month=next_boundary.month % 12 + 1)
        target = min(next_boundary, anniversary(dt.date.fromisoformat(obj.config['birth_date']), 24))
        obj.core.advance_to_date(target.isoformat(), a_actions=obj.queue,
                                 research_continue=reviewed, scenario_effects=False)
        periods = obj.core.a_periods[old_periods:]
        views = {}
        for cg in obj.core.identity['caregiver_local_ids']:
            child = child_record(obj.core, cg, obj.report_offsets[cg])
            views[cg] = {'child': child, 'household': household_record(obj.core)}
            obj.report_offsets[cg] = child['total_reports']
        decisions = decision_records(periods)
        if not periods and obj.queue:
            # Final partial calendar period: the native private forecast must not
            # be shown as an already completed outcome at the 24-month birthday.
            decisions = [fact('decision/' + a['id'],
                              ACTIONS[a['type']][0] + '：最終途中月の希望として記録しました。結果はこの体験期間では未確定です。',
                              'C0.requested_unsettled/' + a['id'], a,
                              'unsettled_final_calendar_period') | {
                                  'kind': a['type'], 'outcome': 'deferred',
                                  'request_id': a['id'], 'person': a.get('person'),
                                  'requested_value': a.get('value')} for a in obj.queue]
        obj.turns.append({'turn': len(obj.turns) + 1, 'start': start, 'end': target.isoformat(),
                          'age_days': obj.core.child._state['age_days'],
                          'age_months': obj.core.elapsed_months, 'views': views,
                          'decisions': decisions, 'pauses': pauses(obj.core),
                          'requested_actions': copy.deepcopy(obj.queue),
                          'reviewed_unresolved': reviewed,
                          'core_sha256': digest(obj.core.payload())})
        obj.commands.append({'type': 'advance', 'reviewed': reviewed, 'observer': observer,
                             'start': start, 'end': target.isoformat()})
        obj.queue = []
        obj.child_actions_this_turn = []
        obj.revision += 1
        self.__dict__.update(obj.__dict__)
        self.core.assert_consistent()
        return self

    def advance_many(self, count, *, reviewed=False, observer='mother'):
        if type(count) is not int or not 1 <= count <= 3:
            raise ValueError('1〜3期を指定してください。')
        done = 0
        while done < count and not self.finished:
            self.advance(reviewed=reviewed if done == 0 else False, observer=observer)
            done += 1
            turn = self.turns[-1]
            if turn['pauses'] or turn['views'][observer]['child']['notices']:
                break
            if any(p.get('job_offer') for p in self.core.a['parents'].values()):
                break
        return done

    def view(self, observer='mother'):
        if observer not in self.core.identity['caregiver_local_ids']:
            raise PermissionError('この家庭の養育者ではありません。')
        current = child_record(self.core, observer, self.report_offsets[observer])
        using_last = not current['report_count'] and bool(self.turns)
        child = copy.deepcopy(self.turns[-1]['views'][observer]['child']) if using_last else current
        s = self.core.child._state
        queued = [{'id': a['id'], 'kind': a['type'], 'label': ACTIONS[a['type']][0],
                   'person': PARENT.get(a.get('person')), 'value': a.get('value')}
                  for a in self.queue]
        return {'version': VERSION, 'revision': self.revision,
                'child_name': self.config['child_name'], 'date': s['as_of_date'],
                'birth_date': self.config['birth_date'], 'age_months': s['elapsed_months'],
                'age_days': s['age_days'], 'finished': self.finished,
                'observer': observer, 'observers': self.core.identity['caregiver_local_ids'],
                'household': household_record(self.core), 'child': child,
                'record_period': ({'start': self.turns[-1]['start'], 'end': self.turns[-1]['end']}
                                  if using_last else {'start': s['as_of_date'], 'end': s['as_of_date']}),
                'queued_requests': queued, 'pauses': pauses(self.core),
                'decisions': copy.deepcopy(self.turns[-1]['decisions']) if self.turns else [],
                'album': [{'turn': r['turn'], 'start': r['start'], 'end': r['end'],
                           'age_months': r['age_months'],
                           'report_count': r['views'][observer]['child']['report_count'],
                           'notices': r['views'][observer]['child']['notices'],
                           'child': r['views'][observer]['child'],
                           'decisions': r['decisions']} for r in self.turns],
                'actions': [{'kind': k, 'label': v[0], 'description': v[1], 'group': v[2]}
                            for k, v in ACTIONS.items()],
                'child_actions': [{'kind': k, 'label': v[0], 'description': v[1],
                                   'used': observer + '/' + k in self.child_actions_this_turn}
                                  for k, v in CHILD_ACTIONS.items()],
                'limits': {'label': '研究モデルを使った体験版',
                           'child_effects': '関わりは観察の機会として記録します。能力や愛着への長期的な効果は、この版では計算しません。',
                           'household': '就業・保育・税・家計は未検証の条件を含みます。実際の制度利用や入園・就業を保証する計算ではありません。',
                           'observation': '行動と観察誤差の数値は未校正です。性格や発達の診断には使えません。',
                           'scope': '2026年出生・単胎・37〜41週の参照条件で、24か月までを体験します。'},
                'timeline_count': len(self.turns)}

    def snapshot(self):
        return {'version': VERSION, 'configuration': copy.deepcopy(self.config),
                'core': self.core.payload(), 'queue': copy.deepcopy(self.queue),
                'turns': copy.deepcopy(self.turns), 'commands': copy.deepcopy(self.commands),
                'report_offsets': copy.deepcopy(self.report_offsets),
                'child_actions_this_turn': list(self.child_actions_this_turn), 'revision': self.revision}

    def save(self, path):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        body = self.snapshot()
        envelope = {'payload': body, 'sha256': digest(body)}
        temp = path.with_suffix(path.suffix + '.tmp')
        with gzip.open(temp, 'wt', encoding='utf-8') as f:
            json.dump(envelope, f, ensure_ascii=False, sort_keys=True, allow_nan=False)
        os.chmod(temp, 0o600)
        temp.replace(path)
        return envelope['sha256']

    @classmethod
    def load(cls, path, engine):
        with gzip.open(path, 'rt', encoding='utf-8') as f:
            env = json.load(f)
        body = env['payload']
        if body['version'] != VERSION or digest(body) != env['sha256']:
            raise ValueError('保存記録の版・ハッシュが一致しません。')
        core_env = {'model_version': B_VERSION, 'parameter_sha256': PARAMETER_HASH,
                    'payload': body['core'], 'sha256': digest(body['core'])}
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'core.json'
            p.write_text(json.dumps(core_env, ensure_ascii=False, allow_nan=False))
            core = Simulation.load(p, engine=engine)
        obj = cls()
        obj.core, obj.config = core, body['configuration']
        for key in ['queue', 'turns', 'commands', 'report_offsets', 'child_actions_this_turn', 'revision']:
            setattr(obj, key, body[key])
        return obj
