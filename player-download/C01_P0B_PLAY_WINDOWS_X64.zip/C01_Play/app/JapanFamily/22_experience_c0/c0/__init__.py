"""C-0 player layer over pinned A3.0-0.2 and B-1.1; no scientific coefficient changes."""
VERSION = 'C-0.1-experience'
