"""Use original kernels verbatim; optionally inject a lossless SQL projection."""
import functools
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
sys.path.insert(0, str(PROJECT / '21_child_b11'))
from child_b11.integrated import Simulation, a18_engine_class
from child_b11.engine import Child, VERSION as B_VERSION, PARAMETER_HASH, anniversary, digest


def make_engine(runtime_db=None):
    cls = a18_engine_class()
    original = PROJECT / 'data/region.sqlite'
    if runtime_db is None and original.exists():
        return cls()
    path = Path(runtime_db or ROOT / 'data/runtime_region.sqlite')
    if not path.is_file():
        raise FileNotFoundError('既存の地域DBまたはC0_RUNTIME_DATAパックが必要です。')
    # Constructor injection only, restored before serving requests. All actual
    # RegionModel queries and weights remain the unchanged original functions.
    import family
    region_class = family.RegionModel
    family.RegionModel = lambda ignored_db=None: region_class(str(path))
    try:
        return cls()
    finally:
        family.RegionModel = region_class


class ConfiguredEngine:
    """Pass explicit C0 administrative policy to the original A initializer."""
    def __init__(self, engine, scenario):
        self.engine, self.scenario = engine, dict(scenario)

    def initialize(self, pref, conditions, seed, birth, scenario, include_region, initial_family):
        return self.engine.initialize(pref, conditions, seed, birth,
                                      {**self.scenario, **(scenario or {})},
                                      include_region, initial_family)

    def step(self, *args, **kwargs):
        return self.engine.step(*args, **kwargs)
