'use strict';
const $ = id => document.getElementById(id);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const yen = x => x == null ? '未精算' : new Intl.NumberFormat('ja-JP').format(x);
const date = x => {const [y,m,d] = x.split('-'); return `${y}年${Number(m)}月${Number(d)}日`;};
let sid = localStorage.getItem('c0.session') || '', view = null, busy = false, observer = 'mother';
let toastTimer;
function message(text, error = false) { $('notice').textContent = text; $('notice').className = 'toast' + (error ? ' error-toast' : ''); $('notice').hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => {$('notice').hidden = true;}, error ? 9000 : 5000); }
async function api(path, body) {
  const options = body ? {method:'POST',headers:{'Content-Type':'application/json','X-C0-Client':'browser-v1'},body:JSON.stringify(body)} : {};
  const r = await fetch(path, options); const data = await r.json();
  if (!r.ok) { const e = new Error(data.error || '通信を確認してください。'); e.status = r.status; e.needsReview = data.needs_review; throw e; }
  return data;
}
function setBusy(value) {busy = value; document.querySelectorAll('button').forEach(b => {if(value) {b.dataset.wasDisabled = b.disabled ? 'yes' : 'no'; b.disabled = true;} else if(b.dataset.wasDisabled) {b.disabled = b.dataset.wasDisabled === 'yes'; delete b.dataset.wasDisabled;}});document.body.setAttribute('aria-busy', String(value));}
async function command(command, extra = {}) {
  if (busy || !view) return;
  setBusy(true);
  try {
    const data = await api('/api/command', {sid, revision:view.revision, command, observer,...extra});
    if(data.view) {view = data.view; render();}
    if (data.saved) {$('save-state').textContent = `${date(data.saved.date)}の記録を保存しました。`; message('ここまでの家族の記録を保存しました。');}
    if (data.periods_advanced) {$('reviewed').checked = false; message(view.finished ? '24か月の記録が残りました。アルバムで振り返れます。' : `${data.periods_advanced}期の記録が増えました。`);}
    return data;
  } catch (e) {message(e.message,true); if(e.needsReview) {$('review-label').hidden = false; $('review-label').scrollIntoView({behavior:'smooth',block:'center'});} }
  finally {setBusy(false); if(view) applyDisabled();}
}
function tab(name) {document.querySelectorAll('[data-tab]').forEach(b => {b.classList.toggle('active',b.dataset.tab===name);b.setAttribute('aria-selected',String(b.dataset.tab===name));});document.querySelectorAll('.tab-panel').forEach(p => p.hidden=p.id !== `tab-${name}`);}
function card(c) {
 const source = c.sources.map(x => `${x.date} · 観察#${x.observation_index} · ${x.sha256}`).join('\n');
 return `<article class="observation-card"><p class="card-kicker">${esc(c.title)}</p><h3>${esc(c.present ? c.text.split('、')[1] : 'この記録では、まだ見られず。')}</h3><p>${esc(c.sampled)}場面を記録 · うち${esc(c.present)}場面で観察</p><details class="card-source"><summary>記録のもと</summary><p>観察者の報告。行動・観察誤差のモデルは未校正です。</p><code>${esc(source)}</code></details></article>`;
}
function nextDate() {if(view.finished)return view.date; const x = view.date.split('-').map(Number); let y=x[0],m=x[1]+1; if(m>12){y++;m=1;}const next=`${y}-${String(m).padStart(2,'0')}-01`;const end=`2028-${view.birth_date.slice(5)}`;return next<end?next:end;}
function render() {
 $('welcome').hidden=true;$('game').hidden=false;$('new-game').hidden=false;observer=view.observer;
 $('child-name').textContent=view.child_name;$('place').textContent=`${view.household.municipality}で暮らす · 同居する家族 ${view.household.family_size}人`;
 $('age-months').textContent=view.age_months;$('age-days').textContent=`生まれて${view.age_days}日`;$('date-label').textContent=`${date(view.date)}　／　${date(view.birth_date)} 生まれ`;
 $('timeline').innerHTML='<span class="endpoint">誕生</span>'+Array.from({length:24},(_,i)=>`<span class="tick ${i<view.age_months?'filled':''} ${i===view.age_months?'current':''}"></span>`).join('')+'<span class="endpoint">24か月</span>';
 const c=view.child;
 $('child-headline').textContent=view.finished?'この家族の、24か月が残った。':c.notices[0]||(!c.report_count?'まずは、そばで見てみよう。':'見ていたから、気づいたこと。');
 $('child-caption').textContent=!c.report_count?'少しそばで見てみると、いまの様子を記録できます。進めるだけでも、生活の中で観察は増えていきます。':`${observer==='mother'?'母':'父'}が観察できた${c.report_count}件の記録から。見えた姿を、ここに残しています。`;
 $('period-label').textContent=view.record_period.start===view.record_period.end?`${date(view.date)} の場面`:`${date(view.record_period.start)} — ${date(view.record_period.end)}`;
 $('child-notices').innerHTML=c.notices.map(x=>`<p>${esc(x)}</p>`).join('');
 const priority=['takes_independent_steps','uses_contextual_word','looks_toward_voice','orients_to_unfamiliar_object','difficulty_settling','explores_available_space'];
 const cards=[...c.cards].sort((a,b)=>{const pa=priority.indexOf(a.signal),pb=priority.indexOf(b.signal);return (pa<0?20:pa)+(a.present?0:10)-((pb<0?20:pb)+(b.present?0:10));});
 $('child-cards').innerHTML=cards.slice(0,4).map(card).join('');$('extra-child-cards').innerHTML=cards.slice(4).map(card).join('');$('extra-records').hidden=cards.length<=4;
 $('child-actions').innerHTML=view.child_actions.map(a=>`<button class="secondary" data-observe="${esc(a.kind)}" ${a.used||view.finished?'disabled':''}>${esc(a.used?'この期間は記録済み':a.label)}</button>`).join('');
 $('child-effect-note').textContent=view.limits.child_effects;
 const h=view.household;
 $('parents').innerHTML=h.parents.map(p=>`<div class="parent"><p><strong>${esc(p.name)}</strong>${esc(p.status)}</p><p class="fine">${p.weekly_hours==null?'通常時の仕事を参照して開始':`実働の参照配分：週${esc(p.weekly_hours)}時間`} · 通常時年収（参照）：${yen(p.normal_annual_reference)}円</p>${p.status_code==='job_attached_zero_work_unpaid'?'<p class="fine">雇用関係が継続するこの経路は未検証です。復職・保育等の条件を確認できます。</p>':''}${p.job_offer?`<p class="context-hint">仕事の提案：通常年収${yen(p.job_offer.normal_annual)}円、週${esc(p.job_offer.normal_weekly_hours)}時間。受諾は別の選択です。</p>`:''}</div>`).join('');
 $('care-state').innerHTML=`${esc(h.care.status)}<small>${h.care.relative_confirmed?'親族等の支援を利用する条件になっています。':h.care.relative_requested?'支援を相談しましたが、今回は利用する条件に至っていません。':'親族等の支援は、まだ利用を依頼していません。'}</small>`;
 $('time-budget').innerHTML=h.time?`<p class="fine">1週あたりの参照配分。実測の生活日誌ではありません。</p>`+Object.entries(h.time.parents).map(([who,t])=>`<div class="time-row">${who==='mother'?'母':'父'}：仕事${esc(t.work)}h・通勤${esc(t.commute)}h・保育枠${esc(t.active_care)}h・休息枠${esc(t.rest)}h</div>`).join(''):'';
 const b=h.budget;$('accounting-period').textContent=b.period?`${date(b.period.start)} — ${date(b.period.end_exclusive)} の計算。${h.partial_month_unsettled?'現在の月の途中分は未精算です。':''}`:'開始時の家計設定。出生直後の現実の残高を観測した値ではありません。';
 $('budget').innerHTML=[['手元の現金',b.cash_yen],['期限の来た支払いの不足',b.unpaid_due_yen],['給与額面（この計算期間）',b.wages_gross_yen],['生活消費',b.consumption_yen],['住居費',b.rent_yen],['保育料の現金負担',b.care_charge_yen]].map(([l,x])=>`<div class="budget-item"><span>${esc(l)}</span><strong>${yen(x)}</strong><small>${x==null?'':' 円'}</small></div>`).join('');
 $('pause-items').innerHTML=view.pauses.map(p=>`<div class="pause"><strong>${esc(p.title)}</strong><p>${esc(p.text)}${p.amount_yen?`（${yen(p.amount_yen)}円）`:''}</p></div>`).join('');$('review-label').hidden=view.finished||!view.pauses.length;
 $('next-title').textContent=view.finished?'24か月を、振り返る。':view.pauses.length?'一度、立ち止まって。':'家族のペースで。';
 $('advance').innerHTML=view.finished?'家族のアルバムへ':`${Number(nextDate().slice(5,7))}月${Number(nextDate().slice(8,10))}日まで進める <span>→</span>`;
 $('context-prompts').innerHTML=(!view.timeline_count?'<p class="context-hint">児童手当の手続きは、まだ申請していません。</p>':'')+(h.parents.some(p=>p.job_offer)?'<p class="context-hint">届いた仕事の提案を受けるか、相談できます。</p>':'');
 const oldKind=$('action-kind').value;$('action-kind').innerHTML=view.actions.map(a=>`<option value="${esc(a.kind)}">${esc(a.label)}</option>`).join('');if(view.actions.some(a=>a.kind===oldKind))$('action-kind').value=oldKind;
 $('action-person').innerHTML=view.observers.map(x=>`<option value="${x}">${x==='mother'?'母':'父'}</option>`).join('');
 $('action-person').value=observer;
 $('observer').innerHTML=view.observers.map(x=>`<option value="${x}" ${x===observer?'selected':''}>${x==='mother'?'母':'父'}が気づいた記録</option>`).join('');
 actionFields();
 $('queued-requests').innerHTML=view.queued_requests.map(r=>`<div class="queue-item"><span class="tag">希望・未処理</span><p>${esc(r.person?r.person+'：':'')}${esc(r.label)}${r.value==null?'':`<br><small>${esc(requestValue(r.kind,r.value))}</small>`}</p><button class="quiet" data-cancel="${esc(r.id)}">取り消す</button></div>`).join('');
 $('decision-results').hidden=!view.decisions.length;$('decision-items').innerHTML=view.decisions.map(d=>`<div class="decision-item">${esc(d.text)}<p class="fine">実際の入金・就業・入園は、以後の生活記録で確認します。</p><details class="card-source"><summary>記録のもと</summary><code>${esc(d.source_ref)} · ${esc(d.value_sha256)}</code></details></div>`).join('');
 $('album').innerHTML=!view.album.length?'<p class="empty">まだページは白紙です。日々の観察が、ここに残っていきます。</p>':view.album.map(r=>`<details class="album-item"><summary>${esc(date(r.end))} · ${r.age_months}か月　<small>観察${r.report_count}件</small></summary>${r.notices.map(x=>`<p>${esc(x)}</p>`).join('')}${r.child.cards.map(x=>`<p>${esc(x.title)}：${esc(x.text)}</p>`).join('')}${r.decisions.map(x=>`<p>${esc(x.text)}</p>`).join('')}</details>`).join('');
 $('limitations').innerHTML=Object.values(view.limits).map(x=>`<p>${esc(x)}</p>`).join('');applyDisabled();
}
function applyDisabled(){if(!view)return;document.querySelectorAll('[data-observe]').forEach(b=>b.disabled=view.finished||view.child_actions.find(a=>a.kind===b.dataset.observe)?.used);$('queue-action').disabled=view.finished;$('advance-three').disabled=view.finished;$('advance').disabled=false;}
function requestValue(kind,value) {
 if(kind==='request_hours')return `通常時の${Math.round(value*100)}%を希望`;
 if(kind==='set_spending')return `調整できる費目を基準の${Math.round(value*100)}%に`;
 if(kind==='request_return'){const [y,m]=view.birth_date.split('-').map(Number);const t=y*12+m-1+Number(value);return `${Math.floor(t/12)}年${t%12+1}月ごろを希望`;}
 if(kind==='extend_leave')return `${value}か月までの延長を相談`;
 if(kind==='set_liquidity_policy')return {cash_only:'手元の現金だけ',use_term:'定期預金等も使う',use_securities:'有価証券等も使う'}[value]||'選択した支払い方針';
 return '現在の提案を選択';
}
function actionFields() {
 if(!view)return;const k=$('action-kind').value,a=view.actions.find(a=>a.kind===k);$('action-description').textContent=a?.description||'';
 const personal=['take_leave','request_return','request_hours','extend_leave','job_search','accept_job_offer','reject_job_offer','quit'].includes(k);$('person-field').hidden=!personal;
 let values=[];
 if(k==='request_return') values=Array.from({length:Math.min(13,25-view.timeline_count)},(_,i)=>[String(view.timeline_count+i),i===0?'今期からの復職を希望':`${i}期後の復職を希望`]);
 if(k==='request_hours')values=[['1','通常時と同じ時間'],['0.75','通常時の75%を希望'],['0.5','通常時の50%を希望']];
 if(k==='set_spending')values=[['1','基準のまま'],['0.9','調整できる費目を10%減らす'],['0.8','調整できる費目を20%減らす'],['1.1','調整できる費目を10%増やす']];
 if(k==='set_liquidity_policy')values=[['cash_only','手元の現金だけ'],['use_term','定期預金等も振り替える'],['use_securities','有価証券等も振り替える']];
 if(k==='extend_leave')values=[['18','18か月までの延長を相談'],['24','24か月までの延長を相談']];
 if(['accept_job_offer','reject_job_offer'].includes(k)){const p=view.household.parents.find(p=>p.id===$('action-person').value);values=p?.job_offer?[[p.job_offer.id,'現在届いている提案']]:[];}
 $('value-field').hidden=!['request_return','request_hours','set_spending','set_liquidity_policy','extend_leave','accept_job_offer','reject_job_offer'].includes(k);$('action-value').innerHTML=values.map(([v,l])=>`<option value="${esc(v)}">${esc(l)}</option>`).join('');
}
$('start-form').addEventListener('submit',async e=>{e.preventDefault();if(busy)return;setBusy(true);$('start-error').textContent='';try{const f=new FormData(e.target),conditions={};for(const k of ['mother_age','father_age','household_income_yen'])if(f.get(k)!=='')conditions[k]=Number(f.get(k));for(const k of ['mother_employed','father_employed'])if(f.get(k)!=='')conditions[k]=f.get(k)==='true';if(f.get('family')==='mother'){conditions.partner_present=false;conditions.legal_status='nonmarital';delete conditions.father_age;delete conditions.father_employed;}const data=await api('/api/start',{prefecture_code:f.get('prefecture_code'),birth_date:f.get('birth_date'),child_name:f.get('child_name'),seed:f.get('seed'),conditions});sid=data.sid;view=data.view;observer='mother';localStorage.setItem('c0.session',sid);render();window.scrollTo(0,0);}catch(e){$('start-error').textContent=e.message;}finally{setBusy(false);if(view)applyDisabled();}});
$('family-select').addEventListener('change',()=>{const single=$('family-select').value==='mother';$('father-age-label').hidden=single;$('father-work-label').hidden=single;});
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>tab(b.dataset.tab)));
$('child-actions').addEventListener('click',e=>{const b=e.target.closest('[data-observe]');if(b)command('observe',{kind:b.dataset.observe});});
$('queued-requests').addEventListener('click',e=>{const b=e.target.closest('[data-cancel]');if(b)command('cancel',{request_id:b.dataset.cancel});});
$('action-kind').addEventListener('change',actionFields);$('action-person').addEventListener('change',actionFields);
$('queue-action').addEventListener('click',()=>{const k=$('action-kind').value,body={kind:k};if(!$('person-field').hidden)body.person=$('action-person').value;if(!$('value-field').hidden){const raw=$('action-value').value;if(!raw){message('現在、対応する提案は届いていません。',true);return;}body.value=['request_return','request_hours','set_spending','extend_leave'].includes(k)?Number(raw):raw;}command('request',body);});
$('advance').addEventListener('click',()=>{if(view.finished){tab('album');$('album').scrollIntoView({behavior:'smooth'});return;}command('advance',{reviewed:$('reviewed').checked,count:1});});
$('advance-three').addEventListener('click',()=>command('advance',{reviewed:$('reviewed').checked,count:3}));
$('save').addEventListener('click',()=>command('save'));
$('observer').addEventListener('change',async()=>{if(busy)return;try{const data=await api(`/api/session?sid=${sid}&observer=${$('observer').value}`);view=data.view;render();}catch(e){message(e.message,true);}});
$('open-saves').addEventListener('click',async()=>{try{const d=await api('/api/saves');$('saved-list').innerHTML=d.saves.length?d.saves.map(s=>`<div class="saved-item"><div>${esc(s.child_name)}の記録<small>${esc(date(s.date))} · ${s.age_months}か月</small></div><button class="secondary" data-load="${esc(s.slot)}">再開する</button></div>`).join(''):'<p class="empty">まだ保存した記録はありません。</p>';$('saves-dialog').showModal();}catch(e){message(e.message,true);}});
$('close-saves').addEventListener('click',()=>$('saves-dialog').close());
$('saved-list').addEventListener('click',async e=>{const b=e.target.closest('[data-load]');if(!b||busy)return;setBusy(true);try{const d=await api('/api/load',{slot:b.dataset.load});sid=d.sid;view=d.view;localStorage.setItem('c0.session',sid);$('saves-dialog').close();render();window.scrollTo(0,0);message('保存した日から、暮らしを再開しました。');}catch(e){message(e.message,true);}finally{setBusy(false);if(view)applyDisabled();}});
(async()=>{try{const c=await api('/api/catalogue');$('prefecture').innerHTML=c.prefectures.map(p=>`<option value="${p.code}" ${p.code==='13'?'selected':''}>${esc(p.name)}</option>`).join('');if(sid){const d=await api(`/api/session?sid=${sid}&observer=mother`);view=d.view;render();}}catch(e){if(sid){localStorage.removeItem('c0.session');sid='';message('前の実行は終了しています。保存した記録から再開できます。');}else message(e.message,true);}})();

$('new-game').addEventListener('click',async()=>{if(busy)return;const d=await command('save');if(!d)return;view=null;sid='';localStorage.removeItem('c0.session');$('game').hidden=true;$('welcome').hidden=false;$('new-game').hidden=true;window.scrollTo(0,0);message('これまでの家族は保存しました。別の家族を始められます。');});
